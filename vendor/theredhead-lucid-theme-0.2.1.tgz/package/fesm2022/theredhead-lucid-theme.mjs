import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { InjectionToken, inject, DestroyRef, signal, effect, computed, Injectable } from '@angular/core';
import { StorageService } from '@theredhead/lucid-foundation';

/**
 * Default theme configuration
 */
const DEFAULT_THEME_CONFIG = {
    defaultMode: 'system',
    storageKey: 'theredhead-theme-mode',
    darkModeClass: 'dark-theme',
    lightModeClass: 'light-theme',
};
/**
 * Injection token for theme configuration
 */
const THEME_CONFIG = new InjectionToken('THEME_CONFIG', {
    providedIn: 'root',
    factory: () => DEFAULT_THEME_CONFIG,
});

/**
 * Service for managing application theme (light/dark mode).
 *
 * **Note:** This service is optional. If you only include the SCSS theme without
 * injecting this service, the theme will still work correctly:
 * - Light theme applies by default
 * - Dark theme applies automatically via `@media (prefers-color-scheme: dark)`
 * - All Material components are properly themed
 *
 * Use this service when you need:
 * - **User preference persistence** - Saves theme choice to localStorage across sessions
 * - **Explicit theme override** - Let users choose a theme different from system preference
 * - **Reactive state** - Access `isDarkMode()` signal for conditional UI logic
 * - **Theme toggle** - Programmatic control via `toggleTheme()` or `setTheme()`
 *
 * @example
 * ```typescript
 * import { ThemeService } from '@theredhead/lucid-theme';
 *
 * @Component({...})
 * export class AppComponent {
 *   private themeService = inject(ThemeService);
 *
 *   toggleTheme() {
 *     this.themeService.toggleTheme();
 *   }
 * }
 * ```
 */
class ThemeService {
    document = inject(DOCUMENT);
    config = inject(THEME_CONFIG, { optional: true }) ?? DEFAULT_THEME_CONFIG;
    storage = inject(StorageService);
    destroyRef = inject(DestroyRef);
    /** Current theme mode setting (light, dark, or system) */
    _themeMode;
    /** Media query for detecting system dark mode preference */
    darkModeMediaQuery;
    /** Whether the system prefers dark mode */
    _systemPrefersDark;
    onSystemPreferenceChange = (event) => {
        this._systemPrefersDark.set(event.matches);
    };
    constructor() {
        // Initialize media query for system preference
        this.darkModeMediaQuery =
            this.document.defaultView?.matchMedia("(prefers-color-scheme: dark)") ??
                { matches: false };
        this._systemPrefersDark = signal(this.darkModeMediaQuery.matches, ...(ngDevMode ? [{ debugName: "_systemPrefersDark" }] : []));
        // Listen for system preference changes
        if (this.darkModeMediaQuery.addEventListener) {
            this.darkModeMediaQuery.addEventListener("change", this.onSystemPreferenceChange);
            this.destroyRef.onDestroy(() => {
                this.darkModeMediaQuery.removeEventListener("change", this.onSystemPreferenceChange);
            });
        }
        // Initialize theme mode from storage or default
        const storedMode = this.getStoredThemeMode();
        this._themeMode = signal(storedMode ?? this.config.defaultMode, ...(ngDevMode ? [{ debugName: "_themeMode" }] : []));
        // Apply theme whenever mode or system preference changes
        effect(() => {
            this.applyTheme(this.isDarkMode());
        });
    }
    /**
     * Current theme mode setting
     */
    themeMode = computed(() => this._themeMode(), ...(ngDevMode ? [{ debugName: "themeMode" }] : []));
    /**
     * Whether the system prefers dark mode
     */
    systemPrefersDark = computed(() => this._systemPrefersDark(), ...(ngDevMode ? [{ debugName: "systemPrefersDark" }] : []));
    /**
     * Whether dark mode is currently active (resolved from mode + system preference)
     */
    isDarkMode = computed(() => {
        const mode = this._themeMode();
        if (mode === "system") {
            return this._systemPrefersDark();
        }
        return mode === "dark";
    }, ...(ngDevMode ? [{ debugName: "isDarkMode" }] : []));
    /**
     * Whether light mode is currently active
     */
    isLightMode = computed(() => !this.isDarkMode(), ...(ngDevMode ? [{ debugName: "isLightMode" }] : []));
    /**
     * Set the theme mode
     * @param mode - The theme mode to set ('light', 'dark', or 'system')
     */
    setTheme(mode) {
        this._themeMode.set(mode);
        this.persistThemeMode(mode);
    }
    /**
     * Toggle between light and dark mode
     * If currently in system mode, will switch to the opposite of current resolved theme
     */
    toggleTheme() {
        const newMode = this.isDarkMode() ? "light" : "dark";
        this.setTheme(newMode);
    }
    /**
     * Reset to system preference
     */
    resetToSystem() {
        this.setTheme("system");
    }
    /**
     * Apply theme classes to the document
     */
    applyTheme(isDark) {
        const { documentElement } = this.document;
        if (isDark) {
            documentElement.classList.remove(this.config.lightModeClass);
            documentElement.classList.add(this.config.darkModeClass);
        }
        else {
            documentElement.classList.remove(this.config.darkModeClass);
            documentElement.classList.add(this.config.lightModeClass);
        }
    }
    /**
     * Get stored theme mode from localStorage
     */
    getStoredThemeMode() {
        try {
            const stored = this.storage.getItem(this.config.storageKey);
            if (stored && ["light", "dark", "system"].includes(stored)) {
                return stored;
            }
        }
        catch {
            // Storage not available
        }
        return null;
    }
    /**
     * Persist theme mode to storage
     */
    persistThemeMode(mode) {
        try {
            this.storage.setItem(this.config.storageKey, mode);
        }
        catch {
            // Storage not available
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: ThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: ThemeService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }], ctorParameters: () => [] });

/**
 * All `--ui-*` CSS custom property names used by `@theredhead/lucid-kit`.
 *
 * Import these constants when you need to read or override tokens
 * programmatically (e.g. via `getComputedStyle` or `element.style.setProperty`).
 *
 * @example
 * ```ts
 * import { UI_TOKENS } from '@theredhead/lucid-theme';
 *
 * const accent = getComputedStyle(el).getPropertyValue(UI_TOKENS.accent);
 * el.style.setProperty(UI_TOKENS.surface, '#fff');
 * ```
 */
const UI_TOKENS = {
    // ── Core colours ───────────────────────────────────────────────
    text: "--ui-text",
    textMuted: "--ui-text-muted",
    muted: "--ui-muted",
    accent: "--ui-accent",
    accentHover: "--ui-accent-hover",
    accentContrast: "--ui-accent-contrast",
    link: "--ui-link",
    linkHover: "--ui-link-hover",
    error: "--ui-error",
    onError: "--ui-on-error",
    secondary: "--ui-secondary",
    tertiary: "--ui-tertiary",
    onTertiary: "--ui-on-tertiary",
    // ── Surfaces ───────────────────────────────────────────────────
    surface: "--ui-surface",
    surface2: "--ui-surface-2",
    surfaceVariant: "--ui-surface-variant",
    primaryContainer: "--ui-primary-container",
    onPrimaryContainer: "--ui-on-primary-container",
    bg: "--ui-bg",
    hoverBg: "--ui-hover-bg",
    shadow: "--ui-shadow",
    // ── Borders ────────────────────────────────────────────────────
    border: "--ui-border",
    borderStrong: "--ui-border-strong",
    // ── Typography ─────────────────────────────────────────────────
    font: "--ui-font",
    fontBody: "--ui-font-body",
    fontHeader: "--ui-font-header",
    fontCaption: "--ui-font-caption",
    fontFooter: "--ui-font-footer",
    fontBadge: "--ui-font-badge",
    fontSortIcon: "--ui-font-sort-icon",
    lsHeader: "--ui-ls-header",
    lsCaption: "--ui-ls-caption",
    // ── Badge (standalone) ─────────────────────────────────────────
    badgeBg: "--ui-badge-bg",
    badgeText: "--ui-badge-text",
    // ── Badge (table-view inline) ──────────────────────────────────
    badgeNeutralFg: "--ui-badge-neutral-fg",
    badgeNeutralBg: "--ui-badge-neutral-bg",
    badgeNeutralBorder: "--ui-badge-neutral-border",
    badgeSuccessFg: "--ui-badge-success-fg",
    badgeSuccessBg: "--ui-badge-success-bg",
    badgeSuccessBorder: "--ui-badge-success-border",
    badgeWarningFg: "--ui-badge-warning-fg",
    badgeWarningBg: "--ui-badge-warning-bg",
    badgeWarningBorder: "--ui-badge-warning-border",
    badgeDangerFg: "--ui-badge-danger-fg",
    badgeDangerBg: "--ui-badge-danger-bg",
    badgeDangerBorder: "--ui-badge-danger-border",
    badgePadding: "--ui-badge-padding",
    badgeLineHeight: "--ui-badge-line-height",
    badgeLetterSpacing: "--ui-badge-letter-spacing",
    // ── Table ──────────────────────────────────────────────────────
    captionBg: "--ui-caption-bg",
    captionText: "--ui-caption-text",
    viewportHeight: "--ui-viewport-height",
    resizeHandleWidth: "--ui-resize-handle-width",
    resizeIndicatorWidth: "--ui-resize-indicator-width",
    selectionColWidth: "--ui-selection-col-width",
    rowIndexWidth: "--ui-row-index-width",
    selectedBg: "--ui-selected-bg",
    selectedHoverBg: "--ui-selected-hover-bg",
    checkboxSize: "--ui-checkbox-size",
    radioSize: "--ui-radio-size",
    // ── Slider / Progress ──────────────────────────────────────────
    track: "--ui-track",
    thumb: "--ui-thumb",
    // ── Chip ───────────────────────────────────────────────────────
    chipBg: "--ui-chip-bg",
    chipText: "--ui-chip-text",
    chipDismiss: "--ui-chip-dismiss",
    // ── Avatar ─────────────────────────────────────────────────────
    fallback: "--ui-fallback",
    // ── Rich-text editor ───────────────────────────────────────────
    placeholderBg: "--ui-placeholder-bg",
    placeholderText: "--ui-placeholder-text",
    // ── Density ────────────────────────────────────────────────────
    density: "--ui-density",
    densityScale: "--ui-density-scale",
    controlHeight: "--ui-control-height",
    cellHeight: "--ui-cell-height",
    gap: "--ui-gap",
    inlinePadding: "--ui-inline-padding",
    blockPadding: "--ui-block-padding",
    radius: "--ui-radius",
    // ── Elevation ──────────────────────────────────────────────────
    shadowSm: "--ui-shadow-sm",
    shadowMd: "--ui-shadow-md",
    shadowLg: "--ui-shadow-lg",
    shadowXl: "--ui-shadow-xl",
    shadowDropdown: "--ui-shadow-dropdown",
};

/*
 * Public API Surface of @theredhead/lucid-theme
 */
// Services

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_THEME_CONFIG, THEME_CONFIG, ThemeService, UI_TOKENS };
//# sourceMappingURL=theredhead-lucid-theme.mjs.map
