import * as i0 from '@angular/core';
import { InjectionToken, Signal } from '@angular/core';

/**
 * Theme mode type - light, dark, or system (auto-detect current system setting)
 */
type ThemeMode = 'light' | 'dark' | 'system';
/**
 * Theme configuration options
 */
interface ThemeConfig {
    /** Default theme mode */
    defaultMode: ThemeMode;
    /** Storage key for persisting theme preference */
    storageKey: string;
    /** CSS class applied to the document for dark mode */
    darkModeClass: string;
    /** CSS class applied to the document for light mode */
    lightModeClass: string;
}
/**
 * Default theme configuration
 */
declare const DEFAULT_THEME_CONFIG: ThemeConfig;
/**
 * Injection token for theme configuration
 */
declare const THEME_CONFIG: InjectionToken<ThemeConfig>;

/**
 * Service for managing application theme (light/dark mode).
 *
 * **Note:** This service is optional. If you only include the SCSS theme without
 * injecting this service, the theme will still work correctly:
 * - Light theme applies by default
 * - Dark theme applies automatically via `@media (prefers-color-scheme: dark)`
 * - All Material components are properly themed
 *
 * Use this service when you need:
 * - **User preference persistence** - Saves theme choice to localStorage across sessions
 * - **Explicit theme override** - Let users choose a theme different from system preference
 * - **Reactive state** - Access `isDarkMode()` signal for conditional UI logic
 * - **Theme toggle** - Programmatic control via `toggleTheme()` or `setTheme()`
 *
 * @example
 * ```typescript
 * import { ThemeService } from '@theredhead/lucid-theme';
 *
 * @Component({...})
 * export class AppComponent {
 *   private themeService = inject(ThemeService);
 *
 *   toggleTheme() {
 *     this.themeService.toggleTheme();
 *   }
 * }
 * ```
 */
declare class ThemeService {
    private readonly document;
    private readonly config;
    private readonly storage;
    private readonly destroyRef;
    /** Current theme mode setting (light, dark, or system) */
    private readonly _themeMode;
    /** Media query for detecting system dark mode preference */
    private readonly darkModeMediaQuery;
    /** Whether the system prefers dark mode */
    private readonly _systemPrefersDark;
    private readonly onSystemPreferenceChange;
    constructor();
    /**
     * Current theme mode setting
     */
    readonly themeMode: Signal<ThemeMode>;
    /**
     * Whether the system prefers dark mode
     */
    readonly systemPrefersDark: Signal<boolean>;
    /**
     * Whether dark mode is currently active (resolved from mode + system preference)
     */
    readonly isDarkMode: Signal<boolean>;
    /**
     * Whether light mode is currently active
     */
    readonly isLightMode: Signal<boolean>;
    /**
     * Set the theme mode
     * @param mode - The theme mode to set ('light', 'dark', or 'system')
     */
    setTheme(mode: ThemeMode): void;
    /**
     * Toggle between light and dark mode
     * If currently in system mode, will switch to the opposite of current resolved theme
     */
    toggleTheme(): void;
    /**
     * Reset to system preference
     */
    resetToSystem(): void;
    /**
     * Apply theme classes to the document
     */
    private applyTheme;
    /**
     * Get stored theme mode from localStorage
     */
    private getStoredThemeMode;
    /**
     * Persist theme mode to storage
     */
    private persistThemeMode;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}

/**
 * All `--ui-*` CSS custom property names used by `@theredhead/lucid-kit`.
 *
 * Import these constants when you need to read or override tokens
 * programmatically (e.g. via `getComputedStyle` or `element.style.setProperty`).
 *
 * @example
 * ```ts
 * import { UI_TOKENS } from '@theredhead/lucid-theme';
 *
 * const accent = getComputedStyle(el).getPropertyValue(UI_TOKENS.accent);
 * el.style.setProperty(UI_TOKENS.surface, '#fff');
 * ```
 */
declare const UI_TOKENS: {
    readonly text: "--ui-text";
    readonly textMuted: "--ui-text-muted";
    readonly muted: "--ui-muted";
    readonly accent: "--ui-accent";
    readonly accentHover: "--ui-accent-hover";
    readonly accentContrast: "--ui-accent-contrast";
    readonly link: "--ui-link";
    readonly linkHover: "--ui-link-hover";
    readonly error: "--ui-error";
    readonly onError: "--ui-on-error";
    readonly secondary: "--ui-secondary";
    readonly tertiary: "--ui-tertiary";
    readonly onTertiary: "--ui-on-tertiary";
    readonly surface: "--ui-surface";
    readonly surface2: "--ui-surface-2";
    readonly surfaceVariant: "--ui-surface-variant";
    readonly primaryContainer: "--ui-primary-container";
    readonly onPrimaryContainer: "--ui-on-primary-container";
    readonly bg: "--ui-bg";
    readonly hoverBg: "--ui-hover-bg";
    readonly shadow: "--ui-shadow";
    readonly border: "--ui-border";
    readonly borderStrong: "--ui-border-strong";
    readonly font: "--ui-font";
    readonly fontBody: "--ui-font-body";
    readonly fontHeader: "--ui-font-header";
    readonly fontCaption: "--ui-font-caption";
    readonly fontFooter: "--ui-font-footer";
    readonly fontBadge: "--ui-font-badge";
    readonly fontSortIcon: "--ui-font-sort-icon";
    readonly lsHeader: "--ui-ls-header";
    readonly lsCaption: "--ui-ls-caption";
    readonly badgeBg: "--ui-badge-bg";
    readonly badgeText: "--ui-badge-text";
    readonly badgeNeutralFg: "--ui-badge-neutral-fg";
    readonly badgeNeutralBg: "--ui-badge-neutral-bg";
    readonly badgeNeutralBorder: "--ui-badge-neutral-border";
    readonly badgeSuccessFg: "--ui-badge-success-fg";
    readonly badgeSuccessBg: "--ui-badge-success-bg";
    readonly badgeSuccessBorder: "--ui-badge-success-border";
    readonly badgeWarningFg: "--ui-badge-warning-fg";
    readonly badgeWarningBg: "--ui-badge-warning-bg";
    readonly badgeWarningBorder: "--ui-badge-warning-border";
    readonly badgeDangerFg: "--ui-badge-danger-fg";
    readonly badgeDangerBg: "--ui-badge-danger-bg";
    readonly badgeDangerBorder: "--ui-badge-danger-border";
    readonly badgePadding: "--ui-badge-padding";
    readonly badgeLineHeight: "--ui-badge-line-height";
    readonly badgeLetterSpacing: "--ui-badge-letter-spacing";
    readonly captionBg: "--ui-caption-bg";
    readonly captionText: "--ui-caption-text";
    readonly viewportHeight: "--ui-viewport-height";
    readonly resizeHandleWidth: "--ui-resize-handle-width";
    readonly resizeIndicatorWidth: "--ui-resize-indicator-width";
    readonly selectionColWidth: "--ui-selection-col-width";
    readonly rowIndexWidth: "--ui-row-index-width";
    readonly selectedBg: "--ui-selected-bg";
    readonly selectedHoverBg: "--ui-selected-hover-bg";
    readonly checkboxSize: "--ui-checkbox-size";
    readonly radioSize: "--ui-radio-size";
    readonly track: "--ui-track";
    readonly thumb: "--ui-thumb";
    readonly chipBg: "--ui-chip-bg";
    readonly chipText: "--ui-chip-text";
    readonly chipDismiss: "--ui-chip-dismiss";
    readonly fallback: "--ui-fallback";
    readonly placeholderBg: "--ui-placeholder-bg";
    readonly placeholderText: "--ui-placeholder-text";
    readonly density: "--ui-density";
    readonly densityScale: "--ui-density-scale";
    readonly controlHeight: "--ui-control-height";
    readonly cellHeight: "--ui-cell-height";
    readonly gap: "--ui-gap";
    readonly inlinePadding: "--ui-inline-padding";
    readonly blockPadding: "--ui-block-padding";
    readonly radius: "--ui-radius";
    readonly shadowSm: "--ui-shadow-sm";
    readonly shadowMd: "--ui-shadow-md";
    readonly shadowLg: "--ui-shadow-lg";
    readonly shadowXl: "--ui-shadow-xl";
    readonly shadowDropdown: "--ui-shadow-dropdown";
};
/** Union of all `--ui-*` CSS custom property names. */
type UITokenName = (typeof UI_TOKENS)[keyof typeof UI_TOKENS];

export { DEFAULT_THEME_CONFIG, THEME_CONFIG, ThemeService, UI_TOKENS };
export type { ThemeConfig, ThemeMode, UITokenName };
//# sourceMappingURL=theredhead-lucid-theme.d.ts.map
