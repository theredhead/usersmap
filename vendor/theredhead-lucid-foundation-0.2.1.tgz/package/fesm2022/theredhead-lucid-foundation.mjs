import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, computed, Directive } from '@angular/core';

/**
 * Lightweight, context-scoped logger.
 *
 * Each `Logger` instance is bound to a **context** string (typically
 * the class or feature name) and a pluggable {@link ILoggingStrategy}.
 * The context is automatically prepended to every message so that log
 * output is easy to filter.
 *
 * @example
 * ```ts
 * const log = new Logger(new ConsoleLoggingStrategy(), "MyService");
 * log.info("initialised");        // → "[2026-03-23T12:00:00.000Z] MyService: initialised"
 * log.warn("deprecation", [api]); // → "[2026-03-23T12:00:00.000Z] MyService: deprecation" [api]
 * ```
 */
class Logger {
    strategy;
    context;
    constructor(strategy, context) {
        this.strategy = strategy;
        this.context = context;
    }
    /** Log a debug-level message. */
    debug(message, args = []) {
        this.strategy.debug(this.context, message, args);
    }
    /** Log an informational message. */
    info(message, args = []) {
        this.strategy.info(this.context, message, args);
    }
    /** Log a warning. */
    warn(message, args = []) {
        this.strategy.warn(this.context, message, args);
    }
    /** Log an error. */
    error(message, args = []) {
        this.strategy.error(this.context, message, args);
    }
}
/**
 * Default {@link ILoggingStrategy} that delegates to the browser
 * `console`.
 *
 * Messages are formatted as
 * `"[<ISO-timestamp>] <context>: <message>"` followed by any
 * additional arguments spread into the console call.
 */
class ConsoleLoggingStrategy {
    /** @inheritdoc */
    debug(context, message, args) {
        console.debug(`[${new Date().toISOString()}] ${context}: ${message}`, ...args);
    }
    /** @inheritdoc */
    info(context, message, args) {
        console.info(`[${new Date().toISOString()}] ${context}: ${message}`, ...args);
    }
    /** @inheritdoc */
    warn(context, message, args) {
        console.warn(`[${new Date().toISOString()}] ${context}: ${message}`, ...args);
    }
    /** @inheritdoc */
    error(context, message, args) {
        console.error(`[${new Date().toISOString()}] ${context}: ${message}`, ...args);
    }
}

/**
 * Angular service that creates context-scoped {@link Logger} instances.
 *
 * Inject `LoggerFactory` wherever you need a logger and call
 * {@link createLogger} with a context string (typically the class name).
 * A {@link ConsoleLoggingStrategy} is used by default, but you can
 * supply any {@link ILoggingStrategy} to redirect output.
 *
 * @example
 * ```ts
 * export class MyComponent {
 *   private readonly log = inject(LoggerFactory).createLogger("MyComponent");
 *
 *   public ngOnInit(): void {
 *     this.log.debug("component initialised");
 *   }
 * }
 * ```
 */
class LoggerFactory {
    /**
     * Creates a new {@link Logger} bound to the given context.
     *
     * @param context  A label prepended to every log message (e.g. a
     *                 class name or feature area).
     * @param strategy The logging back-end to use.  Defaults to
     *                 {@link ConsoleLoggingStrategy}.
     * @returns A ready-to-use `Logger` instance.
     */
    createLogger(context, strategy = new ConsoleLoggingStrategy()) {
        return new Logger(strategy, context);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: LoggerFactory, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: LoggerFactory, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: LoggerFactory, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

// ── Helpers ───────────────────────────────────────────────────────────────────
/**
 * Inline pattern replacements applied during Markdown → HTML conversion.
 * Order matters — more specific patterns first.
 * @internal
 */
const INLINE_RULES = [
    // Images (before links so `![alt](src)` isn't matched as link)
    [/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2" />'],
    // Links
    [
        /\[([^\]]+)\]\(([^)]+)\)/g,
        '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>',
    ],
    // Bold + italic (***text***)
    [/\*\*\*(.+?)\*\*\*/g, "<b><i>$1</i></b>"],
    // Bold (**text**)
    [/\*\*(.+?)\*\*/g, "<b>$1</b>"],
    // Italic (*text*)
    [/\*(.+?)\*/g, "<i>$1</i>"],
    // Strikethrough (~~text~~)
    [/~~(.+?)~~/g, "<s>$1</s>"],
    // Inline code (`text`)
    [/`([^`]+)`/g, "<code>$1</code>"],
    // Underline (++text++) — non-standard but useful
    [/\+\+(.+?)\+\+/g, "<u>$1</u>"],
];
/** @internal */
function escapeHtml$1(str) {
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
/** @internal */
function applyInline(text) {
    let result = text;
    for (const [pattern, replacement] of INLINE_RULES) {
        result = result.replace(pattern, replacement);
    }
    return result;
}
/** @internal */
function buildTableHtml(lines) {
    if (lines.length < 2)
        return null;
    const sepLine = lines[1].trim();
    if (!/--/.test(sepLine))
        return null;
    const parseRow = (line) => line
        .trim()
        .replace(/^\||\|$/g, "")
        .split("|")
        .map((c) => c.trim());
    const parseAlignments = (line) => parseRow(line).map((cell) => {
        const c = cell.trim();
        if (c.startsWith(":") && c.endsWith(":"))
            return "center";
        if (c.endsWith(":"))
            return "right";
        return "left";
    });
    const headers = parseRow(lines[0]);
    const alignments = parseAlignments(lines[1]);
    const dataRows = lines.slice(2).map(parseRow);
    const alignStyle = (i) => {
        const a = alignments[i] ?? "left";
        return a !== "left" ? ` style="text-align:${a}"` : "";
    };
    let html = "<table><thead><tr>";
    for (let i = 0; i < headers.length; i++) {
        html += `<th${alignStyle(i)}>${applyInline(headers[i])}</th>`;
    }
    html += "</tr></thead><tbody>";
    for (const row of dataRows) {
        html += "<tr>";
        for (let i = 0; i < row.length; i++) {
            html += `<td${alignStyle(i)}>${applyInline(row[i])}</td>`;
        }
        html += "</tr>";
    }
    html += "</tbody></table>";
    return html;
}
/**
 * Converts a Markdown string to an HTML string using the built-in
 * GFM-capable converter.
 *
 * Supports: headings (h1–h3), bold, italic, bold+italic, strikethrough,
 * underline, inline code, links, images, unordered lists, ordered lists,
 * blockquotes, fenced code blocks, horizontal rules, and GFM tables with
 * left/center/right column alignment.
 *
 * This function is used by {@link DefaultMarkdownParser} and is also
 * exported for callers that prefer a plain function over a class.
 */
function markdownToHtml(md) {
    const lines = md.split("\n");
    const htmlParts = [];
    let inList = null;
    let inCodeBlock = false;
    let codeBlockLines = [];
    let inBlockquote = false;
    let blockquoteLines = [];
    let tableBuffer = [];
    const flushTable = () => {
        if (tableBuffer.length === 0)
            return;
        const result = buildTableHtml(tableBuffer);
        if (result !== null) {
            htmlParts.push(result);
        }
        else {
            for (const tLine of tableBuffer) {
                htmlParts.push(`<p>${applyInline(tLine)}</p>`);
            }
        }
        tableBuffer = [];
    };
    const flushBlockquote = () => {
        if (inBlockquote && blockquoteLines.length) {
            htmlParts.push(`<blockquote>${blockquoteLines.map((l) => `<p>${applyInline(l)}</p>`).join("")}</blockquote>`);
            blockquoteLines = [];
            inBlockquote = false;
        }
    };
    const flushList = () => {
        if (inList) {
            htmlParts.push(`</${inList}>`);
            inList = null;
        }
    };
    for (const line of lines) {
        if (line.trimStart().startsWith("```")) {
            if (inCodeBlock) {
                htmlParts.push(`<pre>${escapeHtml$1(codeBlockLines.join("\n"))}</pre>`);
                codeBlockLines = [];
                inCodeBlock = false;
            }
            else {
                flushBlockquote();
                flushList();
                flushTable();
                inCodeBlock = true;
            }
            continue;
        }
        if (inCodeBlock) {
            codeBlockLines.push(line);
            continue;
        }
        const bqMatch = line.match(/^>\s?(.*)/);
        if (bqMatch) {
            flushList();
            flushTable();
            inBlockquote = true;
            blockquoteLines.push(bqMatch[1]);
            continue;
        }
        else {
            flushBlockquote();
        }
        if (line.trimStart().startsWith("|")) {
            flushList();
            tableBuffer.push(line);
            continue;
        }
        flushTable();
        if (line.trim() === "") {
            flushList();
            continue;
        }
        const headingMatch = line.match(/^(#{1,3})\s+(.*)/);
        if (headingMatch) {
            flushList();
            const level = headingMatch[1].length;
            htmlParts.push(`<h${level}>${applyInline(headingMatch[2])}</h${level}>`);
            continue;
        }
        if (/^(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
            flushList();
            htmlParts.push("<hr>");
            continue;
        }
        const ulMatch = line.match(/^[-*+]\s+(.*)/);
        if (ulMatch) {
            if (inList !== "ul") {
                flushList();
                inList = "ul";
                htmlParts.push("<ul>");
            }
            htmlParts.push(`<li>${applyInline(ulMatch[1])}</li>`);
            continue;
        }
        const olMatch = line.match(/^\d+\.\s+(.*)/);
        if (olMatch) {
            if (inList !== "ol") {
                flushList();
                inList = "ol";
                htmlParts.push("<ol>");
            }
            htmlParts.push(`<li>${applyInline(olMatch[1])}</li>`);
            continue;
        }
        flushList();
        htmlParts.push(`<p>${applyInline(line)}</p>`);
    }
    if (inCodeBlock) {
        htmlParts.push(`<pre>${escapeHtml$1(codeBlockLines.join("\n"))}</pre>`);
    }
    flushBlockquote();
    flushList();
    flushTable();
    return htmlParts.join("");
}
/**
 * The built-in GFM-capable {@link MarkdownParser} implementation.
 *
 * Delegates to {@link markdownToHtml}. No configuration required —
 * construct and call `toHtml()`.
 *
 * @example
 * ```ts
 * import { DefaultMarkdownParser } from '@theredhead/lucid-foundation';
 *
 * const parser = new DefaultMarkdownParser();
 * console.log(parser.toHtml('**hello**')); // <b>hello</b>
 * ```
 */
class DefaultMarkdownParser {
    /**
     * Converts a Markdown string to HTML using the built-in GFM converter.
     * @param markdown - Raw Markdown source.
     * @returns HTML string.
     */
    toHtml(markdown) {
        return markdownToHtml(markdown);
    }
}

/**
 * Minimal typed event emitter — a lightweight alternative to RxJS
 * `Subject` for discrete notifications.
 *
 * ```ts
 * const event = new Emitter<RowChangedNotification>();
 *
 * // Consumer (e.g. in a component):
 * const unsub = event.subscribe(n => console.log(n.rowIndex));
 * destroyRef.onDestroy(unsub);
 *
 * // Producer (e.g. in a datasource):
 * event.emit({ rowIndex: 42 });
 * ```
 *
 * @typeParam T - The event payload type.
 */
class Emitter {
    listeners = new Set();
    /**
     * Registers a listener that is invoked every time the event fires.
     *
     * @param fn - Callback receiving the event payload.
     * @returns A teardown function that removes the listener when called.
     *          Designed to be passed directly to `DestroyRef.onDestroy()`.
     */
    subscribe(fn) {
        this.listeners.add(fn);
        return () => this.listeners.delete(fn);
    }
    /**
     * Fires the event, invoking all registered listeners synchronously.
     * Listener errors are caught individually so one failing handler
     * never prevents the remaining listeners from executing.
     * Caught errors are reported via `console.error` so they still
     * surface in logs without causing unhandled exceptions.
     *
     * @param event - The payload to deliver to every listener.
     */
    emit(event) {
        for (const fn of this.listeners) {
            try {
                fn(event);
            }
            catch (e) {
                console.error("Emitter: listener threw", e);
            }
        }
    }
}

/**
 * Mutable set-like registry implementation.
 */
class Registry {
    store;
    constructor(values) {
        this.store = new Set(values);
    }
    /**
     * Number of registered values.
     */
    get size() {
        return this.store.size;
    }
    /**
     * Registers a value.
     */
    register(value) {
        this.store.add(value);
    }
    /**
     * Removes a registered value.
     */
    unregister(value) {
        this.store.delete(value);
    }
    /**
     * Removes all registered values.
     */
    clear() {
        this.store.clear();
    }
    /** @inheritdoc */
    has(value) {
        return this.store.has(value);
    }
    /** @inheritdoc */
    values() {
        return this.store.values();
    }
    /** @inheritdoc */
    toArray() {
        return Array.from(this.store.values());
    }
}
/**
 * Mutable map-like registry implementation.
 */
class KeyedRegistry {
    store;
    constructor(entries) {
        this.store = new Map(entries);
    }
    /**
     * Number of registered entries.
     */
    get size() {
        return this.store.size;
    }
    /**
     * Registers or replaces an entry.
     */
    register(key, value) {
        this.store.set(key, value);
    }
    /**
     * Removes a registered entry.
     */
    unregister(key) {
        this.store.delete(key);
    }
    /**
     * Removes all registered entries.
     */
    clear() {
        this.store.clear();
    }
    /** @inheritdoc */
    has(key) {
        return this.store.has(key);
    }
    /** @inheritdoc */
    get(key) {
        return this.store.get(key);
    }
    /** @inheritdoc */
    keys() {
        return this.store.keys();
    }
    /** @inheritdoc */
    values() {
        return this.store.values();
    }
    /** @inheritdoc */
    entries() {
        return this.store.entries();
    }
    /** @inheritdoc */
    toMap() {
        return new Map(this.store);
    }
    /** @inheritdoc */
    toArray() {
        return Array.from(this.store.values());
    }
}

/** Direction in which a column can be sorted. */
var SortDirection;
(function (SortDirection) {
    /** Sort values from lowest to highest (A → Z, 0 → 9). */
    SortDirection["Ascending"] = "asc";
    /** Sort values from highest to lowest (Z → A, 9 → 0). */
    SortDirection["Descending"] = "desc";
})(SortDirection || (SortDirection = {}));
/**
 * Compare two raw values with type-aware ordering.
 *
 * - Two numbers → numeric comparison.
 * - Two Dates → timestamp comparison.
 * - Everything else → locale-aware string comparison via `String()`.
 * - `null` / `undefined` sort after all other values (stable).
 *
 * @internal
 */
function compareValues(a, b) {
    // Treat null/undefined as empty — push to the end.
    const isNilA = a === null || a === undefined;
    const isNilB = b === null || b === undefined;
    if (isNilA && isNilB)
        return 0;
    if (isNilA)
        return 1;
    if (isNilB)
        return -1;
    // Both numbers → numeric.
    if (typeof a === "number" && typeof b === "number") {
        return a - b;
    }
    // Both Dates → timestamp.
    if (a instanceof Date && b instanceof Date) {
        return a.getTime() - b.getTime();
    }
    // Fallback → locale-aware string comparison.
    return String(a).localeCompare(String(b));
}
/**
 * Compiles a {@link SortExpression} into a comparator function.
 *
 * Uses locale-aware string comparison by default. The first entry is the
 * primary sort; subsequent entries act as tie-breakers.
 *
 * @typeParam T - The row object type.
 * @param expression - The sort expression to compile.
 * @returns A comparator function `(a, b) => number`.
 *
 * @example
 * ```ts
 * const cmp = compileSortExpression<Employee>([
 *   { columnKey: 'department', direction: SortDirection.Ascending },
 *   { columnKey: 'name', direction: SortDirection.Ascending },
 * ]);
 * const sorted = employees.sort(cmp);
 * ```
 */
function compileSortExpression(expression) {
    return (a, b) => {
        for (const criterion of expression) {
            const key = criterion.columnKey;
            const ra = a[key];
            const rb = b[key];
            const cmp = compareValues(ra, rb);
            if (cmp !== 0) {
                return criterion.direction === SortDirection.Ascending ? cmp : -cmp;
            }
        }
        return 0;
    };
}
/**
 * Compiles a {@link SortExpression} into a comparator for {@link TreeNode} objects.
 *
 * Like {@link compileSortExpression} but reaches into `node.data` to access
 * the sort key, which is the standard layout for tree datasources.
 *
 * @typeParam T - The data payload type carried by each tree node.
 * @param expression - The sort expression to compile.
 * @returns A comparator function `(a, b) => number` operating on tree nodes.
 */
function compileTreeSortExpression(expression) {
    return (a, b) => {
        for (const criterion of expression) {
            const key = criterion.columnKey;
            const ra = a.data[key];
            const rb = b.data[key];
            const cmp = compareValues(ra, rb);
            if (cmp !== 0) {
                return criterion.direction === SortDirection.Ascending ? cmp : -cmp;
            }
        }
        return 0;
    };
}

/**
 * Pure-function array helpers for reorder and transfer operations.
 *
 * These are the building blocks that datasource implementations
 * (e.g. `ArrayDatasource` subclasses) can use internally, and that
 * consumers can use directly when working with plain arrays.
 *
 * Both functions mutate the arrays **in place** so datasource
 * implementations can operate directly on their backing store.
 */
/**
 * Moves an item within `array` from `fromIndex` to `toIndex`,
 * shifting other elements to accommodate. The array is mutated
 * **in place**.
 *
 * @typeParam T - The item type.
 * @param array     - The array to mutate.
 * @param fromIndex - Current zero-based index of the item to move.
 * @param toIndex   - Desired zero-based index for the item.
 *
 * @example
 * ```ts
 * const items = ['a', 'b', 'c', 'd'];
 * moveItemInArray(items, 0, 2);
 * // items → ['b', 'c', 'a', 'd']
 * ```
 */
function moveItemInArray(array, fromIndex, toIndex) {
    if (fromIndex < 0 || fromIndex >= array.length) {
        throw new RangeError("fromIndex must be >= 0 and < the size of the array");
    }
    if (toIndex < 0 || toIndex >= array.length) {
        throw new RangeError("toIndex must be >= 0 and < the size of the array");
    }
    const [item] = array.splice(fromIndex, 1);
    array.splice(toIndex, 0, item);
}
/**
 * Removes the item at `fromIndex` from `source` and inserts it into
 * `target` at `toIndex`. Both arrays are mutated **in place**.
 *
 * @typeParam T - The item type.
 * @param source    - The array to remove from.
 * @param fromIndex - Zero-based index of the item to remove from `source`.
 * @param target    - The array to insert into.
 * @param toIndex   - Zero-based index at which to insert into `target`.
 *
 * @example
 * ```ts
 * const src = ['a', 'b', 'c'];
 * const tgt = ['x', 'y'];
 * moveItemToArray(src, 1, tgt, 1);
 * // src → ['a', 'c']
 * // tgt → ['x', 'b', 'y']
 * ```
 */
function moveItemToArray(source, fromIndex, target, toIndex) {
    if (fromIndex < 0 || fromIndex >= source.length) {
        throw new RangeError("fromIndex must be >= 0 and < the size of the source array");
    }
    if (toIndex < 0 || toIndex > target.length) {
        throw new RangeError("toIndex must be >= 0 and <= the size of the target array");
    }
    const [item] = source.splice(fromIndex, 1);
    target.splice(toIndex, 0, item);
}
// ── Pure (non-mutating) variants ────────────────────────────────────
/**
 * Returns a **new** array with the item at `fromIndex` relocated to
 * `toIndex`. The original array is not modified.
 *
 * @typeParam T - The item type.
 * @param array     - The source array (not mutated).
 * @param fromIndex - Current zero-based index of the item to move.
 * @param toIndex   - Desired zero-based index for the item.
 * @returns A new array with the item relocated.
 *
 * @example
 * ```ts
 * const result = moveItemInArrayPure(['a', 'b', 'c', 'd'], 0, 2);
 * // result → ['b', 'c', 'a', 'd']
 * ```
 */
function moveItemInArrayPure(array, fromIndex, toIndex) {
    if (fromIndex < 0 || fromIndex >= array.length) {
        throw new RangeError("fromIndex must be >= 0 and < the size of the array");
    }
    if (toIndex < 0 || toIndex >= array.length) {
        throw new RangeError("toIndex must be >= 0 and < the size of the array");
    }
    const result = [...array];
    const [item] = result.splice(fromIndex, 1);
    result.splice(toIndex, 0, item);
    return result;
}
/**
 * Returns **new** copies of `source` and `target` with the item at
 * `fromIndex` removed from `source` and inserted into `target` at
 * `toIndex`. The original arrays are not modified.
 *
 * @typeParam T - The item type.
 * @param source    - The array to remove from (not mutated).
 * @param fromIndex - Zero-based index of the item to remove from `source`.
 * @param target    - The array to insert into (not mutated).
 * @param toIndex   - Zero-based index at which to insert into `target`.
 * @returns A tuple `[newSource, newTarget]` with the transfer applied.
 *
 * @example
 * ```ts
 * const [src, tgt] = moveItemToArrayPure(
 *   ['a', 'b', 'c'], 1,
 *   ['x', 'y'],       1,
 * );
 * // src → ['a', 'c']
 * // tgt → ['x', 'b', 'y']
 * ```
 */
function moveItemToArrayPure(source, fromIndex, target, toIndex) {
    if (fromIndex < 0 || fromIndex >= source.length) {
        throw new RangeError("fromIndex must be >= 0 and < the size of the source array");
    }
    if (toIndex < 0 || toIndex > target.length) {
        throw new RangeError("toIndex must be >= 0 and <= the size of the target array");
    }
    const newSource = [...source];
    const [item] = newSource.splice(fromIndex, 1);
    const newTarget = [...target];
    newTarget.splice(toIndex, 0, item);
    return [newSource, newTarget];
}

/**
 * Simple in-memory datasource backed by an array.
 *
 * The constructor takes a defensive copy of the provided data so that
 * external mutations to the source array do not affect the table.
 *
 * Implements {@link IActiveDatasource} so that UI components
 * automatically stay in sync when rows are inserted, removed, moved,
 * or individually mutated (via {@link notifyRowChanged}).
 *
 * Implements {@link IReorderableDatasource}, {@link IInsertableDatasource},
 * and {@link IRemovableDatasource} so UI components can reorder items
 * and transfer items between datasources via the capability-detection
 * pattern.
 *
 * @typeParam T - The row object type.
 */
class ArrayDatasource {
    /** @inheritdoc */
    noteRowChanged = new Emitter();
    /** @inheritdoc */
    noteRowRangeChanged = new Emitter();
    rows;
    constructor(data) {
        // Defensive copy so callers cannot mutate table data externally.
        this.rows = [...data];
    }
    getNumberOfItems() {
        return this.rows.length;
    }
    getObjectAtRowIndex(rowIndex) {
        if (rowIndex < 0 || rowIndex >= this.rows.length) {
            throw new RangeError("rowIndex must be >= 0 and < the size of the collection");
        }
        return this.rows[rowIndex];
    }
    /**
     * Notifies consumers that the row at the given index has been
     * externally mutated (e.g. property values changed in-place).
     *
     * Call this after directly modifying a row object so that any
     * listening UI (such as a table view) can re-read the data.
     *
     * @param rowIndex - Zero-based index of the changed row.
     */
    notifyRowChanged(rowIndex) {
        this.noteRowChanged.emit({ rowIndex });
    }
    /**
     * Notifies consumers that all visible data should be considered
     * stale. Call this after bulk mutations that affect many rows.
     */
    notifyDataChanged() {
        this.noteRowRangeChanged.emit({
            range: { start: 0, length: this.rows.length },
        });
    }
    /** @inheritdoc */
    moveItem(fromIndex, toIndex) {
        moveItemInArray(this.rows, fromIndex, toIndex);
        this.noteRowRangeChanged.emit({
            range: {
                start: Math.min(fromIndex, toIndex),
                length: Math.abs(toIndex - fromIndex) + 1,
            },
        });
    }
    /** @inheritdoc */
    insertItem(index, item) {
        if (index < 0 || index > this.rows.length) {
            throw new RangeError("index must be >= 0 and <= the size of the collection");
        }
        this.rows.splice(index, 0, item);
        this.noteRowRangeChanged.emit({
            range: { start: index, length: this.rows.length - index },
        });
    }
    /** @inheritdoc */
    removeItem(index) {
        if (index < 0 || index >= this.rows.length) {
            throw new RangeError("index must be >= 0 and < the size of the collection");
        }
        const [item] = this.rows.splice(index, 1);
        this.noteRowRangeChanged.emit({
            range: { start: index, length: this.rows.length - index + 1 },
        });
        return item;
    }
}

/**
 * An in-memory array datasource that supports filtering via a
 * {@link CompiledFilter}.
 *
 * When an expression is applied the datasource compiles it into a
 * single predicate, re-derives its visible rows from the original
 * data, and exposes only the matching items. The underlying array
 * is never mutated.
 *
 * @typeParam T - The row object type.
 *
 * @example
 * ```ts
 * const ds = new FilterableArrayDatasource(employees);
 * ds.filterBy([{ predicate: row => row.age > 30 }]);
 * ```
 */
class FilterableArrayDatasource extends ArrayDatasource {
    /** The full, unfiltered dataset. */
    _allRows;
    /** The currently visible (filtered) rows. */
    _filteredRows;
    /**
     * The full, unfiltered dataset.
     *
     * Useful when consumers need to inspect the original data while a
     * filter is active (e.g. to infer field types from a sample row
     * without the result disappearing when the filter yields no matches).
     */
    get allRows() {
        return this._allRows;
    }
    constructor(data) {
        super(data);
        this._allRows = this.rows;
        this._filteredRows = this._allRows;
    }
    // ── IDatasource overrides ─────────────────────────────────────────
    getNumberOfItems() {
        return this._filteredRows.length;
    }
    getObjectAtRowIndex(rowIndex) {
        if (rowIndex < 0 || rowIndex >= this._filteredRows.length) {
            throw new RangeError("rowIndex must be >= 0 and < the number of filtered items");
        }
        return this._filteredRows[rowIndex];
    }
    // ── IFilterableDatasource ─────────────────────────────────────────
    /**
     * Applies a structured {@link CompiledFilter} to the datasource.
     *
     * The expression is compiled into a single predicate once, which is
     * then applied to every row. Pass an empty array (or `null` /
     * `undefined`) to clear the filter and show all rows.
     *
     * - **Property-level** entries test a single property value.
     * - **Row-level** entries test the entire row object.
     * - All entries must pass (AND) for a row to be included.
     */
    filterBy(expression) {
        if (!expression || expression.length === 0) {
            this._filteredRows = this._allRows;
        }
        else {
            const predicate = this.compileExpression(expression);
            this._filteredRows = this._allRows.filter(predicate);
        }
        this.noteRowRangeChanged.emit({
            range: { start: 0, length: this._filteredRows.length },
        });
    }
    // ── Private helpers ───────────────────────────────────────────────
    /**
     * Compiles a {@link CompiledFilter} into a single predicate
     * function that can be applied to all rows.
     */
    compileExpression(expression) {
        const tests = expression.map((entry) => {
            if ("property" in entry) {
                const { property, predicate } = entry;
                return (row) => predicate(row[property]);
            }
            const { predicate } = entry;
            return (row) => predicate(row);
        });
        return (row) => tests.every((test) => test(row));
    }
    /** Clears any active filter, restoring all rows. */
    clearFilter() {
        this.filterBy(null);
    }
}

/**
 * An in-memory array datasource that supports sorting via a comparator function.
 *
 * When a comparator is applied, the datasource re-derives its visible rows
 * from the original data. The underlying array is never mutated.
 *
 * @typeParam T - The row object type.
 *
 * @example
 * ```ts
 * const ds = new SortableArrayDatasource(employees);
 * ds.applyComparator((a, b) => a.age - b.age);
 * ```
 */
class SortableArrayDatasource extends ArrayDatasource {
    /** The full, unsorted dataset. */
    _allRows;
    /** The currently sorted rows. */
    _sortedRows;
    /**
     * The full, unsorted dataset.
     *
     * Useful when consumers need to inspect the original data while a
     * sort is active.
     */
    get allRows() {
        return this._allRows;
    }
    constructor(data) {
        super(data);
        this._allRows = this.rows;
        this._sortedRows = this._allRows;
    }
    // ── IDatasource overrides ─────────────────────────────────────────
    getNumberOfItems() {
        return this._sortedRows.length;
    }
    getObjectAtRowIndex(rowIndex) {
        if (rowIndex < 0 || rowIndex >= this._sortedRows.length) {
            throw new RangeError("rowIndex must be >= 0 and < the number of sorted items");
        }
        return this._sortedRows[rowIndex];
    }
    // ── ISortableDatasource ───────────────────────────────────────────
    /**
     * Applies a serializable sort expression to the datasource.
     *
     * The expression is compiled into a comparator function internally.
     * Pass `null` to clear the sort and restore the original insertion order.
     *
     * @param expression - Sort criteria, or `null` to clear.
     */
    sortBy(expression) {
        if (!expression || expression.length === 0) {
            this.applyComparator(null);
            return;
        }
        this.applyComparator(compileSortExpression(expression));
    }
    // ── Convenience: raw comparator ───────────────────────────────────
    /**
     * Applies a comparator function to sort the datasource.
     *
     * Pass `null` or `undefined` to clear the sort and restore the original
     * insertion order.
     *
     * @param comparator - The comparator function, or null/undefined to clear sorting.
     */
    applyComparator(comparator) {
        if (!comparator) {
            this._sortedRows = this._allRows;
        }
        else {
            this._sortedRows = [...this._allRows].sort(comparator);
        }
        this.noteRowRangeChanged.emit({
            range: { start: 0, length: this._sortedRows.length },
        });
    }
}

/** Default page size for REST datasources. */
const DEFAULT_PAGE_SIZE = 100;
const defaultFetch = (input, init) => globalThis.fetch(input, init);
/**
 * Very small lazy REST datasource.
 *
 * It requests pages from:
 * `${baseUrl}?pageIndex=<n>&pageSize=<size>`
 * and caches each page in memory after the first request.
 */
class RestDatasource {
    baseUrl;
    pageSize;
    fetchFn;
    pageCache = new Map();
    inFlightPages = new Map();
    totalItems;
    constructor(baseUrl, pageSize = DEFAULT_PAGE_SIZE, fetchFn = defaultFetch) {
        this.baseUrl = baseUrl;
        this.pageSize = pageSize;
        this.fetchFn = fetchFn;
        if (pageSize <= 0) {
            throw new RangeError("pageSize must be greater than 0");
        }
    }
    getNumberOfItems() {
        if (this.totalItems !== undefined) {
            return this.totalItems;
        }
        // Prime metadata from the first page when total is not known yet.
        return this.ensurePageLoaded(0).then(() => this.totalItems ?? 0);
    }
    getObjectAtRowIndex(rowIndex) {
        if (rowIndex < 0) {
            throw new RangeError("rowIndex must be greater than or equal to 0");
        }
        if (this.totalItems !== undefined && rowIndex >= this.totalItems) {
            throw new RangeError("rowIndex is outside the datasource bounds");
        }
        const pageIndex = Math.floor(rowIndex / this.pageSize);
        const indexInPage = rowIndex % this.pageSize;
        const cachedPage = this.pageCache.get(pageIndex);
        if (cachedPage) {
            const row = cachedPage[indexInPage];
            if (row === undefined) {
                throw new RangeError("rowIndex is outside the datasource bounds");
            }
            return row;
        }
        return this.ensurePageLoaded(pageIndex).then((page) => {
            const row = page[indexInPage];
            if (row === undefined) {
                throw new RangeError("rowIndex is outside the datasource bounds");
            }
            return row;
        });
    }
    ensurePageLoaded(pageIndex) {
        const cached = this.pageCache.get(pageIndex);
        if (cached) {
            return Promise.resolve(cached);
        }
        const inFlight = this.inFlightPages.get(pageIndex);
        if (inFlight) {
            return inFlight;
        }
        const loadPromise = this.fetchPage(pageIndex)
            .then((page) => {
            this.pageCache.set(pageIndex, page);
            this.inFlightPages.delete(pageIndex);
            return page;
        })
            .catch((error) => {
            this.inFlightPages.delete(pageIndex);
            throw error;
        });
        this.inFlightPages.set(pageIndex, loadPromise);
        return loadPromise;
    }
    async fetchPage(pageIndex) {
        const separator = this.baseUrl.includes("?") ? "&" : "?";
        const url = `${this.baseUrl}${separator}pageIndex=${pageIndex}&pageSize=${this.pageSize}`;
        const response = await this.fetchFn(url);
        if (!response.ok) {
            throw new Error(`Failed to load page ${pageIndex} (HTTP ${response.status})`);
        }
        const payload = (await response.json());
        const items = this.extractItems(payload);
        this.trySetTotalItems(payload, pageIndex, items.length);
        return items;
    }
    extractItems(payload) {
        if (Array.isArray(payload.rows)) {
            return payload.rows;
        }
        throw new Error("REST response must include a rows array");
    }
    trySetTotalItems(payload, pageIndex, itemCount) {
        if (typeof payload.totalNumberOfRows === "number") {
            this.totalItems = payload.totalNumberOfRows;
            return;
        }
        // If the page is shorter than pageSize, infer total from this terminal page.
        if (itemCount < this.pageSize) {
            this.totalItems = pageIndex * this.pageSize + itemCount;
        }
    }
}

/**
 * Simple in-memory tree datasource backed by an array of root nodes.
 *
 * The constructor takes a defensive copy of the root array so that
 * external mutations do not affect the tree. Child nodes are read
 * from a configurable property on each {@link TreeNode}, defaulting
 * to `'children'`.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * // Default — reads children from `node.children`
 * const ds = new ArrayTreeDatasource([
 *   { id: '1', data: 'Root', children: [
 *     { id: '1.1', data: 'Child' },
 *   ]},
 * ]);
 *
 * // Custom property — reads children from `node.items`
 * const ds2 = new ArrayTreeDatasource(roots, 'items');
 * ```
 */
class ArrayTreeDatasource {
    roots;
    childrenProperty;
    constructor(roots, childrenProperty = "children") {
        this.roots = [...roots];
        this.childrenProperty = childrenProperty;
    }
    /** Returns the root-level nodes. */
    getRootNodes() {
        return this.roots;
    }
    /** Returns the children of the given node. */
    getChildren(node) {
        return node[this.childrenProperty] ?? [];
    }
    /** Returns `true` when the node has at least one child. */
    hasChildren(node) {
        return this.getChildren(node).length > 0;
    }
}

/**
 * An in-memory tree datasource that supports filtering via a
 * {@link CompiledFilter}.
 *
 * When an expression is applied the datasource compiles it into a
 * single predicate, re-derives its visible tree structure from the
 * original data, and exposes only the matching nodes (plus their
 * ancestors). The underlying tree is never mutated.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * const ds = new FilterableArrayTreeDatasource([
 *   { id: '1', data: 'Root', children: [
 *     { id: '1.1', data: 'Child A' },
 *     { id: '1.2', data: 'Child B' },
 *   ]},
 * ]);
 *
 * // Show only nodes containing 'A' in their data
 * ds.filterBy([{ predicate: node => String(node).includes('A') }]);
 * ```
 */
class FilterableArrayTreeDatasource extends ArrayTreeDatasource {
    /** The full, unfiltered tree. */
    _allRoots;
    /** The currently filtered tree. */
    _filteredRoots;
    /** Cached children property key for accessing child arrays. */
    _childrenProperty;
    /**
     * The full, unfiltered root nodes.
     *
     * Useful when consumers need to inspect the original tree structure
     * while a filter is active.
     */
    get allRoots() {
        return this._allRoots;
    }
    constructor(roots, childrenProperty = "children") {
        super(roots, childrenProperty);
        this._allRoots = this.deepCopyNodes(roots, childrenProperty);
        this._filteredRoots = [...this._allRoots];
        this._childrenProperty = childrenProperty;
    }
    // ── ITreeDatasource overrides ─────────────────────────────────────
    getRootNodes() {
        return this._filteredRoots;
    }
    // ── IFilterableTreeDataSource ────────────────────────────────────
    /**
     * Applies a structured {@link CompiledFilter} to the tree.
     *
     * The expression is compiled into a single predicate once, which is
     * then applied to each node's `data`. Matching nodes and their
     * ancestors are kept. Pass an empty array (or `null` / `undefined`)
     * to clear the filter and show all nodes.
     *
     * - **Property-level** entries test a single property of `T`.
     * - **Row-level** entries test the entire `T` object.
     * - All entries must pass (AND) for a node to be included.
     */
    filterBy(expression) {
        if (!expression || expression.length === 0) {
            this._filteredRoots = this.deepCopyNodes(this._allRoots, this._childrenProperty);
            return;
        }
        const predicate = this.compileExpression(expression);
        this._filteredRoots = this.filterNodes(this._allRoots, predicate, this._childrenProperty);
    }
    /** Clears any active filter, restoring all nodes. */
    clearFilter() {
        this._filteredRoots = this.deepCopyNodes(this._allRoots, this._childrenProperty);
    }
    // ── Private helpers ───────────────────────────────────────────────
    /**
     * Compiles a {@link CompiledFilter} into a single predicate
     * function that can be applied to each node's `data`.
     */
    compileExpression(expression) {
        const tests = expression.map((entry) => {
            if ("property" in entry) {
                const { property, predicate } = entry;
                return (data) => predicate(data[property]);
            }
            const { predicate } = entry;
            return (data) => predicate(data);
        });
        return (data) => tests.every((test) => test(data));
    }
    /**
     * Recursively filter tree nodes, excluding non-matching nodes and
     * their descendants.
     *
     * A node is kept if:
     * - The node itself matches the predicate, OR
     * - At least one of its descendants matches the predicate
     *
     * @param nodes - The nodes to filter.
     * @param predicate - The predicate function.
     * @param childrenProp - The property name for children.
     * @returns Filtered node tree.
     */
    filterNodes(nodes, predicate, childrenProp) {
        const result = [];
        for (const node of nodes) {
            const children = node[childrenProp] ?? [];
            const filteredChildren = this.filterNodes(children, predicate, childrenProp);
            const nodeMatches = predicate(node.data);
            // Keep node if it matches OR if any descendant matches
            if (nodeMatches || filteredChildren.length > 0) {
                const copy = { ...node };
                // Always use filtered children (even if empty) to reflect the filter result
                if (children.length > 0) {
                    copy[childrenProp] = filteredChildren;
                }
                result.push(copy);
            }
        }
        return result;
    }
    /**
     * Create a structural copy of tree nodes to avoid mutations to the
     * original tree shape. Each {@link TreeNode} wrapper is shallow-copied
     * (`{ ...node }`) so the `data` payload remains a shared reference.
     * This is intentional — deep-cloning arbitrary `T` is not feasible.
     *
     * @param nodes - The nodes to copy.
     * @param childrenProp - The property name for children.
     * @returns Structurally-copied node tree (shared `data` references).
     */
    deepCopyNodes(nodes, childrenProp) {
        return nodes.map((node) => {
            const copy = { ...node };
            const children = node[childrenProp] ?? [];
            if (children.length > 0) {
                copy[childrenProp] = this.deepCopyNodes(children, childrenProp);
            }
            return copy;
        });
    }
}

/**
 * An in-memory tree datasource that supports sorting via a comparator function.
 *
 * When a comparator is applied, the datasource re-derives its visible tree
 * structure from the original data. Nodes are sorted at each level of the tree
 * (root nodes and all children recursively). The underlying tree is never mutated.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * const ds = new SortableArrayTreeDatasource([
 *   { id: '1', data: { name: 'Beta' }, children: [
 *     { id: '1.1', data: { name: 'Zebra' } },
 *     { id: '1.2', data: { name: 'Apple' } },
 *   ]},
 * ]);
 *
 * // Sort all levels alphabetically by data.name
 * ds.applyComparator((a, b) => a.data.name.localeCompare(b.data.name));
 * ```
 */
class SortableArrayTreeDatasource extends ArrayTreeDatasource {
    /** The full, unsorted tree. */
    _allRoots;
    /** The currently sorted tree. */
    _sortedRoots;
    /** Cached children property key for accessing child arrays. */
    _childrenProperty;
    /**
     * The full, unsorted root nodes.
     *
     * Useful when consumers need to inspect the original tree structure
     * while a sort is active.
     */
    get allRoots() {
        return this._allRoots;
    }
    constructor(roots, childrenProperty = "children") {
        super(roots, childrenProperty);
        this._allRoots = this.deepCopyNodes(roots, childrenProperty);
        this._sortedRoots = [...this._allRoots];
        this._childrenProperty = childrenProperty;
    }
    // ── ITreeDatasource overrides ─────────────────────────────────────
    getRootNodes() {
        return this._sortedRoots;
    }
    // ── ISortableTreeDatasource ──────────────────────────────────────
    /**   * Applies a serializable sort expression to the tree.
     *
     * The expression is compiled into a tree-node comparator that sorts by
     * `node.data` properties. Sorting is applied recursively at all levels.
     * Pass `null` to clear sorting and restore the original insertion order.
     *
     * @param expression - Sort criteria, or `null` to clear.
     */
    sortBy(expression) {
        if (!expression || expression.length === 0) {
            this.applyComparator(null);
            return;
        }
        this.applyComparator(compileTreeSortExpression(expression));
    }
    // ── ISortableTreeDatasource (legacy) ──────────────────────────────
    /**   * Applies a comparator function to sort the tree at all levels.
     *
     * The comparator is applied recursively to root nodes and all descendants.
     * Pass `null` or `undefined` to clear the sort and restore the original
     * insertion order.
     *
     * @param comparator - The comparator function, or null/undefined to clear sorting.
     */
    applyComparator(comparator) {
        if (!comparator) {
            this._sortedRoots = this.deepCopyNodes(this._allRoots, this._childrenProperty);
            return;
        }
        this._sortedRoots = this.sortNodes(this._allRoots, comparator, this._childrenProperty);
    }
    // ── Private helpers ──────────────────────────────────────────────
    /**
     * Structural copy of tree nodes — each {@link TreeNode} wrapper is
     * shallow-copied (`{ ...node }`) so `data` remains a shared reference.
     *
     * @internal
     */
    deepCopyNodes(nodes, childrenProp) {
        return nodes.map((node) => {
            const copy = { ...node };
            const children = node[childrenProp] ?? [];
            if (children.length > 0) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                copy[childrenProp] = this.deepCopyNodes(children, childrenProp);
            }
            return copy;
        });
    }
    /**
     * Recursively sort tree nodes and their children.
     *
     * @internal
     */
    sortNodes(nodes, comparator, childrenProp) {
        const result = [];
        for (const node of nodes) {
            const copy = { ...node };
            const children = node[childrenProp] ?? [];
            // Recursively sort children
            if (children.length > 0) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                copy[childrenProp] = this.sortNodes(children, comparator, childrenProp);
            }
            result.push(copy);
        }
        // Sort at this level
        return result.sort(comparator);
    }
}

/**
 * Check if a datasource supports filtering.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `IFilterableDatasource<T>`; false otherwise.
 */
function isFilterableDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return typeof obj["filterBy"] === "function";
}
/**
 * Check if a datasource supports sorting.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `ISortableDatasource<T>`; false otherwise.
 */
function isSortableDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return typeof obj["sortBy"] === "function";
}
/**
 * Check if a datasource is a tree datasource that supports filtering.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `IFilterableTreeDatasource<T>`; false otherwise.
 */
function isFilterableTreeDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return (typeof obj["filterBy"] === "function" &&
        typeof obj["getRootNodes"] === "function" &&
        typeof obj["getChildren"] === "function" &&
        typeof obj["hasChildren"] === "function");
}
/**
 * Check if a datasource is a tree datasource.
 *
 * Tests for the presence of the three methods that define
 * {@link ITreeDatasource}: `getRootNodes`, `getChildren`, and
 * `hasChildren`.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `ITreeDatasource<T>`; `false` otherwise.
 */
function isTreeDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return (typeof obj["getRootNodes"] === "function" &&
        typeof obj["getChildren"] === "function" &&
        typeof obj["hasChildren"] === "function");
}
/**
 * Check if a datasource is a tree datasource that supports sorting.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `ISortableTreeDatasource<T>`; false otherwise.
 */
function isSortableTreeDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return (typeof obj["sortBy"] === "function" &&
        typeof obj["getRootNodes"] === "function" &&
        typeof obj["getChildren"] === "function" &&
        typeof obj["hasChildren"] === "function");
}
/**
 * Check if a datasource supports reordering items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IReorderableDatasource<T>`; `false` otherwise.
 */
function isReorderableDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return typeof obj["moveItem"] === "function";
}
/**
 * Check if a datasource supports inserting items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IInsertableDatasource<T>`; `false` otherwise.
 */
function isInsertableDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return typeof obj["insertItem"] === "function";
}
/**
 * Check if a datasource supports removing items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IRemovableDatasource<T>`; `false` otherwise.
 */
function isRemovableDatasource(datasource) {
    if (datasource === null || datasource === undefined) {
        return false;
    }
    const obj = datasource;
    return typeof obj["removeItem"] === "function";
}

// ── Base implementations ────────────────────────────────────────────

/**
 * Decode a base64url-encoded string to a UTF-8 string.
 *
 * Handles the base64url → base64 conversion (padding, URL-safe
 * characters) before delegating to `atob`.
 *
 * @param base64url - A base64url-encoded string.
 * @returns The decoded UTF-8 string.
 *
 * @internal
 */
function base64UrlDecode(base64url) {
    // Replace URL-safe characters with standard base64 characters
    let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
    // Restore padding
    const pad = base64.length % 4;
    if (pad === 2)
        base64 += "==";
    else if (pad === 3)
        base64 += "=";
    // Decode and handle multi-byte UTF-8
    const binary = atob(base64);
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
}
/**
 * Parse a single base64url-encoded JWT segment into a typed object.
 *
 * @param segment - A base64url-encoded JSON segment.
 * @param label   - Human-readable segment name for error messages.
 * @returns The parsed object.
 * @throws {Error} If the segment is not valid base64url or valid JSON.
 *
 * @internal
 */
function parseSegment(segment, label) {
    try {
        const json = base64UrlDecode(segment);
        return JSON.parse(json);
    }
    catch {
        throw new Error(`JWT ${label} is not valid base64url-encoded JSON.`);
    }
}
/**
 * Decode a compact-serialisation JWT string into its constituent
 * parts: header, payload, and raw signature.
 *
 * **This function does NOT verify the token's signature.** Signature
 * verification requires access to the signing key or a JWKS endpoint
 * and is the responsibility of the consumer's backend or auth
 * library.
 *
 * @param token - A JWT in compact serialisation
 *   (`header.payload.signature`).
 * @returns A {@link JwtToken} with decoded header and payload.
 * @throws {Error} If the token structure is malformed or the JSON is
 *   invalid.
 *
 * @example
 * ```ts
 * import { decodeJwt } from '@theredhead/lucid-foundation';
 *
 * const jwt = decodeJwt(rawTokenString);
 * console.log(jwt.payload.sub);  // "user-123"
 * console.log(jwt.payload.exp);  // 1742601600
 * ```
 */
function decodeJwt(token) {
    if (typeof token !== "string" || token.trim().length === 0) {
        throw new Error("JWT must be a non-empty string.");
    }
    const parts = token.split(".");
    if (parts.length !== 3) {
        throw new Error(`JWT must have exactly 3 segments (header.payload.signature), received ${parts.length}.`);
    }
    const [headerSegment, payloadSegment, signature] = parts;
    const header = parseSegment(headerSegment, "header");
    const payload = parseSegment(payloadSegment, "payload");
    return {
        header,
        payload,
        signature,
        raw: token,
    };
}
/**
 * Extract a specific claim value from a JWT payload.
 *
 * This is a convenience wrapper around {@link decodeJwt} for
 * quick one-off claim reads.
 *
 * @param token - A JWT in compact serialisation.
 * @param claim - The claim name to extract.
 * @returns The claim value, or `undefined` if absent.
 *
 * @example
 * ```ts
 * const sub = extractClaim(rawToken, 'sub');   // "user-123"
 * const role = extractClaim(rawToken, 'role'); // "editor"
 * ```
 */
function extractClaim(token, claim) {
    const { payload } = decodeJwt(token);
    return payload[claim];
}
/**
 * Extract an array of permission strings from a JWT payload.
 *
 * Many authorization systems encode permissions in a custom claim
 * (e.g. `"permissions"`, `"scope"`, `"roles"`). This helper
 * normalises the value to a `readonly string[]`.
 *
 * @param token     - A JWT in compact serialisation.
 * @param claimName - The claim that holds the permissions.
 *   Defaults to `"permissions"`.
 * @returns A readonly array of permission strings.
 *   Returns an empty array if the claim is absent or not an array.
 *
 * @example
 * ```ts
 * const perms = extractPermissions(rawToken);
 * // ["user.read", "user.write"]
 *
 * const scopes = extractPermissions(rawToken, 'scope');
 * // ["openid", "profile"]
 * ```
 */
function extractPermissions(token, claimName = "permissions") {
    const value = extractClaim(token, claimName);
    // Handle space-delimited scope strings (OAuth 2.0 convention)
    if (typeof value === "string") {
        return value.split(/\s+/).filter((s) => s.length > 0);
    }
    if (Array.isArray(value)) {
        return value.filter((v) => typeof v === "string");
    }
    return [];
}

// ── Helpers ────────────────────────────────────────────────────────
/** @internal */
function issue(code, message, severity = "error") {
    return { code, message, severity };
}
// ── Single-purpose validators ──────────────────────────────────────
/**
 * Check whether a decoded JWT is expired.
 *
 * @param payload              - The decoded JWT payload.
 * @param nowSeconds           - Current time in seconds since epoch.
 *   Defaults to `Math.floor(Date.now() / 1000)`.
 * @param clockToleranceSeconds - Grace period in seconds. Defaults to `0`.
 * @returns `true` if the token has an `exp` claim and it is in the past.
 *
 * @example
 * ```ts
 * if (isExpired(jwt.payload)) {
 *   // refresh or redirect to login
 * }
 * ```
 */
function isExpired(payload, nowSeconds = Math.floor(Date.now() / 1000), clockToleranceSeconds = 0) {
    if (payload.exp === undefined)
        return false;
    return nowSeconds >= payload.exp + clockToleranceSeconds;
}
/**
 * Check whether a decoded JWT is not yet valid (the `nbf` claim is
 * in the future).
 *
 * @param payload              - The decoded JWT payload.
 * @param nowSeconds           - Current time in seconds since epoch.
 * @param clockToleranceSeconds - Grace period in seconds. Defaults to `0`.
 * @returns `true` if the token has an `nbf` claim and it is in the future.
 */
function isNotYetValid(payload, nowSeconds = Math.floor(Date.now() / 1000), clockToleranceSeconds = 0) {
    if (payload.nbf === undefined)
        return false;
    return nowSeconds < payload.nbf - clockToleranceSeconds;
}
/**
 * Calculate the number of seconds until a JWT expires.
 *
 * @param payload    - The decoded JWT payload.
 * @param nowSeconds - Current time in seconds since epoch.
 * @returns Seconds remaining, or `Infinity` if there is no `exp` claim.
 *   A negative value means the token is already expired.
 *
 * @example
 * ```ts
 * const remaining = secondsUntilExpiry(jwt.payload);
 * if (remaining < 300) {
 *   // less than 5 minutes — trigger silent refresh
 * }
 * ```
 */
function secondsUntilExpiry(payload, nowSeconds = Math.floor(Date.now() / 1000)) {
    if (payload.exp === undefined)
        return Infinity;
    return payload.exp - nowSeconds;
}
// ── Composite validator ────────────────────────────────────────────
/**
 * Validate a decoded JWT against a set of configurable rules.
 *
 * Returns an array of {@link JwtValidationIssue} objects. An empty
 * array means the token passed all requested checks.
 *
 * This function does **not** verify the cryptographic signature.
 *
 * @param token   - A decoded {@link JwtToken}.
 * @param options - Which checks to perform and their parameters.
 * @returns An array of validation issues (empty = valid).
 *
 * @example
 * ```ts
 * const issues = validateJwt(jwt, {
 *   issuer: 'https://auth.example.com',
 *   audience: 'my-app',
 *   requireSubject: true,
 *   requiredClaims: ['role', 'permissions'],
 * });
 *
 * if (issues.length > 0) {
 *   console.warn('JWT validation failed:', issues);
 * }
 * ```
 */
function validateJwt(token, options = {}) {
    const issues = [];
    const { issuer, audience, requireSubject, requiredClaims, clockToleranceSeconds = 0, nowSeconds = Math.floor(Date.now() / 1000), } = options;
    const { header, payload } = token;
    // ── Header checks ──────────────────────────────────────────────
    if (!header.alg) {
        issues.push(issue("MISSING_ALG", 'JWT header is missing the "alg" field.'));
    }
    // ── Time-based checks ──────────────────────────────────────────
    if (isExpired(payload, nowSeconds, clockToleranceSeconds)) {
        issues.push(issue("TOKEN_EXPIRED", `Token expired at ${payload.exp} (now: ${nowSeconds}, tolerance: ${clockToleranceSeconds}s).`));
    }
    if (isNotYetValid(payload, nowSeconds, clockToleranceSeconds)) {
        issues.push(issue("TOKEN_NOT_YET_VALID", `Token is not valid before ${payload.nbf} (now: ${nowSeconds}, tolerance: ${clockToleranceSeconds}s).`));
    }
    // ── Issuer check ───────────────────────────────────────────────
    if (issuer !== undefined && payload.iss !== issuer) {
        const actualIss = payload.iss ?? "(none)";
        issues.push(issue("ISSUER_MISMATCH", 'Expected issuer "' + issuer + '", got "' + actualIss + '".'));
    }
    // ── Audience check ─────────────────────────────────────────────
    if (audience !== undefined) {
        const aud = payload.aud;
        const audArray = typeof aud === "string" ? [aud] : Array.isArray(aud) ? aud : [];
        if (!audArray.includes(audience)) {
            const actualAud = String(aud ?? "(none)");
            issues.push(issue("AUDIENCE_MISMATCH", 'Expected audience "' + audience + '", got "' + actualAud + '".'));
        }
    }
    // ── Subject check ──────────────────────────────────────────────
    if (requireSubject && !payload.sub) {
        issues.push(issue("MISSING_SUBJECT", 'Token is missing the "sub" claim.'));
    }
    // ── Required custom claims ─────────────────────────────────────
    if (requiredClaims) {
        for (const claim of requiredClaims) {
            if (payload[claim] === undefined) {
                issues.push(issue("MISSING_CLAIM", `Token is missing the required "${claim}" claim.`));
            }
        }
    }
    return issues;
}
/**
 * Convenience predicate: returns `true` when a decoded JWT passes
 * all validation checks defined in `options`.
 *
 * @param token   - A decoded {@link JwtToken}.
 * @param options - Validation rules.
 * @returns `true` if no issues were found.
 */
function isJwtValid(token, options = {}) {
    return validateJwt(token, options).length === 0;
}

/**
 * Default storage strategy that delegates to `localStorage`.
 *
 * All operations are wrapped in try/catch so they degrade gracefully
 * in environments where localStorage is unavailable (SSR, private
 * browsing quota exceeded, etc.).
 */
class LocalStorageStrategy {
    getItem(key) {
        try {
            return localStorage.getItem(key);
        }
        catch {
            return null;
        }
    }
    setItem(key, value) {
        try {
            localStorage.setItem(key, value);
        }
        catch {
            // Storage full or unavailable — silently ignore.
        }
    }
    removeItem(key) {
        try {
            localStorage.removeItem(key);
        }
        catch {
            // Silently ignore.
        }
    }
}
/**
 * Injection token for the storage strategy.
 *
 * Defaults to {@link LocalStorageStrategy}. Override at the application
 * root to swap in a different backend:
 *
 * ```ts
 * providers: [
 *   { provide: STORAGE_STRATEGY, useClass: MyCustomStrategy },
 * ]
 * ```
 */
const STORAGE_STRATEGY = new InjectionToken("STORAGE_STRATEGY", {
    providedIn: "root",
    factory: () => new LocalStorageStrategy(),
});
/**
 * Angular service for persisting key-value data.
 *
 * Delegates to the {@link IStorageStrategy} provided via
 * {@link STORAGE_STRATEGY}. Defaults to {@link LocalStorageStrategy}
 * (i.e. `localStorage`).
 *
 * Inject this service instead of calling `localStorage` directly so
 * that storage behaviour can be swapped application-wide through DI.
 *
 * @example
 * ```ts
 * export class MyComponent {
 *   private readonly storage = inject(StorageService);
 *
 *   public save(key: string, data: unknown): void {
 *     this.storage.setItem(key, JSON.stringify(data));
 *   }
 *
 *   public load(key: string): unknown | null {
 *     const raw = this.storage.getItem(key);
 *     return raw ? JSON.parse(raw) : null;
 *   }
 * }
 * ```
 */
class StorageService {
    strategy = inject(STORAGE_STRATEGY);
    /** Retrieve a value by key. Returns `null` when the key does not exist. */
    getItem(key) {
        return this.strategy.getItem(key);
    }
    /** Store a value under the given key. */
    setItem(key, value) {
        this.strategy.setItem(key, value);
    }
    /** Remove the value for the given key. */
    removeItem(key) {
        this.strategy.removeItem(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: StorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: StorageService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: StorageService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * Optional injection token that components can provide to set a default
 * surface type. The directive uses this when no explicit `surfaceType`
 * input is supplied by the consumer.
 *
 * ```ts
 * providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: 'panel' }]
 * ```
 */
const UI_DEFAULT_SURFACE_TYPE = new InjectionToken("UI_DEFAULT_SURFACE_TYPE");
/**
 * Host directive that maps a `surfaceType` input to a CSS class on the
 * host element: `ui-surface-type-<value>`.
 *
 * Applied automatically to every `ui-*` component via `hostDirectives`.
 * The actual visual treatment is defined in the theme stylesheet — the
 * directive only manages the class binding.
 *
 * ### Built-in types
 *
 * | Type          | Intended use                                     |
 * |---------------|--------------------------------------------------|
 * | `transparent` | Fully transparent background                     |
 * | `raised`      | Elevated surface with shadow                     |
 * | `sunken`      | Inset / recessed surface                         |
 * | `panel`       | Generic panel / card surface                     |
 *
 * ### Custom types
 *
 * Define a CSS class with the `ui-surface-type-` prefix in your stylesheet:
 *
 * ```css
 * .ui-surface-type-glass {
 *   background: rgba(255, 255, 255, 0.1);
 *   backdrop-filter: blur(12px);
 * }
 * ```
 *
 * Then use it on any component:
 *
 * ```html
 * <ui-card surfaceType="glass">…</ui-card>
 * ```
 *
 * ### Multiple types
 *
 * Pass a space-separated string or an array to combine surface types:
 *
 * ```html
 * <ui-card surfaceType="raised glass">…</ui-card>
 * <ui-card [surfaceType]="['raised', 'glass']">…</ui-card>
 * ```
 */
class UISurface {
    defaultSurface = inject(UI_DEFAULT_SURFACE_TYPE, {
        optional: true,
    });
    /**
     * One or more surface types to apply.
     * Accepts a single type, a space-separated string, or an array.
     * When unset, falls back to the component's `UI_DEFAULT_SURFACE_TYPE` provider (if any).
     */
    surfaceType = input("", ...(ngDevMode ? [{ debugName: "surfaceType" }] : []));
    /** @internal */
    hostClass = computed(() => {
        let raw = this.surfaceType();
        if (raw === "" && this.defaultSurface)
            raw = this.defaultSurface;
        const types = Array.isArray(raw)
            ? raw
            : String(raw).split(/\s+/).filter(Boolean);
        return types.map((t) => `ui-surface-type-${t}`).join(" ");
    }, ...(ngDevMode ? [{ debugName: "hostClass" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISurface, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.1.0", type: UISurface, isStandalone: true, selector: "[uiSurface]", inputs: { surfaceType: { classPropertyName: "surfaceType", publicName: "surfaceType", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClass()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISurface, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: "[uiSurface]",
                    host: {
                        "[class]": "hostClass()",
                    },
                }]
        }], propDecorators: { surfaceType: [{ type: i0.Input, args: [{ isSignal: true, alias: "surfaceType", required: false }] }] } });

/** @internal */
const TEMPLATE_ROOT = "template-root";
/** @internal */
const parserErrorSelector = "parsererror";
/** @internal */
const blockProviders = new KeyedRegistry();
/** @internal */
const dataDetectors = new Registry();
/**
 * Registers an XML template block provider.
 *
 * Calling this again with the same block name replaces the existing provider.
 */
function registerTextTemplateBlockProvider(provider) {
    blockProviders.register(provider.name, provider);
}
/**
 * Removes a previously registered XML template block provider.
 */
function unregisterTextTemplateBlockProvider(name) {
    blockProviders.unregister(name);
}
/**
 * Returns `true` when a provider for the XML block name is registered.
 */
function haveRegisteredTextTemplateBlockProvider(name) {
    return blockProviders.has(name);
}
/**
 * Returns all currently registered XML template block providers.
 */
function getRegisteredTextTemplateBlockProviders() {
    return Array.from(blockProviders.values());
}
/**
 * Registers a data detector.
 *
 * Detectors are intended to run either before or after XML template
 * processing, never during block expansion itself.
 */
function registerDataDetector(detector) {
    dataDetectors.register(detector);
}
/**
 * Removes a previously registered data detector.
 */
function unregisterDataDetector(detector) {
    dataDetectors.unregister(detector);
}
/**
 * Returns all currently registered data detectors.
 */
function getRegisteredDataDetectors() {
    return Array.from(dataDetectors.values());
}
/**
 * Applies a detector list to a text fragment at a pipeline boundary.
 *
 * Each detector runs only when its {@link IDataDetector.detect} method returns
 * `true`. Detector output is fed into subsequent detectors in registration
 * order.
 */
function applyDataDetectors(text, detectors = getRegisteredDataDetectors()) {
    if (!text || detectors.length === 0) {
        return text;
    }
    const document = new DOMParser().parseFromString("<body></body>", "text/html");
    const container = document.body;
    container.textContent = text;
    for (const detector of detectors) {
        const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
        const textNodes = [];
        let currentNode = walker.nextNode();
        while (currentNode) {
            textNodes.push(currentNode);
            currentNode = walker.nextNode();
        }
        for (const textNode of textNodes) {
            const currentText = textNode.textContent ?? "";
            if (!currentText || !detector.detect(currentText)) {
                continue;
            }
            const transformed = detector.process(currentText);
            if (transformed === currentText) {
                continue;
            }
            const template = document.createElement("template");
            template.innerHTML = transformed;
            textNode.replaceWith(...Array.from(template.content.childNodes));
        }
    }
    return container.innerHTML;
}
/**
 * Parses XML template strings into the canonical document model.
 */
class XmlTemplateParser {
    /**
     * Parses an XML template fragment.
     */
    parse(template) {
        const parser = new DOMParser();
        const xml = parser.parseFromString(`<${TEMPLATE_ROOT}>${template}</${TEMPLATE_ROOT}>`, "application/xml");
        const parserError = xml.querySelector(parserErrorSelector);
        if (parserError) {
            throw new SyntaxError(`XmlTemplateParser: malformed XML template (${parserError.textContent?.trim() ?? "unknown parser error"})`);
        }
        const root = xml.documentElement;
        if (!root || root.nodeName !== TEMPLATE_ROOT) {
            throw new SyntaxError("XmlTemplateParser: missing template root");
        }
        return {
            children: Array.from(root.childNodes)
                .map((node) => this.parseNode(node))
                .filter((node) => node !== null),
        };
    }
    /** @internal */
    parseNode(node) {
        if (node.nodeType === Node.TEXT_NODE ||
            node.nodeType === Node.CDATA_SECTION_NODE) {
            return { kind: "text", text: node.textContent ?? "" };
        }
        if (node.nodeType !== Node.ELEMENT_NODE) {
            return null;
        }
        const element = node;
        const attributes = {};
        for (const attr of Array.from(element.attributes)) {
            attributes[attr.name] = attr.value;
        }
        return {
            kind: "block",
            name: element.tagName,
            attributes,
            children: Array.from(element.childNodes)
                .map((child) => this.parseNode(child))
                .filter((child) => child !== null),
            selfClosing: element.childNodes.length === 0,
        };
    }
}
/**
 * Serializes parsed template documents back to canonical XML.
 */
class XmlTemplateSerializer {
    /**
     * Serializes a complete template document.
     */
    serialize(document) {
        return this.serializeNodes(document.children);
    }
    /**
     * Serializes a node collection.
     */
    serializeNodes(nodes) {
        return nodes.map((node) => this.serializeNode(node)).join("");
    }
    /**
     * Serializes a single template node.
     */
    serializeNode(node) {
        if (node.kind === "text") {
            return this.escapeText(node.text);
        }
        const attrs = Object.entries(node.attributes)
            .map(([key, value]) => ` ${key}="${this.escapeAttribute(value)}"`)
            .join("");
        if (node.selfClosing || node.children.length === 0) {
            return `<${node.name}${attrs} />`;
        }
        return `<${node.name}${attrs}>${this.serializeNodes(node.children)}</${node.name}>`;
    }
    /** @internal */
    escapeText(value) {
        return value.replace(/&/g, "&amp;").replace(/</g, "&lt;");
    }
    /** @internal */
    escapeAttribute(value) {
        return this.escapeText(value).replace(/"/g, "&quot;");
    }
}
/**
 * XML block template processor.
 */
class XmlTemplateProcessor {
    missingKeyBehavior;
    parser = new XmlTemplateParser();
    serializer = new XmlTemplateSerializer();
    constructor(options = {}) {
        this.missingKeyBehavior = options.missingKey ?? "keep";
    }
    /**
     * Fully expands an XML template string.
     */
    expand(template, context) {
        return this.expandDocument(this.parser.parse(template), context);
    }
    /**
     * Fully expands an already parsed template document.
     */
    expandDocument(document, context) {
        return this.expandNodes(document.children, context);
    }
    /**
     * Expands a node collection.
     */
    expandNodes(nodes, context) {
        return nodes.map((node) => this.expandNode(node, context)).join("");
    }
    /**
     * Dispatches one block to its registered provider.
     */
    processBlock(block, context) {
        const provider = blockProviders.get(block.name);
        if (!provider) {
            throw new RangeError(`XmlTemplateProcessor: unknown block <${block.name}>`);
        }
        this.validateBlock(block, provider);
        return provider.expand(block, { data: context, processor: this });
    }
    /**
     * Resolves a context key for built-in replacement blocks.
     */
    processIdentifier(key, context) {
        if (Object.prototype.hasOwnProperty.call(context, key)) {
            const val = context[key];
            return val == null ? "" : String(val);
        }
        return this.resolveMissing(key);
    }
    /** @internal */
    expandNode(node, context) {
        if (node.kind === "text")
            return node.text;
        return this.processBlock(node, context);
    }
    /** @internal */
    validateBlock(block, provider) {
        if (provider.contentModel === "self-closing" && block.children.length > 0) {
            throw new SyntaxError(`XmlTemplateProcessor: <${block.name}> must be self-closing`);
        }
        if (provider.contentModel === "container" && block.selfClosing) {
            throw new SyntaxError(`XmlTemplateProcessor: <${block.name}> must contain a closing tag`);
        }
        for (const attr of provider.requiredAttributes ?? []) {
            if (!Object.prototype.hasOwnProperty.call(block.attributes, attr)) {
                throw new SyntaxError(`XmlTemplateProcessor: <${block.name}> missing required "${attr}" attribute`);
            }
        }
    }
    /** @internal */
    resolveMissing(key) {
        if (this.missingKeyBehavior === "keep") {
            return this.serializer.serializeNode({
                kind: "block",
                name: "placeholder",
                attributes: { key },
                children: [],
                selfClosing: true,
            });
        }
        if (this.missingKeyBehavior === "empty")
            return "";
        if (this.missingKeyBehavior === "error") {
            throw new RangeError(`XmlTemplateProcessor: missing key "${key}"`);
        }
        return this.missingKeyBehavior(key);
    }
}
/**
 * Default processor name retained for consumers that already import
 * `TextTemplateProcessor`. The implementation is XML-only.
 */
class TextTemplateProcessor extends XmlTemplateProcessor {
}
/** @internal */
function registerPassthroughBlock(name) {
    registerTextTemplateBlockProvider({
        name,
        contentModel: "any",
        expand: (block, context) => {
            const attrs = Object.entries(block.attributes)
                .map(([key, value]) => ` ${key}="${escapeAttribute$1(value)}"`)
                .join("");
            if (block.selfClosing || block.children.length === 0) {
                return `<${block.name}${attrs} />`;
            }
            return `<${block.name}${attrs}>${context.processor.expandNodes(block.children, context.data)}</${block.name}>`;
        },
    });
}
/** @internal */
function escapeText(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;");
}
/** @internal */
function escapeAttribute$1(value) {
    return escapeText(value).replace(/"/g, "&quot;");
}
// ── built-in XML block providers ─────────────────────────────────────────────
registerTextTemplateBlockProvider({
    name: "placeholder",
    contentModel: "self-closing",
    requiredAttributes: ["key"],
    expand: (block, context) => context.processor.processIdentifier(block.attributes["key"] ?? "", context.data),
});
registerTextTemplateBlockProvider({
    name: "if",
    contentModel: "container",
    requiredAttributes: ["test"],
    expand: (block, context) => {
        const val = context.data[block.attributes["test"] ?? ""];
        const truthy = Array.isArray(val) ? val.length > 0 : Boolean(val);
        return truthy
            ? context.processor.expandNodes(block.children, context.data)
            : "";
    },
});
registerTextTemplateBlockProvider({
    name: "loop",
    contentModel: "container",
    requiredAttributes: ["items"],
    expand: (block, context) => {
        const items = context.data[block.attributes["items"] ?? ""];
        if (items == null)
            return "";
        if (!Array.isArray(items)) {
            throw new TypeError(`XmlTemplateProcessor <loop>: "${block.attributes["items"] ?? ""}" is not an array (got ${typeof items})`);
        }
        return items
            .map((item) => {
            const itemCtx = typeof item === "object" && item !== null
                ? { ...context.data, ...item }
                : { ...context.data, value: item };
            return context.processor.expandNodes(block.children, itemCtx);
        })
            .join("");
    },
});
registerTextTemplateBlockProvider({
    name: "email",
    contentModel: "self-closing",
    requiredAttributes: ["email", "text"],
    expand: (block, context) => {
        const emailAttr = block.attributes["email"] ?? "";
        const textAttr = block.attributes["text"] ?? "";
        const href = context.data[emailAttr] ?? emailAttr;
        const text = context.data[textAttr] ?? textAttr ?? href;
        return `<a href="mailto:${escapeAttribute$1(String(href))}">${escapeText(String(text))}</a>`;
    },
});
for (const tag of [
    "a",
    "article",
    "b",
    "blockquote",
    "br",
    "caption",
    "code",
    "div",
    "del",
    "dl",
    "dt",
    "dd",
    "em",
    "figcaption",
    "figure",
    "footer",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "hr",
    "i",
    "img",
    "li",
    "main",
    "nav",
    "ol",
    "p",
    "pre",
    "s",
    "section",
    "span",
    "strike",
    "strong",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "tr",
    "u",
    "ul",
]) {
    registerPassthroughBlock(tag);
}

/** @internal */
const EMAIL_PATTERN = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
/** @internal */
const URL_PATTERN = /https?:\/\/[^\s<]+[^\s<.,!?;:)]/gi;
/** @internal */
const PHONE_PATTERN = /(?:\+?\d[\d().\-\s]{5,}\d)/g;
/** @internal */
const EMOTICON_TO_EMOJI = new Map([
    [":-)", "🙂"],
    [":)", "🙂"],
    [":-(", "🙁"],
    [":(", "🙁"],
    [";-)", "😉"],
    [";)", "😉"],
    [":-D", "😄"],
    [":D", "😄"],
    [":-P", "😛"],
    [":P", "😛"],
    [":-p", "😛"],
    [":p", "😛"],
    [":-O", "😮"],
    [":O", "😮"],
    [":-o", "😮"],
    [":o", "😮"],
    [":'(", "😢"],
    ["<3", "❤️"],
]);
/** @internal */
const EMOTICON_PATTERN = new RegExp(Array.from(EMOTICON_TO_EMOJI.keys())
    .sort((left, right) => right.length - left.length)
    .map(escapeRegExp)
    .join("|"), "g");
/**
 * Detects and links email addresses.
 */
class EmailDetector {
    /** @inheritdoc */
    detect(text) {
        EMAIL_PATTERN.lastIndex = 0;
        return EMAIL_PATTERN.test(text);
    }
    /** @inheritdoc */
    process(text) {
        return replaceMatches(text, EMAIL_PATTERN, (match) => {
            const email = match[0];
            return `<a href="mailto:${escapeAttribute(email)}">${escapeHtml(email)}</a>`;
        });
    }
}
/**
 * Detects and links HTTP and HTTPS URLs.
 */
class UrlDetector {
    /** @inheritdoc */
    detect(text) {
        URL_PATTERN.lastIndex = 0;
        return URL_PATTERN.test(text);
    }
    /** @inheritdoc */
    process(text) {
        return replaceMatches(text, URL_PATTERN, (match) => {
            const url = match[0];
            return `<a href="${escapeAttribute(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(url)}</a>`;
        });
    }
}
/**
 * Detects and links phone numbers.
 */
class PhoneNumberDetector {
    /** @inheritdoc */
    detect(text) {
        PHONE_PATTERN.lastIndex = 0;
        return Array.from(text.matchAll(PHONE_PATTERN)).some((match) => isLikelyPhoneNumber(match[0]));
    }
    /** @inheritdoc */
    process(text) {
        return replaceMatches(text, PHONE_PATTERN, (match) => {
            const phoneNumber = match[0];
            if (!isLikelyPhoneNumber(phoneNumber)) {
                return escapeHtml(phoneNumber);
            }
            return `<a href="tel:${escapeAttribute(normalizePhoneNumber(phoneNumber))}">${escapeHtml(phoneNumber)}</a>`;
        });
    }
}
/**
 * Detects old-school plaintext emoticons and converts them to emoji.
 */
class EmojiDetector {
    /** @inheritdoc */
    detect(text) {
        return findEmoticonMatch(text) !== null;
    }
    /** @inheritdoc */
    process(text) {
        let result = "";
        let lastIndex = 0;
        EMOTICON_PATTERN.lastIndex = 0;
        for (const match of text.matchAll(EMOTICON_PATTERN)) {
            const emoticon = match[0];
            const index = match.index ?? 0;
            if (!isEmoticonBoundary(text, index, index + emoticon.length)) {
                continue;
            }
            result += escapeHtml(text.slice(lastIndex, index));
            result += EMOTICON_TO_EMOJI.get(emoticon) ?? escapeHtml(emoticon);
            lastIndex = index + emoticon.length;
        }
        result += escapeHtml(text.slice(lastIndex));
        return result;
    }
}
/** @internal */
function replaceMatches(text, pattern, replaceMatch) {
    let result = "";
    let lastIndex = 0;
    pattern.lastIndex = 0;
    for (const match of text.matchAll(pattern)) {
        const index = match.index ?? 0;
        result += escapeHtml(text.slice(lastIndex, index));
        result += replaceMatch(match);
        lastIndex = index + match[0].length;
    }
    result += escapeHtml(text.slice(lastIndex));
    return result;
}
/** @internal */
function normalizePhoneNumber(phoneNumber) {
    const trimmed = phoneNumber.trim();
    const hasLeadingPlus = trimmed.startsWith("+");
    const digitsOnly = trimmed.replace(/\D/g, "");
    return hasLeadingPlus ? `+${digitsOnly}` : digitsOnly;
}
/** @internal */
function isLikelyPhoneNumber(value) {
    return value.replace(/\D/g, "").length >= 7;
}
/** @internal */
function findEmoticonMatch(text) {
    EMOTICON_PATTERN.lastIndex = 0;
    for (const match of text.matchAll(EMOTICON_PATTERN)) {
        const index = match.index ?? 0;
        if (isEmoticonBoundary(text, index, index + match[0].length)) {
            return match;
        }
    }
    return null;
}
/** @internal */
function isEmoticonBoundary(text, startIndex, endIndex) {
    const previous = startIndex > 0 ? text[startIndex - 1] : "";
    const next = endIndex < text.length ? text[endIndex] : "";
    return (isEmoticonBoundaryCharacter(previous) && isEmoticonBoundaryCharacter(next));
}
/** @internal */
function isEmoticonBoundaryCharacter(value) {
    return value === "" || /[\s([{'"<>,.!?\]-]/.test(value);
}
/** @internal */
function escapeHtml(value) {
    return value
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}
/** @internal */
function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, "&quot;");
}
/** @internal */
function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Parse common CSS color syntax into RGBA channels. */
function parseCssColor(value) {
    const color = value.trim();
    const hex = parseHex(color);
    if (hex)
        return hex;
    const rgb = color.match(/^rgba?\(\s*(\d+(?:\.\d+)?)(?:\s*,\s*|\s+)(\d+(?:\.\d+)?)(?:\s*,\s*|\s+)(\d+(?:\.\d+)?)(?:\s*[,/]\s*(\d+(?:\.\d+)?))?\s*\)$/i);
    if (rgb) {
        return {
            r: clamp(Number(rgb[1]), 0, 255),
            g: clamp(Number(rgb[2]), 0, 255),
            b: clamp(Number(rgb[3]), 0, 255),
            a: clamp(rgb[4] === undefined ? 1 : Number(rgb[4]), 0, 1),
        };
    }
    const hsl = color.match(/^hsla?\(\s*(-?\d+(?:\.\d+)?)(?:deg)?\s*[, ]\s*(\d+(?:\.\d+)?)%\s*[, ]\s*(\d+(?:\.\d+)?)%(?:\s*[,/]\s*(\d+(?:\.\d+)?))?\s*\)$/i);
    if (hsl) {
        return hslToRgba(Number(hsl[1]), Number(hsl[2]), Number(hsl[3]), hsl[4] === undefined ? 1 : Number(hsl[4]));
    }
    return parseNamedCssColor(color);
}
/** Return whether a value is a usable CSS color or CSS custom-property reference. */
function isCssColor(value) {
    const color = value.trim();
    if (!color)
        return false;
    if (/^var\(--[a-z0-9-]+\)$/i.test(color))
        return true;
    if (/^(currentcolor|transparent)$/i.test(color))
        return true;
    return parseCssColor(color) !== null;
}
/** Choose black or white text for readable contrast on a CSS color. */
function getContrastingTextColor(value) {
    const parsed = parseCssColor(value);
    if (!parsed)
        return null;
    const linear = (channel) => {
        const normalized = channel / 255;
        return normalized <= 0.03928
            ? normalized / 12.92
            : Math.pow((normalized + 0.055) / 1.055, 2.4);
    };
    const luminance = 0.2126 * linear(parsed.r) +
        0.7152 * linear(parsed.g) +
        0.0722 * linear(parsed.b);
    return luminance > 0.179 ? "#1d232b" : "#ffffff";
}
function parseHex(value) {
    const match = value.match(/^#([0-9a-f]{3,8})$/i);
    if (!match)
        return null;
    const hex = match[1];
    if (![3, 4, 6, 8].includes(hex.length))
        return null;
    const expanded = hex.length < 5
        ? hex.split("").map((channel) => channel + channel).join("")
        : hex;
    const channels = expanded.match(/.{2}/g) ?? [];
    return {
        r: parseInt(channels[0], 16),
        g: parseInt(channels[1], 16),
        b: parseInt(channels[2], 16),
        a: channels[3] === undefined ? 1 : parseInt(channels[3], 16) / 255,
    };
}
function parseNamedCssColor(value) {
    if (typeof document === "undefined" || !/^[a-z]+$/i.test(value))
        return null;
    try {
        const canvas = document.createElement("canvas");
        canvas.width = canvas.height = 1;
        const context = canvas.getContext("2d");
        if (!context)
            return null;
        context.fillStyle = "#000000";
        context.fillStyle = value;
        if (context.fillStyle === "#000000" && value.toLowerCase() !== "black")
            return null;
        context.clearRect(0, 0, 1, 1);
        context.fillStyle = value;
        context.fillRect(0, 0, 1, 1);
        const data = context.getImageData(0, 0, 1, 1).data;
        return { r: data[0], g: data[1], b: data[2], a: data[3] / 255 };
    }
    catch {
        return null;
    }
}
function hslToRgba(hue, saturation, lightness, alpha) {
    const h = ((hue % 360) + 360) % 360 / 360;
    const s = clamp(saturation / 100, 0, 1);
    const l = clamp(lightness / 100, 0, 1);
    if (s === 0) {
        const channel = Math.round(l * 255);
        return { r: channel, g: channel, b: channel, a: clamp(alpha, 0, 1) };
    }
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    return {
        r: Math.round(hueChannel(p, q, h + 1 / 3) * 255),
        g: Math.round(hueChannel(p, q, h) * 255),
        b: Math.round(hueChannel(p, q, h - 1 / 3) * 255),
        a: clamp(alpha, 0, 1),
    };
}
function hueChannel(p, q, value) {
    let channel = value;
    if (channel < 0)
        channel += 1;
    if (channel > 1)
        channel -= 1;
    if (channel < 1 / 6)
        return p + (q - p) * 6 * channel;
    if (channel < 1 / 2)
        return q;
    if (channel < 2 / 3)
        return p + (q - p) * (2 / 3 - channel) * 6;
    return p;
}
function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
}

/*
 * Public API Surface of @theredhead/lucid-foundation
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ArrayDatasource, ArrayTreeDatasource, ConsoleLoggingStrategy, DefaultMarkdownParser, EmailDetector, Emitter, EmojiDetector, FilterableArrayDatasource, FilterableArrayTreeDatasource, KeyedRegistry, LocalStorageStrategy, Logger, LoggerFactory, PhoneNumberDetector, Registry, RestDatasource, STORAGE_STRATEGY, SortDirection, SortableArrayDatasource, SortableArrayTreeDatasource, StorageService, TextTemplateProcessor, UISurface, UI_DEFAULT_SURFACE_TYPE, UrlDetector, XmlTemplateParser, XmlTemplateProcessor, XmlTemplateSerializer, applyDataDetectors, compileSortExpression, compileTreeSortExpression, decodeJwt, extractClaim, extractPermissions, getContrastingTextColor, getRegisteredDataDetectors, getRegisteredTextTemplateBlockProviders, haveRegisteredTextTemplateBlockProvider, isCssColor, isExpired, isFilterableDatasource, isFilterableTreeDatasource, isInsertableDatasource, isJwtValid, isNotYetValid, isRemovableDatasource, isReorderableDatasource, isSortableDatasource, isSortableTreeDatasource, isTreeDatasource, markdownToHtml, moveItemInArray, moveItemInArrayPure, moveItemToArray, moveItemToArrayPure, parseCssColor, registerDataDetector, registerTextTemplateBlockProvider, secondsUntilExpiry, unregisterDataDetector, unregisterTextTemplateBlockProvider, validateJwt };
//# sourceMappingURL=theredhead-lucid-foundation.mjs.map
