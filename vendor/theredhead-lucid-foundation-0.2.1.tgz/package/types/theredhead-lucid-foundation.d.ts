import * as i0 from '@angular/core';
import { Predicate, InjectionToken } from '@angular/core';
export { Predicate } from '@angular/core';

/**
 * Strategy interface for log output.
 *
 * Implement this interface to redirect log messages to a remote
 * service, an in-memory buffer, or any other sink. The default
 * implementation ({@link ConsoleLoggingStrategy}) writes to the
 * browser console.
 */
interface ILoggingStrategy {
    /** Emit an debug message. */
    debug(context: string, message: string, args: unknown[]): void;
    /** Emit an informational message. */
    info(context: string, message: string, args: unknown[]): void;
    /** Emit a warning. */
    warn(context: string, message: string, args: unknown[]): void;
    /** Emit an error. */
    error(context: string, message: string, args: unknown[]): void;
}
/**
 * Lightweight, context-scoped logger.
 *
 * Each `Logger` instance is bound to a **context** string (typically
 * the class or feature name) and a pluggable {@link ILoggingStrategy}.
 * The context is automatically prepended to every message so that log
 * output is easy to filter.
 *
 * @example
 * ```ts
 * const log = new Logger(new ConsoleLoggingStrategy(), "MyService");
 * log.info("initialised");        // → "[2026-03-23T12:00:00.000Z] MyService: initialised"
 * log.warn("deprecation", [api]); // → "[2026-03-23T12:00:00.000Z] MyService: deprecation" [api]
 * ```
 */
declare class Logger {
    private readonly strategy;
    private readonly context;
    constructor(strategy: ILoggingStrategy, context: string);
    /** Log a debug-level message. */
    debug(message: string, args?: unknown[]): void;
    /** Log an informational message. */
    info(message: string, args?: unknown[]): void;
    /** Log a warning. */
    warn(message: string, args?: unknown[]): void;
    /** Log an error. */
    error(message: string, args?: unknown[]): void;
}
/**
 * Default {@link ILoggingStrategy} that delegates to the browser
 * `console`.
 *
 * Messages are formatted as
 * `"[<ISO-timestamp>] <context>: <message>"` followed by any
 * additional arguments spread into the console call.
 */
declare class ConsoleLoggingStrategy implements ILoggingStrategy {
    /** @inheritdoc */
    debug(context: string, message: string, args: unknown[]): void;
    /** @inheritdoc */
    info(context: string, message: string, args: unknown[]): void;
    /** @inheritdoc */
    warn(context: string, message: string, args: unknown[]): void;
    /** @inheritdoc */
    error(context: string, message: string, args: unknown[]): void;
}

/**
 * Angular service that creates context-scoped {@link Logger} instances.
 *
 * Inject `LoggerFactory` wherever you need a logger and call
 * {@link createLogger} with a context string (typically the class name).
 * A {@link ConsoleLoggingStrategy} is used by default, but you can
 * supply any {@link ILoggingStrategy} to redirect output.
 *
 * @example
 * ```ts
 * export class MyComponent {
 *   private readonly log = inject(LoggerFactory).createLogger("MyComponent");
 *
 *   public ngOnInit(): void {
 *     this.log.debug("component initialised");
 *   }
 * }
 * ```
 */
declare class LoggerFactory {
    /**
     * Creates a new {@link Logger} bound to the given context.
     *
     * @param context  A label prepended to every log message (e.g. a
     *                 class name or feature area).
     * @param strategy The logging back-end to use.  Defaults to
     *                 {@link ConsoleLoggingStrategy}.
     * @returns A ready-to-use `Logger` instance.
     */
    createLogger(context: string, strategy?: ILoggingStrategy): Logger;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerFactory>;
}

/**
 * A pluggable Markdown-to-HTML converter.
 *
 * The library ships a lightweight built-in converter (via
 * {@link DefaultMarkdownParser}) that covers headings, bold, italic,
 * strikethrough, inline code, links, images, lists, blockquotes,
 * fenced code blocks, and GFM tables with column alignment.
 *
 * For full CommonMark / GFM support, consumers can supply their own
 * implementation backed by a third-party parser such as `marked` or
 * `markdown-it`.
 *
 * This module has **no Angular dependency** — it is plain TypeScript
 * and can be used in any context (Angular DI, server-side, tests, etc.).
 *
 * @example
 * ```ts
 * import { DefaultMarkdownParser } from '@theredhead/lucid-foundation';
 *
 * const parser = new DefaultMarkdownParser();
 * const html = parser.toHtml('# Hello\n\n**world**');
 * ```
 */
interface MarkdownParser {
    /**
     * Converts a Markdown string to an HTML string.
     *
     * @param markdown - The raw Markdown source text.
     * @returns An HTML string.
     */
    toHtml(markdown: string): string;
}
/**
 * Converts a Markdown string to an HTML string using the built-in
 * GFM-capable converter.
 *
 * Supports: headings (h1–h3), bold, italic, bold+italic, strikethrough,
 * underline, inline code, links, images, unordered lists, ordered lists,
 * blockquotes, fenced code blocks, horizontal rules, and GFM tables with
 * left/center/right column alignment.
 *
 * This function is used by {@link DefaultMarkdownParser} and is also
 * exported for callers that prefer a plain function over a class.
 */
declare function markdownToHtml(md: string): string;
/**
 * The built-in GFM-capable {@link MarkdownParser} implementation.
 *
 * Delegates to {@link markdownToHtml}. No configuration required —
 * construct and call `toHtml()`.
 *
 * @example
 * ```ts
 * import { DefaultMarkdownParser } from '@theredhead/lucid-foundation';
 *
 * const parser = new DefaultMarkdownParser();
 * console.log(parser.toHtml('**hello**')); // <b>hello</b>
 * ```
 */
declare class DefaultMarkdownParser implements MarkdownParser {
    /**
     * Converts a Markdown string to HTML using the built-in GFM converter.
     * @param markdown - Raw Markdown source.
     * @returns HTML string.
     */
    toHtml(markdown: string): string;
}

/**
 * Minimal typed event emitter — a lightweight alternative to RxJS
 * `Subject` for discrete notifications.
 *
 * ```ts
 * const event = new Emitter<RowChangedNotification>();
 *
 * // Consumer (e.g. in a component):
 * const unsub = event.subscribe(n => console.log(n.rowIndex));
 * destroyRef.onDestroy(unsub);
 *
 * // Producer (e.g. in a datasource):
 * event.emit({ rowIndex: 42 });
 * ```
 *
 * @typeParam T - The event payload type.
 */
declare class Emitter<T> {
    private readonly listeners;
    /**
     * Registers a listener that is invoked every time the event fires.
     *
     * @param fn - Callback receiving the event payload.
     * @returns A teardown function that removes the listener when called.
     *          Designed to be passed directly to `DestroyRef.onDestroy()`.
     */
    subscribe(fn: (event: T) => void): () => void;
    /**
     * Fires the event, invoking all registered listeners synchronously.
     * Listener errors are caught individually so one failing handler
     * never prevents the remaining listeners from executing.
     * Caught errors are reported via `console.error` so they still
     * surface in logs without causing unhandled exceptions.
     *
     * @param event - The payload to deliver to every listener.
     */
    emit(event: T): void;
}

/**
 * Read-only contract for an unordered collection of registered values.
 */
interface IRegistry<T> {
    /**
     * Number of registered values.
     */
    readonly size: number;
    /**
     * Returns `true` when the value is registered.
     */
    has(value: T): boolean;
    /**
     * Returns all registered values.
     */
    values(): IterableIterator<T>;
    /**
     * Returns a stable snapshot of the registered values.
     */
    toArray(): readonly T[];
}
/**
 * Mutable set-like registry implementation.
 */
declare class Registry<T> implements IRegistry<T> {
    protected readonly store: Set<T>;
    constructor(values?: Iterable<T>);
    /**
     * Number of registered values.
     */
    get size(): number;
    /**
     * Registers a value.
     */
    register(value: T): void;
    /**
     * Removes a registered value.
     */
    unregister(value: T): void;
    /**
     * Removes all registered values.
     */
    clear(): void;
    /** @inheritdoc */
    has(value: T): boolean;
    /** @inheritdoc */
    values(): IterableIterator<T>;
    /** @inheritdoc */
    toArray(): readonly T[];
}
/**
 * Read-only contract for a registry whose values are addressed by key.
 */
interface IKeyedRegistry<T> {
    /**
     * Number of registered entries.
     */
    readonly size: number;
    /**
     * Returns `true` when an entry exists for the key.
     */
    has(key: string): boolean;
    /**
     * Looks up a registered entry by key.
     */
    get(key: string): T | undefined;
    /**
     * Returns all registered keys.
     */
    keys(): IterableIterator<string>;
    /**
     * Returns all registered values.
     */
    values(): IterableIterator<T>;
    /**
     * Returns all registered key-value pairs.
     */
    entries(): IterableIterator<[string, T]>;
    /**
     * Returns a stable snapshot of the registered entries.
     */
    toMap(): ReadonlyMap<string, T>;
    /**
     * Returns a stable snapshot of the registered values.
     */
    toArray(): readonly T[];
}
/**
 * Mutable map-like registry implementation.
 */
declare class KeyedRegistry<T> implements IKeyedRegistry<T> {
    protected readonly store: Map<string, T>;
    constructor(entries?: Iterable<readonly [string, T]>);
    /**
     * Number of registered entries.
     */
    get size(): number;
    /**
     * Registers or replaces an entry.
     */
    register(key: string, value: T): void;
    /**
     * Removes a registered entry.
     */
    unregister(key: string): void;
    /**
     * Removes all registered entries.
     */
    clear(): void;
    /** @inheritdoc */
    has(key: string): boolean;
    /** @inheritdoc */
    get(key: string): T | undefined;
    /** @inheritdoc */
    keys(): IterableIterator<string>;
    /** @inheritdoc */
    values(): IterableIterator<T>;
    /** @inheritdoc */
    entries(): IterableIterator<[string, T]>;
    /** @inheritdoc */
    toMap(): ReadonlyMap<string, T>;
    /** @inheritdoc */
    toArray(): readonly T[];
}

/** Direction in which a column can be sorted. */
declare enum SortDirection {
    /** Sort values from lowest to highest (A → Z, 0 → 9). */
    Ascending = "asc",
    /** Sort values from highest to lowest (Z → A, 9 → 0). */
    Descending = "desc"
}
/**
 * An ordered list of sort criteria applied to a datasource.
 *
 * The first entry is the primary sort; subsequent entries act as
 * tie-breakers.
 *
 * @typeParam T - The row object type.
 */
type SortExpression<T> = {
    /** The property of `T` to sort by. */
    columnKey: keyof T;
    /** Whether to sort ascending or descending. */
    direction: SortDirection;
}[];
/**
 * Compiles a {@link SortExpression} into a comparator function.
 *
 * Uses locale-aware string comparison by default. The first entry is the
 * primary sort; subsequent entries act as tie-breakers.
 *
 * @typeParam T - The row object type.
 * @param expression - The sort expression to compile.
 * @returns A comparator function `(a, b) => number`.
 *
 * @example
 * ```ts
 * const cmp = compileSortExpression<Employee>([
 *   { columnKey: 'department', direction: SortDirection.Ascending },
 *   { columnKey: 'name', direction: SortDirection.Ascending },
 * ]);
 * const sorted = employees.sort(cmp);
 * ```
 */
declare function compileSortExpression<T>(expression: SortExpression<T>): (a: T, b: T) => number;
/**
 * Compiles a {@link SortExpression} into a comparator for {@link TreeNode} objects.
 *
 * Like {@link compileSortExpression} but reaches into `node.data` to access
 * the sort key, which is the standard layout for tree datasources.
 *
 * @typeParam T - The data payload type carried by each tree node.
 * @param expression - The sort expression to compile.
 * @returns A comparator function `(a, b) => number` operating on tree nodes.
 */
declare function compileTreeSortExpression<T>(expression: SortExpression<T>): (a: {
    data: T;
}, b: {
    data: T;
}) => number;

/**
 * Describes one or more filter criteria for a datasource.
 *
 * Each element is either:
 * - **Property-level** – targets a single column; the predicate receives
 *   the value of that property (`T[K]`).
 * - **Row-level** – no `property` key; the predicate receives the
 *   entire row object (`T`).
 *
 * @typeParam T - The row object type.
 * @typeParam K - The specific property key (inferred when `property` is provided).
 */
type CompiledFilter<T, K extends keyof T = keyof T> = ({
    /** The property of `T` to filter on. */
    property: K;
    /** Predicate that receives the property's value and returns `true` to keep the row. */
    predicate: Predicate<T[K]>;
} | {
    /** Predicate that receives the full row object and returns `true` to keep it. */
    predicate: Predicate<T>;
})[];

/**
 * Defines a contiguous range of row indices.
 *
 * Used to request a slice of data from a datasource (e.g. for
 * virtual scrolling or pagination).
 */
interface RangeDefinition {
    /** Zero-based index of the first row in the range. */
    start: number;
    /** Number of rows in the range. */
    length: number;
}

/** Notification emitted when a single row's data has changed. */
interface RowChangedNotification {
    /** Zero-based index of the changed row. */
    rowIndex: number;
}
/** Notification emitted when a contiguous range of rows has changed. */
interface RowRangeChangedNotification {
    /** The range of rows that changed. */
    range: RangeDefinition;
}

/**
 * Represents a single row that may or may not be immediately available.
 */
type RowResult<T> = T | Promise<T>;
/**
 * Core datasource contract for data-driven views (table, repeater, etc.).
 *
 * Implementations provide the total item count and on-demand access
 * to individual rows by index, optionally returning a `Promise` for
 * rows that are fetched asynchronously.
 *
 * @typeParam T - The row object type.
 */
interface IDatasource<T = unknown> {
    /** Returns the total number of items, synchronously or asynchronously. */
    getNumberOfItems(): number | Promise<number>;
    /**
     * Returns the row object at the given index.
     *
     * @param rowIndex - Zero-based index of the row to retrieve.
     * @returns The row value, or a `Promise` that resolves to it.
     */
    getObjectAtRowIndex(rowIndex: number): RowResult<T>;
}
/**
 * A datasource that supports server-side or in-memory sorting.
 *
 * @typeParam T - The row object type.
 */
interface ISortableDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Applies the given sort expression to the datasource.
     *
     * The expression is a serializable array of `{ columnKey, direction }` objects
     * that can safely cross network boundaries (e.g. to a REST or GraphQL backend).
     *
     * Pass `null` to clear the current sort and restore the original order.
     *
     * @param expression - One or more sort criteria in priority order, or `null` to clear.
     */
    sortBy(expression: SortExpression<T> | null): void;
}
/**
 * A datasource that supports server-side or in-memory filtering.
 *
 * @typeParam T - The row object type.
 */
interface IFilterableDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Applies the given filter expression to the datasource.
     *
     * The expression is a structured array of property-level or row-level
     * predicates. Pass `null` or `undefined` to clear the filter and
     * restore all rows.
     *
     * @param expression - The filter criteria to apply, or `null`/`undefined` to clear.
     */
    filterBy(expression: CompiledFilter<T> | null | undefined): void;
}
/**
 * A datasource that supports notifying consumers about changes
 * to specific rows or ranges of rows.
 *
 * @typeParam T - The row object type.
 */
interface IActiveDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Fires when a specific row has changed.
     * The event includes the index of the changed row.
     */
    noteRowChanged?: Emitter<RowChangedNotification>;
    /**
     * Fires when a range of rows has changed.
     * The event includes the definition of the changed range.
     */
    noteRowRangeChanged?: Emitter<RowRangeChangedNotification>;
}
/**
 * Contract for an autocomplete suggestion provider.
 *
 * `completeFor` receives the current query string and the items that
 * are already selected (so the implementation can exclude them) and
 * returns an array of suggestions.
 *
 * @typeParam T - The suggestion item type.
 */
interface AutocompleteDatasource<T> {
    completeFor(query: string, selection: readonly T[]): T[];
}
/**
 * A single node in a hierarchical tree structure.
 *
 * @typeParam T - The data payload type carried by each node.
 */
interface TreeNode<T = unknown> {
    /** Unique identifier for the node. */
    id: string;
    /** The data payload associated with this node. */
    data: T;
    /** Child nodes. An empty array or `undefined` indicates a leaf node. */
    children?: TreeNode<T>[];
    /**
     * Whether the node starts in an expanded state.
     * Defaults to `false` when omitted.
     */
    expanded?: boolean;
    /** Whether the node is disabled (cannot be selected or toggled). */
    disabled?: boolean;
    /**
     * Optional icon SVG inner content (paths, circles, etc.) rendered
     * via `<ui-icon>`. When omitted, no icon is shown.
     */
    icon?: string;
}
/**
 * Core datasource contract for tree-view.
 *
 * Implementations provide the root nodes and child resolution,
 * following the same philosophy as `IDatasource<T>` for flat data
 * but adapted for hierarchical data.
 *
 * @typeParam T - The data payload type.
 */
interface ITreeDatasource<T = unknown> {
    /**
     * Returns the root-level nodes of the tree.
     *
     * May return synchronously or as a `Promise` for lazy-loaded trees.
     */
    getRootNodes(): TreeNode<T>[] | Promise<TreeNode<T>[]>;
    /**
     * Returns the children of the given node.
     *
     * The default implementation reads `node.children`. Override this
     * method to support lazy-loading children from a remote source.
     *
     * @param node - The parent node whose children are requested.
     */
    getChildren(node: TreeNode<T>): TreeNode<T>[] | Promise<TreeNode<T>[]>;
    /**
     * Returns `true` if the node has children (or might have children
     * that can be lazy-loaded).
     *
     * The default implementation checks `node.children?.length > 0`.
     */
    hasChildren(node: TreeNode<T>): boolean;
}
/**
 * How the tree-view handles selection.
 *
 * - `'none'`     — No selection.
 * - `'single'`   — Clicking or arrow-keying selects exactly one node.
 * - `'path'`     — Like single, but arrow-key navigation always
 *                  selects the deepest visible child under the
 *                  focused node, keeping an entire ancestor path
 *                  "active".
 * - `'multiple'` — Checkbox-style multi-select (toggle on click/Space).
 */
type TreeSelectionMode = "none" | "single" | "path" | "multiple";
/**
 * Optional tree filtering capability.
 *
 * Implement this interface alongside `ITreeDatasource` when the datasource supports
 * filtering hierarchical data. This is commonly used by `UIMasterDetailView` in tree mode.
 *
 * @typeParam T - The data payload type.
 */
interface IFilterableTreeDatasource<T = unknown> extends ITreeDatasource<T> {
    /**
     * Apply a filter expression to the tree datasource.
     *
     * This should update the internal state to reflect filtered tree structure.
     * Subsequent calls to `getRootNodes()` and `getChildren()` should return filtered data.
     *
     * @param expression - The filter expression to apply.
     */
    filterBy(expression: CompiledFilter<T> | null | undefined): void;
}
/**
 * Optional tree sorting capability.
 *
 * Implement this interface alongside `ITreeDatasource` when the datasource supports
 * sorting hierarchical data at all levels (root nodes and their descendants).
 *
 * @typeParam T - The data payload type.
 */
interface ISortableTreeDatasource<T = unknown> extends ITreeDatasource<T> {
    /**
     * Applies a serializable sort expression to the tree datasource.
     *
     * The expression describes which properties of the data payload `T` to sort by.
     * Sorting is applied recursively at all levels (root nodes and all descendants).
     * Subsequent calls to `getRootNodes()` and `getChildren()` should return sorted data.
     *
     * Pass `null` to clear sorting and restore the original insertion order.
     *
     * @param expression - Sort criteria in priority order, or `null` to clear.
     */
    sortBy(expression: SortExpression<T> | null): void;
}
/**
 * A datasource that supports reordering items by index.
 *
 * Implement this interface when the datasource can move an item from one
 * position to another. UI components use the {@link isReorderableDatasource}
 * type guard to detect this capability before calling `moveItem`.
 *
 * @typeParam T - The row object type.
 */
interface IReorderableDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Moves the item at `fromIndex` to `toIndex`, shifting other items
     * to accommodate.
     *
     * After this call, subsequent calls to `getObjectAtRowIndex()` and
     * `getNumberOfItems()` must reflect the new order.
     *
     * @param fromIndex - The current zero-based index of the item to move.
     * @param toIndex   - The desired zero-based index for the item.
     */
    moveItem(fromIndex: number, toIndex: number): void;
}
/**
 * A datasource that supports inserting items at a given index.
 *
 * Implement this interface when the datasource can accept new items
 * (e.g. as the target of a cross-list drag-and-drop transfer).
 * UI components use the {@link isInsertableDatasource} type guard
 * to detect this capability.
 *
 * @typeParam T - The row object type.
 */
interface IInsertableDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Inserts `item` at `index`, shifting subsequent items to the right.
     *
     * After this call, `getNumberOfItems()` must return one more than
     * before, and `getObjectAtRowIndex(index)` must return the inserted item.
     *
     * @param index - The zero-based position at which to insert.
     * @param item  - The item to insert.
     */
    insertItem(index: number, item: T): void;
}
/**
 * A datasource that supports removing items by index.
 *
 * Implement this interface when the datasource can give up items
 * (e.g. as the source of a cross-list drag-and-drop transfer).
 * UI components use the {@link isRemovableDatasource} type guard
 * to detect this capability.
 *
 * @typeParam T - The row object type.
 */
interface IRemovableDatasource<T = unknown> extends IDatasource<T> {
    /**
     * Removes and returns the item at `index`, shifting subsequent items
     * to the left.
     *
     * After this call, `getNumberOfItems()` must return one fewer than
     * before.
     *
     * @param index - The zero-based position of the item to remove.
     * @returns The removed item.
     */
    removeItem(index: number): T;
}

/**
 * Simple in-memory datasource backed by an array.
 *
 * The constructor takes a defensive copy of the provided data so that
 * external mutations to the source array do not affect the table.
 *
 * Implements {@link IActiveDatasource} so that UI components
 * automatically stay in sync when rows are inserted, removed, moved,
 * or individually mutated (via {@link notifyRowChanged}).
 *
 * Implements {@link IReorderableDatasource}, {@link IInsertableDatasource},
 * and {@link IRemovableDatasource} so UI components can reorder items
 * and transfer items between datasources via the capability-detection
 * pattern.
 *
 * @typeParam T - The row object type.
 */
declare class ArrayDatasource<T> implements IDatasource<T>, IActiveDatasource<T>, IReorderableDatasource<T>, IInsertableDatasource<T>, IRemovableDatasource<T> {
    /** @inheritdoc */
    readonly noteRowChanged: Emitter<RowChangedNotification>;
    /** @inheritdoc */
    readonly noteRowRangeChanged: Emitter<RowRangeChangedNotification>;
    protected readonly rows: T[];
    constructor(data: T[]);
    getNumberOfItems(): number | Promise<number>;
    getObjectAtRowIndex(rowIndex: number): RowResult<T>;
    /**
     * Notifies consumers that the row at the given index has been
     * externally mutated (e.g. property values changed in-place).
     *
     * Call this after directly modifying a row object so that any
     * listening UI (such as a table view) can re-read the data.
     *
     * @param rowIndex - Zero-based index of the changed row.
     */
    notifyRowChanged(rowIndex: number): void;
    /**
     * Notifies consumers that all visible data should be considered
     * stale. Call this after bulk mutations that affect many rows.
     */
    notifyDataChanged(): void;
    /** @inheritdoc */
    moveItem(fromIndex: number, toIndex: number): void;
    /** @inheritdoc */
    insertItem(index: number, item: T): void;
    /** @inheritdoc */
    removeItem(index: number): T;
}

/**
 * An in-memory array datasource that supports filtering via a
 * {@link CompiledFilter}.
 *
 * When an expression is applied the datasource compiles it into a
 * single predicate, re-derives its visible rows from the original
 * data, and exposes only the matching items. The underlying array
 * is never mutated.
 *
 * @typeParam T - The row object type.
 *
 * @example
 * ```ts
 * const ds = new FilterableArrayDatasource(employees);
 * ds.filterBy([{ predicate: row => row.age > 30 }]);
 * ```
 */
declare class FilterableArrayDatasource<T> extends ArrayDatasource<T> implements IFilterableDatasource<T> {
    /** The full, unfiltered dataset. */
    private readonly _allRows;
    /** The currently visible (filtered) rows. */
    private _filteredRows;
    /**
     * The full, unfiltered dataset.
     *
     * Useful when consumers need to inspect the original data while a
     * filter is active (e.g. to infer field types from a sample row
     * without the result disappearing when the filter yields no matches).
     */
    get allRows(): readonly T[];
    constructor(data: T[]);
    getNumberOfItems(): number;
    getObjectAtRowIndex(rowIndex: number): T;
    /**
     * Applies a structured {@link CompiledFilter} to the datasource.
     *
     * The expression is compiled into a single predicate once, which is
     * then applied to every row. Pass an empty array (or `null` /
     * `undefined`) to clear the filter and show all rows.
     *
     * - **Property-level** entries test a single property value.
     * - **Row-level** entries test the entire row object.
     * - All entries must pass (AND) for a row to be included.
     */
    filterBy(expression: CompiledFilter<T> | null | undefined): void;
    /**
     * Compiles a {@link CompiledFilter} into a single predicate
     * function that can be applied to all rows.
     */
    private compileExpression;
    /** Clears any active filter, restoring all rows. */
    clearFilter(): void;
}

/**
 * An in-memory array datasource that supports sorting via a comparator function.
 *
 * When a comparator is applied, the datasource re-derives its visible rows
 * from the original data. The underlying array is never mutated.
 *
 * @typeParam T - The row object type.
 *
 * @example
 * ```ts
 * const ds = new SortableArrayDatasource(employees);
 * ds.applyComparator((a, b) => a.age - b.age);
 * ```
 */
declare class SortableArrayDatasource<T> extends ArrayDatasource<T> implements ISortableDatasource<T> {
    /** The full, unsorted dataset. */
    private readonly _allRows;
    /** The currently sorted rows. */
    private _sortedRows;
    /**
     * The full, unsorted dataset.
     *
     * Useful when consumers need to inspect the original data while a
     * sort is active.
     */
    get allRows(): readonly T[];
    constructor(data: T[]);
    getNumberOfItems(): number;
    getObjectAtRowIndex(rowIndex: number): T;
    /**
     * Applies a serializable sort expression to the datasource.
     *
     * The expression is compiled into a comparator function internally.
     * Pass `null` to clear the sort and restore the original insertion order.
     *
     * @param expression - Sort criteria, or `null` to clear.
     */
    sortBy(expression: SortExpression<T> | null): void;
    /**
     * Applies a comparator function to sort the datasource.
     *
     * Pass `null` or `undefined` to clear the sort and restore the original
     * insertion order.
     *
     * @param comparator - The comparator function, or null/undefined to clear sorting.
     */
    applyComparator(comparator: ((a: T, b: T) => number) | null | undefined): void;
}

/**
 * Very small lazy REST datasource.
 *
 * It requests pages from:
 * `${baseUrl}?pageIndex=<n>&pageSize=<size>`
 * and caches each page in memory after the first request.
 */
declare class RestDatasource<T> implements IDatasource<T> {
    private readonly baseUrl;
    private readonly pageSize;
    private readonly fetchFn;
    private readonly pageCache;
    private readonly inFlightPages;
    private totalItems;
    constructor(baseUrl: string, pageSize?: number, fetchFn?: typeof fetch);
    getNumberOfItems(): number | Promise<number>;
    getObjectAtRowIndex(rowIndex: number): RowResult<T>;
    private ensurePageLoaded;
    private fetchPage;
    private extractItems;
    private trySetTotalItems;
}

/**
 * Simple in-memory tree datasource backed by an array of root nodes.
 *
 * The constructor takes a defensive copy of the root array so that
 * external mutations do not affect the tree. Child nodes are read
 * from a configurable property on each {@link TreeNode}, defaulting
 * to `'children'`.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * // Default — reads children from `node.children`
 * const ds = new ArrayTreeDatasource([
 *   { id: '1', data: 'Root', children: [
 *     { id: '1.1', data: 'Child' },
 *   ]},
 * ]);
 *
 * // Custom property — reads children from `node.items`
 * const ds2 = new ArrayTreeDatasource(roots, 'items');
 * ```
 */
declare class ArrayTreeDatasource<T = unknown> implements ITreeDatasource<T> {
    private readonly roots;
    private readonly childrenProperty;
    constructor(roots: TreeNode<T>[], childrenProperty?: keyof TreeNode<T>);
    /** Returns the root-level nodes. */
    getRootNodes(): TreeNode<T>[];
    /** Returns the children of the given node. */
    getChildren(node: TreeNode<T>): TreeNode<T>[];
    /** Returns `true` when the node has at least one child. */
    hasChildren(node: TreeNode<T>): boolean;
}

/**
 * An in-memory tree datasource that supports filtering via a
 * {@link CompiledFilter}.
 *
 * When an expression is applied the datasource compiles it into a
 * single predicate, re-derives its visible tree structure from the
 * original data, and exposes only the matching nodes (plus their
 * ancestors). The underlying tree is never mutated.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * const ds = new FilterableArrayTreeDatasource([
 *   { id: '1', data: 'Root', children: [
 *     { id: '1.1', data: 'Child A' },
 *     { id: '1.2', data: 'Child B' },
 *   ]},
 * ]);
 *
 * // Show only nodes containing 'A' in their data
 * ds.filterBy([{ predicate: node => String(node).includes('A') }]);
 * ```
 */
declare class FilterableArrayTreeDatasource<T = unknown> extends ArrayTreeDatasource<T> implements IFilterableTreeDatasource<T> {
    /** The full, unfiltered tree. */
    private readonly _allRoots;
    /** The currently filtered tree. */
    private _filteredRoots;
    /** Cached children property key for accessing child arrays. */
    private readonly _childrenProperty;
    /**
     * The full, unfiltered root nodes.
     *
     * Useful when consumers need to inspect the original tree structure
     * while a filter is active.
     */
    get allRoots(): TreeNode<T>[];
    constructor(roots: TreeNode<T>[], childrenProperty?: keyof TreeNode<T>);
    getRootNodes(): TreeNode<T>[];
    /**
     * Applies a structured {@link CompiledFilter} to the tree.
     *
     * The expression is compiled into a single predicate once, which is
     * then applied to each node's `data`. Matching nodes and their
     * ancestors are kept. Pass an empty array (or `null` / `undefined`)
     * to clear the filter and show all nodes.
     *
     * - **Property-level** entries test a single property of `T`.
     * - **Row-level** entries test the entire `T` object.
     * - All entries must pass (AND) for a node to be included.
     */
    filterBy(expression: CompiledFilter<T> | null | undefined): void;
    /** Clears any active filter, restoring all nodes. */
    clearFilter(): void;
    /**
     * Compiles a {@link CompiledFilter} into a single predicate
     * function that can be applied to each node's `data`.
     */
    private compileExpression;
    /**
     * Recursively filter tree nodes, excluding non-matching nodes and
     * their descendants.
     *
     * A node is kept if:
     * - The node itself matches the predicate, OR
     * - At least one of its descendants matches the predicate
     *
     * @param nodes - The nodes to filter.
     * @param predicate - The predicate function.
     * @param childrenProp - The property name for children.
     * @returns Filtered node tree.
     */
    private filterNodes;
    /**
     * Create a structural copy of tree nodes to avoid mutations to the
     * original tree shape. Each {@link TreeNode} wrapper is shallow-copied
     * (`{ ...node }`) so the `data` payload remains a shared reference.
     * This is intentional — deep-cloning arbitrary `T` is not feasible.
     *
     * @param nodes - The nodes to copy.
     * @param childrenProp - The property name for children.
     * @returns Structurally-copied node tree (shared `data` references).
     */
    private deepCopyNodes;
}

/**
 * An in-memory tree datasource that supports sorting via a comparator function.
 *
 * When a comparator is applied, the datasource re-derives its visible tree
 * structure from the original data. Nodes are sorted at each level of the tree
 * (root nodes and all children recursively). The underlying tree is never mutated.
 *
 * @typeParam T - The data payload type.
 *
 * @example
 * ```ts
 * const ds = new SortableArrayTreeDatasource([
 *   { id: '1', data: { name: 'Beta' }, children: [
 *     { id: '1.1', data: { name: 'Zebra' } },
 *     { id: '1.2', data: { name: 'Apple' } },
 *   ]},
 * ]);
 *
 * // Sort all levels alphabetically by data.name
 * ds.applyComparator((a, b) => a.data.name.localeCompare(b.data.name));
 * ```
 */
declare class SortableArrayTreeDatasource<T = unknown> extends ArrayTreeDatasource<T> implements ISortableTreeDatasource<T> {
    /** The full, unsorted tree. */
    private readonly _allRoots;
    /** The currently sorted tree. */
    private _sortedRoots;
    /** Cached children property key for accessing child arrays. */
    private readonly _childrenProperty;
    /**
     * The full, unsorted root nodes.
     *
     * Useful when consumers need to inspect the original tree structure
     * while a sort is active.
     */
    get allRoots(): TreeNode<T>[];
    constructor(roots: TreeNode<T>[], childrenProperty?: keyof TreeNode<T>);
    getRootNodes(): TreeNode<T>[];
    /**   * Applies a serializable sort expression to the tree.
     *
     * The expression is compiled into a tree-node comparator that sorts by
     * `node.data` properties. Sorting is applied recursively at all levels.
     * Pass `null` to clear sorting and restore the original insertion order.
     *
     * @param expression - Sort criteria, or `null` to clear.
     */
    sortBy(expression: SortExpression<T> | null): void;
    /**   * Applies a comparator function to sort the tree at all levels.
     *
     * The comparator is applied recursively to root nodes and all descendants.
     * Pass `null` or `undefined` to clear the sort and restore the original
     * insertion order.
     *
     * @param comparator - The comparator function, or null/undefined to clear sorting.
     */
    applyComparator<U = TreeNode<T>>(comparator: ((a: U, b: U) => number) | null | undefined): void;
    /**
     * Structural copy of tree nodes — each {@link TreeNode} wrapper is
     * shallow-copied (`{ ...node }`) so `data` remains a shared reference.
     *
     * @internal
     */
    private deepCopyNodes;
    /**
     * Recursively sort tree nodes and their children.
     *
     * @internal
     */
    private sortNodes;
}

/**
 * Type guards for datasource capability detection.
 *
 * Use these guards in UI components to check if a datasource supports optional
 * capabilities before calling those methods. This enables graceful degradation
 * and supports datasources with arbitrary capability combinations.
 *
 * @example
 * ```ts
 * export class UIMyTable {
 *   public readonly datasource = input.required<IDatasource<Item>>();
 *
 *   protected handleFilter(expression: unknown): void {
 *     const ds = this.datasource();
 *     if (isFilterableDatasource(ds)) {
 *       ds.filterBy(expression);
 *     }
 *     // Otherwise, silently ignore filter request; table shows all data
 *   }
 *
 *   protected handleSort(expression: unknown): void {
 *     const ds = this.datasource();
 *     if (isSortableDatasource(ds)) {
 *       ds.sortBy(expression);
 *     }
 *     // Otherwise, silently ignore sort request; table shows insertion order
 *   }
 * }
 * ```
 */

/**
 * Check if a datasource supports filtering.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `IFilterableDatasource<T>`; false otherwise.
 */
declare function isFilterableDatasource<T>(datasource: unknown): datasource is IFilterableDatasource<T>;
/**
 * Check if a datasource supports sorting.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `ISortableDatasource<T>`; false otherwise.
 */
declare function isSortableDatasource<T>(datasource: unknown): datasource is ISortableDatasource<T>;
/**
 * Check if a datasource is a tree datasource that supports filtering.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `IFilterableTreeDatasource<T>`; false otherwise.
 */
declare function isFilterableTreeDatasource<T>(datasource: unknown): datasource is IFilterableTreeDatasource<T>;
/**
 * Check if a datasource is a tree datasource.
 *
 * Tests for the presence of the three methods that define
 * {@link ITreeDatasource}: `getRootNodes`, `getChildren`, and
 * `hasChildren`.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `ITreeDatasource<T>`; `false` otherwise.
 */
declare function isTreeDatasource<T>(datasource: unknown): datasource is ITreeDatasource<T>;
/**
 * Check if a datasource is a tree datasource that supports sorting.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns True if datasource implements `ISortableTreeDatasource<T>`; false otherwise.
 */
declare function isSortableTreeDatasource<T>(datasource: unknown): datasource is ISortableTreeDatasource<T>;
/**
 * Check if a datasource supports reordering items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IReorderableDatasource<T>`; `false` otherwise.
 */
declare function isReorderableDatasource<T>(datasource: unknown): datasource is IReorderableDatasource<T>;
/**
 * Check if a datasource supports inserting items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IInsertableDatasource<T>`; `false` otherwise.
 */
declare function isInsertableDatasource<T>(datasource: unknown): datasource is IInsertableDatasource<T>;
/**
 * Check if a datasource supports removing items.
 *
 * @template T The item type (used for type narrowing).
 * @param datasource The datasource to check.
 * @returns `true` if `datasource` implements `IRemovableDatasource<T>`; `false` otherwise.
 */
declare function isRemovableDatasource<T>(datasource: unknown): datasource is IRemovableDatasource<T>;

/**
 * Pure-function array helpers for reorder and transfer operations.
 *
 * These are the building blocks that datasource implementations
 * (e.g. `ArrayDatasource` subclasses) can use internally, and that
 * consumers can use directly when working with plain arrays.
 *
 * Both functions mutate the arrays **in place** so datasource
 * implementations can operate directly on their backing store.
 */
/**
 * Moves an item within `array` from `fromIndex` to `toIndex`,
 * shifting other elements to accommodate. The array is mutated
 * **in place**.
 *
 * @typeParam T - The item type.
 * @param array     - The array to mutate.
 * @param fromIndex - Current zero-based index of the item to move.
 * @param toIndex   - Desired zero-based index for the item.
 *
 * @example
 * ```ts
 * const items = ['a', 'b', 'c', 'd'];
 * moveItemInArray(items, 0, 2);
 * // items → ['b', 'c', 'a', 'd']
 * ```
 */
declare function moveItemInArray<T>(array: T[], fromIndex: number, toIndex: number): void;
/**
 * Removes the item at `fromIndex` from `source` and inserts it into
 * `target` at `toIndex`. Both arrays are mutated **in place**.
 *
 * @typeParam T - The item type.
 * @param source    - The array to remove from.
 * @param fromIndex - Zero-based index of the item to remove from `source`.
 * @param target    - The array to insert into.
 * @param toIndex   - Zero-based index at which to insert into `target`.
 *
 * @example
 * ```ts
 * const src = ['a', 'b', 'c'];
 * const tgt = ['x', 'y'];
 * moveItemToArray(src, 1, tgt, 1);
 * // src → ['a', 'c']
 * // tgt → ['x', 'b', 'y']
 * ```
 */
declare function moveItemToArray<T>(source: T[], fromIndex: number, target: T[], toIndex: number): void;
/**
 * Returns a **new** array with the item at `fromIndex` relocated to
 * `toIndex`. The original array is not modified.
 *
 * @typeParam T - The item type.
 * @param array     - The source array (not mutated).
 * @param fromIndex - Current zero-based index of the item to move.
 * @param toIndex   - Desired zero-based index for the item.
 * @returns A new array with the item relocated.
 *
 * @example
 * ```ts
 * const result = moveItemInArrayPure(['a', 'b', 'c', 'd'], 0, 2);
 * // result → ['b', 'c', 'a', 'd']
 * ```
 */
declare function moveItemInArrayPure<T>(array: readonly T[], fromIndex: number, toIndex: number): T[];
/**
 * Returns **new** copies of `source` and `target` with the item at
 * `fromIndex` removed from `source` and inserted into `target` at
 * `toIndex`. The original arrays are not modified.
 *
 * @typeParam T - The item type.
 * @param source    - The array to remove from (not mutated).
 * @param fromIndex - Zero-based index of the item to remove from `source`.
 * @param target    - The array to insert into (not mutated).
 * @param toIndex   - Zero-based index at which to insert into `target`.
 * @returns A tuple `[newSource, newTarget]` with the transfer applied.
 *
 * @example
 * ```ts
 * const [src, tgt] = moveItemToArrayPure(
 *   ['a', 'b', 'c'], 1,
 *   ['x', 'y'],       1,
 * );
 * // src → ['a', 'c']
 * // tgt → ['x', 'b', 'y']
 * ```
 */
declare function moveItemToArrayPure<T>(source: readonly T[], fromIndex: number, target: readonly T[], toIndex: number): [source: T[], target: T[]];

/**
 * Standard JWT registered header fields (RFC 7515 / RFC 7519).
 *
 * Consumers may extend this with additional custom header claims by
 * intersecting with their own type.
 */
interface JwtHeader {
    /** Algorithm used to sign the token (e.g. `"RS256"`, `"HS256"`). */
    readonly alg: string;
    /** Token type — almost always `"JWT"`. */
    readonly typ?: string;
    /** Key ID hint for signature verification. */
    readonly kid?: string;
    /** Allow arbitrary additional header claims. */
    readonly [key: string]: unknown;
}
/**
 * Standard JWT registered payload claims (RFC 7519 §4.1).
 *
 * All registered claims are optional. The index signature allows
 * consumers to read custom claims without casting.
 */
interface JwtPayload {
    /** Issuer — identifies the principal that issued the JWT. */
    readonly iss?: string;
    /** Subject — identifies the principal that is the subject. */
    readonly sub?: string;
    /** Audience — recipient(s) the JWT is intended for. */
    readonly aud?: string | readonly string[];
    /**
     * Expiration time — NumericDate (seconds since Unix epoch) after
     * which the JWT must not be accepted.
     */
    readonly exp?: number;
    /**
     * Not-before time — NumericDate before which the JWT must not be
     * accepted.
     */
    readonly nbf?: number;
    /**
     * Issued-at time — NumericDate when the JWT was issued.
     */
    readonly iat?: number;
    /** JWT ID — unique identifier for the token. */
    readonly jti?: string;
    /** Allow arbitrary additional payload claims. */
    readonly [key: string]: unknown;
}
/**
 * A decoded JWT token with typed header and payload.
 *
 * The raw signature is preserved as-is (base64url-encoded) because
 * signature *verification* is out of scope — it requires server-side
 * keys or a JWKS endpoint.
 */
interface JwtToken<TPayload extends JwtPayload = JwtPayload> {
    /** Decoded JOSE header. */
    readonly header: JwtHeader;
    /** Decoded payload claims. */
    readonly payload: TPayload;
    /** Raw base64url-encoded signature (not verified). */
    readonly signature: string;
    /** The original compact-serialisation string. */
    readonly raw: string;
}
/**
 * Severity levels for JWT validation results.
 */
type JwtValidationSeverity = "error" | "warning";
/**
 * A single validation issue found when inspecting a JWT.
 */
interface JwtValidationIssue {
    /** Machine-readable error code. */
    readonly code: JwtValidationCode;
    /** Human-readable description of the issue. */
    readonly message: string;
    /** Whether this issue should prevent the token from being used. */
    readonly severity: JwtValidationSeverity;
}
/**
 * Machine-readable validation codes returned by the JWT validators.
 */
type JwtValidationCode = "MALFORMED" | "INVALID_JSON" | "MISSING_ALG" | "TOKEN_EXPIRED" | "TOKEN_NOT_YET_VALID" | "ISSUER_MISMATCH" | "AUDIENCE_MISMATCH" | "MISSING_SUBJECT" | "MISSING_CLAIM";
/**
 * Options for {@link validateJwt}.
 *
 * All fields are optional — only the checks whose options are
 * provided will be executed.
 */
interface JwtValidationOptions {
    /**
     * If set, the token's `iss` claim must match this value.
     */
    readonly issuer?: string;
    /**
     * If set, the token's `aud` claim must include this value.
     */
    readonly audience?: string;
    /**
     * If `true`, the token must have a `sub` claim.
     */
    readonly requireSubject?: boolean;
    /**
     * Additional claim names that must be present in the payload.
     */
    readonly requiredClaims?: readonly string[];
    /**
     * Clock tolerance in **seconds** for `exp` and `nbf` checks.
     * Defaults to `0`.
     */
    readonly clockToleranceSeconds?: number;
    /**
     * Reference timestamp in **seconds since epoch** for time-based
     * checks. Defaults to `Math.floor(Date.now() / 1000)`.
     */
    readonly nowSeconds?: number;
}

/**
 * Decode a compact-serialisation JWT string into its constituent
 * parts: header, payload, and raw signature.
 *
 * **This function does NOT verify the token's signature.** Signature
 * verification requires access to the signing key or a JWKS endpoint
 * and is the responsibility of the consumer's backend or auth
 * library.
 *
 * @param token - A JWT in compact serialisation
 *   (`header.payload.signature`).
 * @returns A {@link JwtToken} with decoded header and payload.
 * @throws {Error} If the token structure is malformed or the JSON is
 *   invalid.
 *
 * @example
 * ```ts
 * import { decodeJwt } from '@theredhead/lucid-foundation';
 *
 * const jwt = decodeJwt(rawTokenString);
 * console.log(jwt.payload.sub);  // "user-123"
 * console.log(jwt.payload.exp);  // 1742601600
 * ```
 */
declare function decodeJwt<TPayload extends JwtPayload = JwtPayload>(token: string): JwtToken<TPayload>;
/**
 * Extract a specific claim value from a JWT payload.
 *
 * This is a convenience wrapper around {@link decodeJwt} for
 * quick one-off claim reads.
 *
 * @param token - A JWT in compact serialisation.
 * @param claim - The claim name to extract.
 * @returns The claim value, or `undefined` if absent.
 *
 * @example
 * ```ts
 * const sub = extractClaim(rawToken, 'sub');   // "user-123"
 * const role = extractClaim(rawToken, 'role'); // "editor"
 * ```
 */
declare function extractClaim<T = unknown>(token: string, claim: string): T | undefined;
/**
 * Extract an array of permission strings from a JWT payload.
 *
 * Many authorization systems encode permissions in a custom claim
 * (e.g. `"permissions"`, `"scope"`, `"roles"`). This helper
 * normalises the value to a `readonly string[]`.
 *
 * @param token     - A JWT in compact serialisation.
 * @param claimName - The claim that holds the permissions.
 *   Defaults to `"permissions"`.
 * @returns A readonly array of permission strings.
 *   Returns an empty array if the claim is absent or not an array.
 *
 * @example
 * ```ts
 * const perms = extractPermissions(rawToken);
 * // ["user.read", "user.write"]
 *
 * const scopes = extractPermissions(rawToken, 'scope');
 * // ["openid", "profile"]
 * ```
 */
declare function extractPermissions(token: string, claimName?: string): readonly string[];

/**
 * Check whether a decoded JWT is expired.
 *
 * @param payload              - The decoded JWT payload.
 * @param nowSeconds           - Current time in seconds since epoch.
 *   Defaults to `Math.floor(Date.now() / 1000)`.
 * @param clockToleranceSeconds - Grace period in seconds. Defaults to `0`.
 * @returns `true` if the token has an `exp` claim and it is in the past.
 *
 * @example
 * ```ts
 * if (isExpired(jwt.payload)) {
 *   // refresh or redirect to login
 * }
 * ```
 */
declare function isExpired(payload: JwtPayload, nowSeconds?: number, clockToleranceSeconds?: number): boolean;
/**
 * Check whether a decoded JWT is not yet valid (the `nbf` claim is
 * in the future).
 *
 * @param payload              - The decoded JWT payload.
 * @param nowSeconds           - Current time in seconds since epoch.
 * @param clockToleranceSeconds - Grace period in seconds. Defaults to `0`.
 * @returns `true` if the token has an `nbf` claim and it is in the future.
 */
declare function isNotYetValid(payload: JwtPayload, nowSeconds?: number, clockToleranceSeconds?: number): boolean;
/**
 * Calculate the number of seconds until a JWT expires.
 *
 * @param payload    - The decoded JWT payload.
 * @param nowSeconds - Current time in seconds since epoch.
 * @returns Seconds remaining, or `Infinity` if there is no `exp` claim.
 *   A negative value means the token is already expired.
 *
 * @example
 * ```ts
 * const remaining = secondsUntilExpiry(jwt.payload);
 * if (remaining < 300) {
 *   // less than 5 minutes — trigger silent refresh
 * }
 * ```
 */
declare function secondsUntilExpiry(payload: JwtPayload, nowSeconds?: number): number;
/**
 * Validate a decoded JWT against a set of configurable rules.
 *
 * Returns an array of {@link JwtValidationIssue} objects. An empty
 * array means the token passed all requested checks.
 *
 * This function does **not** verify the cryptographic signature.
 *
 * @param token   - A decoded {@link JwtToken}.
 * @param options - Which checks to perform and their parameters.
 * @returns An array of validation issues (empty = valid).
 *
 * @example
 * ```ts
 * const issues = validateJwt(jwt, {
 *   issuer: 'https://auth.example.com',
 *   audience: 'my-app',
 *   requireSubject: true,
 *   requiredClaims: ['role', 'permissions'],
 * });
 *
 * if (issues.length > 0) {
 *   console.warn('JWT validation failed:', issues);
 * }
 * ```
 */
declare function validateJwt(token: JwtToken, options?: JwtValidationOptions): readonly JwtValidationIssue[];
/**
 * Convenience predicate: returns `true` when a decoded JWT passes
 * all validation checks defined in `options`.
 *
 * @param token   - A decoded {@link JwtToken}.
 * @param options - Validation rules.
 * @returns `true` if no issues were found.
 */
declare function isJwtValid(token: JwtToken, options?: JwtValidationOptions): boolean;

/**
 * Strategy interface for key-value storage.
 *
 * Implement this interface to provide alternative storage backends
 * (e.g. sessionStorage, in-memory, IndexedDB, or a server-side store).
 *
 * All methods should handle errors internally and never throw.
 */
interface IStorageStrategy {
    /** Retrieve a value by key. Returns `null` when the key does not exist. */
    getItem(key: string): string | null;
    /** Store a value under the given key. */
    setItem(key: string, value: string): void;
    /** Remove the value for the given key. */
    removeItem(key: string): void;
}
/**
 * Default storage strategy that delegates to `localStorage`.
 *
 * All operations are wrapped in try/catch so they degrade gracefully
 * in environments where localStorage is unavailable (SSR, private
 * browsing quota exceeded, etc.).
 */
declare class LocalStorageStrategy implements IStorageStrategy {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
/**
 * Injection token for the storage strategy.
 *
 * Defaults to {@link LocalStorageStrategy}. Override at the application
 * root to swap in a different backend:
 *
 * ```ts
 * providers: [
 *   { provide: STORAGE_STRATEGY, useClass: MyCustomStrategy },
 * ]
 * ```
 */
declare const STORAGE_STRATEGY: InjectionToken<IStorageStrategy>;
/**
 * Angular service for persisting key-value data.
 *
 * Delegates to the {@link IStorageStrategy} provided via
 * {@link STORAGE_STRATEGY}. Defaults to {@link LocalStorageStrategy}
 * (i.e. `localStorage`).
 *
 * Inject this service instead of calling `localStorage` directly so
 * that storage behaviour can be swapped application-wide through DI.
 *
 * @example
 * ```ts
 * export class MyComponent {
 *   private readonly storage = inject(StorageService);
 *
 *   public save(key: string, data: unknown): void {
 *     this.storage.setItem(key, JSON.stringify(data));
 *   }
 *
 *   public load(key: string): unknown | null {
 *     const raw = this.storage.getItem(key);
 *     return raw ? JSON.parse(raw) : null;
 *   }
 * }
 * ```
 */
declare class StorageService {
    private readonly strategy;
    /** Retrieve a value by key. Returns `null` when the key does not exist. */
    getItem(key: string): string | null;
    /** Store a value under the given key. */
    setItem(key: string, value: string): void;
    /** Remove the value for the given key. */
    removeItem(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageService>;
}

/**
 * Optional injection token that components can provide to set a default
 * surface type. The directive uses this when no explicit `surfaceType`
 * input is supplied by the consumer.
 *
 * ```ts
 * providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: 'panel' }]
 * ```
 */
declare const UI_DEFAULT_SURFACE_TYPE: InjectionToken<SurfaceType | SurfaceType[]>;
/**
 * Built-in surface types shipped with the library.
 *
 * Consumers can extend this by defining additional CSS classes with the
 * `ui-surface-type-` prefix and passing the suffix as the `surfaceType` input.
 */
type SurfaceType = "transparent" | "raised" | "sunken" | "panel" | "avatar" | (string & {});
/**
 * Host directive that maps a `surfaceType` input to a CSS class on the
 * host element: `ui-surface-type-<value>`.
 *
 * Applied automatically to every `ui-*` component via `hostDirectives`.
 * The actual visual treatment is defined in the theme stylesheet — the
 * directive only manages the class binding.
 *
 * ### Built-in types
 *
 * | Type          | Intended use                                     |
 * |---------------|--------------------------------------------------|
 * | `transparent` | Fully transparent background                     |
 * | `raised`      | Elevated surface with shadow                     |
 * | `sunken`      | Inset / recessed surface                         |
 * | `panel`       | Generic panel / card surface                     |
 *
 * ### Custom types
 *
 * Define a CSS class with the `ui-surface-type-` prefix in your stylesheet:
 *
 * ```css
 * .ui-surface-type-glass {
 *   background: rgba(255, 255, 255, 0.1);
 *   backdrop-filter: blur(12px);
 * }
 * ```
 *
 * Then use it on any component:
 *
 * ```html
 * <ui-card surfaceType="glass">…</ui-card>
 * ```
 *
 * ### Multiple types
 *
 * Pass a space-separated string or an array to combine surface types:
 *
 * ```html
 * <ui-card surfaceType="raised glass">…</ui-card>
 * <ui-card [surfaceType]="['raised', 'glass']">…</ui-card>
 * ```
 */
declare class UISurface {
    private readonly defaultSurface;
    /**
     * One or more surface types to apply.
     * Accepts a single type, a space-separated string, or an array.
     * When unset, falls back to the component's `UI_DEFAULT_SURFACE_TYPE` provider (if any).
     */
    readonly surfaceType: i0.InputSignal<SurfaceType | SurfaceType[]>;
    /** @internal */
    protected readonly hostClass: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UISurface, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UISurface, "[uiSurface]", never, { "surfaceType": { "alias": "surfaceType"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Controls how a template processor reacts when a block references a key that
 * does not exist in the expansion context.
 *
 * - `"keep"` keeps the original XML block in place.
 * - `"empty"` replaces the block with an empty string.
 * - `"error"` throws a `RangeError`.
 * - A function receives the missing key and returns a replacement string.
 */
type MissingKeyBehavior = "keep" | "empty" | "error" | ((key: string) => string);
/**
 * Options for XML template processing.
 */
interface TextTemplateOptions {
    /**
     * How to handle a missing key during block expansion.
     * Defaults to `"keep"`.
     */
    readonly missingKey?: MissingKeyBehavior;
}
/**
 * Contract for optional text detectors that transform raw text at a pipeline
 * boundary.
 *
 * Data detectors are intended to run either before or after XML template
 * processing, never during block expansion itself.
 */
interface IDataDetector {
    /**
     * Returns `true` when the detector should process the provided text.
     */
    detect(text: string): boolean;
    /**
     * Transforms detected text into the desired output string.
     */
    process(text: string): string;
}
/**
 * A parsed XML template document.
 */
interface TemplateDocument {
    /**
     * Top-level text and block nodes.
     */
    readonly children: readonly TemplateNode[];
}
/**
 * Any parsed template node.
 */
type TemplateNode = TemplateTextNode | TemplateBlockNode;
/**
 * A literal text/content node.
 */
interface TemplateTextNode {
    /**
     * Node discriminator.
     */
    readonly kind: "text";
    /**
     * Literal text content.
     */
    readonly text: string;
}
/**
 * A block node. All template constructs, including placeholders, use this
 * single representation.
 */
interface TemplateBlockNode {
    /**
     * Node discriminator.
     */
    readonly kind: "block";
    /**
     * XML tag name.
     */
    readonly name: string;
    /**
     * XML attributes keyed by attribute name.
     */
    readonly attributes: Readonly<Record<string, string>>;
    /**
     * Child nodes for container blocks.
     */
    readonly children: readonly TemplateNode[];
    /**
     * Whether the block was parsed or created as self-closing.
     */
    readonly selfClosing: boolean;
}
/**
 * Controls whether a block must be self-closing or may contain children.
 */
type TemplateBlockContentModel = "self-closing" | "container" | "any";
/**
 * Context passed to block providers during expansion.
 */
interface TemplateBlockExpansionContext {
    /**
     * Current data context.
     */
    readonly data: Record<string, unknown>;
    /**
     * Active processor, useful for expanding child nodes with a modified data
     * context.
     */
    readonly processor: ITextTemplateProcessor;
}
/**
 * Runtime and validation contract for a named XML template block.
 */
interface TemplateBlockProvider {
    /**
     * XML tag name handled by this provider.
     */
    readonly name: string;
    /**
     * Whether this block is self-closing, a container, or accepts either shape.
     */
    readonly contentModel: TemplateBlockContentModel;
    /**
     * Required XML attribute names.
     */
    readonly requiredAttributes?: readonly string[];
    /**
     * Optional XML attribute names. When omitted, any extra attributes are
     * accepted.
     */
    readonly optionalAttributes?: readonly string[];
    /**
     * Expands the block into output content.
     */
    expand(block: TemplateBlockNode, context: TemplateBlockExpansionContext): string;
}
/**
 * Contract for XML template processors.
 */
interface ITextTemplateProcessor {
    /**
     * Fully expands a template string against the given context.
     */
    expand(template: string, context: Record<string, unknown>): string;
    /**
     * Expands an already-parsed document.
     */
    expandDocument(document: TemplateDocument, context: Record<string, unknown>): string;
    /**
     * Expands a node collection against the given context.
     */
    expandNodes(nodes: readonly TemplateNode[], context: Record<string, unknown>): string;
    /**
     * Processes one XML block by dispatching to the registered block provider.
     */
    processBlock(block: TemplateBlockNode, context: Record<string, unknown>): string;
    /**
     * Resolves a data key for built-in replacement-style blocks.
     */
    processIdentifier(key: string, context: Record<string, unknown>): string;
}
/**
 * Registers an XML template block provider.
 *
 * Calling this again with the same block name replaces the existing provider.
 */
declare function registerTextTemplateBlockProvider(provider: TemplateBlockProvider): void;
/**
 * Removes a previously registered XML template block provider.
 */
declare function unregisterTextTemplateBlockProvider(name: string): void;
/**
 * Returns `true` when a provider for the XML block name is registered.
 */
declare function haveRegisteredTextTemplateBlockProvider(name: string): boolean;
/**
 * Returns all currently registered XML template block providers.
 */
declare function getRegisteredTextTemplateBlockProviders(): TemplateBlockProvider[];
/**
 * Registers a data detector.
 *
 * Detectors are intended to run either before or after XML template
 * processing, never during block expansion itself.
 */
declare function registerDataDetector(detector: IDataDetector): void;
/**
 * Removes a previously registered data detector.
 */
declare function unregisterDataDetector(detector: IDataDetector): void;
/**
 * Returns all currently registered data detectors.
 */
declare function getRegisteredDataDetectors(): IDataDetector[];
/**
 * Applies a detector list to a text fragment at a pipeline boundary.
 *
 * Each detector runs only when its {@link IDataDetector.detect} method returns
 * `true`. Detector output is fed into subsequent detectors in registration
 * order.
 */
declare function applyDataDetectors(text: string, detectors?: readonly IDataDetector[]): string;
/**
 * Parses XML template strings into the canonical document model.
 */
declare class XmlTemplateParser {
    /**
     * Parses an XML template fragment.
     */
    parse(template: string): TemplateDocument;
    /** @internal */
    private parseNode;
}
/**
 * Serializes parsed template documents back to canonical XML.
 */
declare class XmlTemplateSerializer {
    /**
     * Serializes a complete template document.
     */
    serialize(document: TemplateDocument): string;
    /**
     * Serializes a node collection.
     */
    serializeNodes(nodes: readonly TemplateNode[]): string;
    /**
     * Serializes a single template node.
     */
    serializeNode(node: TemplateNode): string;
    /** @internal */
    private escapeText;
    /** @internal */
    private escapeAttribute;
}
/**
 * XML block template processor.
 */
declare class XmlTemplateProcessor implements ITextTemplateProcessor {
    private readonly missingKeyBehavior;
    private readonly parser;
    private readonly serializer;
    constructor(options?: TextTemplateOptions);
    /**
     * Fully expands an XML template string.
     */
    expand(template: string, context: Record<string, unknown>): string;
    /**
     * Fully expands an already parsed template document.
     */
    expandDocument(document: TemplateDocument, context: Record<string, unknown>): string;
    /**
     * Expands a node collection.
     */
    expandNodes(nodes: readonly TemplateNode[], context: Record<string, unknown>): string;
    /**
     * Dispatches one block to its registered provider.
     */
    processBlock(block: TemplateBlockNode, context: Record<string, unknown>): string;
    /**
     * Resolves a context key for built-in replacement blocks.
     */
    processIdentifier(key: string, context: Record<string, unknown>): string;
    /** @internal */
    private expandNode;
    /** @internal */
    private validateBlock;
    /** @internal */
    private resolveMissing;
}
/**
 * Default processor name retained for consumers that already import
 * `TextTemplateProcessor`. The implementation is XML-only.
 */
declare class TextTemplateProcessor extends XmlTemplateProcessor {
}

/**
 * Detects and links email addresses.
 */
declare class EmailDetector implements IDataDetector {
    /** @inheritdoc */
    detect(text: string): boolean;
    /** @inheritdoc */
    process(text: string): string;
}
/**
 * Detects and links HTTP and HTTPS URLs.
 */
declare class UrlDetector implements IDataDetector {
    /** @inheritdoc */
    detect(text: string): boolean;
    /** @inheritdoc */
    process(text: string): string;
}
/**
 * Detects and links phone numbers.
 */
declare class PhoneNumberDetector implements IDataDetector {
    /** @inheritdoc */
    detect(text: string): boolean;
    /** @inheritdoc */
    process(text: string): string;
}
/**
 * Detects old-school plaintext emoticons and converts them to emoji.
 */
declare class EmojiDetector implements IDataDetector {
    /** @inheritdoc */
    detect(text: string): boolean;
    /** @inheritdoc */
    process(text: string): string;
}

/** RGBA channels with red, green, and blue in 0-255 and alpha in 0-1. */
interface ParsedCssColor {
    readonly r: number;
    readonly g: number;
    readonly b: number;
    readonly a: number;
}
/** Parse common CSS color syntax into RGBA channels. */
declare function parseCssColor(value: string): ParsedCssColor | null;
/** Return whether a value is a usable CSS color or CSS custom-property reference. */
declare function isCssColor(value: string): boolean;
/** Choose black or white text for readable contrast on a CSS color. */
declare function getContrastingTextColor(value: string): string | null;

export { ArrayDatasource, ArrayTreeDatasource, ConsoleLoggingStrategy, DefaultMarkdownParser, EmailDetector, Emitter, EmojiDetector, FilterableArrayDatasource, FilterableArrayTreeDatasource, KeyedRegistry, LocalStorageStrategy, Logger, LoggerFactory, PhoneNumberDetector, Registry, RestDatasource, STORAGE_STRATEGY, SortDirection, SortableArrayDatasource, SortableArrayTreeDatasource, StorageService, TextTemplateProcessor, UISurface, UI_DEFAULT_SURFACE_TYPE, UrlDetector, XmlTemplateParser, XmlTemplateProcessor, XmlTemplateSerializer, applyDataDetectors, compileSortExpression, compileTreeSortExpression, decodeJwt, extractClaim, extractPermissions, getContrastingTextColor, getRegisteredDataDetectors, getRegisteredTextTemplateBlockProviders, haveRegisteredTextTemplateBlockProvider, isCssColor, isExpired, isFilterableDatasource, isFilterableTreeDatasource, isInsertableDatasource, isJwtValid, isNotYetValid, isRemovableDatasource, isReorderableDatasource, isSortableDatasource, isSortableTreeDatasource, isTreeDatasource, markdownToHtml, moveItemInArray, moveItemInArrayPure, moveItemToArray, moveItemToArrayPure, parseCssColor, registerDataDetector, registerTextTemplateBlockProvider, secondsUntilExpiry, unregisterDataDetector, unregisterTextTemplateBlockProvider, validateJwt };
export type { AutocompleteDatasource, CompiledFilter, CompiledFilter as FilterExpression, IActiveDatasource, IDataDetector, IDatasource, IFilterableDatasource, IFilterableTreeDatasource, IInsertableDatasource, IKeyedRegistry, ILoggingStrategy, IRegistry, IRemovableDatasource, IReorderableDatasource, ISortableDatasource, ISortableTreeDatasource, IStorageStrategy, ITextTemplateProcessor, ITreeDatasource, JwtHeader, JwtPayload, JwtToken, JwtValidationCode, JwtValidationIssue, JwtValidationOptions, JwtValidationSeverity, MarkdownParser, MissingKeyBehavior, ParsedCssColor, RangeDefinition, RowChangedNotification, RowRangeChangedNotification, RowResult, SortExpression, SurfaceType, TemplateBlockContentModel, TemplateBlockExpansionContext, TemplateBlockNode, TemplateBlockProvider, TemplateDocument, TemplateNode, TemplateTextNode, TextTemplateOptions, TreeNode, TreeSelectionMode };
