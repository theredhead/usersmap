import * as i0 from '@angular/core';
import { input, output, model, contentChildren, contentChild, viewChild, computed, signal, effect, untracked, ChangeDetectionStrategy, Component, inject, DestroyRef, ElementRef, Injectable, InjectionToken, Injector, afterNextRender, TemplateRef } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import * as i1 from '@theredhead/lucid-foundation';
import { isTreeDatasource, FilterableArrayDatasource, FilterableArrayTreeDatasource, UISurface, LoggerFactory, UI_DEFAULT_SURFACE_TYPE, StorageService, ArrayTreeDatasource, haveRegisteredTextTemplateBlockProvider, markdownToHtml, getRegisteredTextTemplateBlockProviders } from '@theredhead/lucid-foundation';
import { UITableViewColumn, UITableView, inferFilterFields, FilterableArrayDatasource as FilterableArrayDatasource$1, SelectionModel, UIIcons, toPredicate, UISplitContainer, UISplitPanel, UITreeView, UIFilter, UIIcon, UISidebarItem, UIButton, UIDrawer, UISidebarNav, UISidebarGroup, UIBreadcrumb, UIDialog, UIDialogBody, UIDialogFooter, UIDialogHeader, UIInput, UIPagination, UIDropdownList, UICheckbox, UIColorPicker, UISlider, UIAccordion, UIAccordionItem, UITabGroup, UITab, PopoverRef, PopoverService, UIEmojiPicker, UIToolbar, UIButtonTool, UIToggleTool, UISeparatorTool, UISpacerTool, UIDropdownTool, UIButtonGroupTool, UIToggleGroupTool, UIRichTextView, UIAvatar, ModalRef, ModalService } from '@theredhead/lucid-kit';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { moveItemInArray, transferArrayItem, CdkDropListGroup, CdkDropList, CdkDrag, CdkDragPlaceholder } from '@angular/cdk/drag-drop';
import { firstValueFrom } from 'rxjs';

/**
 * A master-detail layout that shows a list of items in a
 * {@link UITableView} and renders a detail template for the
 * currently selected item.
 *
 * ### Basic usage (table mode)
 * ```html
 * <ui-master-detail-view [datasource]="adapter" title="People">
 *   <ui-text-column key="name" headerText="Name" />
 *   <ui-text-column key="email" headerText="Email" />
 *
 *   <ng-template #detail let-object>
 *     <h3>{{ object.name }}</h3>
 *     <p>{{ object.email }}</p>
 *   </ng-template>
 * </ui-master-detail-view>
 * ```
 *
 * ### Tree mode
 * ```html
 * <ui-master-detail-view [datasource]="treeDs" [treeDisplayWith]="labelFn">
 *   <ng-template #detail let-object>
 *     <h3>{{ object.name }}</h3>
 *   </ng-template>
 * </ui-master-detail-view>
 * ```
 *
 * ### With filter
 * ```html
 * <!-- Auto-inferred fields from columns + data types -->
 * <ui-master-detail-view [datasource]="adapter" [showFilter]="true">
 *   <ui-text-column key="name" headerText="Name" />
 *   <ui-text-column key="email" headerText="Email" />
 *   <ng-template #detail let-object>…</ng-template>
 * </ui-master-detail-view>
 * ```
 *
 * ### With custom filter template (override)
 * ```html
 * <ui-master-detail-view [datasource]="adapter" [showFilter]="true">
 *   <ng-template #filter>
 *     <ui-filter [fields]="fields" [(value)]="descriptor"
 *                (expressionChange)="ds.filterBy($event)" />
 *   </ng-template>
 *   <!-- columns and detail template -->
 * </ui-master-detail-view>
 * ```
 */
class UIMasterDetailView {
    // ── Inputs ────────────────────────────────────────────────────────
    /** Title displayed above the list panel. */
    title = input("Items", ...(ngDevMode ? [{ debugName: "title" }] : []));
    /**
     * Layout orientation.
     * - `'horizontal'` (default) — list on the left, detail on the right.
     * - `'vertical'` — list on top, detail below.
     */
    orientation = input("horizontal", ...(ngDevMode ? [{ debugName: "orientation" }] : []));
    /**
     * The datasource powering the master list.
     *
     * Accepts any {@link IDatasource} (for flat table mode)
     * or an {@link ITreeDatasource} (for hierarchical tree mode).
     * The component detects the type at runtime and renders the
     * appropriate view.
     */
    datasource = input(undefined, ...(ngDevMode ? [{ debugName: "datasource" }] : []));
    /**
     * Function that returns a display string for tree node data.
     * Only used in tree mode when no `#nodeTemplate` is projected.
     * Defaults to `String(data)`.
     */
    treeDisplayWith = input((data) => String(data), ...(ngDevMode ? [{ debugName: "treeDisplayWith" }] : []));
    /** Placeholder text shown when no item is selected. */
    placeholder = input("Select an item to view details", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /**
     * Whether the filter section is visible.
     *
     * - `true` — always show the filter.
     * - `false` — never show the filter.
     * - `undefined` (default) — auto-detect: show the filter when the
     *   resolved datasource is a {@link FilterableArrayDatasource}.
     *
     * When shown without a projected `#filter` template, the component
     * embeds a `<ui-filter>` internally using auto-inferred field
     * definitions.
     */
    showFilter = input(undefined, ...(ngDevMode ? [{ debugName: "showFilter" }] : []));
    /** Whether the filter section starts expanded. */
    filterExpanded = input(true, ...(ngDevMode ? [{ debugName: "filterExpanded" }] : []));
    /**
     * Whether the filter toggle button is hidden.
     *
     * When `true`, the toggle is removed and the filter section stays
     * permanently in whatever state `filterExpanded` dictates:
     * - `filterExpanded: true` + `filterModeLocked: true` → filter is
     *   always visible, cannot be collapsed.
     * - `filterExpanded: false` + `filterModeLocked: true` → filter bar
     *   is completely hidden (equivalent to `showFilter: false`).
     *
     * This value is also forwarded to the embedded `<ui-filter>` as
     * `[modeLocked]`, preventing the user from toggling between
     * simple and advanced filter modes.
     */
    filterModeLocked = input(false, ...(ngDevMode ? [{ debugName: "filterModeLocked" }] : []));
    /**
     * Explicit filter field definitions.
     *
     * When provided these override the auto-inferred fields.
     * Only relevant when no `#filter` template is projected.
     */
    filterFields = input(undefined, ...(ngDevMode ? [{ debugName: "filterFields" }] : []));
    /**
     * Initial split sizes as a `[list, detail]` percentage tuple.
     * Must sum to 100. Defaults to `[33, 67]`.
     */
    splitSizes = input([33, 67], ...(ngDevMode ? [{ debugName: "splitSizes" }] : []));
    /**
     * Optional localStorage key for persisting the split panel sizes.
     * When set the user's last divider position is restored on init.
     */
    splitName = input(undefined, ...(ngDevMode ? [{ debugName: "splitName" }] : []));
    /**
     * Size constraints for the list (first) panel in pixels.
     * Defaults to `{ min: 200 }`.
     */
    listConstraints = input({
        min: 200,
    }, ...(ngDevMode ? [{ debugName: "listConstraints" }] : []));
    // ── Table pass-through inputs ─────────────────────────────────
    /** Whether the embedded table view is disabled. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    /**
     * Page size for the embedded table view's paginator.
     * Leave `undefined` to use the table's default.
     */
    pageSize = input(undefined, ...(ngDevMode ? [{ debugName: "pageSize" }] : []));
    /**
     * External page index (zero-based) for the embedded table view.
     * Leave `undefined` to let the built-in paginator manage it.
     */
    pageIndex = input(undefined, ...(ngDevMode ? [{ debugName: "pageIndex" }] : []));
    /**
     * Whether to show the table's built-in paginator.
     * Defaults to `false`.
     */
    showBuiltInPaginator = input(false, ...(ngDevMode ? [{ debugName: "showBuiltInPaginator" }] : []));
    /** Accessible caption for the embedded table. */
    caption = input("", ...(ngDevMode ? [{ debugName: "caption" }] : []));
    /** Whether to show row-index numbers in the table. */
    showRowIndexIndicator = input(false, ...(ngDevMode ? [{ debugName: "showRowIndexIndicator" }] : []));
    /** Header text for the row-index column.  Defaults to `"#"`. */
    rowIndexHeaderText = input("#", ...(ngDevMode ? [{ debugName: "rowIndexHeaderText" }] : []));
    /**
     * Unique table identifier used for persisting column widths.
     * When set, column widths are stored in localStorage.
     */
    tableId = input("", ...(ngDevMode ? [{ debugName: "tableId" }] : []));
    /**
     * Whether table columns can be resized by dragging header borders.
     * Defaults to `true`.
     */
    resizable = input(true, ...(ngDevMode ? [{ debugName: "resizable" }] : []));
    /**
     * Row height in pixels for the internal table-view.
     * Forwarded to `<ui-table-view [rowHeight]>`.
     * Defaults to 36 px.
     */
    rowHeight = input(36, ...(ngDevMode ? [{ debugName: "rowHeight" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emits whenever the selection changes. Carries the selected item or `undefined`. */
    selectedChange = output();
    /**
     * Emits the {@link FilterExpression} every time the filter rules
     * change. Emits an empty array when no valid rules remain.
     *
     * For {@link FilterableArrayDatasource} instances the expression is
     * applied automatically — this output is for consumers who use a
     * custom datasource and need to handle filtering manually.
     */
    expressionChange = output();
    // ── Models ────────────────────────────────────────────────────────
    /**
     * The filter descriptor state (two-way bindable).
     *
     * Provides full read/write access to the filter's rule set and
     * junction mode. Defaults to an empty AND descriptor.
     */
    filterDescriptor = model({
        junction: "and",
        rules: [],
    }, ...(ngDevMode ? [{ debugName: "filterDescriptor" }] : []));
    // ── Content queries ───────────────────────────────────────────────
    /**
     * Projected table-view columns.
     * These are forwarded to the internal `<ui-table-view>`.
     */
    columns = contentChildren(UITableViewColumn, ...(ngDevMode ? [{ debugName: "columns" }] : []));
    /** Detail template — rendered when an item is selected. */
    detailTemplate = contentChild("detail", ...(ngDevMode ? [{ debugName: "detailTemplate" }] : []));
    /** Optional filter template — shown in the collapsible filter area. */
    filterTemplate = contentChild("filter", ...(ngDevMode ? [{ debugName: "filterTemplate" }] : []));
    /**
     * Optional tree-node template — forwarded to `<ui-tree-view>`.
     * Receives {@link TreeNodeContext} as its context.
     */
    treeNodeTemplate = contentChild("nodeTemplate", ...(ngDevMode ? [{ debugName: "treeNodeTemplate" }] : []));
    // ── View queries ──────────────────────────────────────────────────
    /** @internal — the internal table view instance (table mode). */
    tableViewChild = viewChild(UITableView, ...(ngDevMode ? [{ debugName: "tableViewChild" }] : []));
    // ── Computed ──────────────────────────────────────────────────────
    /**
     * Whether the component is in tree mode.
     * `true` when the `datasource` input is an `ITreeDatasource`. @internal
     */
    isTreeMode = computed(() => isTreeDatasource(this.datasource()), ...(ngDevMode ? [{ debugName: "isTreeMode" }] : []));
    /**
     * The tree datasource, extracted from the unified `datasource`
     * input. Returns `undefined` when not in tree mode.
     * @internal
     */
    resolvedTreeDatasource = computed(() => {
        const ds = this.datasource();
        return isTreeDatasource(ds) ? ds : undefined;
    }, ...(ngDevMode ? [{ debugName: "resolvedTreeDatasource" }] : []));
    /**
     * The currently selected item, derived from the table selection
     * model or the tree selection signal. @internal
     */
    selectedItem = computed(() => {
        if (this.isTreeMode()) {
            const nodes = this.selectedTreeNodes();
            return nodes.length > 0 ? nodes[0].data : undefined;
        }
        const items = this.selectionModel.selected();
        return items.length > 0 ? items[0] : undefined;
    }, ...(ngDevMode ? [{ debugName: "selectedItem" }] : []));
    /** Context for the detail template outlet. @internal */
    detailContext = computed(() => {
        const item = this.selectedItem();
        if (item === undefined)
            return undefined;
        return { $implicit: item };
    }, ...(ngDevMode ? [{ debugName: "detailContext" }] : []));
    /**
     * The resolved flat-table datasource.
     *
     * Returns the `datasource` input when it is a flat
     * {@link IDatasource} (not a tree). Falls back to an empty
     * {@link FilterableArrayDatasource} when no datasource is set or
     * when the input is a tree datasource.
     * @internal
     */
    resolvedTableDatasource = computed(() => {
        const explicit = this.datasource();
        if (explicit && !isTreeDatasource(explicit)) {
            return explicit;
        }
        return new FilterableArrayDatasource([]);
    }, ...(ngDevMode ? [{ debugName: "resolvedTableDatasource" }] : []));
    /**
     * Whether the filter section should be displayed.
     *
     * - Explicit `showFilter` input wins when not `undefined`.
     * - Otherwise auto-detects: `true` when the underlying raw
     *   datasource is a {@link FilterableArrayDatasource}.
     * @internal
     */
    resolvedShowFilter = computed(() => {
        const explicit = this.showFilter();
        if (explicit !== undefined)
            return explicit;
        // Tree mode: auto-show when a tree datasource is provided
        if (this.resolvedTreeDatasource() !== undefined)
            return false;
        // Auto-detect: show filter when the datasource supports filtering
        const ds = this.resolvedTableDatasource();
        return ds instanceof FilterableArrayDatasource;
    }, ...(ngDevMode ? [{ debugName: "resolvedShowFilter" }] : []));
    /**
     * The filter field definitions used by the embedded `<ui-filter>`.
     *
     * Priority: explicit `filterFields` input → inferred from projected
     * columns and the first data row.
     * @internal
     */
    resolvedFilterFields = computed(() => {
        const explicit = this.filterFields();
        if (explicit)
            return explicit;
        // ── Tree mode: infer from tree node data ──
        const treeDs = this.resolvedTreeDatasource();
        if (treeDs) {
            const flatData = this.collectTreeData(treeDs);
            if (flatData.length === 0)
                return [];
            return inferFilterFields(flatData[0]);
        }
        // ── Table mode: infer from columns + datasource rows ──
        // Derive column metadata from projected UITableViewColumn instances
        const cols = this.columns();
        const columnMeta = cols.map((c) => ({
            key: c.key(),
            headerText: c.headerText(),
        }));
        // Get a sample row from the *unfiltered* datasource to sniff
        // types.  We must NOT use getNumberOfItems() on a filtered
        // datasource — the filtered count drops to 0 when no rows match
        // the current predicate and would make the filter fields (and
        // the filter component) disappear.
        const ds = this.resolvedTableDatasource();
        // Prefer the full unfiltered list when available
        const allRows = ds instanceof FilterableArrayDatasource
            ? ds.allRows
            : undefined;
        let sample;
        if (allRows && allRows.length > 0) {
            sample = allRows[0];
        }
        else {
            // Fallback for non-filterable datasources
            const count = ds.getNumberOfItems();
            if (typeof count !== "number" || count === 0)
                return [];
            const result = ds.getObjectAtRowIndex(0);
            if (!result || result instanceof Promise)
                return [];
            sample = result;
        }
        if (!sample)
            return [];
        return inferFilterFields(sample, columnMeta.length > 0 ? columnMeta : undefined);
    }, ...(ngDevMode ? [{ debugName: "resolvedFilterFields" }] : []));
    /**
     * The raw data array for the embedded filter (used to derive
     * distinct values for autocomplete / select).
     * @internal
     */
    resolvedFilterData = computed(() => {
        // ── Tree mode: flatten all node data ──
        const treeDs = this.resolvedTreeDatasource();
        if (treeDs) {
            const flatData = this.collectTreeData(treeDs);
            return flatData.length < 1000 ? flatData : [];
        }
        // ── Table mode ──
        const ds = this.resolvedTableDatasource();
        // Use the full unfiltered dataset when available so that distinct
        // value lists and autocomplete options don't shrink as the user
        // narrows the filter.
        if (ds instanceof FilterableArrayDatasource$1) {
            const all = ds.allRows;
            return all.length < 1000 ? all : [];
        }
        if (ds instanceof FilterableArrayDatasource) {
            const all = ds.allRows;
            return all.length < 1000 ? all : [];
        }
        // Fallback for non-filterable datasources: gather visible rows
        const count = ds.getNumberOfItems();
        if (typeof count !== "number" || count === 0 || count >= 1000)
            return [];
        const rows = [];
        for (let i = 0; i < count; i++) {
            const row = ds.getObjectAtRowIndex(i);
            if (!(row instanceof Promise))
                rows.push(row);
        }
        return rows;
    }, ...(ngDevMode ? [{ debugName: "resolvedFilterData" }] : []));
    // ── Public fields ───────────────────────────────────────────────
    /** Selection model for the table-view (single mode). */
    selectionModel = new SelectionModel("single");
    // ── Protected fields ──────────────────────────────────────────────
    /** @internal — currently selected tree nodes (tree mode). */
    selectedTreeNodes = signal([], ...(ngDevMode ? [{ debugName: "selectedTreeNodes" }] : []));
    /** @internal — whether the filter section is collapsed. */
    filterCollapsed = signal(false, ...(ngDevMode ? [{ debugName: "filterCollapsed" }] : []));
    /**
     * The current filter predicate for tree mode.
     * Forwarded to the `<ui-tree-view>` `filterPredicate` input.
     * @internal
     */
    treeFilterPredicate = signal(undefined, ...(ngDevMode ? [{ debugName: "treeFilterPredicate" }] : []));
    // ── Protected constants ───────────────────────────────────────────
    /** @internal */
    chevronDown = UIIcons.Lucide.Arrows.ChevronDown;
    /** @internal */
    chevronRight = UIIcons.Lucide.Arrows.ChevronRight;
    // ── Constructor ───────────────────────────────────────────────────
    constructor() {
        // Initialise filterCollapsed from the filterExpanded input
        effect(() => {
            const expanded = this.filterExpanded();
            untracked(() => this.filterCollapsed.set(!expanded));
        });
        // Emit selectedChange whenever selection changes
        effect(() => {
            const item = this.selectedItem();
            untracked(() => this.selectedChange.emit(item));
        });
    }
    // ── Public methods ────────────────────────────────────────────────
    /**
     * Called by the embedded `<ui-filter>` when the expression changes.
     *
     * - For {@link FilterableArrayDatasource} the expression is applied
     *   via `filterBy()` and the adapter is refreshed.
     * - For tree mode the expression is compiled into a predicate for
     *   the tree-view's `filterPredicate` input.
     * - Always emits via {@link expressionChange} so consumers with
     *   custom datasources can react.
     */
    onFilterExpressionChange(expression) {
        this.expressionChange.emit(expression);
        if (this.isTreeMode()) {
            const treeDs = this.resolvedTreeDatasource();
            // FilterableArrayTreeDatasource: compile expression and apply
            if (treeDs instanceof FilterableArrayTreeDatasource) {
                this.applyFoundationTreeFilter(treeDs, expression);
                return;
            }
            // Plain ITreeDatasource: fall back to tree-view filterPredicate input
            const fields = this.resolvedFilterFields();
            const descriptor = this.filterDescriptor();
            this.treeFilterPredicate.set(toPredicate(descriptor, fields));
            return;
        }
        // Table mode: apply expression to FilterableArrayDatasource
        const ds = this.resolvedTableDatasource();
        if (ds instanceof FilterableArrayDatasource$1) {
            ds.filterBy(expression);
            this.tableViewChild()?.refreshDatasource();
            return;
        }
        if (ds instanceof FilterableArrayDatasource) {
            this.applyFoundationTableFilter(ds, expression);
            this.tableViewChild()?.refreshDatasource();
        }
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — toggle filter visibility. */
    toggleFilter() {
        this.filterCollapsed.update((v) => !v);
    }
    // ── Private helpers ───────────────────────────────────────────────
    /**
     * Recursively collects the `data` payloads from every node in the
     * tree datasource into a flat array. Used to infer filter fields
     * and provide distinct values in tree mode.
     */
    collectTreeData(ds) {
        const items = [];
        const walk = (nodes) => {
            for (const node of nodes) {
                items.push(node.data);
                const children = ds.getChildren(node);
                if (Array.isArray(children))
                    walk(children);
            }
        };
        const roots = ds.getRootNodes();
        if (Array.isArray(roots))
            walk(roots);
        return items;
    }
    applyFoundationTableFilter(ds, expression) {
        const predicate = toPredicate(expression, this.resolvedFilterFields());
        ds.filterBy(predicate ? [{ predicate }] : null);
    }
    applyFoundationTreeFilter(ds, expression) {
        const predicate = toPredicate(expression, this.resolvedFilterFields());
        ds.filterBy(predicate ? [{ predicate }] : null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIMasterDetailView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIMasterDetailView, isStandalone: true, selector: "ui-master-detail-view", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: false, transformFunction: null }, treeDisplayWith: { classPropertyName: "treeDisplayWith", publicName: "treeDisplayWith", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, showFilter: { classPropertyName: "showFilter", publicName: "showFilter", isSignal: true, isRequired: false, transformFunction: null }, filterExpanded: { classPropertyName: "filterExpanded", publicName: "filterExpanded", isSignal: true, isRequired: false, transformFunction: null }, filterModeLocked: { classPropertyName: "filterModeLocked", publicName: "filterModeLocked", isSignal: true, isRequired: false, transformFunction: null }, filterFields: { classPropertyName: "filterFields", publicName: "filterFields", isSignal: true, isRequired: false, transformFunction: null }, splitSizes: { classPropertyName: "splitSizes", publicName: "splitSizes", isSignal: true, isRequired: false, transformFunction: null }, splitName: { classPropertyName: "splitName", publicName: "splitName", isSignal: true, isRequired: false, transformFunction: null }, listConstraints: { classPropertyName: "listConstraints", publicName: "listConstraints", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, pageIndex: { classPropertyName: "pageIndex", publicName: "pageIndex", isSignal: true, isRequired: false, transformFunction: null }, showBuiltInPaginator: { classPropertyName: "showBuiltInPaginator", publicName: "showBuiltInPaginator", isSignal: true, isRequired: false, transformFunction: null }, caption: { classPropertyName: "caption", publicName: "caption", isSignal: true, isRequired: false, transformFunction: null }, showRowIndexIndicator: { classPropertyName: "showRowIndexIndicator", publicName: "showRowIndexIndicator", isSignal: true, isRequired: false, transformFunction: null }, rowIndexHeaderText: { classPropertyName: "rowIndexHeaderText", publicName: "rowIndexHeaderText", isSignal: true, isRequired: false, transformFunction: null }, tableId: { classPropertyName: "tableId", publicName: "tableId", isSignal: true, isRequired: false, transformFunction: null }, resizable: { classPropertyName: "resizable", publicName: "resizable", isSignal: true, isRequired: false, transformFunction: null }, rowHeight: { classPropertyName: "rowHeight", publicName: "rowHeight", isSignal: true, isRequired: false, transformFunction: null }, filterDescriptor: { classPropertyName: "filterDescriptor", publicName: "filterDescriptor", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedChange: "selectedChange", expressionChange: "expressionChange", filterDescriptor: "filterDescriptorChange" }, host: { properties: { "class.horizontal": "orientation() === 'horizontal'", "class.vertical": "orientation() === 'vertical'" }, classAttribute: "ui-master-detail-view" }, queries: [{ propertyName: "columns", predicate: UITableViewColumn, isSignal: true }, { propertyName: "detailTemplate", first: true, predicate: ["detail"], descendants: true, isSignal: true }, { propertyName: "filterTemplate", first: true, predicate: ["filter"], descendants: true, isSignal: true }, { propertyName: "treeNodeTemplate", first: true, predicate: ["nodeTemplate"], descendants: true, isSignal: true }], viewQueries: [{ propertyName: "tableViewChild", first: true, predicate: UITableView, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<!-- Hidden slot: instantiates projected columns so contentChildren can discover them. -->\r\n<div class=\"columns-slot\"><ng-content /></div>\r\n\r\n@if (resolvedShowFilter()) {\r\n  <div class=\"filter-bar\">\r\n    @if (!filterModeLocked()) {\r\n      <button\r\n        class=\"filter-toggle\"\r\n        type=\"button\"\r\n        (click)=\"toggleFilter()\"\r\n        [attr.aria-expanded]=\"!filterCollapsed()\"\r\n        aria-controls=\"mdv-filter-content\"\r\n      >\r\n        <ui-icon\r\n          [svg]=\"filterCollapsed() ? chevronRight : chevronDown\"\r\n          [size]=\"14\"\r\n        />\r\n        <span>Filter</span>\r\n      </button>\r\n    }\r\n    @if (!filterCollapsed()) {\r\n      <div class=\"filter-content\" id=\"mdv-filter-content\">\r\n        @if (filterTemplate(); as filterTpl) {\r\n          <ng-container *ngTemplateOutlet=\"filterTpl\" />\r\n        } @else {\r\n          @if (resolvedFilterFields(); as fields) {\r\n            @if (fields.length > 0) {\r\n              <ui-filter\r\n                [fields]=\"fields\"\r\n                [data]=\"resolvedFilterData()\"\r\n                [allowJunction]=\"true\"\r\n                [modeLocked]=\"filterModeLocked()\"\r\n                [(value)]=\"filterDescriptor\"\r\n                (expressionChange)=\"onFilterExpressionChange($event)\"\r\n              />\r\n            }\r\n          }\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n}\r\n\r\n<ui-split-container\r\n  class=\"split\"\r\n  [orientation]=\"orientation()\"\r\n  [initialSizes]=\"splitSizes()\"\r\n  [name]=\"splitName()\"\r\n  ariaLabel=\"Resize list and detail panels\"\r\n>\r\n  <ui-split-panel [min]=\"listConstraints().min\" [max]=\"listConstraints().max\">\r\n  <aside class=\"list\">\r\n    <header class=\"ui-surface-type-panel\">\r\n      <h2 class=\"title\">{{ title() }}</h2>\r\n    </header>\r\n\r\n    @if (isTreeMode()) {\r\n      <div class=\"tree-wrapper\">\r\n        <ui-tree-view\r\n          [datasource]=\"resolvedTreeDatasource()!\"\r\n          [displayWith]=\"treeDisplayWith()\"\r\n          [filterPredicate]=\"treeFilterPredicate()\"\r\n          [(selected)]=\"selectedTreeNodes\"\r\n          ariaLabel=\"Master list\"\r\n        >\r\n          @if (treeNodeTemplate(); as nodeTpl) {\r\n            <ng-template #nodeTemplate let-node let-level=\"level\" let-expanded=\"expanded\" let-hasChildren=\"hasChildren\">\r\n              <ng-container *ngTemplateOutlet=\"nodeTpl; context: { $implicit: node, level: level, expanded: expanded, hasChildren: hasChildren }\" />\r\n            </ng-template>\r\n          }\r\n        </ui-tree-view>\r\n      </div>\r\n    } @else {\r\n      <div class=\"table-wrapper\">\r\n        <ui-table-view\r\n          [datasource]=\"resolvedTableDatasource()\"\r\n          [externalColumns]=\"columns()\"\r\n          [disabled]=\"disabled()\"\r\n          [pageSize]=\"pageSize()\"\r\n          [pageIndex]=\"pageIndex()\"\r\n          [showBuiltInPaginator]=\"showBuiltInPaginator()\"\r\n          [caption]=\"caption()\"\r\n          [showRowIndexIndicator]=\"showRowIndexIndicator()\"\r\n          [rowIndexHeaderText]=\"rowIndexHeaderText()\"\r\n          [tableId]=\"tableId()\"\r\n          [resizable]=\"resizable()\"\r\n          [rowHeight]=\"rowHeight()\"\r\n          selectionMode=\"single\"\r\n          [showSelectionColumn]=\"false\"\r\n          [rowClickSelect]=\"true\"\r\n          [selectionModel]=\"selectionModel\"\r\n        />\r\n      </div>\r\n    }\r\n  </aside>\r\n  </ui-split-panel>\r\n\r\n  <ui-split-panel>\r\n  <main class=\"detail\">\r\n    @if (detailContext(); as ctx) {\r\n      @if (detailTemplate(); as tpl) {\r\n        <section class=\"detail-content\">\r\n          <ng-container *ngTemplateOutlet=\"tpl; context: ctx\" />\r\n        </section>\r\n      }\r\n    } @else {\r\n      <div class=\"placeholder\">\r\n        <p>{{ placeholder() }}</p>\r\n      </div>\r\n    }\r\n  </main>\r\n  </ui-split-panel>\r\n</ui-split-container>", styles: ["@charset \"UTF-8\";:host{--ui-radius: 6px;display:flex;flex-direction:column;height:100%;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif}.columns-slot{display:none}.split{flex:1;min-height:0}.list{display:flex;flex-direction:column;overflow:hidden;height:100%;min-height:0}.header{padding:.75rem 1rem;flex-shrink:0}.title{margin:0;font-size:.9rem;font-weight:600;letter-spacing:.01em}.filter-bar{flex-shrink:0}.filter-toggle{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:6px;width:100%;padding:.45rem 1rem;font-size:.78rem;font-weight:500;text-align:left}.table-wrapper{flex:1;overflow:hidden;min-height:0}.table-wrapper ::ng-deep ui-table-view{display:flex;flex-direction:column;height:100%}.table-wrapper ::ng-deep .root{display:flex;flex-direction:column;flex:1;min-height:0;border-radius:0;border:none;box-shadow:none}.table-wrapper ::ng-deep ui-table-body{flex:1;min-height:0}.table-wrapper ::ng-deep .table-body-viewport{height:100%}.tree-wrapper{flex:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;padding:.25rem 0}.detail{display:flex;flex-direction:column;overflow:hidden;height:100%}:host.vertical .list{height:100%;width:100%}:host.vertical .detail{height:100%;width:100%}.detail-content{flex:1;overflow-y:auto;padding:1.25rem}.placeholder{flex:1;display:flex;align-items:center;justify-content:center}.placeholder p{margin:0;font-size:.88rem}\n"], dependencies: [{ kind: "component", type: UISplitContainer, selector: "ui-split-container", inputs: ["disabled", "orientation", "initialSizes", "name", "dividerWidth", "ariaLabel"], outputs: ["resized", "resizing"] }, { kind: "component", type: UISplitPanel, selector: "ui-split-panel", inputs: ["min", "max"] }, { kind: "component", type: UITableView, selector: "ui-table-view", inputs: ["renderingStrategy", "disabled", "rowHeight", "datasource", "pageSize", "pageIndex", "showBuiltInPaginator", "pageSizeOptions", "caption", "showRowIndexIndicator", "rowIndexHeaderText", "tableId", "resizable", "selectionMode", "rowClickSelect", "showSelectionColumn", "selectionModel", "externalColumns"], outputs: ["selectionChange"] }, { kind: "component", type: UITreeView, selector: "ui-tree-view", inputs: ["disabled", "datasource", "ariaLabel", "displayWith", "filterPredicate", "sortComparator", "selected"], outputs: ["selectedChange", "nodeExpanded", "nodeCollapsed", "nodeActivated"] }, { kind: "component", type: UIFilter, selector: "ui-filter", inputs: ["disabled", "fields", "allowJunction", "allowSimple", "allowAdvanced", "modeLocked", "showSaveButton", "data", "value"], outputs: ["valueChange", "expressionChange", "saveFilter"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIMasterDetailView, decorators: [{
            type: Component,
            args: [{ selector: "ui-master-detail-view", standalone: true, imports: [
                        UISplitContainer,
                        UISplitPanel,
                        UITableView,
                        UITreeView,
                        UIFilter,
                        NgTemplateOutlet,
                        UIIcon,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-master-detail-view",
                        "[class.horizontal]": "orientation() === 'horizontal'",
                        "[class.vertical]": "orientation() === 'vertical'",
                    }, template: "<!-- Hidden slot: instantiates projected columns so contentChildren can discover them. -->\r\n<div class=\"columns-slot\"><ng-content /></div>\r\n\r\n@if (resolvedShowFilter()) {\r\n  <div class=\"filter-bar\">\r\n    @if (!filterModeLocked()) {\r\n      <button\r\n        class=\"filter-toggle\"\r\n        type=\"button\"\r\n        (click)=\"toggleFilter()\"\r\n        [attr.aria-expanded]=\"!filterCollapsed()\"\r\n        aria-controls=\"mdv-filter-content\"\r\n      >\r\n        <ui-icon\r\n          [svg]=\"filterCollapsed() ? chevronRight : chevronDown\"\r\n          [size]=\"14\"\r\n        />\r\n        <span>Filter</span>\r\n      </button>\r\n    }\r\n    @if (!filterCollapsed()) {\r\n      <div class=\"filter-content\" id=\"mdv-filter-content\">\r\n        @if (filterTemplate(); as filterTpl) {\r\n          <ng-container *ngTemplateOutlet=\"filterTpl\" />\r\n        } @else {\r\n          @if (resolvedFilterFields(); as fields) {\r\n            @if (fields.length > 0) {\r\n              <ui-filter\r\n                [fields]=\"fields\"\r\n                [data]=\"resolvedFilterData()\"\r\n                [allowJunction]=\"true\"\r\n                [modeLocked]=\"filterModeLocked()\"\r\n                [(value)]=\"filterDescriptor\"\r\n                (expressionChange)=\"onFilterExpressionChange($event)\"\r\n              />\r\n            }\r\n          }\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n}\r\n\r\n<ui-split-container\r\n  class=\"split\"\r\n  [orientation]=\"orientation()\"\r\n  [initialSizes]=\"splitSizes()\"\r\n  [name]=\"splitName()\"\r\n  ariaLabel=\"Resize list and detail panels\"\r\n>\r\n  <ui-split-panel [min]=\"listConstraints().min\" [max]=\"listConstraints().max\">\r\n  <aside class=\"list\">\r\n    <header class=\"ui-surface-type-panel\">\r\n      <h2 class=\"title\">{{ title() }}</h2>\r\n    </header>\r\n\r\n    @if (isTreeMode()) {\r\n      <div class=\"tree-wrapper\">\r\n        <ui-tree-view\r\n          [datasource]=\"resolvedTreeDatasource()!\"\r\n          [displayWith]=\"treeDisplayWith()\"\r\n          [filterPredicate]=\"treeFilterPredicate()\"\r\n          [(selected)]=\"selectedTreeNodes\"\r\n          ariaLabel=\"Master list\"\r\n        >\r\n          @if (treeNodeTemplate(); as nodeTpl) {\r\n            <ng-template #nodeTemplate let-node let-level=\"level\" let-expanded=\"expanded\" let-hasChildren=\"hasChildren\">\r\n              <ng-container *ngTemplateOutlet=\"nodeTpl; context: { $implicit: node, level: level, expanded: expanded, hasChildren: hasChildren }\" />\r\n            </ng-template>\r\n          }\r\n        </ui-tree-view>\r\n      </div>\r\n    } @else {\r\n      <div class=\"table-wrapper\">\r\n        <ui-table-view\r\n          [datasource]=\"resolvedTableDatasource()\"\r\n          [externalColumns]=\"columns()\"\r\n          [disabled]=\"disabled()\"\r\n          [pageSize]=\"pageSize()\"\r\n          [pageIndex]=\"pageIndex()\"\r\n          [showBuiltInPaginator]=\"showBuiltInPaginator()\"\r\n          [caption]=\"caption()\"\r\n          [showRowIndexIndicator]=\"showRowIndexIndicator()\"\r\n          [rowIndexHeaderText]=\"rowIndexHeaderText()\"\r\n          [tableId]=\"tableId()\"\r\n          [resizable]=\"resizable()\"\r\n          [rowHeight]=\"rowHeight()\"\r\n          selectionMode=\"single\"\r\n          [showSelectionColumn]=\"false\"\r\n          [rowClickSelect]=\"true\"\r\n          [selectionModel]=\"selectionModel\"\r\n        />\r\n      </div>\r\n    }\r\n  </aside>\r\n  </ui-split-panel>\r\n\r\n  <ui-split-panel>\r\n  <main class=\"detail\">\r\n    @if (detailContext(); as ctx) {\r\n      @if (detailTemplate(); as tpl) {\r\n        <section class=\"detail-content\">\r\n          <ng-container *ngTemplateOutlet=\"tpl; context: ctx\" />\r\n        </section>\r\n      }\r\n    } @else {\r\n      <div class=\"placeholder\">\r\n        <p>{{ placeholder() }}</p>\r\n      </div>\r\n    }\r\n  </main>\r\n  </ui-split-panel>\r\n</ui-split-container>", styles: ["@charset \"UTF-8\";:host{--ui-radius: 6px;display:flex;flex-direction:column;height:100%;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif}.columns-slot{display:none}.split{flex:1;min-height:0}.list{display:flex;flex-direction:column;overflow:hidden;height:100%;min-height:0}.header{padding:.75rem 1rem;flex-shrink:0}.title{margin:0;font-size:.9rem;font-weight:600;letter-spacing:.01em}.filter-bar{flex-shrink:0}.filter-toggle{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:6px;width:100%;padding:.45rem 1rem;font-size:.78rem;font-weight:500;text-align:left}.table-wrapper{flex:1;overflow:hidden;min-height:0}.table-wrapper ::ng-deep ui-table-view{display:flex;flex-direction:column;height:100%}.table-wrapper ::ng-deep .root{display:flex;flex-direction:column;flex:1;min-height:0;border-radius:0;border:none;box-shadow:none}.table-wrapper ::ng-deep ui-table-body{flex:1;min-height:0}.table-wrapper ::ng-deep .table-body-viewport{height:100%}.tree-wrapper{flex:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;padding:.25rem 0}.detail{display:flex;flex-direction:column;overflow:hidden;height:100%}:host.vertical .list{height:100%;width:100%}:host.vertical .detail{height:100%;width:100%}.detail-content{flex:1;overflow-y:auto;padding:1.25rem}.placeholder{flex:1;display:flex;align-items:center;justify-content:center}.placeholder p{margin:0;font-size:.88rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: false }] }], treeDisplayWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "treeDisplayWith", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], showFilter: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFilter", required: false }] }], filterExpanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterExpanded", required: false }] }], filterModeLocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterModeLocked", required: false }] }], filterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterFields", required: false }] }], splitSizes: [{ type: i0.Input, args: [{ isSignal: true, alias: "splitSizes", required: false }] }], splitName: [{ type: i0.Input, args: [{ isSignal: true, alias: "splitName", required: false }] }], listConstraints: [{ type: i0.Input, args: [{ isSignal: true, alias: "listConstraints", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], pageIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageIndex", required: false }] }], showBuiltInPaginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "showBuiltInPaginator", required: false }] }], caption: [{ type: i0.Input, args: [{ isSignal: true, alias: "caption", required: false }] }], showRowIndexIndicator: [{ type: i0.Input, args: [{ isSignal: true, alias: "showRowIndexIndicator", required: false }] }], rowIndexHeaderText: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowIndexHeaderText", required: false }] }], tableId: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableId", required: false }] }], resizable: [{ type: i0.Input, args: [{ isSignal: true, alias: "resizable", required: false }] }], rowHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHeight", required: false }] }], selectedChange: [{ type: i0.Output, args: ["selectedChange"] }], expressionChange: [{ type: i0.Output, args: ["expressionChange"] }], filterDescriptor: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterDescriptor", required: false }] }, { type: i0.Output, args: ["filterDescriptorChange"] }], columns: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => UITableViewColumn), { isSignal: true }] }], detailTemplate: [{ type: i0.ContentChild, args: ["detail", { isSignal: true }] }], filterTemplate: [{ type: i0.ContentChild, args: ["filter", { isSignal: true }] }], treeNodeTemplate: [{ type: i0.ContentChild, args: ["nodeTemplate", { isSignal: true }] }], tableViewChild: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UITableView), { isSignal: true }] }] } });

/**
 * A single panel inside a {@link UIDashboard}.
 *
 * The panel renders a header bar (title + optional collapse / remove
 * controls) and projects arbitrary content via `<ng-content>`.
 *
 * @example
 * ```html
 * <ui-dashboard-panel [config]="{ id: 'sales', title: 'Sales KPI', collapsible: true }">
 *   <p>Revenue chart goes here</p>
 * </ui-dashboard-panel>
 * ```
 */
class UIDashboardPanel {
    // ── Inputs ──────────────────────────────────────────────────────
    /** Panel configuration (id, title, grid placement, flags). */
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : []));
    // ── Outputs ─────────────────────────────────────────────────────
    /** Emitted when the user removes (hides) this panel. */
    panelRemoved = output();
    /** Emitted when the collapsed state changes. */
    collapsedChange = output();
    // ── Computed ────────────────────────────────────────────────────
    /** CSS `grid-column` value derived from placement config. */
    gridColumn = computed(() => {
        const span = this.config().placement?.colSpan ?? 1;
        return span > 1 ? `span ${span}` : undefined;
    }, ...(ngDevMode ? [{ debugName: "gridColumn" }] : []));
    /** CSS `grid-row` value derived from placement config. */
    gridRow = computed(() => {
        const span = this.config().placement?.rowSpan ?? 1;
        return span > 1 ? `span ${span}` : undefined;
    }, ...(ngDevMode ? [{ debugName: "gridRow" }] : []));
    /** Whether the panel header shows a collapse toggle. */
    isCollapsible = computed(() => this.config().collapsible === true, ...(ngDevMode ? [{ debugName: "isCollapsible" }] : []));
    /** Whether the panel header shows a remove button. */
    isRemovable = computed(() => this.config().removable === true, ...(ngDevMode ? [{ debugName: "isRemovable" }] : []));
    /** SVG icon for the collapse toggle button. */
    collapseIcon = computed(() => this.collapsed()
        ? UIIcons.Lucide.Arrows.ChevronRight
        : UIIcons.Lucide.Arrows.ChevronDown, ...(ngDevMode ? [{ debugName: "collapseIcon" }] : []));
    /** SVG icon for the remove button. */
    removeIcon = UIIcons.Lucide.Math.X;
    // ── Public fields ───────────────────────────────────────────────
    /** Whether the panel body is currently collapsed. */
    collapsed = signal(false, ...(ngDevMode ? [{ debugName: "collapsed" }] : []));
    /** Whether the panel has been removed (hidden) by the user. */
    removed = signal(false, ...(ngDevMode ? [{ debugName: "removed" }] : []));
    /** Whether the panel currently has an active notification. */
    notified = signal(false, ...(ngDevMode ? [{ debugName: "notified" }] : []));
    // ── Private fields ──────────────────────────────────────────────
    log = inject(LoggerFactory).createLogger("UIDashboardPanel");
    destroyRef = inject(DestroyRef);
    notificationTimer = null;
    // ── Public methods ──────────────────────────────────────────────
    constructor() {
        this.destroyRef.onDestroy(() => this.clearNotificationTimer());
    }
    // ── Public methods ──────────────────────────────────────────────
    /**
     * Activate a notification on this panel.
     *
     * The notification accent remains visible until the panel is
     * focused (expanded) or the optional `timeoutMs` elapses.
     *
     * @param timeoutMs - Auto-clear delay in milliseconds. When `0`
     *   or omitted the notification persists until manually cleared.
     */
    notify(timeoutMs = 0) {
        this.clearNotificationTimer();
        this.notified.set(true);
        this.log.debug("Panel notified", [this.config().id, timeoutMs]);
        if (timeoutMs > 0) {
            this.notificationTimer = setTimeout(() => {
                this.clearNotification();
            }, timeoutMs);
        }
    }
    /** Clear the active notification. */
    clearNotification() {
        this.clearNotificationTimer();
        this.notified.set(false);
    }
    /** Toggle the collapsed state. */
    toggleCollapse() {
        if (!this.isCollapsible())
            return;
        this.collapsed.update((v) => !v);
        this.collapsedChange.emit(this.collapsed());
        // Expanding a panel clears its notification
        if (!this.collapsed()) {
            this.clearNotification();
        }
        this.log.debug("Panel collapse toggled", [
            this.config().id,
            this.collapsed(),
        ]);
    }
    /** Remove (hide) the panel. */
    remove() {
        if (!this.isRemovable())
            return;
        this.removed.set(true);
        this.panelRemoved.emit(this.config().id);
        this.log.debug("Panel removed", [this.config().id]);
    }
    /** Restore a previously removed panel. */
    restore() {
        this.removed.set(false);
        this.log.debug("Panel restored", [this.config().id]);
    }
    // ── Private methods ─────────────────────────────────────────────
    clearNotificationTimer() {
        if (this.notificationTimer !== null) {
            clearTimeout(this.notificationTimer);
            this.notificationTimer = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIDashboardPanel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIDashboardPanel, isStandalone: true, selector: "ui-dashboard-panel", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { panelRemoved: "panelRemoved", collapsedChange: "collapsedChange" }, host: { properties: { "class.collapsed": "collapsed()", "class.removed": "removed()", "class.notified": "notified()", "style.grid-column": "gridColumn()", "style.grid-row": "gridRow()", "attr.data-panel-id": "config().id" }, classAttribute: "ui-dashboard-panel" }, providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<header class=\"header\">\n  <div class=\"heading\">\n    @if (config().icon) {\n      <ui-icon [svg]=\"config().icon!\" [size]=\"14\" class=\"icon\" />\n    }\n    <h3 class=\"title\">{{ config().title }}</h3>\n  </div>\n\n  <div class=\"actions\">\n    @if (isCollapsible()) {\n      <button\n        type=\"button\"\n        class=\"action\"\n        [attr.aria-label]=\"collapsed() ? 'Expand panel' : 'Collapse panel'\"\n        [attr.aria-expanded]=\"!collapsed()\"\n        (click)=\"toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"collapseIcon()\" [size]=\"14\" />\n      </button>\n    }\n    @if (isRemovable()) {\n      <button\n        type=\"button\"\n        class=\"action action--remove\"\n        aria-label=\"Remove panel\"\n        (click)=\"remove()\"\n      >\n        <ui-icon [svg]=\"removeIcon\" [size]=\"14\" />\n      </button>\n    }\n  </div>\n</header>\n\n@if (!collapsed()) {\n  <div class=\"body\">\n    <ng-content />\n  </div>\n}\n", styles: [":host{--ui-panel-radius: 8px;--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .08), 0 2px 8px rgba(0, 0, 0, .06);display:flex;flex-direction:column;border-radius:var(--ui-panel-radius);overflow:hidden;min-width:0;min-height:0}:host.removed{display:none}:host-context(html.dark-theme){--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .3), 0 2px 8px rgba(0, 0, 0, .2)}@media(prefers-color-scheme:dark){:host-context(html:not(.light-theme):not(.dark-theme)){--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .3), 0 2px 8px rgba(0, 0, 0, .2)}}.header{display:flex;align-items:center;justify-content:space-between;padding:.625rem .875rem;flex-shrink:0}.heading{display:flex;align-items:center;gap:6px;min-width:0}.icon{flex-shrink:0}.title{margin:0;font-size:.82rem;font-weight:600;letter-spacing:.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.actions{display:flex;align-items:center;gap:2px;flex-shrink:0;margin-left:.5rem}.action{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:4px;font-size:.7rem;transition:background-color .15s,color .15s}.body{flex:1;overflow:auto;padding:.875rem;min-height:0}:host(.collapsed){display:none}:host(.notified){animation:ui-panel-pulse 2s ease-in-out infinite}:host(.notified) .icon{animation:ui-icon-pulse 2s ease-in-out infinite}@keyframes ui-icon-pulse{0%,to{opacity:1}50%{opacity:.5}}\n"], dependencies: [{ kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIDashboardPanel, decorators: [{
            type: Component,
            args: [{ selector: "ui-dashboard-panel", standalone: true, imports: [UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], host: {
                        class: "ui-dashboard-panel",
                        "[class.collapsed]": "collapsed()",
                        "[class.removed]": "removed()",
                        "[class.notified]": "notified()",
                        "[style.grid-column]": "gridColumn()",
                        "[style.grid-row]": "gridRow()",
                        "[attr.data-panel-id]": "config().id",
                    }, template: "<header class=\"header\">\n  <div class=\"heading\">\n    @if (config().icon) {\n      <ui-icon [svg]=\"config().icon!\" [size]=\"14\" class=\"icon\" />\n    }\n    <h3 class=\"title\">{{ config().title }}</h3>\n  </div>\n\n  <div class=\"actions\">\n    @if (isCollapsible()) {\n      <button\n        type=\"button\"\n        class=\"action\"\n        [attr.aria-label]=\"collapsed() ? 'Expand panel' : 'Collapse panel'\"\n        [attr.aria-expanded]=\"!collapsed()\"\n        (click)=\"toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"collapseIcon()\" [size]=\"14\" />\n      </button>\n    }\n    @if (isRemovable()) {\n      <button\n        type=\"button\"\n        class=\"action action--remove\"\n        aria-label=\"Remove panel\"\n        (click)=\"remove()\"\n      >\n        <ui-icon [svg]=\"removeIcon\" [size]=\"14\" />\n      </button>\n    }\n  </div>\n</header>\n\n@if (!collapsed()) {\n  <div class=\"body\">\n    <ng-content />\n  </div>\n}\n", styles: [":host{--ui-panel-radius: 8px;--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .08), 0 2px 8px rgba(0, 0, 0, .06);display:flex;flex-direction:column;border-radius:var(--ui-panel-radius);overflow:hidden;min-width:0;min-height:0}:host.removed{display:none}:host-context(html.dark-theme){--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .3), 0 2px 8px rgba(0, 0, 0, .2)}@media(prefers-color-scheme:dark){:host-context(html:not(.light-theme):not(.dark-theme)){--ui-panel-shadow: 0 1px 3px rgba(0, 0, 0, .3), 0 2px 8px rgba(0, 0, 0, .2)}}.header{display:flex;align-items:center;justify-content:space-between;padding:.625rem .875rem;flex-shrink:0}.heading{display:flex;align-items:center;gap:6px;min-width:0}.icon{flex-shrink:0}.title{margin:0;font-size:.82rem;font-weight:600;letter-spacing:.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.actions{display:flex;align-items:center;gap:2px;flex-shrink:0;margin-left:.5rem}.action{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:4px;font-size:.7rem;transition:background-color .15s,color .15s}.body{flex:1;overflow:auto;padding:.875rem;min-height:0}:host(.collapsed){display:none}:host(.notified){animation:ui-panel-pulse 2s ease-in-out infinite}:host(.notified) .icon{animation:ui-icon-pulse 2s ease-in-out infinite}@keyframes ui-icon-pulse{0%,to{opacity:1}50%{opacity:.5}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], panelRemoved: [{ type: i0.Output, args: ["panelRemoved"] }], collapsedChange: [{ type: i0.Output, args: ["collapsedChange"] }] } });

/**
 * Dashboard host component.
 *
 * Lays out projected {@link UIDashboardPanel} children on a CSS grid.
 * The grid column count is configurable via the `columns` input — either
 * a fixed number or `'auto'` for responsive auto-fill.
 *
 * Panels declare their own grid span via their `config.placement`
 * property. The host is intentionally *content-agnostic*: it provides
 * the grid shell and panel management (collapse, remove, restore)
 * while consumers project whatever widgets they need.
 *
 * @example
 * ```html
 * <ui-dashboard [columns]="3" [gap]="16">
 *   <ui-dashboard-panel [config]="{ id: 'kpi', title: 'KPI', placement: { colSpan: 2 } }">
 *     <my-kpi-widget />
 *   </ui-dashboard-panel>
 *
 *   <ui-dashboard-panel [config]="{ id: 'chart', title: 'Revenue' }">
 *     <my-chart />
 *   </ui-dashboard-panel>
 *
 *   <ui-dashboard-panel [config]="{ id: 'feed', title: 'Activity', placement: { colSpan: 3 } }">
 *     <my-activity-feed />
 *   </ui-dashboard-panel>
 * </ui-dashboard>
 * ```
 */
class UIDashboard {
    // ── Inputs ──────────────────────────────────────────────────────
    /**
     * Number of grid columns.
     *
     * - A number (e.g. `3`) creates a fixed column layout.
     * - `'auto'` uses responsive `auto-fill` with `minmax(280px, 1fr)`.
     *
     * Defaults to `'auto'`.
     */
    columns = input("auto", ...(ngDevMode ? [{ debugName: "columns" }] : []));
    /**
     * Gap between grid cells in pixels.
     * Defaults to `16`.
     */
    gap = input(16, ...(ngDevMode ? [{ debugName: "gap" }] : []));
    /**
     * Minimum column width in pixels (only used when `columns` is `'auto'`).
     * Defaults to `280`.
     */
    minColumnWidth = input(280, ...(ngDevMode ? [{ debugName: "minColumnWidth" }] : []));
    /** Accessible label for the dashboard region. */
    ariaLabel = input("Dashboard", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Where the collapsed-panel dock is rendered.
     * Defaults to `'bottom'`.
     */
    dockPosition = input("bottom", ...(ngDevMode ? [{ debugName: "dockPosition" }] : []));
    /**
     * Whether dock chips show the panel title alongside the icon.
     * Defaults to `false` (icon-only with title in tooltip).
     */
    dockShowTitles = input(false, ...(ngDevMode ? [{ debugName: "dockShowTitles" }] : []));
    /**
     * Default SVG icon for panels that don't declare their own `icon`.
     * Defaults to the Lucide `LayoutDashboard` icon.
     */
    defaultDockIcon = input(UIIcons.Lucide.Layout.LayoutDashboard, ...(ngDevMode ? [{ debugName: "defaultDockIcon" }] : []));
    /**
     * SVG icon for the optional dock menu button.
     * When set, a menu button is rendered at the leading edge of the dock.
     * When omitted (`undefined`), no menu button is shown.
     */
    dockMenuIcon = input(undefined, ...(ngDevMode ? [{ debugName: "dockMenuIcon" }] : []));
    // ── Outputs ─────────────────────────────────────────────────────
    /** Emitted when any panel is removed by the user. */
    panelRemoved = output();
    /** Emitted when the dock menu button is clicked. */
    dockMenuClicked = output();
    // ── Content queries ─────────────────────────────────────────────
    /** All projected dashboard panels. */
    panels = contentChildren(UIDashboardPanel, ...(ngDevMode ? [{ debugName: "panels" }] : []));
    // ── Computed ────────────────────────────────────────────────────
    /** CSS value for `grid-template-columns`. */
    gridTemplateColumns = computed(() => {
        const cols = this.columns();
        if (cols === "auto") {
            return `repeat(auto-fill, minmax(${this.minColumnWidth()}px, 1fr))`;
        }
        return `repeat(${cols}, 1fr)`;
    }, ...(ngDevMode ? [{ debugName: "gridTemplateColumns" }] : []));
    /** CSS value for `gap`. */
    gridGap = computed(() => `${this.gap()}px`, ...(ngDevMode ? [{ debugName: "gridGap" }] : []));
    /** Panels that have been removed by the user. */
    removedPanelIds = computed(() => this.panels()
        .filter((p) => p.removed())
        .map((p) => p.config().id), ...(ngDevMode ? [{ debugName: "removedPanelIds" }] : []));
    /** Panels that are currently collapsed (shown in the dock). */
    collapsedPanels = computed(() => this.panels().filter((p) => p.collapsed() && !p.removed()), ...(ngDevMode ? [{ debugName: "collapsedPanels" }] : []));
    // ── Public fields ───────────────────────────────────────────────
    /** Whether the dock panel-picker menu is open. */
    dockMenuOpen = signal(false, ...(ngDevMode ? [{ debugName: "dockMenuOpen" }] : []));
    // ── Protected fields ────────────────────────────────────────────
    // ── Private fields ──────────────────────────────────────────────
    log = inject(LoggerFactory).createLogger("UIDashboard");
    destroyRef = inject(DestroyRef);
    elRef = inject((ElementRef));
    /** Subscriptions to panel `panelRemoved` outputs. */
    panelSubs = [];
    // ── Constructor ─────────────────────────────────────────────────
    constructor() {
        // Close dock menu on outside click
        const onDocClick = (e) => {
            if (this.dockMenuOpen() &&
                !this.elRef.nativeElement
                    .querySelector(".dock-menu-anchor")
                    ?.contains(e.target)) {
                this.dockMenuOpen.set(false);
            }
        };
        document.addEventListener("pointerdown", onDocClick);
        this.destroyRef.onDestroy(() => document.removeEventListener("pointerdown", onDocClick));
        // Whenever the projected panels change, subscribe to their
        // panelRemoved outputs so the host can re-emit them.
        effect(() => {
            const panels = this.panels();
            untracked(() => {
                // Tear down previous subscriptions
                for (const unsub of this.panelSubs) {
                    unsub();
                }
                this.panelSubs = [];
                for (const panel of panels) {
                    const sub = panel.panelRemoved.subscribe((id) => {
                        this.panelRemoved.emit(id);
                    });
                    this.panelSubs.push(() => sub.unsubscribe());
                }
            });
        });
        // Clean up on destroy
        this.destroyRef.onDestroy(() => {
            for (const unsub of this.panelSubs) {
                unsub();
            }
            this.panelSubs = [];
        });
    }
    // ── Public methods ──────────────────────────────────────────────
    /**
     * Restore a previously removed panel by its id.
     *
     * @param panelId - The `config.id` of the panel to restore.
     * @returns `true` if the panel was found and restored.
     */
    restorePanel(panelId) {
        const panel = this.panels().find((p) => p.config().id === panelId);
        if (panel) {
            panel.restore();
            this.log.debug("Panel restored via host", [panelId]);
            return true;
        }
        return false;
    }
    /**
     * Restore all removed panels.
     */
    restoreAll() {
        for (const panel of this.panels()) {
            if (panel.removed()) {
                panel.restore();
            }
        }
        this.log.debug("All panels restored");
    }
    /**
     * Resolve the icon SVG for a panel, falling back to the default.
     *
     * @param panelIcon - The panel's own icon, if any.
     * @returns SVG inner-content string.
     */
    resolveIcon(panelIcon) {
        return panelIcon ?? this.defaultDockIcon();
    }
    /** Toggle the dock panel-picker menu. */
    toggleDockMenu() {
        this.dockMenuOpen.update((v) => !v);
        this.dockMenuClicked.emit();
    }
    /** Close the dock panel-picker menu. */
    closeDockMenu() {
        this.dockMenuOpen.set(false);
    }
    /**
     * Toggle a panel's collapsed state from the menu.
     * If removed, restore it first.
     */
    menuTogglePanel(panel) {
        if (panel.removed()) {
            panel.restore();
        }
        else if (panel.collapsed()) {
            panel.toggleCollapse();
        }
        else if (panel.config().collapsible) {
            panel.toggleCollapse();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIDashboard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIDashboard, isStandalone: true, selector: "ui-dashboard", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, gap: { classPropertyName: "gap", publicName: "gap", isSignal: true, isRequired: false, transformFunction: null }, minColumnWidth: { classPropertyName: "minColumnWidth", publicName: "minColumnWidth", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, dockPosition: { classPropertyName: "dockPosition", publicName: "dockPosition", isSignal: true, isRequired: false, transformFunction: null }, dockShowTitles: { classPropertyName: "dockShowTitles", publicName: "dockShowTitles", isSignal: true, isRequired: false, transformFunction: null }, defaultDockIcon: { classPropertyName: "defaultDockIcon", publicName: "defaultDockIcon", isSignal: true, isRequired: false, transformFunction: null }, dockMenuIcon: { classPropertyName: "dockMenuIcon", publicName: "dockMenuIcon", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { panelRemoved: "panelRemoved", dockMenuClicked: "dockMenuClicked" }, host: { classAttribute: "ui-dashboard" }, queries: [{ propertyName: "panels", predicate: UIDashboardPanel, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "@if (dockPosition() === 'top') {\n  <div class=\"dock\" role=\"toolbar\" aria-label=\"Dashboard dock\">\n    @if (dockMenuIcon()) {\n      <div class=\"anchor\">\n        <button\n          type=\"button\"\n          class=\"menu-btn\"\n          [class.menu-btn--active]=\"dockMenuOpen()\"\n          aria-label=\"Dashboard menu\"\n          [attr.aria-expanded]=\"dockMenuOpen()\"\n          aria-haspopup=\"menu\"\n          (click)=\"toggleDockMenu()\"\n        >\n          <ui-icon [svg]=\"dockMenuIcon()!\" [size]=\"16\" />\n        </button>\n        @if (dockMenuOpen()) {\n          <div class=\"menu\" role=\"menu\" aria-label=\"Panel picker\">\n            @for (panel of panels(); track panel.config().id) {\n              <button\n                type=\"button\"\n                class=\"item\"\n                [class.item--hidden]=\"panel.collapsed() || panel.removed()\"\n                role=\"menuitem\"\n                (click)=\"menuTogglePanel(panel)\"\n              >\n                <ui-icon\n                  [svg]=\"resolveIcon(panel.config().icon)\"\n                  [size]=\"14\"\n                  class=\"item-icon\"\n                />\n                <span class=\"item-label\">{{ panel.config().title }}</span>\n                @if (panel.collapsed() || panel.removed()) {\n                  <span class=\"item-badge\">hidden</span>\n                }\n              </button>\n            }\n            <ng-content select=\"[dockMenuItem]\" />\n          </div>\n        }\n      </div>\n      @if (collapsedPanels().length > 0) {\n        <span class=\"separator\" aria-hidden=\"true\"></span>\n      }\n    }\n    @for (panel of collapsedPanels(); track panel.config().id) {\n      <button\n        type=\"button\"\n        class=\"chip\"\n        [class.chip--notified]=\"panel.notified()\"\n        [attr.title]=\"panel.config().title\"\n        [attr.aria-label]=\"'Restore ' + panel.config().title\"\n        (click)=\"panel.toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"resolveIcon(panel.config().icon)\" [size]=\"16\" />\n        @if (dockShowTitles()) {\n          <span class=\"chip-label\">{{ panel.config().title }}</span>\n        }\n      </button>\n    }\n  </div>\n}\n\n<div\n  class=\"grid\"\n  [style.grid-template-columns]=\"gridTemplateColumns()\"\n  [style.gap]=\"gridGap()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  role=\"region\"\n>\n  <ng-content />\n</div>\n\n@if (dockPosition() === 'bottom') {\n  <div class=\"dock\" role=\"toolbar\" aria-label=\"Dashboard dock\">\n    @if (dockMenuIcon()) {\n      <div class=\"anchor\">\n        <button\n          type=\"button\"\n          class=\"menu-btn\"\n          [class.menu-btn--active]=\"dockMenuOpen()\"\n          aria-label=\"Dashboard menu\"\n          [attr.aria-expanded]=\"dockMenuOpen()\"\n          aria-haspopup=\"menu\"\n          (click)=\"toggleDockMenu()\"\n        >\n          <ui-icon [svg]=\"dockMenuIcon()!\" [size]=\"16\" />\n        </button>\n        @if (dockMenuOpen()) {\n          <div class=\"menu menu--above\" role=\"menu\" aria-label=\"Panel picker\">\n            @for (panel of panels(); track panel.config().id) {\n              <button\n                type=\"button\"\n                class=\"item\"\n                [class.item--hidden]=\"panel.collapsed() || panel.removed()\"\n                role=\"menuitem\"\n                (click)=\"menuTogglePanel(panel)\"\n              >\n                <ui-icon\n                  [svg]=\"resolveIcon(panel.config().icon)\"\n                  [size]=\"14\"\n                  class=\"item-icon\"\n                />\n                <span class=\"item-label\">{{ panel.config().title }}</span>\n                @if (panel.collapsed() || panel.removed()) {\n                  <span class=\"item-badge\">hidden</span>\n                }\n              </button>\n            }\n            <ng-content select=\"[dockMenuItem]\" />\n          </div>\n        }\n      </div>\n      @if (collapsedPanels().length > 0) {\n        <span class=\"separator\" aria-hidden=\"true\"></span>\n      }\n    }\n    @for (panel of collapsedPanels(); track panel.config().id) {\n      <button\n        type=\"button\"\n        class=\"chip\"\n        [class.chip--notified]=\"panel.notified()\"\n        [attr.title]=\"panel.config().title\"\n        [attr.aria-label]=\"'Restore ' + panel.config().title\"\n        (click)=\"panel.toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"resolveIcon(panel.config().icon)\" [size]=\"16\" />\n        @if (dockShowTitles()) {\n          <span class=\"chip-label\">{{ panel.config().title }}</span>\n        }\n      </button>\n    }\n  </div>\n}\n", styles: [":host{display:block;font-family:system-ui,-apple-system,sans-serif}.grid{display:grid;grid-auto-rows:minmax(120px,auto)}.dock{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;margin-top:12px}.dock:first-child{margin-top:0;margin-bottom:12px}.chip{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:6px;font-size:.78rem;font-weight:500;white-space:nowrap;transition:background-color .15s,box-shadow .15s}.chip-label{line-height:1}.chip--notified{animation:ui-dock-chip-pulse 2s ease-in-out infinite}.chip--notified ui-icon{animation:ui-dock-icon-pulse 2s ease-in-out infinite}@keyframes ui-dock-icon-pulse{0%,to{opacity:1}50%{opacity:.5}}.menu-btn{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;padding:6px;border-radius:6px;transition:background-color .15s,color .15s}.separator{width:1px;height:20px;flex-shrink:0}.anchor{position:relative}.menu{position:absolute;top:calc(100% + 6px);left:0;z-index:100;min-width:200px;padding:4px;border-radius:8px}.menu--above{top:auto;bottom:calc(100% + 6px)}.menu hr{border:none;height:1px;margin:4px 0}.item{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:8px;width:100%;padding:8px 10px;border-radius:6px;font-size:.8rem;font-weight:500;white-space:nowrap;text-align:left;transition:background-color .15s}.item--hidden{opacity:.5}.item--disabled{opacity:.4;pointer-events:none}.item-icon{flex-shrink:0}.item-label{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.item-badge{font-size:.65rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;padding:2px 6px;border-radius:4px;opacity:.7}\n"], dependencies: [{ kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIDashboard, decorators: [{
            type: Component,
            args: [{ selector: "ui-dashboard", standalone: true, imports: [UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: {
                        class: "ui-dashboard",
                    }, template: "@if (dockPosition() === 'top') {\n  <div class=\"dock\" role=\"toolbar\" aria-label=\"Dashboard dock\">\n    @if (dockMenuIcon()) {\n      <div class=\"anchor\">\n        <button\n          type=\"button\"\n          class=\"menu-btn\"\n          [class.menu-btn--active]=\"dockMenuOpen()\"\n          aria-label=\"Dashboard menu\"\n          [attr.aria-expanded]=\"dockMenuOpen()\"\n          aria-haspopup=\"menu\"\n          (click)=\"toggleDockMenu()\"\n        >\n          <ui-icon [svg]=\"dockMenuIcon()!\" [size]=\"16\" />\n        </button>\n        @if (dockMenuOpen()) {\n          <div class=\"menu\" role=\"menu\" aria-label=\"Panel picker\">\n            @for (panel of panels(); track panel.config().id) {\n              <button\n                type=\"button\"\n                class=\"item\"\n                [class.item--hidden]=\"panel.collapsed() || panel.removed()\"\n                role=\"menuitem\"\n                (click)=\"menuTogglePanel(panel)\"\n              >\n                <ui-icon\n                  [svg]=\"resolveIcon(panel.config().icon)\"\n                  [size]=\"14\"\n                  class=\"item-icon\"\n                />\n                <span class=\"item-label\">{{ panel.config().title }}</span>\n                @if (panel.collapsed() || panel.removed()) {\n                  <span class=\"item-badge\">hidden</span>\n                }\n              </button>\n            }\n            <ng-content select=\"[dockMenuItem]\" />\n          </div>\n        }\n      </div>\n      @if (collapsedPanels().length > 0) {\n        <span class=\"separator\" aria-hidden=\"true\"></span>\n      }\n    }\n    @for (panel of collapsedPanels(); track panel.config().id) {\n      <button\n        type=\"button\"\n        class=\"chip\"\n        [class.chip--notified]=\"panel.notified()\"\n        [attr.title]=\"panel.config().title\"\n        [attr.aria-label]=\"'Restore ' + panel.config().title\"\n        (click)=\"panel.toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"resolveIcon(panel.config().icon)\" [size]=\"16\" />\n        @if (dockShowTitles()) {\n          <span class=\"chip-label\">{{ panel.config().title }}</span>\n        }\n      </button>\n    }\n  </div>\n}\n\n<div\n  class=\"grid\"\n  [style.grid-template-columns]=\"gridTemplateColumns()\"\n  [style.gap]=\"gridGap()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  role=\"region\"\n>\n  <ng-content />\n</div>\n\n@if (dockPosition() === 'bottom') {\n  <div class=\"dock\" role=\"toolbar\" aria-label=\"Dashboard dock\">\n    @if (dockMenuIcon()) {\n      <div class=\"anchor\">\n        <button\n          type=\"button\"\n          class=\"menu-btn\"\n          [class.menu-btn--active]=\"dockMenuOpen()\"\n          aria-label=\"Dashboard menu\"\n          [attr.aria-expanded]=\"dockMenuOpen()\"\n          aria-haspopup=\"menu\"\n          (click)=\"toggleDockMenu()\"\n        >\n          <ui-icon [svg]=\"dockMenuIcon()!\" [size]=\"16\" />\n        </button>\n        @if (dockMenuOpen()) {\n          <div class=\"menu menu--above\" role=\"menu\" aria-label=\"Panel picker\">\n            @for (panel of panels(); track panel.config().id) {\n              <button\n                type=\"button\"\n                class=\"item\"\n                [class.item--hidden]=\"panel.collapsed() || panel.removed()\"\n                role=\"menuitem\"\n                (click)=\"menuTogglePanel(panel)\"\n              >\n                <ui-icon\n                  [svg]=\"resolveIcon(panel.config().icon)\"\n                  [size]=\"14\"\n                  class=\"item-icon\"\n                />\n                <span class=\"item-label\">{{ panel.config().title }}</span>\n                @if (panel.collapsed() || panel.removed()) {\n                  <span class=\"item-badge\">hidden</span>\n                }\n              </button>\n            }\n            <ng-content select=\"[dockMenuItem]\" />\n          </div>\n        }\n      </div>\n      @if (collapsedPanels().length > 0) {\n        <span class=\"separator\" aria-hidden=\"true\"></span>\n      }\n    }\n    @for (panel of collapsedPanels(); track panel.config().id) {\n      <button\n        type=\"button\"\n        class=\"chip\"\n        [class.chip--notified]=\"panel.notified()\"\n        [attr.title]=\"panel.config().title\"\n        [attr.aria-label]=\"'Restore ' + panel.config().title\"\n        (click)=\"panel.toggleCollapse()\"\n      >\n        <ui-icon [svg]=\"resolveIcon(panel.config().icon)\" [size]=\"16\" />\n        @if (dockShowTitles()) {\n          <span class=\"chip-label\">{{ panel.config().title }}</span>\n        }\n      </button>\n    }\n  </div>\n}\n", styles: [":host{display:block;font-family:system-ui,-apple-system,sans-serif}.grid{display:grid;grid-auto-rows:minmax(120px,auto)}.dock{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;margin-top:12px}.dock:first-child{margin-top:0;margin-bottom:12px}.chip{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:6px;font-size:.78rem;font-weight:500;white-space:nowrap;transition:background-color .15s,box-shadow .15s}.chip-label{line-height:1}.chip--notified{animation:ui-dock-chip-pulse 2s ease-in-out infinite}.chip--notified ui-icon{animation:ui-dock-icon-pulse 2s ease-in-out infinite}@keyframes ui-dock-icon-pulse{0%,to{opacity:1}50%{opacity:.5}}.menu-btn{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;padding:6px;border-radius:6px;transition:background-color .15s,color .15s}.separator{width:1px;height:20px;flex-shrink:0}.anchor{position:relative}.menu{position:absolute;top:calc(100% + 6px);left:0;z-index:100;min-width:200px;padding:4px;border-radius:8px}.menu--above{top:auto;bottom:calc(100% + 6px)}.menu hr{border:none;height:1px;margin:4px 0}.item{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:8px;width:100%;padding:8px 10px;border-radius:6px;font-size:.8rem;font-weight:500;white-space:nowrap;text-align:left;transition:background-color .15s}.item--hidden{opacity:.5}.item--disabled{opacity:.4;pointer-events:none}.item-icon{flex-shrink:0}.item-label{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.item-badge{font-size:.65rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;padding:2px 6px;border-radius:4px;opacity:.7}\n"] }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], gap: [{ type: i0.Input, args: [{ isSignal: true, alias: "gap", required: false }] }], minColumnWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "minColumnWidth", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], dockPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "dockPosition", required: false }] }], dockShowTitles: [{ type: i0.Input, args: [{ isSignal: true, alias: "dockShowTitles", required: false }] }], defaultDockIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultDockIcon", required: false }] }], dockMenuIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "dockMenuIcon", required: false }] }], panelRemoved: [{ type: i0.Output, args: ["panelRemoved"] }], dockMenuClicked: [{ type: i0.Output, args: ["dockMenuClicked"] }], panels: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => UIDashboardPanel), { isSignal: true }] }] } });

// ── Component ────────────────────────────────────────────────────────
/**
 * A full-page navigation layout that combines a {@link UIDrawer},
 * a {@link UISidebarNav} with configurable items, a {@link UIBreadcrumb}
 * path, and a main content area.
 *
 * Navigation items are provided as a tree — either via an
 * {@link ITreeDatasource} for dynamic data, or via a convenience
 * `items` input accepting `NavigationNode[]`.
 *
 * Tree nodes with **children** are rendered as collapsible
 * `<ui-sidebar-group>` elements; leaf nodes render as
 * `<ui-sidebar-item>` entries. The breadcrumb trail is built
 * automatically from the node hierarchy.
 *
 * ### Data sources
 *
 * | Input        | Type                                     | Use case                     |
 * |--------------|------------------------------------------|------------------------------|
 * | `datasource` | `ITreeDatasource<NavigationNodeData>`     | Dynamic / async data         |
 * | `items`      | `NavigationNode[]`                       | Static in-memory tree        |
 *
 * When both are set, `datasource` takes precedence.
 *
 * Use the `navItem()` and `navGroup()` factory functions (or
 * `routesToNavigation()` for Angular Router integration) to build
 * the node array ergonomically.
 *
 * @example
 * ```html
 * <ui-navigation-page
 *   [items]="navItems"
 *   [(activePage)]="currentPage"
 *   (navigated)="onNavigate($event)"
 * >
 *   <ng-template #content let-node>
 *     <h2>{{ node.data.label }}</h2>
 *   </ng-template>
 * </ui-navigation-page>
 * ```
 */
class UINavigationPage {
    // ── Inputs ──────────────────────────────────────────────────────────
    /**
     * Tree datasource providing navigation nodes.
     *
     * Accepts any {@link ITreeDatasource} whose data payload is
     * {@link NavigationNodeData}. Root nodes with `children` render as
     * collapsible groups; leaf nodes render as sidebar items.
     *
     * Takes precedence over the `items` convenience input.
     */
    datasource = input(undefined, ...(ngDevMode ? [{ debugName: "datasource" }] : []));
    /**
     * Convenience: static array of navigation tree nodes.
     *
     * When set (and no `datasource` is provided), an internal
     * `ArrayTreeDatasource` is created automatically.
     *
     * Build nodes with the `navItem()` / `navGroup()` factories
     * or the `routesToNavigation()` utility.
     */
    items = input([], ...(ngDevMode ? [{ debugName: "items" }] : []));
    /**
     * Root breadcrumb label displayed as the first item in the trail.
     * Clicking it navigates to the first leaf node.
     */
    rootLabel = input("Home", ...(ngDevMode ? [{ debugName: "rootLabel" }] : []));
    /** Side the drawer slides in from. */
    drawerPosition = input("left", ...(ngDevMode ? [{ debugName: "drawerPosition" }] : []));
    /** Width of the drawer panel. */
    drawerWidth = input("medium", ...(ngDevMode ? [{ debugName: "drawerWidth" }] : []));
    /** Visual style for the breadcrumb trail. */
    breadcrumbVariant = input("button", ...(ngDevMode ? [{ debugName: "breadcrumbVariant" }] : []));
    /** Accessible label for the navigation landmark. */
    ariaLabel = input("Page navigation", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /** Whether the drawer should always be visible (desktop layout). */
    sidebarPinned = input(true, ...(ngDevMode ? [{ debugName: "sidebarPinned" }] : []));
    /** Whether to show the sidebar toggle button before the breadcrumb. */
    showSidebarToggle = input(true, ...(ngDevMode ? [{ debugName: "showSidebarToggle" }] : []));
    /**
     * Optional localStorage key for persisting the sidebar open/closed state.
     *
     * When set, the component reads the stored value on creation and
     * writes back whenever `sidebarVisible` changes. Leave empty
     * (the default) to disable persistence.
     */
    storageKey = input("", ...(ngDevMode ? [{ debugName: "storageKey" }] : []));
    // ── Models ──────────────────────────────────────────────────────────
    /** The currently active node id. Supports two-way binding. */
    activePage = model("", ...(ngDevMode ? [{ debugName: "activePage" }] : []));
    /** Whether the drawer is open (when not pinned). Supports two-way binding. */
    drawerOpen = model(false, ...(ngDevMode ? [{ debugName: "drawerOpen" }] : []));
    /** Whether the sidebar panel is visible. Supports two-way binding. Defaults to shown. */
    sidebarVisible = model(true, ...(ngDevMode ? [{ debugName: "sidebarVisible" }] : []));
    // ── Outputs ─────────────────────────────────────────────────────────
    /** Emitted when the user navigates to a node. */
    navigated = output();
    // ── Content queries ─────────────────────────────────────────────────
    /**
     * Projected template for the main content area.
     * Receives the current {@link NavigationNode} as the implicit context.
     *
     * ```html
     * <ng-template #content let-node>
     *   <h2>{{ node.data.label }}</h2>
     * </ng-template>
     * ```
     */
    contentTemplate = contentChild("content", ...(ngDevMode ? [{ debugName: "contentTemplate" }] : []));
    /** Projected sidebar items for custom content above the generated items. */
    projectedItems = contentChildren(UISidebarItem, ...(ngDevMode ? [{ debugName: "projectedItems" }] : []));
    // ── Computed ────────────────────────────────────────────────────────
    /** Icon for the sidebar toggle button. @internal */
    sidebarToggleIcon = computed(() => this.sidebarVisible()
        ? UIIcons.Lucide.Arrows.PanelLeftClose
        : UIIcons.Lucide.Arrows.PanelLeftOpen, ...(ngDevMode ? [{ debugName: "sidebarToggleIcon" }] : []));
    // ── Private fields ──────────────────────────────────────────────────
    storage = inject(StorageService);
    // ── Lifecycle ───────────────────────────────────────────────────────
    ngOnInit() {
        const key = this.storageKey();
        if (key) {
            const stored = this.storage.getItem(key);
            if (stored !== null) {
                this.sidebarVisible.set(stored === "true");
            }
        }
    }
    // ── Public methods ──────────────────────────────────────────────────
    /** Toggle the sidebar and persist the new state to storage. */
    toggleSidebar() {
        const next = !this.sidebarVisible();
        this.sidebarVisible.set(next);
        const key = this.storageKey();
        if (key) {
            this.storage.setItem(key, String(next));
        }
    }
    /** Resolved datasource — from the input or auto-created from items. */
    resolvedDatasource = computed(() => {
        const ds = this.datasource();
        if (ds) {
            return ds;
        }
        return new ArrayTreeDatasource(this.items());
    }, ...(ngDevMode ? [{ debugName: "resolvedDatasource" }] : []));
    /** Root nodes from the resolved datasource. */
    rootNodes = computed(() => {
        const ds = this.resolvedDatasource();
        const roots = ds.getRootNodes();
        // Support only synchronous datasources for now
        return Array.isArray(roots) ? roots : [];
    }, ...(ngDevMode ? [{ debugName: "rootNodes" }] : []));
    /** The currently active navigation node. */
    currentPage = computed(() => {
        const id = this.activePage();
        return this.findNodeById(id, this.rootNodes()) ?? this.firstLeaf();
    }, ...(ngDevMode ? [{ debugName: "currentPage" }] : []));
    /** Breadcrumb trail derived from the active node and its ancestors. */
    breadcrumbItems = computed(() => {
        const current = this.currentPage();
        if (!current) {
            return [{ label: this.rootLabel() }];
        }
        const items = [{ label: this.rootLabel(), url: "/" }];
        // If the node is a child of a group, add the group crumb
        const parent = this.findParent(current.id, this.rootNodes());
        if (parent) {
            items.push({ label: parent.data.label });
        }
        items.push({ label: current.data.label });
        return items;
    }, ...(ngDevMode ? [{ debugName: "breadcrumbItems" }] : []));
    // ── Public methods ──────────────────────────────────────────────────
    /** Navigate to a node by its tree-node reference. */
    navigate(node) {
        if (node.disabled) {
            return;
        }
        this.activePage.set(node.id);
        this.navigated.emit(node);
        // Auto-close drawer on navigation when not pinned
        if (!this.sidebarPinned()) {
            this.drawerOpen.set(false);
        }
    }
    /** Navigate to the first leaf node (root breadcrumb click handler). */
    navigateToRoot() {
        const first = this.firstLeaf();
        if (first) {
            this.navigate(first);
        }
    }
    /** @internal Handle breadcrumb item clicks. */
    onBreadcrumbClick(item) {
        if (item.url === "/") {
            this.navigateToRoot();
            return;
        }
        // Try to find a node matching the breadcrumb label
        const node = this.findNodeByLabel(item.label, this.rootNodes());
        if (node) {
            this.navigate(node);
        }
    }
    // ── Private helpers ─────────────────────────────────────────────────
    /**
     * Finds a node by `id` anywhere in the tree (depth-first).
     * @internal
     */
    findNodeById(id, nodes) {
        for (const node of nodes) {
            if (node.id === id) {
                return node;
            }
            if (node.children?.length) {
                const found = this.findNodeById(id, node.children);
                if (found) {
                    return found;
                }
            }
        }
        return undefined;
    }
    /**
     * Finds a node by `data.label` anywhere in the tree (depth-first).
     * @internal
     */
    findNodeByLabel(label, nodes) {
        for (const node of nodes) {
            if (node.data.label === label) {
                return node;
            }
            if (node.children?.length) {
                const found = this.findNodeByLabel(label, node.children);
                if (found) {
                    return found;
                }
            }
        }
        return undefined;
    }
    /**
     * Finds the parent node of a given child `id`.
     * @internal
     */
    findParent(childId, nodes) {
        for (const node of nodes) {
            if (node.children?.some((c) => c.id === childId)) {
                return node;
            }
            if (node.children?.length) {
                const found = this.findParent(childId, node.children);
                if (found) {
                    return found;
                }
            }
        }
        return undefined;
    }
    /**
     * Returns the first leaf node (no children) in the tree.
     * @internal
     */
    firstLeaf() {
        const roots = this.rootNodes();
        for (const node of roots) {
            if (!node.children?.length) {
                return node;
            }
            // First child of a group
            const leaf = node.children.find((c) => !c.children?.length);
            if (leaf) {
                return leaf;
            }
        }
        return roots[0];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UINavigationPage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UINavigationPage, isStandalone: true, selector: "ui-navigation-page", inputs: { datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, rootLabel: { classPropertyName: "rootLabel", publicName: "rootLabel", isSignal: true, isRequired: false, transformFunction: null }, drawerPosition: { classPropertyName: "drawerPosition", publicName: "drawerPosition", isSignal: true, isRequired: false, transformFunction: null }, drawerWidth: { classPropertyName: "drawerWidth", publicName: "drawerWidth", isSignal: true, isRequired: false, transformFunction: null }, breadcrumbVariant: { classPropertyName: "breadcrumbVariant", publicName: "breadcrumbVariant", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, sidebarPinned: { classPropertyName: "sidebarPinned", publicName: "sidebarPinned", isSignal: true, isRequired: false, transformFunction: null }, showSidebarToggle: { classPropertyName: "showSidebarToggle", publicName: "showSidebarToggle", isSignal: true, isRequired: false, transformFunction: null }, storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: false, transformFunction: null }, activePage: { classPropertyName: "activePage", publicName: "activePage", isSignal: true, isRequired: false, transformFunction: null }, drawerOpen: { classPropertyName: "drawerOpen", publicName: "drawerOpen", isSignal: true, isRequired: false, transformFunction: null }, sidebarVisible: { classPropertyName: "sidebarVisible", publicName: "sidebarVisible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activePage: "activePageChange", drawerOpen: "drawerOpenChange", sidebarVisible: "sidebarVisibleChange", navigated: "navigated" }, host: { properties: { "class.drawer-open": "drawerOpen()", "class.sidebar-hidden": "!sidebarVisible()" }, classAttribute: "ui-navigation-page" }, queries: [{ propertyName: "contentTemplate", first: true, predicate: ["content"], descendants: true, isSignal: true }, { propertyName: "projectedItems", predicate: UISidebarItem, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"layout\">\n  <!-- Sidebar (pinned or inside drawer) -->\n  @if (sidebarPinned()) {\n    <aside class=\"sidebar\" [class.sidebar--collapsed]=\"!sidebarVisible()\">\n      <ng-content select=\"[uiSidebarHeader]\" />\n      <ui-sidebar-nav [ariaLabel]=\"ariaLabel()\">\n        <ng-content select=\"ui-sidebar-item\" />\n\n        @for (node of rootNodes(); track node.id) {\n          @if (node.children?.length) {\n            <ui-sidebar-group\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [expanded]=\"node.expanded ?? true\"\n            >\n              @for (child of node.children; track child.id) {\n                <ui-sidebar-item\n                  [label]=\"child.data.label\"\n                  [icon]=\"child.icon ?? ''\"\n                  [badge]=\"child.data.badge ?? ''\"\n                  [active]=\"currentPage()?.id === child.id\"\n                  [disabled]=\"child.disabled ?? false\"\n                  (activated)=\"navigate(child)\"\n                />\n              }\n            </ui-sidebar-group>\n          } @else {\n            <ui-sidebar-item\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [badge]=\"node.data.badge ?? ''\"\n              [active]=\"currentPage()?.id === node.id\"\n              [disabled]=\"node.disabled ?? false\"\n              (activated)=\"navigate(node)\"\n            />\n          }\n        }\n      </ui-sidebar-nav>\n      <ng-content select=\"[uiSidebarFooter]\" />\n    </aside>\n  } @else {\n    <ui-drawer\n      [(open)]=\"drawerOpen\"\n      [position]=\"drawerPosition()\"\n      [width]=\"drawerWidth()\"\n      [ariaLabel]=\"ariaLabel()\"\n    >\n      <ng-content select=\"[uiSidebarHeader]\" />\n      <ui-sidebar-nav [ariaLabel]=\"ariaLabel()\">\n        <ng-content select=\"ui-sidebar-item\" />\n\n        @for (node of rootNodes(); track node.id) {\n          @if (node.children?.length) {\n            <ui-sidebar-group\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [expanded]=\"node.expanded ?? true\"\n            >\n              @for (child of node.children; track child.id) {\n                <ui-sidebar-item\n                  [label]=\"child.data.label\"\n                  [icon]=\"child.icon ?? ''\"\n                  [badge]=\"child.data.badge ?? ''\"\n                  [active]=\"currentPage()?.id === child.id\"\n                  [disabled]=\"child.disabled ?? false\"\n                  (activated)=\"navigate(child)\"\n                />\n              }\n            </ui-sidebar-group>\n          } @else {\n            <ui-sidebar-item\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [badge]=\"node.data.badge ?? ''\"\n              [active]=\"currentPage()?.id === node.id\"\n              [disabled]=\"node.disabled ?? false\"\n              (activated)=\"navigate(node)\"\n            />\n          }\n        }\n      </ui-sidebar-nav>\n      <ng-content select=\"[uiSidebarFooter]\" />\n    </ui-drawer>\n  }\n\n  <!-- Main content area -->\n  <main class=\"main\">\n    <header class=\"breadcrumb\">\n      @if (showSidebarToggle()) {\n        <ui-button\n          class=\"sidebar-toggle\"\n          variant=\"ghost\"\n          ariaLabel=\"Toggle sidebar\"\n          (click)=\"toggleSidebar()\"\n        >\n          <ui-icon [svg]=\"sidebarToggleIcon()\" [size]=\"18\" />\n        </ui-button>\n      }\n      <ui-breadcrumb\n        surfaceType=\"panel\"\n        [items]=\"breadcrumbItems()\"\n        [variant]=\"breadcrumbVariant()\"\n        ariaLabel=\"Page breadcrumb\"\n        (itemClicked)=\"onBreadcrumbClick($event)\"\n      />\n    </header>\n\n    <div class=\"content\">\n      @if (contentTemplate(); as tpl) {\n        <ng-container\n          *ngTemplateOutlet=\"tpl; context: { $implicit: currentPage(), page: currentPage() }\"\n        />\n      } @else {\n        <ng-content />\n      }\n    </div>\n  </main>\n</div>\n", styles: ["@charset \"UTF-8\";:host{--ui-sidebar-width: 16rem;display:block;height:100%;width:100%}.layout{display:flex;height:100%;width:100%}.sidebar{display:flex;flex-direction:column;flex-shrink:0;width:var(--ui-sidebar-width);transition:width .25s ease,opacity .2s ease;opacity:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;overflow-x:hidden}.sidebar ui-sidebar-nav{flex:1;min-height:0;height:auto}.sidebar--collapsed{width:0;opacity:0;overflow:hidden}.main{flex:1;display:flex;flex-direction:column;min-width:0;overflow:hidden}.breadcrumb{display:flex;align-items:center;gap:.25rem;flex-shrink:0;padding:.75rem 1.25rem}.sidebar-toggle{flex-shrink:0}.content{flex:1;padding:1.5rem;overflow-y:auto}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDrawer, selector: "ui-drawer", inputs: ["open", "position", "width", "closeOnBackdropClick", "closeOnEscape", "ariaLabel"], outputs: ["openChange", "closed"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }, { kind: "component", type: UISidebarNav, selector: "ui-sidebar-nav", inputs: ["ariaLabel", "collapsed"] }, { kind: "component", type: UISidebarItem, selector: "ui-sidebar-item", inputs: ["label", "icon", "badge", "active", "disabled"], outputs: ["activated"] }, { kind: "component", type: UISidebarGroup, selector: "ui-sidebar-group", inputs: ["label", "icon", "expanded"], outputs: ["expandedChange"] }, { kind: "component", type: UIBreadcrumb, selector: "ui-breadcrumb", inputs: ["disabled", "items", "variant", "separator", "ariaLabel"], outputs: ["itemClicked"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UINavigationPage, decorators: [{
            type: Component,
            args: [{ selector: "ui-navigation-page", standalone: true, imports: [
                        NgTemplateOutlet,
                        UIButton,
                        UIDrawer,
                        UIIcon,
                        UISidebarNav,
                        UISidebarItem,
                        UISidebarGroup,
                        UIBreadcrumb,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-navigation-page",
                        "[class.drawer-open]": "drawerOpen()",
                        "[class.sidebar-hidden]": "!sidebarVisible()",
                    }, template: "<div class=\"layout\">\n  <!-- Sidebar (pinned or inside drawer) -->\n  @if (sidebarPinned()) {\n    <aside class=\"sidebar\" [class.sidebar--collapsed]=\"!sidebarVisible()\">\n      <ng-content select=\"[uiSidebarHeader]\" />\n      <ui-sidebar-nav [ariaLabel]=\"ariaLabel()\">\n        <ng-content select=\"ui-sidebar-item\" />\n\n        @for (node of rootNodes(); track node.id) {\n          @if (node.children?.length) {\n            <ui-sidebar-group\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [expanded]=\"node.expanded ?? true\"\n            >\n              @for (child of node.children; track child.id) {\n                <ui-sidebar-item\n                  [label]=\"child.data.label\"\n                  [icon]=\"child.icon ?? ''\"\n                  [badge]=\"child.data.badge ?? ''\"\n                  [active]=\"currentPage()?.id === child.id\"\n                  [disabled]=\"child.disabled ?? false\"\n                  (activated)=\"navigate(child)\"\n                />\n              }\n            </ui-sidebar-group>\n          } @else {\n            <ui-sidebar-item\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [badge]=\"node.data.badge ?? ''\"\n              [active]=\"currentPage()?.id === node.id\"\n              [disabled]=\"node.disabled ?? false\"\n              (activated)=\"navigate(node)\"\n            />\n          }\n        }\n      </ui-sidebar-nav>\n      <ng-content select=\"[uiSidebarFooter]\" />\n    </aside>\n  } @else {\n    <ui-drawer\n      [(open)]=\"drawerOpen\"\n      [position]=\"drawerPosition()\"\n      [width]=\"drawerWidth()\"\n      [ariaLabel]=\"ariaLabel()\"\n    >\n      <ng-content select=\"[uiSidebarHeader]\" />\n      <ui-sidebar-nav [ariaLabel]=\"ariaLabel()\">\n        <ng-content select=\"ui-sidebar-item\" />\n\n        @for (node of rootNodes(); track node.id) {\n          @if (node.children?.length) {\n            <ui-sidebar-group\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [expanded]=\"node.expanded ?? true\"\n            >\n              @for (child of node.children; track child.id) {\n                <ui-sidebar-item\n                  [label]=\"child.data.label\"\n                  [icon]=\"child.icon ?? ''\"\n                  [badge]=\"child.data.badge ?? ''\"\n                  [active]=\"currentPage()?.id === child.id\"\n                  [disabled]=\"child.disabled ?? false\"\n                  (activated)=\"navigate(child)\"\n                />\n              }\n            </ui-sidebar-group>\n          } @else {\n            <ui-sidebar-item\n              [label]=\"node.data.label\"\n              [icon]=\"node.icon ?? ''\"\n              [badge]=\"node.data.badge ?? ''\"\n              [active]=\"currentPage()?.id === node.id\"\n              [disabled]=\"node.disabled ?? false\"\n              (activated)=\"navigate(node)\"\n            />\n          }\n        }\n      </ui-sidebar-nav>\n      <ng-content select=\"[uiSidebarFooter]\" />\n    </ui-drawer>\n  }\n\n  <!-- Main content area -->\n  <main class=\"main\">\n    <header class=\"breadcrumb\">\n      @if (showSidebarToggle()) {\n        <ui-button\n          class=\"sidebar-toggle\"\n          variant=\"ghost\"\n          ariaLabel=\"Toggle sidebar\"\n          (click)=\"toggleSidebar()\"\n        >\n          <ui-icon [svg]=\"sidebarToggleIcon()\" [size]=\"18\" />\n        </ui-button>\n      }\n      <ui-breadcrumb\n        surfaceType=\"panel\"\n        [items]=\"breadcrumbItems()\"\n        [variant]=\"breadcrumbVariant()\"\n        ariaLabel=\"Page breadcrumb\"\n        (itemClicked)=\"onBreadcrumbClick($event)\"\n      />\n    </header>\n\n    <div class=\"content\">\n      @if (contentTemplate(); as tpl) {\n        <ng-container\n          *ngTemplateOutlet=\"tpl; context: { $implicit: currentPage(), page: currentPage() }\"\n        />\n      } @else {\n        <ng-content />\n      }\n    </div>\n  </main>\n</div>\n", styles: ["@charset \"UTF-8\";:host{--ui-sidebar-width: 16rem;display:block;height:100%;width:100%}.layout{display:flex;height:100%;width:100%}.sidebar{display:flex;flex-direction:column;flex-shrink:0;width:var(--ui-sidebar-width);transition:width .25s ease,opacity .2s ease;opacity:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;overflow-x:hidden}.sidebar ui-sidebar-nav{flex:1;min-height:0;height:auto}.sidebar--collapsed{width:0;opacity:0;overflow:hidden}.main{flex:1;display:flex;flex-direction:column;min-width:0;overflow:hidden}.breadcrumb{display:flex;align-items:center;gap:.25rem;flex-shrink:0;padding:.75rem 1.25rem}.sidebar-toggle{flex-shrink:0}.content{flex:1;padding:1.5rem;overflow-y:auto}\n"] }]
        }], propDecorators: { datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], rootLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rootLabel", required: false }] }], drawerPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "drawerPosition", required: false }] }], drawerWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "drawerWidth", required: false }] }], breadcrumbVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "breadcrumbVariant", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], sidebarPinned: [{ type: i0.Input, args: [{ isSignal: true, alias: "sidebarPinned", required: false }] }], showSidebarToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSidebarToggle", required: false }] }], storageKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "storageKey", required: false }] }], activePage: [{ type: i0.Input, args: [{ isSignal: true, alias: "activePage", required: false }] }, { type: i0.Output, args: ["activePageChange"] }], drawerOpen: [{ type: i0.Input, args: [{ isSignal: true, alias: "drawerOpen", required: false }] }, { type: i0.Output, args: ["drawerOpenChange"] }], sidebarVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "sidebarVisible", required: false }] }, { type: i0.Output, args: ["sidebarVisibleChange"] }], navigated: [{ type: i0.Output, args: ["navigated"] }], contentTemplate: [{ type: i0.ContentChild, args: ["content", { isSignal: true }] }], projectedItems: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => UISidebarItem), { isSignal: true }] }] } });

// ── Factory helpers ──────────────────────────────────────────────────
/**
 * Creates a leaf navigation node (sidebar item).
 *
 * @param id    - Unique identifier (also used as the active-page key).
 * @param label - Display text in the sidebar and breadcrumb.
 * @param options - Optional icon, badge, route, and disabled state.
 * @returns A {@link NavigationNode} without children.
 *
 * @example
 * ```ts
 * navItem('dashboard', 'Dashboard', {
 *   icon: UIIcons.Lucide.Layout.LayoutDashboard,
 *   badge: '3',
 * })
 * ```
 */
function navItem(id, label, options) {
    return {
        id,
        data: {
            label,
            badge: options?.badge,
            route: options?.route,
        },
        icon: options?.icon,
        disabled: options?.disabled,
    };
}
/**
 * Creates a group navigation node (collapsible sidebar group).
 *
 * @param id       - Unique identifier for the group.
 * @param label    - Display text for the group header.
 * @param children - Child navigation nodes rendered inside the group.
 * @param options  - Optional icon and expanded state.
 * @returns A {@link NavigationNode} with children.
 *
 * @example
 * ```ts
 * navGroup('settings', 'Settings', [
 *   navItem('general', 'General'),
 *   navItem('security', 'Security'),
 * ], { icon: UIIcons.Lucide.Account.Settings })
 * ```
 */
function navGroup(id, label, children, options) {
    return {
        id,
        data: { label },
        icon: options?.icon,
        expanded: options?.expanded ?? true,
        children: [...children],
    };
}
/**
 * Converts an Angular-Router-compatible route config array into
 * {@link NavigationNode NavigationNode[]} for use with
 * {@link UINavigationPage}.
 *
 * Only routes that include `data: { navLabel: '…' }` are emitted.
 * Child routes are recursively processed, producing group nodes
 * when a parent has navigable children.
 *
 * @param routes     - The route configuration (e.g. `inject(Router).config`).
 * @param parentPath - Internal: accumulated path prefix for nested routes.
 * @returns An array of navigation tree nodes.
 *
 * @example
 * ```ts
 * // In your app component:
 * private readonly router = inject(Router);
 * readonly navItems = routesToNavigation(this.router.config);
 * ```
 */
function routesToNavigation(routes, parentPath = "") {
    const nodes = [];
    for (const route of routes) {
        const data = route.data;
        if (!data?.["navLabel"]) {
            // Skip routes without navigation metadata, but recurse into children
            if (route.children?.length) {
                const childPath = joinPath(parentPath, route.path);
                nodes.push(...routesToNavigation(route.children, childPath));
            }
            continue;
        }
        const fullPath = joinPath(parentPath, route.path);
        const children = route.children
            ? routesToNavigation(route.children, fullPath)
            : undefined;
        nodes.push({
            id: fullPath || "/",
            data: {
                label: data["navLabel"],
                badge: data["navBadge"] ?? undefined,
                route: fullPath || "/",
            },
            icon: data["navIcon"] ?? undefined,
            disabled: data["navDisabled"] ?? false,
            expanded: data["navExpanded"] ?? true,
            children: children?.length ? children : undefined,
        });
    }
    return nodes;
}
/** @internal Join two path segments, avoiding double slashes. */
function joinPath(parent, segment) {
    if (!segment) {
        return parent;
    }
    if (!parent) {
        return segment;
    }
    return `${parent}/${segment}`.replace(/\/+/g, "/");
}

/**
 * Manages persisted saved searches through the application-wide
 * {@link StorageService} (which defaults to `localStorage` via
 * the `STORAGE_STRATEGY` injection token).
 *
 * Searches are stored as a JSON array under a key derived from the
 * caller-supplied `storageKey`. Multiple independent search views can
 * coexist by using different storage keys.
 *
 * ### Usage
 *
 * ```ts
 * private readonly savedSearchService = inject(SavedSearchService);
 *
 * // list
 * const searches = this.savedSearchService.list('my-view');
 *
 * // save
 * this.savedSearchService.save('my-view', {
 *   id: crypto.randomUUID(),
 *   name: 'Active users',
 *   descriptor: { junction: 'and', rules: [...] },
 *   savedAt: new Date().toISOString(),
 * });
 *
 * // delete
 * this.savedSearchService.remove('my-view', searchId);
 * ```
 *
 * ### Swapping the storage backend
 *
 * Override the `STORAGE_STRATEGY` token from `@theredhead/lucid-foundation`:
 *
 * ```ts
 * providers: [
 *   { provide: STORAGE_STRATEGY, useClass: MyIndexedDbStrategy },
 * ]
 * ```
 */
class SavedSearchService {
    storage = inject(StorageService);
    /**
     * Retrieve all saved searches for the given storage key.
     *
     * Returns an empty array when nothing is stored or when the stored
     * value cannot be parsed.
     */
    list(storageKey) {
        const raw = this.storage.getItem(this.prefixedKey(storageKey));
        if (!raw)
            return [];
        try {
            const parsed = JSON.parse(raw);
            if (!Array.isArray(parsed))
                return [];
            return parsed;
        }
        catch {
            return [];
        }
    }
    /**
     * Persist a saved search. If a search with the same `id` already
     * exists it is replaced; otherwise the new search is appended.
     */
    save(storageKey, search) {
        const list = this.list(storageKey);
        const index = list.findIndex((s) => s.id === search.id);
        if (index >= 0) {
            list[index] = search;
        }
        else {
            list.push(search);
        }
        this.persist(storageKey, list);
    }
    /**
     * Remove a saved search by its `id`.
     *
     * No-op if the id does not exist.
     */
    remove(storageKey, searchId) {
        const list = this.list(storageKey);
        const filtered = list.filter((s) => s.id !== searchId);
        this.persist(storageKey, filtered);
    }
    /**
     * Persist a new ordering of saved searches.
     *
     * Accepts an array of IDs in the desired order. Searches whose
     * IDs are not in the list are dropped.
     */
    reorder(storageKey, orderedIds) {
        const list = this.list(storageKey);
        const map = new Map(list.map((s) => [s.id, s]));
        const reordered = orderedIds
            .map((id) => map.get(id))
            .filter((s) => s !== undefined);
        this.persist(storageKey, reordered);
    }
    /**
     * Remove all saved searches for a given storage key.
     */
    clear(storageKey) {
        this.storage.removeItem(this.prefixedKey(storageKey));
    }
    // ── Private helpers ─────────────────────────────────────────────
    prefixedKey(storageKey) {
        return `ui-saved-searches:${storageKey}`;
    }
    persist(storageKey, list) {
        this.storage.setItem(this.prefixedKey(storageKey), JSON.stringify(list));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: SavedSearchService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: SavedSearchService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: SavedSearchService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * A unified browse-and-filter layout that composes {@link UIFilter},
 * {@link UITableView} (or a custom results template), and
 * {@link UIPagination} into a single search screen.
 *
 * ### Table mode (default)
 * ```html
 * <ui-search-view [datasource]="ds" title="Users">
 *   <ui-text-column key="name" headerText="Name" />
 *   <ui-text-column key="email" headerText="Email" />
 * </ui-search-view>
 * ```
 *
 * ### Custom results template
 * ```html
 * <ui-search-view [datasource]="ds" layout="custom" [filterFields]="fields">
 *   <ng-template #results let-items>
 *     @for (item of items; track item.id) {
 *       <app-card [data]="item" />
 *     }
 *   </ng-template>
 * </ui-search-view>
 * ```
 *
 * ### With custom filter template
 * ```html
 * <ui-search-view [datasource]="ds">
 *   <ng-template #filter>
 *     <my-custom-filter (change)="applyFilter($event)" />
 *   </ng-template>
 *   <ui-text-column key="name" headerText="Name" />
 * </ui-search-view>
 * ```
 */
class UISearchView {
    // ── Inputs ────────────────────────────────────────────────────────
    /** Title displayed in the header area. */
    title = input("Results", ...(ngDevMode ? [{ debugName: "title" }] : []));
    /**
     * The datasource powering the search results.
     *
     * Accepts any {@link IDatasource}. When the datasource is a
     * {@link FilterableArrayDatasource} the component automatically
     * applies filter expressions from the embedded filter.
     */
    datasource = input(undefined, ...(ngDevMode ? [{ debugName: "datasource" }] : []));
    /**
     * Results layout mode.
     *
     * - `'table'` (default) — uses `<ui-table-view>` with projected columns.
     * - `'custom'` — renders the projected `#results` template.
     */
    layout = input("table", ...(ngDevMode ? [{ debugName: "layout" }] : []));
    /**
     * Explicit filter field definitions.
     *
     * When provided these override the auto-inferred fields derived
     * from projected columns and sample data.
     */
    filterFields = input(undefined, ...(ngDevMode ? [{ debugName: "filterFields" }] : []));
    /**
     * Whether the filter section is visible.
     *
     * - `true` — always show the filter.
     * - `false` — never show the filter.
     * - `undefined` (default) — auto-detect: show when the datasource
     *   is a {@link FilterableArrayDatasource}.
     */
    showFilter = input(undefined, ...(ngDevMode ? [{ debugName: "showFilter" }] : []));
    /** Whether the filter section starts expanded. */
    filterExpanded = input(true, ...(ngDevMode ? [{ debugName: "filterExpanded" }] : []));
    /** Whether the filter toggle button is hidden. */
    filterModeLocked = input(false, ...(ngDevMode ? [{ debugName: "filterModeLocked" }] : []));
    /** Whether to show the pagination footer. */
    showPagination = input(true, ...(ngDevMode ? [{ debugName: "showPagination" }] : []));
    /** Items per page. */
    pageSize = input(25, ...(ngDevMode ? [{ debugName: "pageSize" }] : []));
    /** Available page-size options in the pagination selector. */
    pageSizeOptions = input([10, 25, 50, 100], ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : []));
    /** Placeholder text shown when there are no results. */
    placeholder = input("No results found", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /** Accessible label for the component. */
    ariaLabel = input("Search view", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Storage key that enables the saved-searches feature.
     *
     * When set, a toolbar strip is shown allowing users to save, load,
     * and delete named filter states. The key is used to namespace the
     * persisted data in the underlying {@link StorageService}.
     *
     * Leave `undefined` (default) to disable saved searches.
     */
    storageKey = input(undefined, ...(ngDevMode ? [{ debugName: "storageKey" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /**
     * Emits the {@link FilterExpression} every time the filter rules change.
     */
    expressionChange = output();
    /** Emits when the page changes. */
    pageChange = output();
    /** Emits when a saved search is loaded, saved, or deleted. */
    savedSearchChange = output();
    // ── Models ────────────────────────────────────────────────────────
    /** The filter descriptor state (two-way bindable). */
    filterDescriptor = model({
        junction: "and",
        rules: [],
    }, ...(ngDevMode ? [{ debugName: "filterDescriptor" }] : []));
    /** Current page index (two-way bindable, zero-based). */
    pageIndex = model(0, ...(ngDevMode ? [{ debugName: "pageIndex" }] : []));
    // ── Content queries ───────────────────────────────────────────────
    /** Projected table-view columns (used in table layout mode). */
    columns = contentChildren(UITableViewColumn, ...(ngDevMode ? [{ debugName: "columns" }] : []));
    /** Optional custom results template (used in custom layout mode). */
    resultsTemplate = contentChild("results", ...(ngDevMode ? [{ debugName: "resultsTemplate" }] : []));
    /** Optional custom filter template. */
    filterTemplate = contentChild("filter", ...(ngDevMode ? [{ debugName: "filterTemplate" }] : []));
    /** Optional empty-state template. */
    emptyTemplate = contentChild("empty", ...(ngDevMode ? [{ debugName: "emptyTemplate" }] : []));
    // ── View queries ──────────────────────────────────────────────────
    /** @internal — reference to the embedded table-view (when in table layout). */
    tableView = viewChild(UITableView, ...(ngDevMode ? [{ debugName: "tableView" }] : []));
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal */
    chevronRight = UIIcons.Lucide.Arrows.ChevronRight;
    /** @internal */
    chevronDown = UIIcons.Lucide.Arrows.ChevronDown;
    /** @internal — whether the filter panel is collapsed. */
    filterCollapsed = signal(false, ...(ngDevMode ? [{ debugName: "filterCollapsed" }] : []));
    /** @internal — total item count from the datasource. */
    totalItems = signal(0, ...(ngDevMode ? [{ debugName: "totalItems" }] : []));
    /** @internal */
    resolvedShowFilter = computed(() => {
        const explicit = this.showFilter();
        if (explicit !== undefined)
            return explicit;
        const ds = this.datasource();
        return (ds instanceof FilterableArrayDatasource$1 ||
            ds instanceof FilterableArrayDatasource);
    }, ...(ngDevMode ? [{ debugName: "resolvedShowFilter" }] : []));
    /** @internal — auto-inferred or explicit filter fields. */
    resolvedFilterFields = computed(() => {
        const explicit = this.filterFields();
        if (explicit)
            return explicit;
        const ds = this.datasource();
        if (!ds)
            return [];
        const cols = this.columns();
        const columnMeta = cols.map((c) => ({
            key: c.key(),
            headerText: c.headerText(),
        }));
        // Prefer the full unfiltered list when available
        const allRows = ds instanceof FilterableArrayDatasource$1 ||
            ds instanceof FilterableArrayDatasource
            ? ds.allRows
            : undefined;
        let sample;
        if (allRows && allRows.length > 0) {
            sample = allRows[0];
        }
        else {
            const count = ds.getNumberOfItems();
            if (typeof count !== "number" || count === 0)
                return [];
            const result = ds.getObjectAtRowIndex(0);
            if (!result || result instanceof Promise)
                return [];
            sample = result;
        }
        if (!sample)
            return [];
        return inferFilterFields(sample, columnMeta.length > 0 ? columnMeta : undefined);
    }, ...(ngDevMode ? [{ debugName: "resolvedFilterFields" }] : []));
    /** @internal — sample data for filter value suggestions. */
    resolvedFilterData = computed(() => {
        const ds = this.datasource();
        if (!ds)
            return [];
        if (ds instanceof FilterableArrayDatasource$1) {
            const all = ds.allRows;
            return all.length < 1000 ? all : [];
        }
        if (ds instanceof FilterableArrayDatasource) {
            const all = ds.allRows;
            return all.length < 1000 ? all : [];
        }
        const count = ds.getNumberOfItems();
        if (typeof count !== "number" || count === 0 || count >= 1000)
            return [];
        const rows = [];
        for (let i = 0; i < count; i++) {
            const row = ds.getObjectAtRowIndex(i);
            if (!(row instanceof Promise))
                rows.push(row);
        }
        return rows;
    }, ...(ngDevMode ? [{ debugName: "resolvedFilterData" }] : []));
    // ── Saved-search state ──────────────────────────────────────────
    /** @internal — whether the saved-searches feature is enabled. */
    savedSearchesEnabled = computed(() => this.storageKey() !== undefined, ...(ngDevMode ? [{ debugName: "savedSearchesEnabled" }] : []));
    /** @internal — list of persisted saved searches. */
    savedSearches = signal([], ...(ngDevMode ? [{ debugName: "savedSearches" }] : []));
    /** @internal — ID of the currently selected saved search (empty = none). */
    selectedSearchId = signal("", ...(ngDevMode ? [{ debugName: "selectedSearchId" }] : []));
    /** @internal — name input value when saving a filter. */
    searchName = signal("", ...(ngDevMode ? [{ debugName: "searchName" }] : []));
    /** @internal — whether the save-filter dialog is open. */
    saveDialogOpen = signal(false, ...(ngDevMode ? [{ debugName: "saveDialogOpen" }] : []));
    /** @internal — index of the chip being dragged (−1 = none). */
    dragSourceIndex = -1;
    /**
     * @internal — bumped after every `filterBy` call so computeds
     * that depend on the datasource's filtered state re-evaluate.
     */
    _filterVersion = signal(0, ...(ngDevMode ? [{ debugName: "_filterVersion" }] : []));
    /**
     * @internal — the rows for the current page (filtered + paged).
     * Used only for custom layout mode where the table is not
     * available to handle paging internally.
     */
    pagedRows = computed(() => {
        this._filterVersion();
        const ds = this.datasource();
        if (!ds)
            return [];
        const total = ds.getNumberOfItems();
        if (typeof total !== "number" || total === 0)
            return [];
        if (!this.showPagination()) {
            const rows = [];
            for (let i = 0; i < total; i++) {
                const row = ds.getObjectAtRowIndex(i);
                if (!(row instanceof Promise))
                    rows.push(row);
            }
            return rows;
        }
        const size = this.pageSize();
        const start = this.pageIndex() * size;
        const end = Math.min(start + size, total);
        const rows = [];
        for (let i = start; i < end; i++) {
            const row = ds.getObjectAtRowIndex(i);
            if (!(row instanceof Promise))
                rows.push(row);
        }
        return rows;
    }, ...(ngDevMode ? [{ debugName: "pagedRows" }] : []));
    savedSearchService = inject(SavedSearchService);
    // ── Constructor ───────────────────────────────────────────────────
    constructor() {
        this.filterCollapsed.set(!this.filterExpanded());
        effect(() => {
            this.filterCollapsed.set(!this.filterExpanded());
        });
        effect(() => {
            const ds = this.datasource();
            if (!ds) {
                this.totalItems.set(0);
                return;
            }
            const count = ds.getNumberOfItems();
            if (typeof count === "number") {
                this.totalItems.set(count);
            }
        });
        // Reload persisted saved searches whenever the storage key changes.
        effect(() => {
            const key = this.storageKey();
            if (key) {
                this.savedSearches.set(this.savedSearchService.list(key));
            }
            else {
                this.savedSearches.set([]);
            }
            this.selectedSearchId.set("");
            this.saveDialogOpen.set(false);
        });
    }
    // ── Public methods ────────────────────────────────────────────────
    /** Toggle the filter panel open/closed. */
    toggleFilter() {
        this.filterCollapsed.update((c) => !c);
    }
    /**
     * Load a saved search by its ID, applying its filter descriptor
     * to the search view.
     */
    loadSavedSearch(searchId) {
        if (!searchId) {
            this.selectedSearchId.set("");
            return;
        }
        const search = this.savedSearches().find((s) => s.id === searchId);
        if (search) {
            this.filterDescriptor.set(structuredClone(search.descriptor));
            this.selectedSearchId.set(search.id);
            this.savedSearchChange.emit(search);
        }
    }
    /**
     * Save the current filter state as a new named search.
     */
    saveNewSearch(name) {
        const key = this.storageKey();
        if (!key || !name.trim())
            return;
        const search = {
            id: crypto.randomUUID(),
            name: name.trim(),
            descriptor: structuredClone(this.filterDescriptor()),
            savedAt: new Date().toISOString(),
        };
        this.savedSearchService.save(key, search);
        this.savedSearches.set(this.savedSearchService.list(key));
        this.selectedSearchId.set(search.id);
        this.saveDialogOpen.set(false);
        this.searchName.set("");
        this.savedSearchChange.emit(search);
    }
    /**
     * Delete a saved search by its ID.
     */
    deleteSavedSearch(searchId) {
        const key = this.storageKey();
        if (!key)
            return;
        this.savedSearchService.remove(key, searchId);
        this.savedSearches.set(this.savedSearchService.list(key));
        if (this.selectedSearchId() === searchId) {
            this.selectedSearchId.set("");
        }
        this.savedSearchChange.emit(null);
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal */
    saveIcon = UIIcons.Lucide.Files.Save;
    /** @internal */
    xIcon = UIIcons.Lucide.Math.X;
    /** @internal */
    onLoadSearch(searchId) {
        this.loadSavedSearch(searchId);
    }
    /** @internal */
    onDeleteSearch(event, searchId) {
        event.stopPropagation();
        this.deleteSavedSearch(searchId);
    }
    /** @internal — opens the save-filter dialog. */
    onSaveFilterClick() {
        this.searchName.set("");
        this.saveDialogOpen.set(true);
    }
    /** @internal */
    onConfirmSave() {
        this.saveNewSearch(this.searchName());
    }
    /** @internal */
    onCancelSave() {
        this.saveDialogOpen.set(false);
        this.searchName.set("");
    }
    // ── Chip drag-and-drop reorder ────────────────────────────────────
    /** @internal */
    onChipDragStart(event, index) {
        this.dragSourceIndex = index;
        if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = "move";
        }
    }
    /** @internal */
    onChipDragOver(event) {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = "move";
        }
    }
    /** @internal */
    onChipDrop(event, targetIndex) {
        event.preventDefault();
        const from = this.dragSourceIndex;
        if (from < 0 || from === targetIndex)
            return;
        const key = this.storageKey();
        if (!key)
            return;
        const list = [...this.savedSearches()];
        const [moved] = list.splice(from, 1);
        list.splice(targetIndex, 0, moved);
        const orderedIds = list.map((s) => s.id);
        this.savedSearchService.reorder(key, orderedIds);
        this.savedSearches.set(this.savedSearchService.list(key));
        this.dragSourceIndex = -1;
    }
    /** @internal */
    onChipDragEnd() {
        this.dragSourceIndex = -1;
    }
    /** @internal */
    onFilterExpressionChange(expression) {
        this.expressionChange.emit(expression);
        const ds = this.datasource();
        if (ds instanceof FilterableArrayDatasource$1) {
            ds.filterBy(expression);
            const count = ds.getNumberOfItems();
            this.totalItems.set(typeof count === "number" ? count : 0);
            this.pageIndex.set(0);
            // Tell the table to rebuild its adapter so it picks up the
            // newly filtered datasource content.
            this.tableView()?.refreshDatasource();
        }
        else if (ds instanceof FilterableArrayDatasource) {
            this.applyFoundationFilter(ds, expression);
            const count = ds.getNumberOfItems();
            this.totalItems.set(typeof count === "number" ? count : 0);
            this.pageIndex.set(0);
            // Tell the table to rebuild its adapter so it picks up the
            // newly filtered datasource content.
            this.tableView()?.refreshDatasource();
        }
        this._filterVersion.update((v) => v + 1);
    }
    /** @internal */
    onPageChange(event) {
        this.pageChange.emit(event);
    }
    applyFoundationFilter(ds, expression) {
        const predicate = toPredicate(expression, this.resolvedFilterFields());
        ds.filterBy(predicate ? [{ predicate }] : null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISearchView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UISearchView, isStandalone: true, selector: "ui-search-view", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, filterFields: { classPropertyName: "filterFields", publicName: "filterFields", isSignal: true, isRequired: false, transformFunction: null }, showFilter: { classPropertyName: "showFilter", publicName: "showFilter", isSignal: true, isRequired: false, transformFunction: null }, filterExpanded: { classPropertyName: "filterExpanded", publicName: "filterExpanded", isSignal: true, isRequired: false, transformFunction: null }, filterModeLocked: { classPropertyName: "filterModeLocked", publicName: "filterModeLocked", isSignal: true, isRequired: false, transformFunction: null }, showPagination: { classPropertyName: "showPagination", publicName: "showPagination", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, storageKey: { classPropertyName: "storageKey", publicName: "storageKey", isSignal: true, isRequired: false, transformFunction: null }, filterDescriptor: { classPropertyName: "filterDescriptor", publicName: "filterDescriptor", isSignal: true, isRequired: false, transformFunction: null }, pageIndex: { classPropertyName: "pageIndex", publicName: "pageIndex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expressionChange: "expressionChange", pageChange: "pageChange", savedSearchChange: "savedSearchChange", filterDescriptor: "filterDescriptorChange", pageIndex: "pageIndexChange" }, host: { classAttribute: "ui-search-view" }, queries: [{ propertyName: "columns", predicate: UITableViewColumn, isSignal: true }, { propertyName: "resultsTemplate", first: true, predicate: ["results"], descendants: true, isSignal: true }, { propertyName: "filterTemplate", first: true, predicate: ["filter"], descendants: true, isSignal: true }, { propertyName: "emptyTemplate", first: true, predicate: ["empty"], descendants: true, isSignal: true }], viewQueries: [{ propertyName: "tableView", first: true, predicate: UITableView, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<!-- Hidden slot: instantiates projected columns for contentChildren discovery. -->\n<div class=\"columns-slot\"><ng-content /></div>\n\n<header class=\"sv-header\">\n  <h2 class=\"sv-title\">{{ title() }}</h2>\n  <span class=\"sv-count\">{{ totalItems() }} items</span>\n</header>\n\n@if (resolvedShowFilter()) {\n<div class=\"sv-filter-bar\">\n  @if (!filterModeLocked()) {\n  <button class=\"sv-filter-toggle\" type=\"button\" (click)=\"toggleFilter()\" [attr.aria-expanded]=\"!filterCollapsed()\"\n    aria-controls=\"sv-filter-content\">\n    <ui-icon [svg]=\"filterCollapsed() ? chevronRight : chevronDown\" [size]=\"14\" />\n    <span>Filter</span>\n  </button>\n  }\n  @if (!filterCollapsed()) {\n  <div class=\"sv-filter-content\" id=\"sv-filter-content\">\n    @if (filterTemplate(); as filterTpl) {\n    <ng-container *ngTemplateOutlet=\"filterTpl\" />\n    } @else {\n    @if (resolvedFilterFields(); as fields) {\n    @if (fields.length > 0) {\n    <ui-filter [fields]=\"fields\" [data]=\"resolvedFilterData()\" [allowJunction]=\"true\" [modeLocked]=\"filterModeLocked()\"\n      [showSaveButton]=\"savedSearchesEnabled()\" [(value)]=\"filterDescriptor\"\n      (expressionChange)=\"onFilterExpressionChange($event)\" (saveFilter)=\"onSaveFilterClick()\" />\n    }\n    }\n    }\n  </div>\n  }\n</div>\n}\n\n@if (savedSearchesEnabled() && savedSearches().length > 0) {\n<div class=\"sv-chip-strip\" role=\"listbox\" aria-label=\"Saved searches\">\n  @for (search of savedSearches(); track search.id; let idx = $index) {\n  <button class=\"sv-chip\" type=\"button\" role=\"option\" [attr.aria-selected]=\"selectedSearchId() === search.id\"\n    [class.sv-chip--active]=\"selectedSearchId() === search.id\" draggable=\"true\" (click)=\"onLoadSearch(search.id)\"\n    (dragstart)=\"onChipDragStart($event, idx)\" (dragover)=\"onChipDragOver($event)\" (drop)=\"onChipDrop($event, idx)\"\n    (dragend)=\"onChipDragEnd()\">\n    <span class=\"sv-chip-label\">{{ search.name }}</span>\n    <span class=\"sv-chip-remove\" role=\"button\" tabindex=\"0\" [attr.aria-label]=\"'Delete ' + search.name\"\n      (click)=\"onDeleteSearch($event, search.id)\" (keydown.enter)=\"onDeleteSearch($event, search.id)\"\n      (keydown.space)=\"onDeleteSearch($event, search.id)\">\n      <ui-icon [svg]=\"xIcon\" [size]=\"10\" />\n    </span>\n  </button>\n  }\n</div>\n}\n\n<div class=\"sv-results\" role=\"region\" [attr.aria-label]=\"ariaLabel()\">\n  @if (layout() === 'table') {\n  <div class=\"sv-table-wrapper\">\n    <ui-table-view [datasource]=\"datasource()!\" [externalColumns]=\"columns()\" [showBuiltInPaginator]=\"false\"\n      [showRowIndexIndicator]=\"false\" [pageSize]=\"pageSize()\" [pageIndex]=\"pageIndex()\" />\n    @if (totalItems() === 0) {\n    @if (emptyTemplate(); as emptyTpl) {\n    <ng-container *ngTemplateOutlet=\"emptyTpl\" />\n    } @else {\n    <div class=\"sv-empty\">\n      <p>{{ placeholder() }}</p>\n    </div>\n    }\n    }\n  </div>\n  } @else if (totalItems() === 0) {\n  @if (emptyTemplate(); as emptyTpl) {\n  <ng-container *ngTemplateOutlet=\"emptyTpl\" />\n  } @else {\n  <div class=\"sv-empty\">\n    <p>{{ placeholder() }}</p>\n  </div>\n  }\n  } @else if (resultsTemplate(); as resultsTpl) {\n  <div class=\"sv-custom-results\">\n    <ng-container *ngTemplateOutlet=\"resultsTpl; context: { $implicit: pagedRows() }\" />\n  </div>\n  }\n</div>\n\n@if (showPagination() && totalItems() > 0) {\n<footer class=\"sv-footer\">\n  <ui-pagination [totalItems]=\"totalItems()\" [pageSize]=\"pageSize()\" [pageSizeOptions]=\"pageSizeOptions()\"\n    [(pageIndex)]=\"pageIndex\" (pageChange)=\"onPageChange($event)\" />\n</footer>\n}\n\n<ui-dialog [(open)]=\"saveDialogOpen\" ariaLabel=\"Save filter\">\n  <ui-dialog-header>Save Filter</ui-dialog-header>\n  <ui-dialog-body>\n    <ui-input [(value)]=\"searchName\" placeholder=\"Filter name\" ariaLabel=\"Filter name\" />\n  </ui-dialog-body>\n  <ui-dialog-footer>\n    <ui-button variant=\"ghost\" (click)=\"onCancelSave()\">Cancel saving filter</ui-button>\n    <ui-button variant=\"filled\" (click)=\"onConfirmSave()\" [disabled]=\"!searchName().trim()\">Save filter</ui-button>\n  </ui-dialog-footer>\n</ui-dialog>", styles: ["@charset \"UTF-8\";:host{--ui-radius: 6px;display:flex;flex-direction:column;height:100%;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif}.columns-slot{display:none}.sv-header{display:flex;align-items:baseline;gap:.75rem;padding:.75rem 1rem;flex-shrink:0}.sv-title{margin:0;font-size:.9rem;font-weight:600;letter-spacing:.01em}.sv-count{font-size:.75rem}.sv-filter-bar{flex-shrink:0}.sv-chip-strip{display:flex;align-items:center;gap:.35rem;padding:.35rem 1rem;flex-shrink:0;overflow-x:auto;scrollbar-width:thin}.sv-chip{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;gap:.3rem;padding:.2rem .55rem;border-radius:999px;font-size:.75rem;font-weight:500;white-space:nowrap;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background .15s,border-color .15s}.sv-chip[draggable=true]{cursor:grab}.sv-chip[draggable=true]:active{cursor:grabbing;opacity:.6}.sv-chip-label{pointer-events:none}.sv-chip-remove{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;opacity:.6;transition:opacity .15s}.sv-chip-remove:hover{opacity:1}.sv-filter-toggle{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:6px;width:100%;padding:.45rem 1rem;font-size:.78rem;font-weight:500;text-align:left}.sv-filter-content ::ng-deep ui-filter{border:none;padding:.75rem 1rem}.sv-results{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column}.sv-table-wrapper{position:relative;flex:1;overflow:hidden;min-height:0}.sv-table-wrapper ::ng-deep ui-table-view{display:flex;flex-direction:column;height:100%}.sv-table-wrapper ::ng-deep .root{display:flex;flex-direction:column;flex:1;min-height:0;border-radius:0;border:none;box-shadow:none}.sv-table-wrapper ::ng-deep ui-table-body{flex:1;min-height:0}.sv-table-wrapper ::ng-deep .table-body-viewport{height:100%}.sv-custom-results{flex:1;overflow-y:auto;padding:1rem}.sv-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none}.sv-empty p{margin:0;font-size:.88rem}.sv-footer{flex-shrink:0;padding:.25rem .5rem}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDialog, selector: "ui-dialog", inputs: ["open", "closeOnBackdropClick", "closeOnEscape", "ariaLabel"], outputs: ["openChange", "closed"] }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIFilter, selector: "ui-filter", inputs: ["disabled", "fields", "allowJunction", "allowSimple", "allowAdvanced", "modeLocked", "showSaveButton", "data", "value"], outputs: ["valueChange", "expressionChange", "saveFilter"] }, { kind: "component", type: UIInput, selector: "ui-input", inputs: ["type", "text", "value", "adapter", "placeholder", "disabled", "multiline", "rows", "heightAdjustable", "ariaLabel"], outputs: ["textChange", "valueChange"] }, { kind: "component", type: UITableView, selector: "ui-table-view", inputs: ["renderingStrategy", "disabled", "rowHeight", "datasource", "pageSize", "pageIndex", "showBuiltInPaginator", "pageSizeOptions", "caption", "showRowIndexIndicator", "rowIndexHeaderText", "tableId", "resizable", "selectionMode", "rowClickSelect", "showSelectionColumn", "selectionModel", "externalColumns"], outputs: ["selectionChange"] }, { kind: "component", type: UIPagination, selector: "ui-pagination", inputs: ["totalItems", "pageSize", "pageSizeOptions", "pageIndex", "disabled", "hasMore", "buttonColor", "muted", "ariaLabel"], outputs: ["pageIndexChange", "pageChange"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISearchView, decorators: [{
            type: Component,
            args: [{ selector: "ui-search-view", standalone: true, imports: [
                        UIButton,
                        UIDialog,
                        UIDialogBody,
                        UIDialogFooter,
                        UIDialogHeader,
                        UIFilter,
                        UIInput,
                        UITableView,
                        UIPagination,
                        UIIcon,
                        NgTemplateOutlet,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-search-view",
                    }, template: "<!-- Hidden slot: instantiates projected columns for contentChildren discovery. -->\n<div class=\"columns-slot\"><ng-content /></div>\n\n<header class=\"sv-header\">\n  <h2 class=\"sv-title\">{{ title() }}</h2>\n  <span class=\"sv-count\">{{ totalItems() }} items</span>\n</header>\n\n@if (resolvedShowFilter()) {\n<div class=\"sv-filter-bar\">\n  @if (!filterModeLocked()) {\n  <button class=\"sv-filter-toggle\" type=\"button\" (click)=\"toggleFilter()\" [attr.aria-expanded]=\"!filterCollapsed()\"\n    aria-controls=\"sv-filter-content\">\n    <ui-icon [svg]=\"filterCollapsed() ? chevronRight : chevronDown\" [size]=\"14\" />\n    <span>Filter</span>\n  </button>\n  }\n  @if (!filterCollapsed()) {\n  <div class=\"sv-filter-content\" id=\"sv-filter-content\">\n    @if (filterTemplate(); as filterTpl) {\n    <ng-container *ngTemplateOutlet=\"filterTpl\" />\n    } @else {\n    @if (resolvedFilterFields(); as fields) {\n    @if (fields.length > 0) {\n    <ui-filter [fields]=\"fields\" [data]=\"resolvedFilterData()\" [allowJunction]=\"true\" [modeLocked]=\"filterModeLocked()\"\n      [showSaveButton]=\"savedSearchesEnabled()\" [(value)]=\"filterDescriptor\"\n      (expressionChange)=\"onFilterExpressionChange($event)\" (saveFilter)=\"onSaveFilterClick()\" />\n    }\n    }\n    }\n  </div>\n  }\n</div>\n}\n\n@if (savedSearchesEnabled() && savedSearches().length > 0) {\n<div class=\"sv-chip-strip\" role=\"listbox\" aria-label=\"Saved searches\">\n  @for (search of savedSearches(); track search.id; let idx = $index) {\n  <button class=\"sv-chip\" type=\"button\" role=\"option\" [attr.aria-selected]=\"selectedSearchId() === search.id\"\n    [class.sv-chip--active]=\"selectedSearchId() === search.id\" draggable=\"true\" (click)=\"onLoadSearch(search.id)\"\n    (dragstart)=\"onChipDragStart($event, idx)\" (dragover)=\"onChipDragOver($event)\" (drop)=\"onChipDrop($event, idx)\"\n    (dragend)=\"onChipDragEnd()\">\n    <span class=\"sv-chip-label\">{{ search.name }}</span>\n    <span class=\"sv-chip-remove\" role=\"button\" tabindex=\"0\" [attr.aria-label]=\"'Delete ' + search.name\"\n      (click)=\"onDeleteSearch($event, search.id)\" (keydown.enter)=\"onDeleteSearch($event, search.id)\"\n      (keydown.space)=\"onDeleteSearch($event, search.id)\">\n      <ui-icon [svg]=\"xIcon\" [size]=\"10\" />\n    </span>\n  </button>\n  }\n</div>\n}\n\n<div class=\"sv-results\" role=\"region\" [attr.aria-label]=\"ariaLabel()\">\n  @if (layout() === 'table') {\n  <div class=\"sv-table-wrapper\">\n    <ui-table-view [datasource]=\"datasource()!\" [externalColumns]=\"columns()\" [showBuiltInPaginator]=\"false\"\n      [showRowIndexIndicator]=\"false\" [pageSize]=\"pageSize()\" [pageIndex]=\"pageIndex()\" />\n    @if (totalItems() === 0) {\n    @if (emptyTemplate(); as emptyTpl) {\n    <ng-container *ngTemplateOutlet=\"emptyTpl\" />\n    } @else {\n    <div class=\"sv-empty\">\n      <p>{{ placeholder() }}</p>\n    </div>\n    }\n    }\n  </div>\n  } @else if (totalItems() === 0) {\n  @if (emptyTemplate(); as emptyTpl) {\n  <ng-container *ngTemplateOutlet=\"emptyTpl\" />\n  } @else {\n  <div class=\"sv-empty\">\n    <p>{{ placeholder() }}</p>\n  </div>\n  }\n  } @else if (resultsTemplate(); as resultsTpl) {\n  <div class=\"sv-custom-results\">\n    <ng-container *ngTemplateOutlet=\"resultsTpl; context: { $implicit: pagedRows() }\" />\n  </div>\n  }\n</div>\n\n@if (showPagination() && totalItems() > 0) {\n<footer class=\"sv-footer\">\n  <ui-pagination [totalItems]=\"totalItems()\" [pageSize]=\"pageSize()\" [pageSizeOptions]=\"pageSizeOptions()\"\n    [(pageIndex)]=\"pageIndex\" (pageChange)=\"onPageChange($event)\" />\n</footer>\n}\n\n<ui-dialog [(open)]=\"saveDialogOpen\" ariaLabel=\"Save filter\">\n  <ui-dialog-header>Save Filter</ui-dialog-header>\n  <ui-dialog-body>\n    <ui-input [(value)]=\"searchName\" placeholder=\"Filter name\" ariaLabel=\"Filter name\" />\n  </ui-dialog-body>\n  <ui-dialog-footer>\n    <ui-button variant=\"ghost\" (click)=\"onCancelSave()\">Cancel saving filter</ui-button>\n    <ui-button variant=\"filled\" (click)=\"onConfirmSave()\" [disabled]=\"!searchName().trim()\">Save filter</ui-button>\n  </ui-dialog-footer>\n</ui-dialog>", styles: ["@charset \"UTF-8\";:host{--ui-radius: 6px;display:flex;flex-direction:column;height:100%;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif}.columns-slot{display:none}.sv-header{display:flex;align-items:baseline;gap:.75rem;padding:.75rem 1rem;flex-shrink:0}.sv-title{margin:0;font-size:.9rem;font-weight:600;letter-spacing:.01em}.sv-count{font-size:.75rem}.sv-filter-bar{flex-shrink:0}.sv-chip-strip{display:flex;align-items:center;gap:.35rem;padding:.35rem 1rem;flex-shrink:0;overflow-x:auto;scrollbar-width:thin}.sv-chip{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;gap:.3rem;padding:.2rem .55rem;border-radius:999px;font-size:.75rem;font-weight:500;white-space:nowrap;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background .15s,border-color .15s}.sv-chip[draggable=true]{cursor:grab}.sv-chip[draggable=true]:active{cursor:grabbing;opacity:.6}.sv-chip-label{pointer-events:none}.sv-chip-remove{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;opacity:.6;transition:opacity .15s}.sv-chip-remove:hover{opacity:1}.sv-filter-toggle{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:6px;width:100%;padding:.45rem 1rem;font-size:.78rem;font-weight:500;text-align:left}.sv-filter-content ::ng-deep ui-filter{border:none;padding:.75rem 1rem}.sv-results{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column}.sv-table-wrapper{position:relative;flex:1;overflow:hidden;min-height:0}.sv-table-wrapper ::ng-deep ui-table-view{display:flex;flex-direction:column;height:100%}.sv-table-wrapper ::ng-deep .root{display:flex;flex-direction:column;flex:1;min-height:0;border-radius:0;border:none;box-shadow:none}.sv-table-wrapper ::ng-deep ui-table-body{flex:1;min-height:0}.sv-table-wrapper ::ng-deep .table-body-viewport{height:100%}.sv-custom-results{flex:1;overflow-y:auto;padding:1rem}.sv-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none}.sv-empty p{margin:0;font-size:.88rem}.sv-footer{flex-shrink:0;padding:.25rem .5rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], filterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterFields", required: false }] }], showFilter: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFilter", required: false }] }], filterExpanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterExpanded", required: false }] }], filterModeLocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterModeLocked", required: false }] }], showPagination: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPagination", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], storageKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "storageKey", required: false }] }], expressionChange: [{ type: i0.Output, args: ["expressionChange"] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], savedSearchChange: [{ type: i0.Output, args: ["savedSearchChange"] }], filterDescriptor: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterDescriptor", required: false }] }, { type: i0.Output, args: ["filterDescriptorChange"] }], pageIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageIndex", required: false }] }, { type: i0.Output, args: ["pageIndexChange"] }], columns: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => UITableViewColumn), { isSignal: true }] }], resultsTemplate: [{ type: i0.ContentChild, args: ["results", { isSignal: true }] }], filterTemplate: [{ type: i0.ContentChild, args: ["filter", { isSignal: true }] }], emptyTemplate: [{ type: i0.ContentChild, args: ["empty", { isSignal: true }] }], tableView: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UITableView), { isSignal: true }] }] } });

/**
 * A key-value inspector panel that renders a schema of typed fields
 * against a data object.
 *
 * Each field definition maps to an appropriate editor widget
 * (`UIInput`, `UISelect`, `UICheckbox`, `UIColorPicker`, or
 * `UISlider`). Changes are emitted per-field via
 * {@link propertyChange} and the data model is updated in-place.
 *
 * ### Basic usage
 * ```html
 * <ui-property-sheet
 *   [fields]="fields"
 *   [(data)]="config"
 *   (propertyChange)="onChanged($event)"
 * />
 * ```
 *
 * ### Grouped fields
 * ```ts
 * const fields: PropertyFieldDefinition<Config>[] = [
 *   { key: 'name',  label: 'Name',  type: 'string', group: 'General' },
 *   { key: 'color', label: 'Color', type: 'color',  group: 'Appearance' },
 * ];
 * ```
 */
class UIPropertySheet {
    // ── Inputs ────────────────────────────────────────────────────────
    /** Field definitions describing the properties to edit. */
    fields = input.required(...(ngDevMode ? [{ debugName: "fields" }] : []));
    /** Accessible label for the sheet. */
    ariaLabel = input("Property sheet", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    // ── Models ────────────────────────────────────────────────────────
    /** The data object being inspected/edited (two-way bindable). */
    data = model({}, ...(ngDevMode ? [{ debugName: "data" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emits when any property value changes. */
    propertyChange = output();
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — fields organised into named groups. */
    groups = computed(() => {
        const defs = this.fields();
        const map = new Map();
        for (const field of defs) {
            const group = field.group ?? "";
            let list = map.get(group);
            if (!list) {
                list = [];
                map.set(group, list);
            }
            list.push(field);
        }
        const result = [];
        for (const [name, fields] of map) {
            result.push({ name, fields });
        }
        return result;
    }, ...(ngDevMode ? [{ debugName: "groups" }] : []));
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — read a field value from the data object. */
    getValue(key) {
        return this.data()[key];
    }
    /** @internal — update a field and emit. */
    onValueChange(key, value) {
        const updated = { ...this.data(), [key]: value };
        this.data.set(updated);
        this.propertyChange.emit({ key, value, data: updated });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIPropertySheet, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIPropertySheet, isStandalone: true, selector: "ui-property-sheet", inputs: { fields: { classPropertyName: "fields", publicName: "fields", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { data: "dataChange", propertyChange: "propertyChange" }, host: { classAttribute: "ui-property-sheet" }, providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"ps-sheet\" role=\"form\" [attr.aria-label]=\"ariaLabel()\">\n  @for (group of groups(); track group.name) {\n    @if (group.name) {\n      <h3 class=\"ps-group-heading\">{{ group.name }}</h3>\n    }\n    @for (field of group.fields; track field.key) {\n      <div class=\"ps-row\" [class.ps-row--readonly]=\"field.readonly\">\n        <label class=\"ps-label\" [attr.for]=\"'ps-' + field.key\">\n          {{ field.label }}\n          @if (field.required) {\n            <span class=\"ps-required\" aria-hidden=\"true\">*</span>\n          }\n        </label>\n        <div class=\"ps-editor\">\n          @switch (field.type) {\n            @case ('string') {\n              <ui-input\n                [attr.id]=\"'ps-' + field.key\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [placeholder]=\"field.placeholder ?? ''\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('number') {\n              <ui-input\n                [attr.id]=\"'ps-' + field.key\"\n                type=\"number\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [placeholder]=\"field.placeholder ?? ''\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, +$event)\"\n              />\n            }\n            @case ('boolean') {\n              <ui-checkbox\n                [checked]=\"!!getValue(field.key)\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (checkedChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('select') {\n              <ui-dropdown-list\n                [options]=\"field.options ?? []\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('color') {\n              <ui-color-picker\n                [value]=\"'' + (getValue(field.key) ?? '#000000')\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('slider') {\n              <ui-slider\n                [value]=\"+(getValue(field.key) ?? 0)\"\n                [min]=\"field.min ?? 0\"\n                [max]=\"field.max ?? 100\"\n                [step]=\"field.step ?? 1\"\n                [disabled]=\"field.readonly ?? false\"\n                [showValue]=\"true\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n          }\n        </div>\n      </div>\n    }\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--property-text: var(--ui-text);--property-surface: var(--ui-surface);--property-error: var(--ui-error);display:block;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif;font-size:.8125rem;color:var(--property-text);background:var(--property-surface)}.ps-sheet{display:flex;flex-direction:column}.ps-group-heading{margin:0;padding:.5rem .75rem .25rem;font-size:.6875rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.ps-group-heading:first-child{border-top:none}.ps-row{display:flex;align-items:center;gap:.5rem;padding:.3rem .75rem;min-height:2rem}.ps-row:last-child{border-bottom:none}.ps-row--readonly{opacity:.65}.ps-label{flex:0 0 38%;max-width:38%;font-size:.78rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--property-text);background:transparent}.ps-required{color:var(--property-error);background:transparent}.ps-editor{flex:1;min-width:0}.ps-editor ui-input,.ps-editor ui-select,.ps-editor ui-slider{width:100%}\n"], dependencies: [{ kind: "component", type: UIInput, selector: "ui-input", inputs: ["type", "text", "value", "adapter", "placeholder", "disabled", "multiline", "rows", "heightAdjustable", "ariaLabel"], outputs: ["textChange", "valueChange"] }, { kind: "component", type: UIDropdownList, selector: "ui-dropdown-list", inputs: ["options", "placeholder", "disabled", "ariaLabel", "value"], outputs: ["valueChange"] }, { kind: "component", type: UICheckbox, selector: "ui-checkbox", inputs: ["variant", "checked", "disabled", "indeterminate", "ariaLabel"], outputs: ["checkedChange"] }, { kind: "component", type: UIColorPicker, selector: "ui-color-picker", inputs: ["value", "initialMode", "availableModes", "disabled", "ariaLabel"], outputs: ["valueChange", "colorChange"] }, { kind: "component", type: UISlider, selector: "ui-slider", inputs: ["mode", "value", "min", "max", "step", "disabled", "showValue", "showMinMax", "ariaLabel", "showTicks", "ticks"], outputs: ["valueChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIPropertySheet, decorators: [{
            type: Component,
            args: [{ selector: "ui-property-sheet", standalone: true, imports: [UIInput, UIDropdownList, UICheckbox, UIColorPicker, UISlider], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], host: {
                        class: "ui-property-sheet",
                    }, template: "<div class=\"ps-sheet\" role=\"form\" [attr.aria-label]=\"ariaLabel()\">\n  @for (group of groups(); track group.name) {\n    @if (group.name) {\n      <h3 class=\"ps-group-heading\">{{ group.name }}</h3>\n    }\n    @for (field of group.fields; track field.key) {\n      <div class=\"ps-row\" [class.ps-row--readonly]=\"field.readonly\">\n        <label class=\"ps-label\" [attr.for]=\"'ps-' + field.key\">\n          {{ field.label }}\n          @if (field.required) {\n            <span class=\"ps-required\" aria-hidden=\"true\">*</span>\n          }\n        </label>\n        <div class=\"ps-editor\">\n          @switch (field.type) {\n            @case ('string') {\n              <ui-input\n                [attr.id]=\"'ps-' + field.key\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [placeholder]=\"field.placeholder ?? ''\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('number') {\n              <ui-input\n                [attr.id]=\"'ps-' + field.key\"\n                type=\"number\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [placeholder]=\"field.placeholder ?? ''\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, +$event)\"\n              />\n            }\n            @case ('boolean') {\n              <ui-checkbox\n                [checked]=\"!!getValue(field.key)\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (checkedChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('select') {\n              <ui-dropdown-list\n                [options]=\"field.options ?? []\"\n                [value]=\"'' + (getValue(field.key) ?? '')\"\n                [disabled]=\"field.readonly ?? false\"\n                [ariaLabel]=\"field.label\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('color') {\n              <ui-color-picker\n                [value]=\"'' + (getValue(field.key) ?? '#000000')\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n            @case ('slider') {\n              <ui-slider\n                [value]=\"+(getValue(field.key) ?? 0)\"\n                [min]=\"field.min ?? 0\"\n                [max]=\"field.max ?? 100\"\n                [step]=\"field.step ?? 1\"\n                [disabled]=\"field.readonly ?? false\"\n                [showValue]=\"true\"\n                (valueChange)=\"onValueChange(field.key, $event)\"\n              />\n            }\n          }\n        </div>\n      </div>\n    }\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--property-text: var(--ui-text);--property-surface: var(--ui-surface);--property-error: var(--ui-error);display:block;font-family:Cantarell,Noto Sans,Segoe UI,sans-serif;font-size:.8125rem;color:var(--property-text);background:var(--property-surface)}.ps-sheet{display:flex;flex-direction:column}.ps-group-heading{margin:0;padding:.5rem .75rem .25rem;font-size:.6875rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.ps-group-heading:first-child{border-top:none}.ps-row{display:flex;align-items:center;gap:.5rem;padding:.3rem .75rem;min-height:2rem}.ps-row:last-child{border-bottom:none}.ps-row--readonly{opacity:.65}.ps-label{flex:0 0 38%;max-width:38%;font-size:.78rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--property-text);background:transparent}.ps-required{color:var(--property-error);background:transparent}.ps-editor{flex:1;min-width:0}.ps-editor ui-input,.ps-editor ui-select,.ps-editor ui-slider{width:100%}\n"] }]
        }], propDecorators: { fields: [{ type: i0.Input, args: [{ isSignal: true, alias: "fields", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }, { type: i0.Output, args: ["dataChange"] }], propertyChange: [{ type: i0.Output, args: ["propertyChange"] }] } });

/**
 * A themed, tabbed code viewer for examples that need separate panes
 * for markup, TypeScript, styles, or other implementation slices.
 *
 * The component intentionally renders plain escaped code rather than a
 * syntax-highlighting pipeline so it stays light-weight and follows the
 * workspace's existing theme tokens.
 */
class UISourceTabs {
    /** Ordered source panes to display. Empty code panes are hidden. */
    tabs = input([], ...(ngDevMode ? [{ debugName: "tabs" }] : []));
    /** Accessible label forwarded to the underlying tab group. */
    ariaLabel = input("Source code tabs", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /** Message shown when no non-empty panes are available. */
    emptyMessage = input("No source available.", ...(ngDevMode ? [{ debugName: "emptyMessage" }] : []));
    /** @internal */
    visibleTabs = computed(() => this.tabs().filter((tab) => tab.code.trim().length > 0), ...(ngDevMode ? [{ debugName: "visibleTabs" }] : []));
    /** @internal */
    trackTab(index, tab) {
        return `${tab.label}:${tab.language ?? ""}:${index}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISourceTabs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UISourceTabs, isStandalone: true, selector: "ui-source-tabs", inputs: { tabs: { classPropertyName: "tabs", publicName: "tabs", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-source-tabs" }, ngImport: i0, template: "@if (visibleTabs().length > 0) {\n  <ui-accordion [ariaLabel]=\"ariaLabel()\" [requireOpen]=\"false\">\n    <ui-accordion-item label=\"Source code\" contentPadding=\"none\">\n      <ui-tab-group panelStyle=\"flat\" [ariaLabel]=\"ariaLabel()\">\n        @for (tab of visibleTabs(); track trackTab($index, tab)) {\n          <ui-tab [label]=\"tab.label\">\n            <div class=\"pane\">\n              @if (tab.filename || tab.language) {\n                <div class=\"meta\">\n                  @if (tab.filename) {\n                    <span class=\"filename\">{{ tab.filename }}</span>\n                  }\n\n                  @if (tab.language) {\n                    <span class=\"language\">{{ tab.language }}</span>\n                  }\n                </div>\n              }\n\n              <pre class=\"code\"><code>{{ tab.code }}</code></pre>\n            </div>\n          </ui-tab>\n        }\n      </ui-tab-group>\n    </ui-accordion-item>\n  </ui-accordion>\n} @else {\n  <div class=\"empty\">{{ emptyMessage() }}</div>\n}", styles: [":host{display:block;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.pane{display:grid;gap:.75rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.meta{display:flex;align-items:center;justify-content:space-between;gap:.75rem;flex-wrap:wrap;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.filename{font-size:.8rem;font-weight:600}.language{padding:.2rem .55rem;border:1px solid var(--ui-border, #d7dce2);border-radius:999px;font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface-2, #f3f5f7)}.code{margin:0;padding:1rem;overflow:auto;border:1px solid var(--ui-border, #d7dce2);border-radius:.9rem;font-family:ui-monospace,SFMono-Regular,SFMono-Regular,Menlo,Consolas,Liberation Mono,monospace;font-size:.82rem;line-height:1.6;white-space:pre;tab-size:2;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f3f5f7)}.empty{padding:1rem;border:1px dashed var(--ui-border, #d7dce2);border-radius:.9rem;font-size:.9rem;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface-2, #f3f5f7)}\n"], dependencies: [{ kind: "component", type: UIAccordion, selector: "ui-accordion", inputs: ["disabled", "mode", "requireOpen", "ariaLabel"] }, { kind: "component", type: UIAccordionItem, selector: "ui-accordion-item", inputs: ["label", "expanded", "disabled", "contentPadding", "ariaLabel"], outputs: ["expandedChange"] }, { kind: "component", type: UITabGroup, selector: "ui-tab-group", inputs: ["tabPosition", "panelStyle", "tabAlign", "disabled", "selectedIndex", "ariaLabel"] }, { kind: "component", type: UITab, selector: "ui-tab", inputs: ["label", "icon", "ariaLabel", "disabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISourceTabs, decorators: [{
            type: Component,
            args: [{ selector: "ui-source-tabs", standalone: true, imports: [UIAccordion, UIAccordionItem, UITabGroup, UITab], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: "ui-source-tabs",
                    }, template: "@if (visibleTabs().length > 0) {\n  <ui-accordion [ariaLabel]=\"ariaLabel()\" [requireOpen]=\"false\">\n    <ui-accordion-item label=\"Source code\" contentPadding=\"none\">\n      <ui-tab-group panelStyle=\"flat\" [ariaLabel]=\"ariaLabel()\">\n        @for (tab of visibleTabs(); track trackTab($index, tab)) {\n          <ui-tab [label]=\"tab.label\">\n            <div class=\"pane\">\n              @if (tab.filename || tab.language) {\n                <div class=\"meta\">\n                  @if (tab.filename) {\n                    <span class=\"filename\">{{ tab.filename }}</span>\n                  }\n\n                  @if (tab.language) {\n                    <span class=\"language\">{{ tab.language }}</span>\n                  }\n                </div>\n              }\n\n              <pre class=\"code\"><code>{{ tab.code }}</code></pre>\n            </div>\n          </ui-tab>\n        }\n      </ui-tab-group>\n    </ui-accordion-item>\n  </ui-accordion>\n} @else {\n  <div class=\"empty\">{{ emptyMessage() }}</div>\n}", styles: [":host{display:block;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.pane{display:grid;gap:.75rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.meta{display:flex;align-items:center;justify-content:space-between;gap:.75rem;flex-wrap:wrap;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.filename{font-size:.8rem;font-weight:600}.language{padding:.2rem .55rem;border:1px solid var(--ui-border, #d7dce2);border-radius:999px;font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface-2, #f3f5f7)}.code{margin:0;padding:1rem;overflow:auto;border:1px solid var(--ui-border, #d7dce2);border-radius:.9rem;font-family:ui-monospace,SFMono-Regular,SFMono-Regular,Menlo,Consolas,Liberation Mono,monospace;font-size:.82rem;line-height:1.6;white-space:pre;tab-size:2;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f3f5f7)}.empty{padding:1rem;border:1px dashed var(--ui-border, #d7dce2);border-radius:.9rem;font-size:.9rem;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface-2, #f3f5f7)}\n"] }]
        }], propDecorators: { tabs: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabs", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }] } });

// ── Component ──────────────────────────────────────────────────────
/**
 * Popover content component for inserting or editing a hyperlink.
 *
 * Receives the initial URL and display-text values via inputs and
 * emits a {@link LinkDialogResult} on apply or `undefined` on
 * cancel / dismiss.
 *
 * @internal  Used exclusively by {@link UIRichTextEditor}.
 */
class UILinkDialog {
    popoverRef = inject((PopoverRef));
    /** Pre-filled URL (set via input by PopoverService). */
    initialUrl = input("", ...(ngDevMode ? [{ debugName: "initialUrl" }] : []));
    /** Pre-filled display text (set via input by PopoverService). */
    initialText = input("", ...(ngDevMode ? [{ debugName: "initialText" }] : []));
    /** Whether we are editing an existing link (changes button label). */
    editMode = input(false, ...(ngDevMode ? [{ debugName: "editMode" }] : []));
    /** Mutable URL value for the form. @internal */
    url = signal("", ...(ngDevMode ? [{ debugName: "url" }] : []));
    /** Mutable display-text value for the form. @internal */
    text = signal("", ...(ngDevMode ? [{ debugName: "text" }] : []));
    /** @internal */
    linkIcon = UIIcons.Lucide.Text.Link;
    constructor() {
        // Sync initial inputs → mutable signals after inputs resolve.
        // We use a microtask because signal inputs are set after
        // construction by ComponentRef.setInput().
        queueMicrotask(() => {
            this.url.set(this.initialUrl());
            this.text.set(this.initialText());
        });
    }
    /** Apply the link and close the popover with the result. */
    apply() {
        const url = this.url().trim();
        if (!url)
            return;
        this.popoverRef.close({ url, text: this.text().trim() || url });
    }
    /** Cancel and dismiss the popover without a result. */
    cancel() {
        this.popoverRef.close(undefined);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UILinkDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UILinkDialog, isStandalone: true, selector: "ui-link-dialog", inputs: { initialUrl: { classPropertyName: "initialUrl", publicName: "initialUrl", isSignal: true, isRequired: false, transformFunction: null }, initialText: { classPropertyName: "initialText", publicName: "initialText", isSignal: true, isRequired: false, transformFunction: null }, editMode: { classPropertyName: "editMode", publicName: "editMode", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-link-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"field\">\n  <label class=\"label\" for=\"ld-url\">URL</label>\n  <input\n    id=\"ld-url\"\n    class=\"input\"\n    type=\"url\"\n    placeholder=\"https://example.com\"\n    [ngModel]=\"url()\"\n    (ngModelChange)=\"url.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"field\">\n  <label class=\"label\" for=\"ld-text\">Display text</label>\n  <input\n    id=\"ld-text\"\n    class=\"input\"\n    type=\"text\"\n    placeholder=\"Link text\"\n    [ngModel]=\"text()\"\n    (ngModelChange)=\"text.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"actions\">\n  <button\n    type=\"button\"\n    class=\"btn btn--cancel\"\n    (click)=\"cancel()\"\n  >\n    Cancel\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn btn--apply\"\n    [disabled]=\"!url().trim()\"\n    (click)=\"apply()\"\n  >\n    <ui-icon [svg]=\"linkIcon\" [size]=\"14\" />\n    @if (editMode()) {\n      Edit hyperlink\n    } @else {\n      Add hyperlink\n    }\n  </button>\n</div>\n", styles: [":host{display:block;padding:.6rem;min-width:18rem;font-family:inherit;font-size:.8125rem}.field{display:flex;flex-direction:column;gap:.2rem}.field+.field{margin-top:.4rem}.label{font-size:.6875rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--ui-text-muted, #5a6470)}.input{appearance:none;border-radius:.2rem;padding:.3rem .45rem;font-family:inherit;font-size:.8125rem;outline:none;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:border-color .12s ease}.input:focus{border-color:var(--ui-accent, #3584e4)}.input::placeholder{color:var(--ui-text-muted, #5a6470);opacity:.7}.actions{display:flex;gap:.35rem;justify-content:flex-end;margin-top:.5rem}.btn{appearance:none;border-radius:.2rem;padding:.3rem .6rem;font-family:inherit;font-size:.75rem;font-weight:500;cursor:var(--ui-cursor-click, pointer);display:inline-flex;align-items:center;gap:.3rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:background-color 80ms ease,border-color 80ms ease;white-space:nowrap}.btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.btn--apply{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-color:var(--ui-accent, #3584e4)}.btn--apply:hover:not(:disabled){opacity:.9}.btn--apply:disabled{opacity:.5;cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UILinkDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-link-dialog", standalone: true, imports: [FormsModule, UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-link-dialog" }, template: "<div class=\"field\">\n  <label class=\"label\" for=\"ld-url\">URL</label>\n  <input\n    id=\"ld-url\"\n    class=\"input\"\n    type=\"url\"\n    placeholder=\"https://example.com\"\n    [ngModel]=\"url()\"\n    (ngModelChange)=\"url.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"field\">\n  <label class=\"label\" for=\"ld-text\">Display text</label>\n  <input\n    id=\"ld-text\"\n    class=\"input\"\n    type=\"text\"\n    placeholder=\"Link text\"\n    [ngModel]=\"text()\"\n    (ngModelChange)=\"text.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"actions\">\n  <button\n    type=\"button\"\n    class=\"btn btn--cancel\"\n    (click)=\"cancel()\"\n  >\n    Cancel\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn btn--apply\"\n    [disabled]=\"!url().trim()\"\n    (click)=\"apply()\"\n  >\n    <ui-icon [svg]=\"linkIcon\" [size]=\"14\" />\n    @if (editMode()) {\n      Edit hyperlink\n    } @else {\n      Add hyperlink\n    }\n  </button>\n</div>\n", styles: [":host{display:block;padding:.6rem;min-width:18rem;font-family:inherit;font-size:.8125rem}.field{display:flex;flex-direction:column;gap:.2rem}.field+.field{margin-top:.4rem}.label{font-size:.6875rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--ui-text-muted, #5a6470)}.input{appearance:none;border-radius:.2rem;padding:.3rem .45rem;font-family:inherit;font-size:.8125rem;outline:none;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:border-color .12s ease}.input:focus{border-color:var(--ui-accent, #3584e4)}.input::placeholder{color:var(--ui-text-muted, #5a6470);opacity:.7}.actions{display:flex;gap:.35rem;justify-content:flex-end;margin-top:.5rem}.btn{appearance:none;border-radius:.2rem;padding:.3rem .6rem;font-family:inherit;font-size:.75rem;font-weight:500;cursor:var(--ui-cursor-click, pointer);display:inline-flex;align-items:center;gap:.3rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:background-color 80ms ease,border-color 80ms ease;white-space:nowrap}.btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.btn--apply{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-color:var(--ui-accent, #3584e4)}.btn--apply:hover:not(:disabled){opacity:.9}.btn--apply:disabled{opacity:.5;cursor:not-allowed}\n"] }]
        }], ctorParameters: () => [], propDecorators: { initialUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialUrl", required: false }] }], initialText: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialText", required: false }] }], editMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "editMode", required: false }] }] } });

// ── Component ──────────────────────────────────────────────────────
/**
 * Popover content component for inserting an image by URL.
 *
 * Receives an optional initial URL and alt text via inputs and
 * emits an {@link ImageDialogResult} on apply or `undefined` on
 * cancel / dismiss.
 *
 * @internal  Used exclusively by {@link UIRichTextEditor}.
 */
class UIImageDialog {
    popoverRef = inject((PopoverRef));
    /** Pre-filled image URL (set via input by PopoverService). */
    initialSrc = input("", ...(ngDevMode ? [{ debugName: "initialSrc" }] : []));
    /** Pre-filled alt text (set via input by PopoverService). */
    initialAlt = input("", ...(ngDevMode ? [{ debugName: "initialAlt" }] : []));
    /** Mutable URL value for the form. @internal */
    src = signal("", ...(ngDevMode ? [{ debugName: "src" }] : []));
    /** Mutable alt-text value for the form. @internal */
    alt = signal("", ...(ngDevMode ? [{ debugName: "alt" }] : []));
    /** @internal */
    imageIcon = UIIcons.Lucide.Files.ImagePlus;
    constructor() {
        queueMicrotask(() => {
            this.src.set(this.initialSrc());
            this.alt.set(this.initialAlt());
        });
    }
    /** Apply the image insertion and close the popover with the result. */
    apply() {
        const src = this.src().trim();
        if (!src)
            return;
        this.popoverRef.close({ src, alt: this.alt().trim() || "" });
    }
    /** Cancel and dismiss the popover without a result. */
    cancel() {
        this.popoverRef.close(undefined);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIImageDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UIImageDialog, isStandalone: true, selector: "ui-image-dialog", inputs: { initialSrc: { classPropertyName: "initialSrc", publicName: "initialSrc", isSignal: true, isRequired: false, transformFunction: null }, initialAlt: { classPropertyName: "initialAlt", publicName: "initialAlt", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-image-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"field\">\n  <label class=\"label\" for=\"id-src\">Image URL</label>\n  <input\n    id=\"id-src\"\n    class=\"input\"\n    type=\"url\"\n    placeholder=\"https://example.com/image.png\"\n    [ngModel]=\"src()\"\n    (ngModelChange)=\"src.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"field\">\n  <label class=\"label\" for=\"id-alt\">Alt text</label>\n  <input\n    id=\"id-alt\"\n    class=\"input\"\n    type=\"text\"\n    placeholder=\"Describe the image\"\n    [ngModel]=\"alt()\"\n    (ngModelChange)=\"alt.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"actions\">\n  <button\n    type=\"button\"\n    class=\"btn btn--cancel\"\n    (click)=\"cancel()\"\n  >\n    Cancel\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn btn--apply\"\n    [disabled]=\"!src().trim()\"\n    (click)=\"apply()\"\n  >\n    <ui-icon [svg]=\"imageIcon\" [size]=\"14\" />\n    Insert image\n  </button>\n</div>\n", styles: [":host{display:block;padding:.6rem;min-width:18rem;font-family:inherit;font-size:.8125rem}.field{display:flex;flex-direction:column;gap:.2rem}.field+.field{margin-top:.4rem}.label{font-size:.6875rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--ui-text-muted, #5a6470)}.input{appearance:none;border-radius:.2rem;padding:.3rem .45rem;font-family:inherit;font-size:.8125rem;outline:none;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:border-color .12s ease}.input:focus{border-color:var(--ui-accent, #3584e4)}.input::placeholder{color:var(--ui-text-muted, #5a6470);opacity:.7}.actions{display:flex;gap:.35rem;justify-content:flex-end;margin-top:.5rem}.btn{appearance:none;border-radius:.2rem;padding:.3rem .6rem;font-family:inherit;font-size:.75rem;font-weight:500;cursor:var(--ui-cursor-click, pointer);display:inline-flex;align-items:center;gap:.3rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:background-color 80ms ease,border-color 80ms ease;white-space:nowrap}.btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.btn--apply{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-color:var(--ui-accent, #3584e4)}.btn--apply:disabled{opacity:.5;cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIImageDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-image-dialog", standalone: true, imports: [FormsModule, UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-image-dialog" }, template: "<div class=\"field\">\n  <label class=\"label\" for=\"id-src\">Image URL</label>\n  <input\n    id=\"id-src\"\n    class=\"input\"\n    type=\"url\"\n    placeholder=\"https://example.com/image.png\"\n    [ngModel]=\"src()\"\n    (ngModelChange)=\"src.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"field\">\n  <label class=\"label\" for=\"id-alt\">Alt text</label>\n  <input\n    id=\"id-alt\"\n    class=\"input\"\n    type=\"text\"\n    placeholder=\"Describe the image\"\n    [ngModel]=\"alt()\"\n    (ngModelChange)=\"alt.set($event)\"\n    (keydown.enter)=\"apply()\"\n  />\n</div>\n<div class=\"actions\">\n  <button\n    type=\"button\"\n    class=\"btn btn--cancel\"\n    (click)=\"cancel()\"\n  >\n    Cancel\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn btn--apply\"\n    [disabled]=\"!src().trim()\"\n    (click)=\"apply()\"\n  >\n    <ui-icon [svg]=\"imageIcon\" [size]=\"14\" />\n    Insert image\n  </button>\n</div>\n", styles: [":host{display:block;padding:.6rem;min-width:18rem;font-family:inherit;font-size:.8125rem}.field{display:flex;flex-direction:column;gap:.2rem}.field+.field{margin-top:.4rem}.label{font-size:.6875rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--ui-text-muted, #5a6470)}.input{appearance:none;border-radius:.2rem;padding:.3rem .45rem;font-family:inherit;font-size:.8125rem;outline:none;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:border-color .12s ease}.input:focus{border-color:var(--ui-accent, #3584e4)}.input::placeholder{color:var(--ui-text-muted, #5a6470);opacity:.7}.actions{display:flex;gap:.35rem;justify-content:flex-end;margin-top:.5rem}.btn{appearance:none;border-radius:.2rem;padding:.3rem .6rem;font-family:inherit;font-size:.75rem;font-weight:500;cursor:var(--ui-cursor-click, pointer);display:inline-flex;align-items:center;gap:.3rem;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);transition:background-color 80ms ease,border-color 80ms ease;white-space:nowrap}.btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.btn--apply{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-color:var(--ui-accent, #3584e4)}.btn--apply:disabled{opacity:.5;cursor:not-allowed}\n"] }]
        }], ctorParameters: () => [], propDecorators: { initialSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialSrc", required: false }] }], initialAlt: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialAlt", required: false }] }] } });

/** @internal */
const TEMPLATE_BLOCK_UI_PROVIDERS = new Map();
/**
 * Registers rich-text editor UI metadata for an XML template block.
 */
function registerRichTextTemplateBlockUiProvider(provider) {
    TEMPLATE_BLOCK_UI_PROVIDERS.set(provider.name, provider);
}
/**
 * Removes rich-text editor UI metadata for an XML template block.
 */
function unregisterRichTextTemplateBlockUiProvider(name) {
    TEMPLATE_BLOCK_UI_PROVIDERS.delete(name);
}
/**
 * Looks up rich-text editor UI metadata for an XML template block.
 */
function getRichTextTemplateBlockUiProvider(name) {
    return TEMPLATE_BLOCK_UI_PROVIDERS.get(name);
}
/**
 * Returns all registered rich-text editor XML template block UI providers.
 */
function getRichTextTemplateBlockUiProviders() {
    return Array.from(TEMPLATE_BLOCK_UI_PROVIDERS.values());
}
registerRichTextTemplateBlockUiProvider({
    name: "placeholder",
    label: "Placeholder",
    selfClosing: true,
    display: "inline",
    attributes: [
        {
            key: "key",
            label: "Placeholder",
            type: "string",
            required: true,
            placeholder: "firstName",
        },
    ],
    formatLabel: (attributes) => attributes["label"] ?? attributes["key"] ?? "Placeholder",
});
registerRichTextTemplateBlockUiProvider({
    name: "if",
    label: "If",
    selfClosing: false,
    display: "block",
    attributes: [
        {
            key: "test",
            label: "Condition",
            type: "string",
            required: true,
            placeholder: "isPremium",
        },
    ],
    formatLabel: (attributes) => `If ${attributes["test"] ?? ""}`.trim(),
});
registerRichTextTemplateBlockUiProvider({
    name: "loop",
    label: "Loop",
    selfClosing: false,
    display: "block",
    attributes: [
        {
            key: "items",
            label: "Items",
            type: "string",
            required: true,
            placeholder: "lines",
        },
    ],
    formatLabel: (attributes) => `Loop ${attributes["items"] ?? ""}`.trim(),
});
registerRichTextTemplateBlockUiProvider({
    name: "email",
    label: "Email",
    selfClosing: true,
    display: "inline",
    attributes: [
        {
            key: "email",
            label: "Email Field",
            type: "string",
            required: true,
            placeholder: "email",
        },
        {
            key: "text",
            label: "Text Field",
            type: "string",
            required: true,
            placeholder: "fullName",
        },
    ],
    formatLabel: (attributes) => `Email ${attributes["email"] ?? ""}`.trim(),
});
/**
 * The default set of toolbar actions shown when no explicit list is
 * provided.
 */
const DEFAULT_TOOLBAR_ACTIONS = [
    "undo",
    "redo",
    "bold",
    "italic",
    "underline",
    "strikethrough",
    "paragraph",
    "heading1",
    "heading2",
    "heading3",
    "blockquote",
    "codeBlock",
    "unorderedList",
    "orderedList",
    "indent",
    "outdent",
    "alignLeft",
    "alignCenter",
    "alignRight",
    "alignJustify",
    "horizontalRule",
    "insertTable",
    "insertTableRowBefore",
    "insertTableRowAfter",
    "insertTableColumnBefore",
    "insertTableColumnAfter",
    "wrapRowsLoop",
    "image",
    "link",
    "removeFormat",
];
/**
 * Complete registry mapping every {@link RichTextFormatAction} to its
 * toolbar button metadata.
 *
 * Icons are SVG inner-content strings from the Lucide icon set.
 *
 * @internal
 */
const TOOLBAR_BUTTON_REGISTRY = {
    undo: {
        action: "undo",
        label: "Undo",
        icon: UIIcons.Lucide.Arrows.Undo2,
        group: "history",
    },
    redo: {
        action: "redo",
        label: "Redo",
        icon: UIIcons.Lucide.Arrows.Redo2,
        group: "history",
    },
    bold: {
        action: "bold",
        label: "Bold",
        icon: UIIcons.Lucide.Text.Bold,
        group: "inline",
    },
    italic: {
        action: "italic",
        label: "Italic",
        icon: UIIcons.Lucide.Text.Italic,
        group: "inline",
    },
    underline: {
        action: "underline",
        label: "Underline",
        icon: UIIcons.Lucide.Text.Underline,
        group: "inline",
    },
    strikethrough: {
        action: "strikethrough",
        label: "Strikethrough",
        icon: UIIcons.Lucide.Text.Strikethrough,
        group: "inline",
    },
    paragraph: {
        action: "paragraph",
        label: "Normal text",
        icon: UIIcons.Lucide.Text.Pilcrow,
        group: "block",
    },
    heading1: {
        action: "heading1",
        label: "Heading 1",
        icon: UIIcons.Lucide.Text.Heading1,
        group: "block",
    },
    heading2: {
        action: "heading2",
        label: "Heading 2",
        icon: UIIcons.Lucide.Text.Heading2,
        group: "block",
    },
    heading3: {
        action: "heading3",
        label: "Heading 3",
        icon: UIIcons.Lucide.Text.Heading3,
        group: "block",
    },
    blockquote: {
        action: "blockquote",
        label: "Quote",
        icon: UIIcons.Lucide.Text.TextQuote,
        group: "block",
    },
    codeBlock: {
        action: "codeBlock",
        label: "Code block",
        icon: UIIcons.Lucide.Text.Code,
        group: "block",
    },
    unorderedList: {
        action: "unorderedList",
        label: "Bullet list",
        icon: UIIcons.Lucide.Text.List,
        group: "list",
    },
    orderedList: {
        action: "orderedList",
        label: "Numbered list",
        icon: UIIcons.Lucide.Text.ListOrdered,
        group: "list",
    },
    indent: {
        action: "indent",
        label: "Increase indent",
        icon: UIIcons.Lucide.Development.ListIndentIncrease,
        group: "list",
    },
    outdent: {
        action: "outdent",
        label: "Decrease indent",
        icon: UIIcons.Lucide.Development.ListIndentDecrease,
        group: "list",
    },
    alignLeft: {
        action: "alignLeft",
        label: "Align left",
        icon: UIIcons.Lucide.Text.TextAlignStart,
        group: "align",
    },
    alignCenter: {
        action: "alignCenter",
        label: "Align centre",
        icon: UIIcons.Lucide.Text.TextAlignCenter,
        group: "align",
    },
    alignRight: {
        action: "alignRight",
        label: "Align right",
        icon: UIIcons.Lucide.Text.TextAlignEnd,
        group: "align",
    },
    alignJustify: {
        action: "alignJustify",
        label: "Justify",
        icon: UIIcons.Lucide.Text.TextAlignJustify,
        group: "align",
    },
    horizontalRule: {
        action: "horizontalRule",
        label: "Horizontal rule",
        icon: UIIcons.Lucide.Development.Minus,
        group: "insert",
    },
    insertTable: {
        action: "insertTable",
        label: "Insert table",
        icon: UIIcons.Lucide.Files.Table,
        group: "insert",
    },
    insertTableRowBefore: {
        action: "insertTableRowBefore",
        label: "Insert row before",
        icon: UIIcons.Lucide.Layout.BetweenHorizontalStart,
        group: "insert",
    },
    insertTableRowAfter: {
        action: "insertTableRowAfter",
        label: "Insert row after",
        icon: UIIcons.Lucide.Layout.BetweenHorizontalEnd,
        group: "insert",
    },
    insertTableColumnBefore: {
        action: "insertTableColumnBefore",
        label: "Insert column before",
        icon: UIIcons.Lucide.Layout.BetweenVerticalStart,
        group: "insert",
    },
    insertTableColumnAfter: {
        action: "insertTableColumnAfter",
        label: "Insert column after",
        icon: UIIcons.Lucide.Layout.BetweenVerticalEnd,
        group: "insert",
    },
    wrapRowsLoop: {
        action: "wrapRowsLoop",
        label: "Loop table rows",
        icon: UIIcons.Lucide.Files.TableRowsSplit,
        group: "insert",
    },
    image: {
        action: "image",
        label: "Insert image",
        icon: UIIcons.Lucide.Files.ImagePlus,
        group: "insert",
    },
    link: {
        action: "link",
        label: "Hyperlink",
        icon: UIIcons.Lucide.Text.Link,
        group: "link-action",
    },
    removeFormat: {
        action: "removeFormat",
        label: "Clear formatting",
        icon: UIIcons.Lucide.Text.RemoveFormatting,
        group: "misc",
    },
};
/**
 * Group names whose buttons render directly in the toolbar.
 * All other groups render as a single dropdown trigger.
 *
 * @internal
 */
const FLAT_TOOLBAR_GROUPS = new Set([
    "history",
    "inline",
    "insert",
    "link-action",
    "misc",
]);
/**
 * Display metadata for dropdown-style toolbar groups.
 *
 * @internal
 */
const TOOLBAR_GROUP_META = {
    block: { label: "Styles", icon: UIIcons.Lucide.Text.Pilcrow },
    list: { label: "Lists", icon: UIIcons.Lucide.Text.List },
    align: { label: "Alignment", icon: UIIcons.Lucide.Text.TextAlignStart },
};

/**
 * CSS class applied to placeholder chips inside the editable area.
 * @internal
 */
const PLACEHOLDER_CLASS$2 = "rte-placeholder";
/**
 * CSS class applied to any rendered XML template block.
 * @internal
 */
const TEMPLATE_BLOCK_CLASS = "rte-template-block";
/**
 * CSS class applied to editable content inside container template blocks.
 * @internal
 */
const TEMPLATE_BLOCK_CONTENT_CLASS = "content";
/**
 * CSS class applied to editor-only caret landing pads at template block edges.
 * @internal
 */
const TEMPLATE_BLOCK_CARET_EDGE_CLASS$1 = "rte-caret-edge";
/**
 * Attribute that marks editor-only caret landing pads.
 * @internal
 */
const TEMPLATE_BLOCK_CARET_EDGE_ATTR$1 = "data-rte-caret-edge";
/**
 * Attribute that marks caret landing pads adjacent to block template UI.
 * @internal
 */
const TEMPLATE_BLOCK_CARET_EDGE_DISPLAY_ATTR$1 = "data-rte-caret-edge-display";
/**
 * Invisible text content used to give the browser a caret position.
 * @internal
 */
const ZERO_WIDTH_SPACE$1 = "\u200b";
/**
 * Rich content tags that should be treated as literal output markup instead of
 * template-editing blocks.
 * @internal
 */
const RICH_CONTENT_TAGS = new Set([
    "a",
    "b",
    "blockquote",
    "br",
    "code",
    "del",
    "em",
    "h1",
    "h2",
    "h3",
    "hr",
    "i",
    "img",
    "li",
    "ol",
    "p",
    "pre",
    "s",
    "span",
    "strike",
    "strong",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "tr",
    "u",
    "ul",
]);
/**
 * HTML void elements that must be serialised as self-closing XML tags.
 * @internal
 */
const XML_VOID_TAGS = new Set([
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
]);
/**
 * HTML editing strategy for the rich-text editor.
 *
 * Uses the native `contenteditable` API with `document.execCommand`
 * for formatting.  Content is stored as HTML strings with
 * template blocks serialised as XML.
 *
 * @internal
 */
class HtmlEditingStrategy {
    sourceToggleLabel = "Edit HTML source";
    previewLabel = "Preview";
    // ── Formatting ────────────────────────────────────────────
    execAction(action, _ctx) {
        switch (action) {
            case "bold":
                document.execCommand("bold");
                break;
            case "italic":
                document.execCommand("italic");
                break;
            case "underline":
                document.execCommand("underline");
                break;
            case "strikethrough":
                document.execCommand("strikeThrough");
                break;
            case "paragraph":
                document.execCommand("formatBlock", false, "p");
                break;
            case "heading1":
                document.execCommand("formatBlock", false, "h1");
                break;
            case "heading2":
                document.execCommand("formatBlock", false, "h2");
                break;
            case "heading3":
                document.execCommand("formatBlock", false, "h3");
                break;
            case "blockquote":
                document.execCommand("formatBlock", false, "blockquote");
                break;
            case "codeBlock":
                document.execCommand("formatBlock", false, "pre");
                break;
            case "unorderedList":
                document.execCommand("insertUnorderedList");
                break;
            case "orderedList":
                document.execCommand("insertOrderedList");
                break;
            case "alignLeft":
                document.execCommand("justifyLeft");
                break;
            case "alignCenter":
                document.execCommand("justifyCenter");
                break;
            case "alignRight":
                document.execCommand("justifyRight");
                break;
            case "alignJustify":
                document.execCommand("justifyFull");
                break;
            case "horizontalRule":
                document.execCommand("insertHorizontalRule");
                break;
            case "insertTable":
            case "insertTableRowBefore":
            case "insertTableRowAfter":
            case "insertTableColumnBefore":
            case "insertTableColumnAfter":
            case "wrapRowsLoop":
                return false;
            case "indent":
                document.execCommand("indent");
                break;
            case "outdent":
                document.execCommand("outdent");
                break;
            case "undo":
                document.execCommand("undo");
                break;
            case "redo":
                document.execCommand("redo");
                break;
            case "link":
                return false; // deferred — link dialog opens separately
            case "removeFormat":
                document.execCommand("removeFormat");
                break;
        }
        return true;
    }
    // ── Serialisation ─────────────────────────────────────────
    serialiseContent(editorEl, _ctx) {
        const clone = editorEl.cloneNode(true);
        const replacements = [];
        const blocks = Array.from(clone.querySelectorAll("[data-template-block]")).reverse();
        blocks.forEach((block) => {
            const marker = `__RTE_TEMPLATE_BLOCK_${replacements.length}__`;
            replacements.push(this.serialiseTemplateBlock(block));
            block.replaceWith(document.createTextNode(marker));
        });
        const legacyChips = clone.querySelectorAll(`.${PLACEHOLDER_CLASS$2}`);
        legacyChips.forEach((chip) => {
            const key = chip.getAttribute("data-placeholder-key") ?? "";
            const marker = `__RTE_TEMPLATE_BLOCK_${replacements.length}__`;
            replacements.push(`<placeholder key="${this.escapeAttr(key)}" />`);
            chip.replaceWith(document.createTextNode(marker));
        });
        let html = this.serialiseNodes(clone.childNodes);
        for (let index = replacements.length - 1; index >= 0; index -= 1) {
            const replacement = replacements[index];
            if (replacement === undefined)
                continue;
            html = html.replace(`__RTE_TEMPLATE_BLOCK_${index}__`, replacement);
        }
        return html;
    }
    deserialiseContent(value, ctx) {
        return this.renderTemplateXml(value, ctx);
    }
    // ── Sanitisation ──────────────────────────────────────────
    sanitiseHtml(html) {
        const temp = document.createElement("div");
        temp.innerHTML = html;
        const dangerous = new Set([
            "SCRIPT",
            "STYLE",
            "IFRAME",
            "OBJECT",
            "EMBED",
            "FORM",
            "INPUT",
            "TEXTAREA",
            "SELECT",
            "BUTTON",
            "LINK",
            "META",
            "BASE",
            "APPLET",
            "SVG",
            "MATH",
        ]);
        const allowed = new Set([
            "B",
            "STRONG",
            "I",
            "EM",
            "U",
            "S",
            "STRIKE",
            "BR",
            "P",
            "H1",
            "H2",
            "H3",
            "UL",
            "OL",
            "LI",
            "SPAN",
            "A",
            "PRE",
            "CODE",
            "BLOCKQUOTE",
            "HR",
            "IMG",
        ]);
        const safeAttrs = new Set([
            "class",
            "href",
            "target",
            "rel",
            "src",
            "alt",
        ]);
        const dangerousSchemeRe = /^\s*(javascript|vbscript|data)\s*:/i;
        const dataImageRe = /^\s*data:image\//i;
        const walk = (el) => {
            for (const child of Array.from(el.children)) {
                if (dangerous.has(child.tagName)) {
                    child.remove();
                    continue;
                }
                if (!allowed.has(child.tagName)) {
                    child.replaceWith(...Array.from(child.childNodes));
                    continue;
                }
                const isTemplateBlock = child.classList.contains(TEMPLATE_BLOCK_CLASS);
                for (const attr of Array.from(child.attributes)) {
                    const name = attr.name.toLowerCase();
                    if (name.startsWith("on")) {
                        child.removeAttribute(attr.name);
                        continue;
                    }
                    if (name === "style") {
                        const sanitisedStyle = this.sanitiseStyleAttr(attr.value);
                        if (sanitisedStyle) {
                            child.setAttribute("style", sanitisedStyle);
                        }
                        else {
                            child.removeAttribute("style");
                        }
                        continue;
                    }
                    if (isTemplateBlock &&
                        (name === "contenteditable" ||
                            name === "data-placeholder-key" ||
                            name === "data-template-block" ||
                            name === "data-template-self-closing" ||
                            name.startsWith("data-template-attr-"))) {
                        continue;
                    }
                    if ((name === "href" || name === "src" || name === "action") &&
                        dangerousSchemeRe.test(attr.value)) {
                        // Allow data:image/* URIs on <img> src
                        if (name === "src" &&
                            child.tagName === "IMG" &&
                            dataImageRe.test(attr.value)) {
                            continue;
                        }
                        child.removeAttribute(attr.name);
                        continue;
                    }
                    if (!safeAttrs.has(name)) {
                        child.removeAttribute(attr.name);
                    }
                }
                walk(child);
            }
        };
        walk(temp);
        return temp.innerHTML;
    }
    /**
     * Filters a `style` attribute value, keeping only safe CSS
     * properties and stripping dangerous values such as
     * `url(...)`, `expression(...)`, and `javascript:`.
     *
     * Returns the cleaned style string, or an empty string if
     * nothing safe remains.
     * @internal
     */
    sanitiseStyleAttr(style) {
        const dangerous = /url\s*\(|expression\s*\(|javascript\s*:/i;
        const result = style
            .split(";")
            .map((decl) => decl.trim())
            .filter((decl) => decl && !dangerous.test(decl))
            .join("; ");
        return result;
    }
    // ── Active format detection ───────────────────────────────
    refreshActiveFormats(ctx) {
        const formats = new Set();
        // Inline toggles
        const inlineChecks = [
            ["bold", "bold"],
            ["italic", "italic"],
            ["underline", "underline"],
            ["strikethrough", "strikeThrough"],
        ];
        for (const [action, cmd] of inlineChecks) {
            try {
                if (document.queryCommandState(cmd))
                    formats.add(action);
            }
            catch {
                // queryCommandState may throw in some browsers
            }
        }
        // Block format (headings, blockquote, code)
        try {
            const block = document.queryCommandValue("formatBlock");
            const tag = block?.toLowerCase().replace(/[<>]/g, "") ?? "";
            if (tag === "p")
                formats.add("paragraph");
            else if (tag === "h1")
                formats.add("heading1");
            else if (tag === "h2")
                formats.add("heading2");
            else if (tag === "h3")
                formats.add("heading3");
            else if (tag === "blockquote")
                formats.add("blockquote");
            else if (tag === "pre")
                formats.add("codeBlock");
        }
        catch {
            // ignore
        }
        // Lists
        const listChecks = [
            ["unorderedList", "insertUnorderedList"],
            ["orderedList", "insertOrderedList"],
        ];
        for (const [action, cmd] of listChecks) {
            try {
                if (document.queryCommandState(cmd))
                    formats.add(action);
            }
            catch {
                // ignore
            }
        }
        // Alignment
        const alignChecks = [
            ["alignLeft", "justifyLeft"],
            ["alignCenter", "justifyCenter"],
            ["alignRight", "justifyRight"],
            ["alignJustify", "justifyFull"],
        ];
        for (const [action, cmd] of alignChecks) {
            try {
                if (document.queryCommandState(cmd))
                    formats.add(action);
            }
            catch {
                // ignore
            }
        }
        // Link detection
        {
            const sel = window.getSelection();
            if (sel && sel.rangeCount > 0) {
                let node = sel.anchorNode;
                while (node && node !== ctx.editorEl) {
                    if (node instanceof HTMLAnchorElement) {
                        formats.add("link");
                        break;
                    }
                    node = node.parentNode;
                }
            }
        }
        return formats;
    }
    // ── Paste ─────────────────────────────────────────────────
    handlePaste(event, ctx) {
        event.preventDefault();
        const html = event.clipboardData?.getData("text/html");
        const text = event.clipboardData?.getData("text/plain") ?? "";
        if (html) {
            const cleaned = ctx.sanitise ? this.sanitiseHtml(html) : html;
            document.execCommand("insertHTML", false, cleaned);
        }
        else {
            document.execCommand("insertText", false, text);
        }
    }
    // ── Link ──────────────────────────────────────────────────
    applyLink(result, existingAnchor, savedRange, ctx) {
        const { url, text } = result;
        if (savedRange) {
            const sel = window.getSelection();
            sel?.removeAllRanges();
            sel?.addRange(savedRange);
        }
        ctx.restoreFocus();
        if (existingAnchor) {
            existingAnchor.setAttribute("href", url);
            existingAnchor.setAttribute("target", "_blank");
            existingAnchor.setAttribute("rel", "noopener noreferrer");
            existingAnchor.textContent = text;
        }
        else {
            const a = document.createElement("a");
            a.href = url;
            a.target = "_blank";
            a.rel = "noopener noreferrer";
            a.textContent = text;
            if (savedRange) {
                savedRange.deleteContents();
                savedRange.insertNode(a);
                const range = document.createRange();
                range.setStartAfter(a);
                range.collapse(true);
                const sel = window.getSelection();
                sel?.removeAllRanges();
                sel?.addRange(range);
            }
        }
    }
    // ── Placeholder ───────────────────────────────────────────
    createPlaceholderChip(placeholder) {
        const chip = document.createElement("span");
        chip.className = `${PLACEHOLDER_CLASS$2} ${TEMPLATE_BLOCK_CLASS}`;
        chip.contentEditable = "false";
        chip.dataset["templateBlock"] = "placeholder";
        chip.dataset["templateSelfClosing"] = "true";
        chip.dataset["templateAttrKey"] = placeholder.key;
        chip.dataset["placeholderKey"] = placeholder.key;
        chip.textContent = placeholder.label;
        return chip;
    }
    // ── Private helpers ───────────────────────────────────────
    /** @internal */
    renderTemplateXml(value, ctx) {
        if (!value.includes("<"))
            return this.escapeHtml(value);
        const parser = new DOMParser();
        const xml = parser.parseFromString(`<template-root>${value}</template-root>`, "application/xml");
        if (xml.querySelector("parsererror"))
            return value;
        const root = xml.documentElement;
        return Array.from(root.childNodes)
            .map((node) => this.renderTemplateNode(node, ctx))
            .join("");
    }
    /** @internal */
    renderTemplateNode(node, ctx) {
        if (node.nodeType === Node.TEXT_NODE ||
            node.nodeType === Node.CDATA_SECTION_NODE) {
            return this.escapeHtml(node.textContent ?? "");
        }
        if (node.nodeType !== Node.ELEMENT_NODE)
            return "";
        const element = node;
        const tag = element.tagName;
        const lowerTag = tag.toLowerCase();
        const uiProvider = getRichTextTemplateBlockUiProvider(tag);
        const isTemplateBlock = uiProvider ||
            (!RICH_CONTENT_TAGS.has(lowerTag) &&
                haveRegisteredTextTemplateBlockProvider(tag));
        if (isTemplateBlock) {
            return this.renderTemplateBlockElement(element, ctx, uiProvider);
        }
        const attrs = Array.from(element.attributes)
            .map((attr) => ` ${attr.name}="${this.escapeAttr(attr.value)}"`)
            .join("");
        if (element.childNodes.length === 0)
            return `<${tag}${attrs} />`;
        const children = Array.from(element.childNodes)
            .map((child) => this.renderTemplateNode(child, ctx))
            .join("");
        return `<${tag}${attrs}>${children}</${tag}>`;
    }
    /** @internal */
    renderTemplateBlockElement(element, ctx, provider) {
        const attrs = this.readElementAttributes(element);
        const resolvedProvider = provider ??
            this.createGenericUiProvider(element.tagName, element.childNodes.length === 0);
        if (element.tagName === "placeholder") {
            const key = attrs["key"] ?? "";
            const placeholder = ctx.placeholders.find((p) => p.key === key);
            attrs["label"] = placeholder?.label ?? attrs["label"] ?? key;
        }
        const label = resolvedProvider.formatLabel?.(attrs) ?? resolvedProvider.label;
        const dataAttrs = this.renderTemplateDataAttributes(element.tagName, attrs, resolvedProvider.selfClosing);
        const placeholderAttr = element.tagName === "placeholder" && attrs["key"]
            ? ` data-placeholder-key="${this.escapeAttr(attrs["key"])}"`
            : "";
        if (resolvedProvider.selfClosing || element.childNodes.length === 0) {
            const classes = element.tagName === "placeholder"
                ? `${PLACEHOLDER_CLASS$2} ${TEMPLATE_BLOCK_CLASS}`
                : TEMPLATE_BLOCK_CLASS;
            return (this.renderTemplateBlockCaretEdge("before") +
                `<span class="${classes}" contenteditable="false"${dataAttrs}${placeholderAttr}>` +
                `${this.escapeHtml(label)}</span>` +
                this.renderTemplateBlockCaretEdge("after"));
        }
        const body = Array.from(element.childNodes)
            .map((child) => this.renderTemplateNode(child, ctx))
            .join("");
        if (this.isTableRowContainerBlock(element)) {
            return (`<tr class="${TEMPLATE_BLOCK_CLASS} table-row-block" ${dataAttrs}>` +
                '<td colspan="999">' +
                this.renderTemplateBlockCaretEdge("before", "block") +
                '<div class="shell">' +
                `<span class="header" contenteditable="false">${this.escapeHtml(label)}</span>` +
                '<table class="table-content"><tbody class="content">' +
                `${body}</tbody></table>` +
                "</div>" +
                this.renderTemplateBlockCaretEdge("after", "block") +
                "</td></tr>");
        }
        return (this.renderTemplateBlockCaretEdge("before", "block") +
            `<div class="${TEMPLATE_BLOCK_CLASS} block" ${dataAttrs}>` +
            `<span class="header" contenteditable="false">${this.escapeHtml(label)}</span>` +
            `<div class="${TEMPLATE_BLOCK_CONTENT_CLASS}">${body}</div>` +
            "</div>" +
            this.renderTemplateBlockCaretEdge("after", "block"));
    }
    /** @internal */
    renderTemplateBlockCaretEdge(position, display = "inline") {
        const displayAttr = display === "block"
            ? ` ${TEMPLATE_BLOCK_CARET_EDGE_DISPLAY_ATTR$1}="block"`
            : "";
        return (`<span class="${TEMPLATE_BLOCK_CARET_EDGE_CLASS$1}" ` +
            `${TEMPLATE_BLOCK_CARET_EDGE_ATTR$1}="${position}"${displayAttr} aria-hidden="true">` +
            `${ZERO_WIDTH_SPACE$1}</span>`);
    }
    /** @internal */
    readElementAttributes(element) {
        const attrs = {};
        for (const attr of Array.from(element.attributes)) {
            attrs[attr.name] = attr.value;
        }
        return attrs;
    }
    /** @internal */
    renderTemplateDataAttributes(name, attrs, selfClosing) {
        const parts = [
            ` data-template-block="${this.escapeAttr(name)}"`,
            ` data-template-self-closing="${selfClosing ? "true" : "false"}"`,
        ];
        for (const [key, value] of Object.entries(attrs)) {
            parts.push(` data-template-attr-${key}="${this.escapeAttr(value)}"`);
        }
        return parts.join("");
    }
    /** @internal */
    createGenericUiProvider(name, selfClosing) {
        return {
            name,
            label: name,
            selfClosing,
            display: selfClosing ? "inline" : "block",
            formatLabel: (attributes) => {
                const detail = Object.entries(attributes)
                    .filter(([key]) => key !== "label")
                    .map(([key, value]) => `${key}=${value}`)
                    .join(", ");
                return detail ? `${name}: ${detail}` : name;
            },
        };
    }
    /** @internal */
    serialiseTemplateBlock(block) {
        const name = block.dataset["templateBlock"] ?? "placeholder";
        const attrs = this.readTemplateDatasetAttributes(block);
        const attrText = Object.entries(attrs)
            .filter(([key]) => key !== "label" || name !== "placeholder")
            .map(([key, value]) => ` ${key}="${this.escapeAttr(value)}"`)
            .join("");
        const selfClosing = block.dataset["templateSelfClosing"] === "true";
        if (selfClosing)
            return `<${name}${attrText} />`;
        if (block instanceof HTMLTemplateElement) {
            const children = this.serialiseNodes(block.content.childNodes);
            return `<${name}${attrText}>${children}</${name}>`;
        }
        const content = block.querySelector(`.${TEMPLATE_BLOCK_CONTENT_CLASS}`);
        const children = content ? this.serialiseNodes(content.childNodes) : "";
        return `<${name}${attrText}>${children}</${name}>`;
    }
    /** @internal */
    serialiseNodes(nodes) {
        return Array.from(nodes)
            .map((node) => this.serialiseNode(node))
            .join("");
    }
    /** @internal */
    serialiseNode(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            return this.escapeText(node.textContent ?? "");
        }
        if (node.nodeType !== Node.ELEMENT_NODE)
            return "";
        const element = node;
        if (element.hasAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR$1))
            return "";
        if (element.hasAttribute("data-template-visual-block"))
            return "";
        if (element instanceof HTMLElement && element.dataset["templateBlock"]) {
            return this.serialiseTemplateBlock(element);
        }
        const tag = element.localName.toLowerCase();
        const attrs = Array.from(element.attributes)
            .map((attr) => ` ${attr.name}="${this.escapeAttr(attr.value)}"`)
            .join("");
        if (XML_VOID_TAGS.has(tag))
            return `<${tag}${attrs} />`;
        return `<${tag}${attrs}>${this.serialiseNodes(element.childNodes)}</${tag}>`;
    }
    /** @internal */
    isTableRowContainerBlock(element) {
        const elementChildren = Array.from(element.childNodes).filter((node) => node.nodeType === Node.ELEMENT_NODE);
        if (!elementChildren.length)
            return false;
        return elementChildren.every((child) => child.tagName.toLowerCase() === "tr");
    }
    /** @internal */
    readTemplateDatasetAttributes(block) {
        const attrs = {};
        for (const [key, value] of Object.entries(block.dataset)) {
            if (!key.startsWith("templateAttr") || value === undefined)
                continue;
            const attrName = key
                .slice("templateAttr".length)
                .replace(/^[A-Z]/, (first) => first.toLowerCase())
                .replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
            attrs[attrName] = value;
        }
        if (!attrs["key"] && block.dataset["placeholderKey"]) {
            attrs["key"] = block.dataset["placeholderKey"];
        }
        return attrs;
    }
    /** XML-escape text content. */
    escapeText(str) {
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;");
    }
    /** HTML-escape a string for safe insertion into markup. */
    escapeHtml(str) {
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }
    /** Escape a string for safe use in an HTML attribute value. */
    escapeAttr(str) {
        return this.escapeHtml(str);
    }
}

/**
 * CSS class applied to placeholder chips inside the preview area.
 * Must match the class used in the HTML strategy for consistent
 * styling.
 * @internal
 */
const PLACEHOLDER_CLASS$1 = "rte-placeholder";
/**
 * Regex matching serialised placeholder XML blocks.
 * @internal
 */
const PLACEHOLDER_BLOCK_RE = /<placeholder\s+[^>]*key=(?:"([^"]+)"|'([^']+)")[^>]*\/>/g;
/**
 * Converts a `<table>` DOM element to a GFM Markdown table string.
 * @internal
 */
function tableToMarkdown(el) {
    const allRowEls = Array.from(el.querySelectorAll("tr"));
    if (allRowEls.length === 0)
        return "";
    const cellText = (cell) => nodeToMarkdown(cell).trim().replace(/\|/g, "\\|");
    const headerCells = Array.from(allRowEls[0].querySelectorAll("th, td")).map(cellText);
    if (headerCells.length === 0)
        return "";
    const sepCells = headerCells.map(() => "---");
    const bodyRowEls = el.querySelector("tbody")
        ? Array.from(el.querySelectorAll("tbody tr"))
        : allRowEls.slice(1);
    const bodyRows = bodyRowEls.map((row) => Array.from(row.querySelectorAll("td, th")).map(cellText));
    const lines = [
        `| ${headerCells.join(" | ")} |`,
        `| ${sepCells.join(" | ")} |`,
        ...bodyRows.map((cells) => `| ${cells.join(" | ")} |`),
    ];
    return lines.join("\n") + "\n\n";
}
/**
 * Converts simple HTML back to Markdown.
 *
 * Used when pasting HTML content into the Markdown editor.
 *
 * @internal
 */
function htmlToMarkdown(html) {
    const temp = document.createElement("div");
    temp.innerHTML = html;
    return nodeToMarkdown(temp).trim();
}
/**
 * Recursively converts a DOM node tree to Markdown.
 * @internal
 */
function nodeToMarkdown(node) {
    if (node.nodeType === Node.TEXT_NODE) {
        return node.textContent ?? "";
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
        return "";
    }
    const el = node;
    const tag = el.tagName;
    const childMd = Array.from(el.childNodes)
        .map((c) => nodeToMarkdown(c))
        .join("");
    switch (tag) {
        case "B":
        case "STRONG":
            return `**${childMd}**`;
        case "I":
        case "EM":
            return `*${childMd}*`;
        case "U":
            return `++${childMd}++`;
        case "S":
        case "STRIKE":
        case "DEL":
            return `~~${childMd}~~`;
        case "CODE":
            return `\`${childMd}\``;
        case "A": {
            const href = el.getAttribute("href") ?? "";
            return `[${childMd}](${href})`;
        }
        case "IMG": {
            const src = el.getAttribute("src") ?? "";
            const alt = el.getAttribute("alt") ?? "";
            return `![${alt}](${src})`;
        }
        case "BR":
            return "\n";
        case "P":
            return `${childMd}\n\n`;
        case "H1":
            return `# ${childMd}\n\n`;
        case "H2":
            return `## ${childMd}\n\n`;
        case "H3":
            return `### ${childMd}\n\n`;
        case "BLOCKQUOTE":
            return (childMd
                .split("\n")
                .filter((l) => l.length > 0)
                .map((l) => `> ${l}`)
                .join("\n") + "\n\n");
        case "PRE":
            return `\`\`\`\n${el.textContent ?? ""}\n\`\`\`\n\n`;
        case "UL":
            return (Array.from(el.children)
                .map((li) => `- ${nodeToMarkdown(li).trim()}`)
                .join("\n") + "\n\n");
        case "OL":
            return (Array.from(el.children)
                .map((li, i) => `${i + 1}. ${nodeToMarkdown(li).trim()}`)
                .join("\n") + "\n\n");
        case "LI":
            return childMd;
        case "TABLE":
            return tableToMarkdown(el);
        case "THEAD":
        case "TBODY":
        case "TFOOT":
        case "TR":
        case "TH":
        case "TD":
        case "CAPTION":
            return childMd;
        case "HR":
            return "---\n\n";
        default:
            return childMd;
    }
}
/** HTML-escape a string. @internal */
function escapeHtml(str) {
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
/**
 * Map of format actions to their Markdown inline syntax wrappers.
 * @internal
 */
const INLINE_WRAPS = {
    bold: { prefix: "**", suffix: "**" },
    italic: { prefix: "*", suffix: "*" },
    underline: { prefix: "++", suffix: "++" },
    strikethrough: { prefix: "~~", suffix: "~~" },
};
/**
 * Map of format actions to their Markdown line prefix.
 * @internal
 */
const BLOCK_PREFIXES = {
    heading1: "# ",
    heading2: "## ",
    heading3: "### ",
    unorderedList: "- ",
    orderedList: "1. ",
    blockquote: "> ",
    paragraph: "",
};
// ── Strategy ───────────────────────────────────────────────────
/**
 * Markdown editing strategy for the rich-text editor.
 *
 * In Markdown mode the editor uses a `<textarea>` (via the
 * existing source-mode textarea) for editing raw Markdown, with
 * a live HTML preview below.
 *
 * Formatting actions insert Markdown syntax around the selection
 * in the textarea.  The serialised value is a Markdown string.
 *
 * @internal
 */
class MarkdownEditingStrategy {
    sourceToggleLabel = "Edit Markdown source";
    previewLabel = "Preview";
    /**
     * Reference to the Markdown `<textarea>` element.
     * Set by the component when the strategy is active.
     */
    textareaEl = null;
    /**
     * Optional external Markdown parser.  When provided, its
     * `toHtml()` method is used instead of the built-in converter
     * for the live preview and deserialisation.
     */
    parser;
    /**
     * @param parser - Optional {@link MarkdownParser} implementation.
     *   When `null` or omitted the built-in lightweight converter is
     *   used.  Consumers can supply a `marked`- or `markdown-it`-
     *   backed parser via the {@link MARKDOWN_PARSER} injection token.
     */
    constructor(parser) {
        this.parser = parser ?? null;
    }
    // ── Formatting ────────────────────────────────────────────
    execAction(action, _ctx) {
        const textarea = this.textareaEl;
        if (!textarea)
            return true;
        if (action === "link") {
            return false; // deferred — link dialog
        }
        if (action === "removeFormat") {
            this.removeInlineFormatting(textarea);
            return true;
        }
        if (action === "codeBlock") {
            this.toggleCodeBlock(textarea);
            return true;
        }
        if (action === "horizontalRule") {
            this.insertTextAtCaret(textarea, "\n---\n");
            return true;
        }
        if (action === "indent") {
            this.indentLines(textarea, true);
            return true;
        }
        if (action === "outdent") {
            this.indentLines(textarea, false);
            return true;
        }
        if (action === "undo" || action === "redo") {
            // Let the browser handle undo/redo natively for textareas
            document.execCommand(action);
            return true;
        }
        // Inline wraps
        const wrap = INLINE_WRAPS[action];
        if (wrap) {
            this.toggleInlineWrap(textarea, wrap);
            return true;
        }
        // Block prefixes
        const prefix = BLOCK_PREFIXES[action];
        if (prefix !== undefined) {
            this.setLinePrefix(textarea, prefix);
            return true;
        }
        // Alignment is not meaningful in Markdown — ignore silently
        if (action === "alignLeft" ||
            action === "alignCenter" ||
            action === "alignRight" ||
            action === "alignJustify") {
            return true;
        }
        return true;
    }
    // ── Serialisation ─────────────────────────────────────────
    serialiseContent(_editorEl, _ctx) {
        // In Markdown mode the authoritative content lives in the
        // textarea, not the contenteditable preview.  The component
        // syncs via a separate path, so this is a fallback.
        return this.textareaEl?.value ?? "";
    }
    deserialiseContent(value, ctx) {
        // Convert Markdown → HTML first, then expand placeholder XML blocks
        // into placeholder chip elements in the HTML output.
        // When an external parser is provided, delegate to it;
        // otherwise fall back to the built-in lightweight converter.
        const html = this.parser
            ? this.parser.toHtml(value)
            : markdownToHtml(value);
        return this.expandPlaceholderTokens(html, ctx);
    }
    // ── Sanitisation ──────────────────────────────────────────
    sanitiseHtml(html) {
        // In Markdown mode all content flows through either:
        //   • markdownToHtml() — our own trusted converter (no sanitisation needed)
        //   • handlePaste()    — converts HTML → Markdown text via htmlToMarkdown()
        // Neither path requires post-processing here.  Sanitisation of paste
        // content is handled exclusively by the HTML→Markdown conversion, which
        // strips unsafe constructs structurally rather than via an allow-list.
        return html;
    }
    // ── Active format detection ───────────────────────────────
    refreshActiveFormats(_ctx) {
        const formats = new Set();
        const textarea = this.textareaEl;
        if (!textarea)
            return formats;
        const { selectionStart, selectionEnd, value } = textarea;
        // Get the current line
        const lineStart = value.lastIndexOf("\n", selectionStart - 1) + 1;
        const lineEnd = value.indexOf("\n", selectionEnd);
        const line = value.substring(lineStart, lineEnd === -1 ? value.length : lineEnd);
        // Block-level detection from line prefix
        if (/^###\s/.test(line))
            formats.add("heading3");
        else if (/^##\s/.test(line))
            formats.add("heading2");
        else if (/^#\s/.test(line))
            formats.add("heading1");
        else if (/^>\s/.test(line))
            formats.add("blockquote");
        else if (/^[-*+]\s/.test(line))
            formats.add("unorderedList");
        else if (/^\d+\.\s/.test(line))
            formats.add("orderedList");
        // Code block detection (check if we're between ``` fences)
        const before = value.substring(0, selectionStart);
        const fenceCount = (before.match(/^```/gm) ?? []).length;
        if (fenceCount % 2 === 1)
            formats.add("codeBlock");
        // Inline detection — check text surrounding the selection
        const _selectedText = selectionStart === selectionEnd
            ? this.getWordAtCaret(value, selectionStart)
            : value.substring(selectionStart, selectionEnd);
        // Expand context around selection for pattern matching
        const contextStart = Math.max(0, selectionStart - 3);
        const contextEnd = Math.min(value.length, selectionEnd + 3);
        const context = value.substring(contextStart, contextEnd);
        if (/\*\*[^*]+\*\*/.test(context) || /\*\*/.test(context.substring(0, 3)))
            formats.add("bold");
        if (/(?<!\*)\*(?!\*)[^*]+\*(?!\*)/.test(context))
            formats.add("italic");
        if (/~~[^~]+~~/.test(context))
            formats.add("strikethrough");
        if (/\+\+[^+]+\+\+/.test(context))
            formats.add("underline");
        // Link detection
        const linkContext = value.substring(Math.max(0, selectionStart - 50), Math.min(value.length, selectionEnd + 50));
        if (/\[([^\]]+)\]\(([^)]+)\)/.test(linkContext))
            formats.add("link");
        return formats;
    }
    // ── Paste ─────────────────────────────────────────────────
    handlePaste(event, _ctx) {
        event.preventDefault();
        const textarea = this.textareaEl;
        if (!textarea)
            return;
        const html = event.clipboardData?.getData("text/html");
        const text = event.clipboardData?.getData("text/plain") ?? "";
        // Convert pasted HTML to Markdown, or use plain text
        const md = html ? htmlToMarkdown(html) : text;
        this.insertTextAtCaret(textarea, md);
    }
    // ── Link ──────────────────────────────────────────────────
    applyLink(result, _existingAnchor, _savedRange, _ctx) {
        const textarea = this.textareaEl;
        if (!textarea)
            return;
        const { url, text } = result;
        const linkMd = `[${text}](${url})`;
        // Replace selection (or insert at caret)
        this.insertTextAtCaret(textarea, linkMd);
    }
    // ── Placeholder ───────────────────────────────────────────
    createPlaceholderChip(placeholder) {
        // In Markdown mode we still create chip elements for the
        // preview, but the actual insertion into the textarea is
        // handled separately.
        const chip = document.createElement("span");
        chip.className = PLACEHOLDER_CLASS$1;
        chip.contentEditable = "false";
        chip.dataset["templateBlock"] = "placeholder";
        chip.dataset["templateSelfClosing"] = "true";
        chip.dataset["templateAttrKey"] = placeholder.key;
        chip.dataset["placeholderKey"] = placeholder.key;
        chip.textContent = placeholder.label;
        return chip;
    }
    // ── Private helpers ───────────────────────────────────────
    /**
     * Toggles an inline Markdown wrap (e.g. `**`, `*`) around the
     * current selection in the textarea.
     */
    toggleInlineWrap(textarea, wrap) {
        const { selectionStart, selectionEnd, value } = textarea;
        const selected = value.substring(selectionStart, selectionEnd);
        const pLen = wrap.prefix.length;
        const sLen = wrap.suffix.length;
        // Check if already wrapped — toggle off
        const before = value.substring(Math.max(0, selectionStart - pLen), selectionStart);
        const after = value.substring(selectionEnd, Math.min(value.length, selectionEnd + sLen));
        if (before === wrap.prefix && after === wrap.suffix) {
            // Remove existing wrap
            textarea.value =
                value.substring(0, selectionStart - pLen) +
                    selected +
                    value.substring(selectionEnd + sLen);
            textarea.selectionStart = selectionStart - pLen;
            textarea.selectionEnd = selectionEnd - pLen;
        }
        else {
            // Add wrap
            textarea.value =
                value.substring(0, selectionStart) +
                    wrap.prefix +
                    selected +
                    wrap.suffix +
                    value.substring(selectionEnd);
            textarea.selectionStart = selectionStart + pLen;
            textarea.selectionEnd = selectionEnd + pLen;
        }
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Sets or removes a line prefix (e.g. `# `, `- `, `> `) on
     * the line(s) containing the current selection.
     */
    setLinePrefix(textarea, prefix) {
        const { selectionStart, selectionEnd, value } = textarea;
        const lineStart = value.lastIndexOf("\n", selectionStart - 1) + 1;
        const lineEnd = value.indexOf("\n", selectionEnd);
        const line = value.substring(lineStart, lineEnd === -1 ? value.length : lineEnd);
        // Remove any existing block prefix
        const stripped = line.replace(/^(#{1,3}\s|[-*+]\s|\d+\.\s|>\s)/, "");
        const newLine = prefix + stripped;
        const actualEnd = lineEnd === -1 ? value.length : lineEnd;
        textarea.value =
            value.substring(0, lineStart) + newLine + value.substring(actualEnd);
        textarea.selectionStart = lineStart + prefix.length;
        textarea.selectionEnd = lineStart + newLine.length;
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Toggles a fenced code block around the current selection.
     */
    toggleCodeBlock(textarea) {
        const { selectionStart, selectionEnd, value } = textarea;
        const selected = value.substring(selectionStart, selectionEnd);
        // Check if inside a code block
        const before = value.substring(0, selectionStart);
        const fenceCount = (before.match(/^```/gm) ?? []).length;
        if (fenceCount % 2 === 1) {
            // Inside a code block — remove the surrounding fences
            const fenceStart = before.lastIndexOf("```");
            const afterSel = value.substring(selectionEnd);
            const fenceEnd = afterSel.indexOf("```");
            if (fenceStart !== -1 && fenceEnd !== -1) {
                const beforeFence = value.substring(0, fenceStart);
                const content = value.substring(fenceStart + 3, selectionEnd + fenceEnd);
                const afterFence = value.substring(selectionEnd + fenceEnd + 3);
                textarea.value =
                    beforeFence +
                        content.replace(/^\n/, "").replace(/\n$/, "") +
                        afterFence;
            }
        }
        else {
            // Wrap in code block
            const wrapped = "\n```\n" + selected + "\n```\n";
            textarea.value =
                value.substring(0, selectionStart) +
                    wrapped +
                    value.substring(selectionEnd);
            textarea.selectionStart = selectionStart + 4;
            textarea.selectionEnd = selectionStart + 4 + selected.length;
        }
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Indents or outdents the lines covered by the current selection.
     * Uses two-space indentation.
     */
    indentLines(textarea, indent) {
        const { selectionStart, selectionEnd, value } = textarea;
        const lineStart = value.lastIndexOf("\n", selectionStart - 1) + 1;
        const lineEnd = value.indexOf("\n", selectionEnd);
        const actualEnd = lineEnd === -1 ? value.length : lineEnd;
        const block = value.substring(lineStart, actualEnd);
        const processed = block
            .split("\n")
            .map((line) => {
            if (indent) {
                return "  " + line;
            }
            // Remove up to 2 leading spaces
            return line.replace(/^ {1,2}/, "");
        })
            .join("\n");
        textarea.value =
            value.substring(0, lineStart) + processed + value.substring(actualEnd);
        textarea.selectionStart = lineStart;
        textarea.selectionEnd = lineStart + processed.length;
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Removes inline formatting markers from the selected text.
     */
    removeInlineFormatting(textarea) {
        const { selectionStart, selectionEnd, value } = textarea;
        if (selectionStart === selectionEnd)
            return;
        const selected = value.substring(selectionStart, selectionEnd);
        const cleaned = selected
            .replace(/\*\*\*(.+?)\*\*\*/g, "$1")
            .replace(/\*\*(.+?)\*\*/g, "$1")
            .replace(/\*(.+?)\*/g, "$1")
            .replace(/~~(.+?)~~/g, "$1")
            .replace(/\+\+(.+?)\+\+/g, "$1")
            .replace(/`([^`]+)`/g, "$1");
        textarea.value =
            value.substring(0, selectionStart) +
                cleaned +
                value.substring(selectionEnd);
        textarea.selectionStart = selectionStart;
        textarea.selectionEnd = selectionStart + cleaned.length;
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Inserts text at the current caret position in the textarea,
     * replacing any existing selection.
     */
    insertTextAtCaret(textarea, text) {
        const { selectionStart, selectionEnd, value } = textarea;
        textarea.value =
            value.substring(0, selectionStart) + text + value.substring(selectionEnd);
        textarea.selectionStart = selectionStart + text.length;
        textarea.selectionEnd = selectionStart + text.length;
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Returns the word surrounding the caret position.
     */
    getWordAtCaret(value, pos) {
        const before = value.substring(0, pos);
        const after = value.substring(pos);
        const wordStart = before.search(/\S+$/);
        const wordEnd = after.search(/\s/);
        return value.substring(wordStart === -1 ? pos : wordStart, wordEnd === -1 ? value.length : pos + wordEnd);
    }
    /**
     * Expands placeholder XML blocks in an HTML string into
     * chip markup for the preview pane.
     */
    expandPlaceholderTokens(html, ctx) {
        const placeholders = ctx.placeholders;
        return html.replace(PLACEHOLDER_BLOCK_RE, (_match, dq, sq) => {
            const key = dq ?? sq ?? "";
            const ph = placeholders.find((p) => p.key === key);
            const label = ph?.label ?? key;
            return (`<span class="${PLACEHOLDER_CLASS$1}" ` +
                `contenteditable="false" ` +
                `data-placeholder-key="${escapeHtml(key)}">` +
                `${escapeHtml(label)}</span>`);
        });
    }
}

/**
 * Optional DI token for a custom {@link MarkdownParser}.
 *
 * When provided, the `MarkdownEditingStrategy` will use it
 * instead of the built-in lightweight converter.  This lets
 * consumers plug in full-featured parsers like `marked` or
 * `markdown-it` without adding a dependency to the library itself.
 *
 * @example
 * ```ts
 * import { MARKDOWN_PARSER, createMarkedParser } from '@theredhead/lucid-blocks';
 * import { marked } from 'marked';
 *
 * @Component({
 *   providers: [
 *     {
 *       provide: MARKDOWN_PARSER,
 *       useValue: createMarkedParser(md => marked.parse(md) as string),
 *     },
 *   ],
 * })
 * export class MyEditorHost {}
 * ```
 */
const MARKDOWN_PARSER = new InjectionToken("MARKDOWN_PARSER");
// ── Adapter factories ─────────────────────────────────────────
/**
 * Creates a {@link MarkdownParser} that delegates to the `marked`
 * library's `parse` function.
 *
 * The consumer must install `marked` themselves and pass in the
 * bound `parse` function — this library never imports `marked`
 * directly.
 *
 * @param parseFn - A function that takes a Markdown string and
 *   returns an HTML string.  Typically `(md) => marked.parse(md)`.
 * @returns A {@link MarkdownParser} instance.
 *
 * @example
 * ```ts
 * import { marked } from 'marked';
 * import { MARKDOWN_PARSER, createMarkedParser } from '@theredhead/lucid-blocks';
 *
 * providers: [
 *   {
 *     provide: MARKDOWN_PARSER,
 *     useValue: createMarkedParser(md => marked.parse(md) as string),
 *   },
 * ]
 * ```
 */
function createMarkedParser(parseFn) {
    return { toHtml: parseFn };
}
/**
 * Creates a {@link MarkdownParser} that delegates to a
 * `markdown-it` instance's `render` method.
 *
 * The consumer must install `markdown-it` themselves and pass in
 * the bound `render` function — this library never imports
 * `markdown-it` directly.
 *
 * @param renderFn - A function that takes a Markdown string and
 *   returns an HTML string.  Typically `(md) => md.render(md)`
 *   where `md` is a configured `MarkdownIt` instance.
 * @returns A {@link MarkdownParser} instance.
 *
 * @example
 * ```ts
 * import MarkdownIt from 'markdown-it';
 * import { MARKDOWN_PARSER, createMarkdownItParser } from '@theredhead/lucid-blocks';
 *
 * const mdit = new MarkdownIt();
 *
 * providers: [
 *   {
 *     provide: MARKDOWN_PARSER,
 *     useValue: createMarkdownItParser(md => mdit.render(md)),
 *   },
 * ]
 * ```
 */
function createMarkdownItParser(renderFn) {
    return { toHtml: renderFn };
}

/**
 * Property-sheet popover for inserting or editing XML template block
 * attributes.
 *
 * @internal
 */
class UITemplateBlockDialog {
    popoverRef = inject((PopoverRef));
    /**
     * XML block name.
     */
    blockName = input("", ...(ngDevMode ? [{ debugName: "blockName" }] : []));
    /**
     * Human-readable block label.
     */
    blockLabel = input("", ...(ngDevMode ? [{ debugName: "blockLabel" }] : []));
    /**
     * Initial attributes.
     */
    initialAttributes = input({}, ...(ngDevMode ? [{ debugName: "initialAttributes" }] : []));
    /**
     * Editable attribute definitions for this block.
     */
    attributeDefinitions = input([], ...(ngDevMode ? [{ debugName: "attributeDefinitions" }] : []));
    /**
     * Whether this popover edits an existing block.
     */
    editMode = input(false, ...(ngDevMode ? [{ debugName: "editMode" }] : []));
    /** @internal */
    attributeValues = signal({}, ...(ngDevMode ? [{ debugName: "attributeValues" }] : []));
    /** @internal */
    fields = computed(() => {
        const definitions = this.attributeDefinitions();
        if (definitions.length > 0) {
            return definitions.map((field) => ({
                ...field,
                type: field.type ?? "string",
            }));
        }
        return Object.keys(this.initialAttributes()).map((key) => this.createGenericField(key));
    }, ...(ngDevMode ? [{ debugName: "fields" }] : []));
    /** @internal */
    canApply = computed(() => this.fields().every((field) => {
        if (!field.required)
            return true;
        return String(this.attributeValues()[field.key] ?? "").trim().length > 0;
    }), ...(ngDevMode ? [{ debugName: "canApply" }] : []));
    /** @internal */
    initialAttributeSync = effect(() => {
        this.attributeDefinitions();
        this.attributeValues.set({ ...this.initialAttributes() });
    }, ...(ngDevMode ? [{ debugName: "initialAttributeSync" }] : []));
    /** @internal */
    apply() {
        if (!this.canApply())
            return;
        const attributes = {};
        for (const field of this.fields()) {
            const value = this.attributeValues()[field.key];
            attributes[field.key] = this.formatAttributeValue(value, field.type);
        }
        this.popoverRef.close({
            name: this.blockName(),
            attributes,
        });
    }
    /** @internal */
    cancel() {
        this.popoverRef.close(undefined);
    }
    /** @internal */
    createGenericField(key) {
        return {
            key,
            label: key
                .replace(/[-_]+/g, " ")
                .replace(/\b\w/g, (letter) => letter.toUpperCase()),
            type: "string",
        };
    }
    /** @internal */
    formatAttributeValue(value, type) {
        if (type === "boolean")
            return value ? "true" : "false";
        if (value == null)
            return "";
        return String(value).trim();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UITemplateBlockDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UITemplateBlockDialog, isStandalone: true, selector: "ui-template-block-dialog", inputs: { blockName: { classPropertyName: "blockName", publicName: "blockName", isSignal: true, isRequired: false, transformFunction: null }, blockLabel: { classPropertyName: "blockLabel", publicName: "blockLabel", isSignal: true, isRequired: false, transformFunction: null }, initialAttributes: { classPropertyName: "initialAttributes", publicName: "initialAttributes", isSignal: true, isRequired: false, transformFunction: null }, attributeDefinitions: { classPropertyName: "attributeDefinitions", publicName: "attributeDefinitions", isSignal: true, isRequired: false, transformFunction: null }, editMode: { classPropertyName: "editMode", publicName: "editMode", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-template-block-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"heading\">\n  @if (editMode()) {\n  Edit {{ blockLabel() || blockName() }}\n  } @else {\n  Insert {{ blockLabel() || blockName() }}\n  }\n</div>\n\n@if (fields().length > 0) {\n<ui-property-sheet class=\"property-sheet\" [fields]=\"fields()\" [(data)]=\"attributeValues\"\n  [ariaLabel]=\"(blockLabel() || blockName()) + ' attributes'\" />\n} @else {\n<div class=\"empty\">This block has no editable attributes.</div>\n}\n\n<div class=\"actions\">\n  <button type=\"button\" class=\"btn cancel\" (click)=\"cancel()\">Cancel editing</button>\n  <button type=\"button\" class=\"btn apply\" [disabled]=\"!canApply()\" (click)=\"apply()\">\n    @if (editMode()) {\n    Apply\n    } @else {\n    Insert\n    }\n  </button>\n</div>", styles: [":host{display:block;width:min(24rem,82vw);padding:.75rem;box-sizing:border-box;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.heading{margin-bottom:.65rem;font-size:.875rem;font-weight:700;color:var(--ui-text, #1d232b);background:transparent}.property-sheet{display:block;margin-bottom:.65rem}.empty{border:1px solid var(--ui-border, #d4d8dd);border-radius:.25rem;padding:.6rem;font-size:.8125rem;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.actions{display:flex;justify-content:flex-end;gap:.5rem}.btn{border:1px solid var(--ui-border, #d4d8dd);border-radius:.25rem;padding:.4rem .65rem;font:inherit;font-size:.8125rem;cursor:var(--ui-cursor-click, pointer);color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.btn:disabled{cursor:default;opacity:.6;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.btn.apply{border-color:var(--ui-accent, #3584e4);color:var(--ui-accent, #3584e4);background:var(--ui-primary-container, #dbeafe)}.btn.apply:disabled{border-color:var(--ui-border, #d4d8dd);color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}\n"], dependencies: [{ kind: "component", type: UIPropertySheet, selector: "ui-property-sheet", inputs: ["fields", "ariaLabel", "data"], outputs: ["dataChange", "propertyChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UITemplateBlockDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-template-block-dialog", standalone: true, imports: [UIPropertySheet], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: { class: "ui-template-block-dialog" }, template: "<div class=\"heading\">\n  @if (editMode()) {\n  Edit {{ blockLabel() || blockName() }}\n  } @else {\n  Insert {{ blockLabel() || blockName() }}\n  }\n</div>\n\n@if (fields().length > 0) {\n<ui-property-sheet class=\"property-sheet\" [fields]=\"fields()\" [(data)]=\"attributeValues\"\n  [ariaLabel]=\"(blockLabel() || blockName()) + ' attributes'\" />\n} @else {\n<div class=\"empty\">This block has no editable attributes.</div>\n}\n\n<div class=\"actions\">\n  <button type=\"button\" class=\"btn cancel\" (click)=\"cancel()\">Cancel editing</button>\n  <button type=\"button\" class=\"btn apply\" [disabled]=\"!canApply()\" (click)=\"apply()\">\n    @if (editMode()) {\n    Apply\n    } @else {\n    Insert\n    }\n  </button>\n</div>", styles: [":host{display:block;width:min(24rem,82vw);padding:.75rem;box-sizing:border-box;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.heading{margin-bottom:.65rem;font-size:.875rem;font-weight:700;color:var(--ui-text, #1d232b);background:transparent}.property-sheet{display:block;margin-bottom:.65rem}.empty{border:1px solid var(--ui-border, #d4d8dd);border-radius:.25rem;padding:.6rem;font-size:.8125rem;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.actions{display:flex;justify-content:flex-end;gap:.5rem}.btn{border:1px solid var(--ui-border, #d4d8dd);border-radius:.25rem;padding:.4rem .65rem;font:inherit;font-size:.8125rem;cursor:var(--ui-cursor-click, pointer);color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff)}.btn:disabled{cursor:default;opacity:.6;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.btn.apply{border-color:var(--ui-accent, #3584e4);color:var(--ui-accent, #3584e4);background:var(--ui-primary-container, #dbeafe)}.btn.apply:disabled{border-color:var(--ui-border, #d4d8dd);color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}\n"] }]
        }], propDecorators: { blockName: [{ type: i0.Input, args: [{ isSignal: true, alias: "blockName", required: false }] }], blockLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "blockLabel", required: false }] }], initialAttributes: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialAttributes", required: false }] }], attributeDefinitions: [{ type: i0.Input, args: [{ isSignal: true, alias: "attributeDefinitions", required: false }] }], editMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "editMode", required: false }] }] } });

/**
 * The CSS class applied to placeholder chips inside the editable area.
 * @internal
 */
const PLACEHOLDER_CLASS = "rte-placeholder";
/** @internal */
const TEMPLATE_BLOCK_CARET_EDGE_CLASS = "rte-caret-edge";
/** @internal */
const TEMPLATE_BLOCK_CARET_EDGE_ATTR = "data-rte-caret-edge";
/** @internal */
const TEMPLATE_BLOCK_CARET_EDGE_DISPLAY_ATTR = "data-rte-caret-edge-display";
/** @internal */
const ZERO_WIDTH_SPACE = "\u200b";
/** @internal */
const RICH_CONTENT_BLOCK_NAMES = new Set([
    "a",
    "article",
    "b",
    "blockquote",
    "br",
    "caption",
    "code",
    "del",
    "div",
    "dl",
    "dt",
    "dd",
    "em",
    "figcaption",
    "figure",
    "footer",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "hr",
    "i",
    "img",
    "li",
    "main",
    "nav",
    "ol",
    "p",
    "pre",
    "s",
    "section",
    "span",
    "strike",
    "strong",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "tr",
    "u",
    "ul",
]);
// ── Component ──────────────────────────────────────────────────────
/**
 * Rich-text editor supporting basic formatting and placeholder
 * insertion.
 *
 * Supports two editing modes controlled by the `mode` input:
 *
 * - **`'html'`** (default) — WYSIWYG editing with a native
 *   `contenteditable` div and `document.execCommand` for
 *   formatting.  Content is stored as HTML.
 *
 * - **`'markdown'`** — Plain-text Markdown editing in a
 *   `<textarea>` with a live HTML preview below.  Formatting
 *   actions insert Markdown syntax.  Content is stored as
 *   Markdown.
 *
 * **Placeholders** are self-closing XML template blocks (e.g.
 * `<placeholder key="firstName" />`) rendered as non-editable inline chips.
 * A downstream template engine resolves them through the same block-provider
 * path used by all other template blocks.
 *
 * The editor exposes its content as a two-way `[(value)]` binding.
 *
 * @example
 * ```html
 * <ui-rich-text-editor
 *   [(value)]="emailBody"
 *   [placeholders]="availablePlaceholders"
 *   ariaLabel="Email body"
 * />
 *
 * <ui-rich-text-editor
 *   mode="markdown"
 *   [(value)]="readmeContent"
 *   ariaLabel="README editor"
 * />
 * ```
 */
class UIRichTextEditor {
    /** @internal Compact editor toolbar actions for chat-style composition. */
    static COMPACT_TOOLBAR_ACTIONS = ["bold", "italic", "underline"];
    /** @internal Prefix for context-derived placeholder entries in the block menu. */
    static TEMPLATE_PLACEHOLDER_ITEM_PREFIX = "placeholder:";
    elRef = inject((ElementRef));
    destroyRef = inject(DestroyRef);
    popoverService = inject(PopoverService);
    log = inject(LoggerFactory).createLogger("UIRichTextEditor");
    /**
     * Optional external Markdown parser injected via
     * {@link MARKDOWN_PARSER}.  When provided, the
     * {@link MarkdownEditingStrategy} delegates its Markdown → HTML
     * conversion to this parser instead of using the built-in
     * lightweight converter.
     */
    markdownParser = inject(MARKDOWN_PARSER, {
        optional: true,
    });
    // ── View queries ───────────────────────────────────────────
    /** @internal */
    editorRef = viewChild.required("editorEl");
    /**
     * Optional reference to the Markdown textarea, present only
     * when `mode === 'markdown'`.
     * @internal
     */
    mdTextareaRef = viewChild("mdTextarea", ...(ngDevMode ? [{ debugName: "mdTextareaRef" }] : []));
    /**
     * Syncs the Markdown textarea element reference into the
     * active strategy whenever it appears or disappears.
     * @internal
     */
    mdTextareaSync = effect(() => {
        const ref = this.mdTextareaRef();
        const strat = this.strategy();
        if (strat instanceof MarkdownEditingStrategy) {
            strat.textareaEl = ref?.nativeElement ?? null;
        }
    }, ...(ngDevMode ? [{ debugName: "mdTextareaSync" }] : []));
    // ── Inputs ─────────────────────────────────────────────────
    /**
     * Editing mode.
     *
     * - `'html'`     — WYSIWYG editing (default)
     * - `'markdown'` — Markdown source editing with live preview
     */
    mode = input("html", ...(ngDevMode ? [{ debugName: "mode" }] : []));
    /** Whether the editor is disabled (non-interactive). */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    /**
     * Presentation style of the editor chrome.
     *
     * - `'default'` — full editor chrome with the standard toolbar.
     * - `'compact'` — chat-style editor with a minimal floating toolbar.
     */
    presentation = input("default", ...(ngDevMode ? [{ debugName: "presentation" }] : []));
    /** Whether the editor is read-only (content visible but not editable). */
    readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : []));
    /**
     * Accessible label forwarded to the editable region via
     * `aria-label`.
     */
    ariaLabel = input("Rich text editor", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Placeholder text shown when the editor is empty.
     */
    placeholder = input("Type here…", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /**
     * Which formatting actions to show in the toolbar.
     * Defaults to {@link DEFAULT_TOOLBAR_ACTIONS}.
     */
    toolbarActions = input(DEFAULT_TOOLBAR_ACTIONS, ...(ngDevMode ? [{ debugName: "toolbarActions" }] : []));
    /**
     * Optional compact-mode toolbar actions.
     *
     * When omitted, compact presentation falls back to the built-in
     * minimal toolbar set.
     */
    compactToolbarActions = input(undefined, ...(ngDevMode ? [{ debugName: "compactToolbarActions" }] : []));
    /**
     * Available placeholder definitions.
     * When non-empty a placeholder picker appears in the toolbar.
     */
    placeholders = input([], ...(ngDevMode ? [{ debugName: "placeholders" }] : []));
    /**
     * Sample context data used to derive the placeholder picker's shape.
     *
     * When provided, the picker shows object keys and array item fields from
     * this value instead of requiring a flat placeholder list. Array item fields
     * are displayed with their collection path, e.g. `lines[].description`.
     */
    placeholderContext = input(undefined, ...(ngDevMode ? [{ debugName: "placeholderContext" }] : []));
    /**
     * Layout of the markdown editor + preview split pane.
     * Only meaningful when `mode === 'markdown'`.
     *
     * - `'vertical'`   — textarea above, preview below (default).
     * - `'horizontal'` — textarea left, preview right (side-by-side).
     */
    splitDirection = input("vertical", ...(ngDevMode ? [{ debugName: "splitDirection" }] : []));
    /**
     * Whether to sanitise HTML content before rendering.
     *
     * When `true` (default) the editor strips dangerous elements
     * (`<script>`, `<iframe>`, etc.), `on*` event handlers,
     * `javascript:` URIs, and `style` attributes from all content
     * — whether pasted, set via `value()`, or typed in source mode.
     *
     * Set to `false` to allow arbitrary HTML. **Only disable this
     * for trusted users/roles** (e.g. developers crafting
     * bookmarklets or embed snippets).
     *
     * @default true
     */
    sanitise = input(true, ...(ngDevMode ? [{ debugName: "sanitise" }] : []));
    /**
     * Optional maximum character count.  When set, a character
     * counter is shown below the editor.  The count is based on
     * the plain-text length of the content (HTML tags and Markdown
     * syntax are excluded).
     *
     * A value of `0` or `undefined` disables the limit.
     */
    maxLength = input(undefined, ...(ngDevMode ? [{ debugName: "maxLength" }] : []));
    /**
     * Optional callback for handling pasted images.
     *
     * When provided, the function receives the pasted image `File`
     * and should return a `Promise<string>` resolving to a URL.
     * The URL is then inserted as an `<img>` (HTML mode) or
     * `![image](url)` (Markdown mode).
     *
     * When not provided, pasted images are embedded inline as
     * base64 `data:` URIs.
     *
     * @example
     * ```html
     * <ui-rich-text-editor [imageHandler]="uploadToS3" />
     * ```
     */
    imageHandler = input(undefined, ...(ngDevMode ? [{ debugName: "imageHandler" }] : []));
    /**
     * Optional custom emoji categories for the inline emoji
     * picker.  When not provided the picker uses the default
     * comprehensive emoji set.
     */
    emojiCategories = input([], ...(ngDevMode ? [{ debugName: "emojiCategories" }] : []));
    // ── Two-way value ──────────────────────────────────────────
    /**
     * Content of the editor.  Two-way bindable via `[(value)]`.
     *
     * In HTML mode this is an HTML string.  In Markdown mode this
     * is a Markdown string.  Placeholder chips are serialised as
     * self-closing XML template blocks in both modes.
     */
    value = model("", ...(ngDevMode ? [{ debugName: "value" }] : []));
    // ── Outputs ────────────────────────────────────────────────
    /** Fired when a template block is inserted. */
    blockInserted = output();
    /** Fired when an existing template block is edited. */
    blockEdited = output();
    /** Fired when a template block is removed. */
    blockRemoved = output();
    // ── Strategy ───────────────────────────────────────────────
    /**
     * The active editing strategy, derived from the `mode` input.
     * @internal
     */
    strategy = computed(() => {
        const m = this.mode();
        if (m === "markdown") {
            return new MarkdownEditingStrategy(this.markdownParser);
        }
        return new HtmlEditingStrategy();
    }, ...(ngDevMode ? [{ debugName: "strategy" }] : []));
    // ── Internal state ─────────────────────────────────────────
    /** Whether the placeholder picker dropdown is open. */
    isPlaceholderPickerOpen = signal(false, ...(ngDevMode ? [{ debugName: "isPlaceholderPickerOpen" }] : []));
    /** Whether the table size picker dropdown is open. */
    isTablePickerOpen = signal(false, ...(ngDevMode ? [{ debugName: "isTablePickerOpen" }] : []));
    /** Rows currently highlighted in the table size picker. */
    tablePickerRows = signal(2, ...(ngDevMode ? [{ debugName: "tablePickerRows" }] : []));
    /** Columns currently highlighted in the table size picker. */
    tablePickerCols = signal(3, ...(ngDevMode ? [{ debugName: "tablePickerCols" }] : []));
    /** @internal Whether the compact floating toolbar is collapsed. */
    isCompactToolbarCollapsed = signal(false, ...(ngDevMode ? [{ debugName: "isCompactToolbarCollapsed" }] : []));
    /** Search term for filtering the placeholder picker. */
    placeholderSearchTerm = signal("", ...(ngDevMode ? [{ debugName: "placeholderSearchTerm" }] : []));
    /** Whether the editor area is currently focused. */
    isFocused = signal(false, ...(ngDevMode ? [{ debugName: "isFocused" }] : []));
    /** Whether the editor is in raw source editing mode. */
    isSourceMode = signal(false, ...(ngDevMode ? [{ debugName: "isSourceMode" }] : []));
    /**
     * Whether the Markdown preview pane is visible.
     * Toggled by the preview toolbar button in Markdown mode.
     */
    showMarkdownPreview = signal(true, ...(ngDevMode ? [{ debugName: "showMarkdownPreview" }] : []));
    /** @internal Row choices shown by the table picker. */
    tablePickerRowOptions = [1, 2, 3, 4, 5, 6];
    /** @internal Column choices shown by the table picker. */
    tablePickerColumnOptions = [1, 2, 3, 4, 5, 6];
    /** @internal True when the editor uses compact chat-style chrome. */
    isCompactPresentation = computed(() => this.presentation() === "compact", ...(ngDevMode ? [{ debugName: "isCompactPresentation" }] : []));
    /**
     * Pre-rendered HTML for the Markdown preview pane.
     *
     * Runs `deserialiseContent` via the active strategy so that
     * placeholder tokens are expanded into chip elements before
     * the content reaches `<ui-rich-text-view>`.
     *
     * @internal
     */
    markdownPreviewHtml = computed(() => {
        const strat = this.strategy();
        const md = this.value();
        const ctx = {
            editorEl: null,
            hostEl: this.elRef.nativeElement,
            placeholders: this.placeholders(),
            sanitise: this.sanitise(),
            restoreFocus: () => { },
        };
        return strat.deserialiseContent(md, ctx);
    }, ...(ngDevMode ? [{ debugName: "markdownPreviewHtml" }] : []));
    /** @internal Effective toolbar actions after applying presentation defaults. */
    effectiveToolbarActions = computed(() => this.isCompactPresentation()
        ? (this.compactToolbarActions() ??
            UIRichTextEditor.COMPACT_TOOLBAR_ACTIONS)
        : this.toolbarActions(), ...(ngDevMode ? [{ debugName: "effectiveToolbarActions" }] : []));
    /** @internal Toolbar display mode for the current presentation. */
    toolbarDisplayMode = computed(() => this.isCompactPresentation() ? "floating-toggle" : "inline", ...(ngDevMode ? [{ debugName: "toolbarDisplayMode" }] : []));
    /**
     * Whether the current value is valid (non-empty) Markdown.
     * Used to show a validity indicator in the Markdown toolbar.
     * @internal
     */
    isValidMarkdown = computed(() => {
        if (!this.isMarkdownMode())
            return true;
        return this.value().trim().length > 0;
    }, ...(ngDevMode ? [{ debugName: "isValidMarkdown" }] : []));
    /** Whether the emoji picker dropdown is open. */
    isEmojiPickerOpen = signal(false, ...(ngDevMode ? [{ debugName: "isEmojiPickerOpen" }] : []));
    /** Whether the editor is in full-screen (full-window) mode. */
    isFullscreen = signal(false, ...(ngDevMode ? [{ debugName: "isFullscreen" }] : []));
    /**
     * Internal override for the split-pane direction, set by the toolbar
     * toggle button.  Takes precedence over the `splitDirection` input.
     * @internal
     */
    _splitDirectionOverride = signal(null, ...(ngDevMode ? [{ debugName: "_splitDirectionOverride" }] : []));
    /**
     * The effective split-pane direction — the internal override if set,
     * otherwise the `splitDirection` input value.
     * @internal
     */
    effectiveSplitDirection = computed(() => this._splitDirectionOverride() ?? this.splitDirection(), ...(ngDevMode ? [{ debugName: "effectiveSplitDirection" }] : []));
    /** SVG content for the source-toggle toolbar button. @internal */
    sourceIcon = UIIcons.Lucide.Development.CodeXml;
    /** SVG content for the emoji toolbar button. @internal */
    emojiIcon = UIIcons.Lucide.Emoji.Smile;
    /** @internal Icon registry for the rich-text toolbar. */
    teIcons = {
        Undo: UIIcons.Lucide.Arrows.Undo2,
        Redo: UIIcons.Lucide.Arrows.Redo2,
        Bold: UIIcons.Lucide.Text.Bold,
        Italic: UIIcons.Lucide.Text.Italic,
        Underline: UIIcons.Lucide.Text.Underline,
        Strikethrough: UIIcons.Lucide.Text.Strikethrough,
        Styles: UIIcons.Lucide.Text.Pilcrow,
        List: UIIcons.Lucide.Text.List,
        AlignLeft: UIIcons.Lucide.Text.TextAlignStart,
        AlignCenter: UIIcons.Lucide.Text.TextAlignCenter,
        AlignRight: UIIcons.Lucide.Text.TextAlignEnd,
        AlignJustify: UIIcons.Lucide.Text.TextAlignJustify,
        HorizontalRule: UIIcons.Lucide.Development.Minus,
        Table: UIIcons.Lucide.Files.Table,
        RowBefore: UIIcons.Lucide.Layout.BetweenHorizontalStart,
        RowAfter: UIIcons.Lucide.Layout.BetweenHorizontalEnd,
        ColumnBefore: UIIcons.Lucide.Layout.BetweenVerticalStart,
        ColumnAfter: UIIcons.Lucide.Layout.BetweenVerticalEnd,
        LoopRows: UIIcons.Lucide.Files.TableRowsSplit,
        Image: UIIcons.Lucide.Files.ImagePlus,
        Link: UIIcons.Lucide.Text.Link,
        RemoveFormat: UIIcons.Lucide.Text.RemoveFormatting,
        Fullscreen: UIIcons.Lucide.Layout.Maximize2,
        ExitFullscreen: UIIcons.Lucide.Layout.Minimize2,
        SplitHorizontal: UIIcons.Lucide.Layout.Columns2,
        SplitVertical: UIIcons.Lucide.Layout.Rows2,
        PreviewShow: UIIcons.Lucide.Accessibility.Eye,
        PreviewHide: UIIcons.Lucide.Accessibility.EyeOff,
        ValidMarkdown: UIIcons.Lucide.Notifications.CircleCheck,
        InvalidMarkdown: UIIcons.Lucide.Notifications.CircleAlert,
    };
    /**
     * Whether the editor is in Markdown mode.  In this mode the
     * textarea is always visible as the primary editing surface.
     * @internal
     */
    isMarkdownMode = computed(() => this.mode() === "markdown", ...(ngDevMode ? [{ debugName: "isMarkdownMode" }] : []));
    /**
     * Current character count of the editor content, computed
     * from the plain-text representation (strips HTML/Markdown
     * syntax).
     * @internal
     */
    charCount = computed(() => {
        const raw = this.value();
        if (!raw)
            return 0;
        if (this.isMarkdownMode()) {
            // Strip Markdown syntax: headers, bold, italic, links, images, code
            return raw
                .replace(/[#*_`~[\]()!>|-]/g, "")
                .replace(/\n+/g, " ")
                .trim().length;
        }
        // Strip HTML tags and decode entities
        const tmp = document.createElement("div");
        tmp.innerHTML = raw;
        return (tmp.textContent ?? "").replace(/\u200b/g, "").trim().length;
    }, ...(ngDevMode ? [{ debugName: "charCount" }] : []));
    /**
     * Whether the character count exceeds the max length.
     * @internal
     */
    isOverMaxLength = computed(() => {
        const max = this.maxLength();
        return max != null && max > 0 && this.charCount() > max;
    }, ...(ngDevMode ? [{ debugName: "isOverMaxLength" }] : []));
    /**
     * Saved selection range captured when the link dialog opens,
     * so we can restore it when applying the link.
     * @internal
     */
    savedRange = null;
    /** Last selection range captured inside the editable document. */
    lastEditorRange = null;
    /** Last table cell that contained the editor caret. */
    lastActiveTableCell = null;
    /** @internal Triggers context recomputation when the caret moves. */
    selectionContextRevision = signal(0, ...(ngDevMode ? [{ debugName: "selectionContextRevision" }] : []));
    /**
     * Set of formatting actions currently active at the caret
     * position.  Updated on every selection change, keypress,
     * and formatting command.
     *
     * @internal
     */
    activeFormats = signal(new Set(), ...(ngDevMode ? [{ debugName: "activeFormats" }] : []));
    /** @internal Whether the editor is non-interactive (disabled or readonly). */
    isEditorDisabled = computed(() => this.disabled() || this.readonly(), ...(ngDevMode ? [{ debugName: "isEditorDisabled" }] : []));
    /** @internal Dropdown items for the block-styles dropdown. */
    blockDropdownItems = computed(() => {
        const actions = this.effectiveToolbarActions();
        return [
            "paragraph",
            "heading1",
            "heading2",
            "heading3",
            "blockquote",
            "codeBlock",
        ]
            .filter((a) => actions.includes(a))
            .map((a) => ({
            id: a,
            label: TOOLBAR_BUTTON_REGISTRY[a].label,
            icon: TOOLBAR_BUTTON_REGISTRY[a].icon,
        }));
    }, ...(ngDevMode ? [{ debugName: "blockDropdownItems" }] : []));
    /** @internal Dropdown items for the lists dropdown. */
    listDropdownItems = computed(() => {
        const actions = this.effectiveToolbarActions();
        return [
            "unorderedList",
            "orderedList",
            "indent",
            "outdent",
        ]
            .filter((a) => actions.includes(a))
            .map((a) => ({
            id: a,
            label: TOOLBAR_BUTTON_REGISTRY[a].label,
            icon: TOOLBAR_BUTTON_REGISTRY[a].icon,
        }));
    }, ...(ngDevMode ? [{ debugName: "listDropdownItems" }] : []));
    /** @internal Dropdown items for contextual table editing. */
    tableDropdownItems = computed(() => {
        if (!this.canEditActiveTable())
            return [];
        return [
            "insertTableRowBefore",
            "insertTableRowAfter",
            "insertTableColumnBefore",
            "insertTableColumnAfter",
            "wrapRowsLoop",
        ].map((a) => ({
            id: a,
            label: TOOLBAR_BUTTON_REGISTRY[a].label,
            icon: TOOLBAR_BUTTON_REGISTRY[a].icon,
        }));
    }, ...(ngDevMode ? [{ debugName: "tableDropdownItems" }] : []));
    /** @internal True when at least one history action is in the toolbar. */
    showHistoryGroup = computed(() => this.effectiveToolbarActions().some((a) => a === "undo" || a === "redo"), ...(ngDevMode ? [{ debugName: "showHistoryGroup" }] : []));
    /** @internal True when at least one inline-format action is in the toolbar. */
    showInlineGroup = computed(() => this.effectiveToolbarActions().some((a) => a === "bold" ||
        a === "italic" ||
        a === "underline" ||
        a === "strikethrough"), ...(ngDevMode ? [{ debugName: "showInlineGroup" }] : []));
    /** @internal True when at least one alignment action is in the toolbar. */
    showAlignGroup = computed(() => this.effectiveToolbarActions().some((a) => a === "alignLeft" ||
        a === "alignCenter" ||
        a === "alignRight" ||
        a === "alignJustify"), ...(ngDevMode ? [{ debugName: "showAlignGroup" }] : []));
    /** @internal True when at least one insert action is in the toolbar. */
    showInsertGroup = computed(() => this.effectiveToolbarActions().some((a) => a === "horizontalRule" ||
        a === "insertTable" ||
        a === "insertTableRowBefore" ||
        a === "insertTableRowAfter" ||
        a === "insertTableColumnBefore" ||
        a === "insertTableColumnAfter" ||
        a === "wrapRowsLoop" ||
        a === "image"), ...(ngDevMode ? [{ debugName: "showInsertGroup" }] : []));
    /** @internal Human-readable dimensions for the table picker. */
    tablePickerSizeLabel = computed(() => `${this.tablePickerCols()} columns, ${this.tablePickerRows()} rows`, ...(ngDevMode ? [{ debugName: "tablePickerSizeLabel" }] : []));
    /** @internal The active table cell under the saved editor caret. */
    activeTableCell = computed(() => {
        this.selectionContextRevision();
        return this.getActiveTableCell();
    }, ...(ngDevMode ? [{ debugName: "activeTableCell" }] : []));
    /** @internal Whether contextual table editing commands can run. */
    canEditActiveTable = computed(() => !this.isMarkdownMode() &&
        !this.isSourceMode() &&
        this.activeTableCell() !== null, ...(ngDevMode ? [{ debugName: "canEditActiveTable" }] : []));
    /** Resolved toolbar button metadata from the actions list. */
    toolbarButtons = computed(() => this.effectiveToolbarActions()
        .map((a) => TOOLBAR_BUTTON_REGISTRY[a])
        .filter(Boolean), ...(ngDevMode ? [{ debugName: "toolbarButtons" }] : []));
    /**
     * Actions that are hidden in Markdown mode because they have
     * no meaningful effect on plain-text Markdown.
     * @internal
     */
    static MARKDOWN_HIDDEN_GROUPS = new Set(["align"]);
    /**
     * Grouped toolbar buttons for rendering separators between
     * groups.
     *
     * In Markdown mode the `align` group is excluded because
     * text alignment is not supported in Markdown.
     *
     * @internal
     */
    groupedToolbarButtons = computed(() => {
        const buttons = this.toolbarButtons();
        const isMarkdown = this.isMarkdownMode();
        const groups = [];
        let currentGroup = "";
        for (const btn of buttons) {
            const g = btn.group ?? "";
            if (isMarkdown && UIRichTextEditor.MARKDOWN_HIDDEN_GROUPS.has(g)) {
                continue;
            }
            if (g !== currentGroup) {
                currentGroup = g;
                const isFlat = FLAT_TOOLBAR_GROUPS.has(g);
                groups.push({
                    group: g,
                    buttons: [],
                    flat: isFlat,
                    meta: isFlat ? null : (TOOLBAR_GROUP_META[g] ?? null),
                });
            }
            groups[groups.length - 1].buttons.push(btn);
        }
        return groups;
    }, ...(ngDevMode ? [{ debugName: "groupedToolbarButtons" }] : []));
    /**
     * Placeholder categories for the picker dropdown, filtered
     * by the current search term.
     *
     * @internal
     */
    placeholderPickerGroups = computed(() => {
        const context = this.placeholderContext();
        if (context !== undefined && context !== null) {
            return this.buildPlaceholderGroupsFromContext(context);
        }
        const ph = this.placeholders();
        if (!ph.length)
            return [];
        const term = this.placeholderSearchTerm().toLowerCase().trim();
        const filtered = term
            ? ph.filter((p) => p.label.toLowerCase().includes(term) ||
                p.key.toLowerCase().includes(term))
            : ph;
        if (!filtered.length)
            return [];
        const catMap = new Map();
        for (const p of filtered) {
            const cat = p.category ?? "";
            if (!catMap.has(cat))
                catMap.set(cat, []);
            catMap.get(cat).push({
                ...p,
                id: p.key,
                path: p.key,
                depth: 0,
                isGroup: false,
                showPath: false,
                searchText: `${p.label} ${p.key} ${p.category ?? ""}`.toLowerCase(),
            });
        }
        return Array.from(catMap.entries()).map(([category, items]) => ({
            category,
            items,
        }));
    }, ...(ngDevMode ? [{ debugName: "placeholderPickerGroups" }] : []));
    /**
     * Whether the placeholder picker has any source data to show.
     *
     * @internal
     */
    hasPlaceholderPickerItems = computed(() => {
        const context = this.placeholderContext();
        if (context !== undefined && context !== null) {
            return this.buildScopedPlaceholderItemsFromContext(context).length > 0;
        }
        return this.placeholders().length > 0;
    }, ...(ngDevMode ? [{ debugName: "hasPlaceholderPickerItems" }] : []));
    /**
     * Whether the unified template insert picker has anything to show.
     *
     * @internal
     */
    hasTemplateInsertItems() {
        return (this.hasPlaceholderPickerItems() ||
            this.templateBlockProviderItems().length > 0);
    }
    /**
     * Insertable template block providers for the toolbar dropdown.
     *
     * @internal
     */
    templateBlockDropdownItems() {
        const placeholderItems = this.templateBlockPlaceholderItems().map((item) => ({
            id: `${UIRichTextEditor.TEMPLATE_PLACEHOLDER_ITEM_PREFIX}${item.id}`,
            label: `Placeholder: ${item.showPath ? item.path : item.label}`,
            icon: UIIcons.Lucide.Development.CodeXml,
        }));
        const uiProviders = getRichTextTemplateBlockUiProviders();
        const providerItems = uiProviders
            .filter((provider) => provider.name !== "placeholder")
            .map((provider) => ({
            id: provider.name,
            label: provider.label,
            icon: provider.display === "block"
                ? UIIcons.Lucide.Layout.PanelTop
                : UIIcons.Lucide.Development.CodeXml,
        }));
        const uiProviderNames = new Set(uiProviders.map((provider) => provider.name));
        const genericProviderItems = getRegisteredTextTemplateBlockProviders()
            .filter((provider) => provider.name !== "placeholder" &&
            !uiProviderNames.has(provider.name) &&
            !RICH_CONTENT_BLOCK_NAMES.has(provider.name))
            .map((provider) => ({
            id: provider.name,
            label: this.humanizeTemplateBlockName(provider.name),
            icon: provider.contentModel === "container"
                ? UIIcons.Lucide.Layout.PanelTop
                : UIIcons.Lucide.Development.CodeXml,
        }));
        return [...placeholderItems, ...providerItems, ...genericProviderItems];
    }
    /**
     * Insertable non-placeholder template blocks for the unified picker.
     *
     * @internal
     */
    templateBlockProviderItems() {
        return this.templateBlockDropdownItems().filter((item) => !item.id.startsWith(UIRichTextEditor.TEMPLATE_PLACEHOLDER_ITEM_PREFIX));
    }
    /**
     * Placeholder leaves exposed in the unified XML block dropdown.
     *
     * @internal
     */
    templateBlockPlaceholderItems = computed(() => {
        const context = this.placeholderContext();
        if (context !== undefined && context !== null) {
            return this.buildScopedPlaceholderItemsFromContext(context).filter((item) => !item.isGroup);
        }
        return this.buildPlaceholderItemsFromPlaceholders(this.placeholders());
    }, ...(ngDevMode ? [{ debugName: "templateBlockPlaceholderItems" }] : []));
    /**
     * The source-toggle button label, from the active strategy.
     * @internal
     */
    sourceToggleLabel = computed(() => this.strategy().sourceToggleLabel, ...(ngDevMode ? [{ debugName: "sourceToggleLabel" }] : []));
    /** Tracks whether init has happened to avoid premature reads. */
    initialised = false;
    /**
     * The last value that was synced to/from the editor,
     * used to distinguish internal edits from external
     * model changes and avoid feedback loops.
     */
    lastSyncedValue = "";
    /**
     * Watches the `value` model signal and re-renders the
     * editor whenever the value changes externally (i.e. not
     * from the editor itself).
     */
    valueChangeEffect = effect(() => {
        const val = this.value();
        if (this.initialised && val !== this.lastSyncedValue) {
            untracked(() => {
                this.lastSyncedValue = val;
                this.renderToEditor(val);
            });
        }
    }, ...(ngDevMode ? [{ debugName: "valueChangeEffect" }] : []));
    /**
     * Watches the `strategy` computed (derived from `mode`) and
     * re-renders the editor content whenever the mode changes.
     * Also resets transient UI state that is mode-specific.
     */
    modeChangeEffect = effect(() => {
        // Track the strategy signal — it changes when mode() changes
        this.strategy();
        if (!this.initialised)
            return;
        untracked(() => {
            this.isSourceMode.set(false);
            this.isPlaceholderPickerOpen.set(false);
            this.isTablePickerOpen.set(false);
            this.isEmojiPickerOpen.set(false);
            this.activeFormats.set(new Set());
            this.renderToEditor(this.value());
        });
    }, ...(ngDevMode ? [{ debugName: "modeChangeEffect" }] : []));
    /** Resets compact-only UI state when presentation or mode changes. */
    compactPresentationEffect = effect(() => {
        const isCompact = this.isCompactPresentation();
        const isMarkdown = this.isMarkdownMode();
        untracked(() => {
            this.isCompactToolbarCollapsed.set(isCompact);
            this.showMarkdownPreview.set(!(isCompact && isMarkdown));
        });
    }, ...(ngDevMode ? [{ debugName: "compactPresentationEffect" }] : []));
    // ── Lifecycle ──────────────────────────────────────────────
    ngOnInit() {
        const onSelectionChange = () => {
            this.captureEditorSelectionFromWindow();
            if (this.isFocused()) {
                this.doRefreshActiveFormats();
            }
        };
        document.addEventListener("selectionchange", onSelectionChange);
        this.destroyRef.onDestroy(() => {
            document.removeEventListener("selectionchange", onSelectionChange);
        });
        // Close toolbar pickers on outside click
        const onDocumentClick = (event) => {
            if (!this.isPlaceholderPickerOpen() &&
                !this.isTablePickerOpen() &&
                !this.isEmojiPickerOpen()) {
                return;
            }
            const target = event.target;
            const host = this.elRef.nativeElement;
            if (!host.contains(target)) {
                this.isPlaceholderPickerOpen.set(false);
                this.isTablePickerOpen.set(false);
                this.isEmojiPickerOpen.set(false);
                return;
            }
            const inDropdown = target.closest(".placeholder-picker, .table-picker-wrapper, .emoji-picker-wrapper");
            if (!inDropdown) {
                this.isPlaceholderPickerOpen.set(false);
                this.isTablePickerOpen.set(false);
                this.isEmojiPickerOpen.set(false);
            }
        };
        document.addEventListener("click", onDocumentClick, true);
        this.destroyRef.onDestroy(() => {
            document.removeEventListener("click", onDocumentClick, true);
        });
    }
    ngAfterViewInit() {
        const val = this.value();
        this.lastSyncedValue = val;
        this.renderToEditor(val);
        this.initialised = true;
        // Exit full-screen when Escape is pressed anywhere in the document
        const onEscape = (e) => {
            if (e.key === "Escape" && this.isFullscreen()) {
                this.isFullscreen.set(false);
            }
        };
        document.addEventListener("keydown", onEscape, { capture: true });
        this.destroyRef.onDestroy(() => document.removeEventListener("keydown", onEscape, { capture: true }));
    }
    // ── Context factory ────────────────────────────────────────
    /**
     * Builds the {@link RichTextEditorContext} for strategy methods.
     * @internal
     */
    buildContext() {
        return {
            editorEl: this.editorRef().nativeElement,
            hostEl: this.elRef.nativeElement,
            placeholders: this.placeholders(),
            sanitise: this.sanitise(),
            restoreFocus: () => this.restoreFocus(),
        };
    }
    // ── Formatting commands ────────────────────────────────────
    /**
     * Executes a formatting action.
     *
     * @internal
     */
    /** @internal Routes toolbar tool-action events to the appropriate handler. */
    onToolAction(event) {
        const id = event.itemId;
        if (id === "source-mode") {
            this.toggleSourceMode();
            return;
        }
        if (id === "fullscreen") {
            this.toggleFullscreen();
            return;
        }
        if (id === "split-direction") {
            this.cycleSplitDirection();
            return;
        }
        if (id === "toggle-preview") {
            this.showMarkdownPreview.update((v) => !v);
            return;
        }
        if (id === "template-block") {
            const tool = event.itemRef;
            const blockName = tool.selectedItemId();
            if (blockName) {
                if (blockName.startsWith(UIRichTextEditor.TEMPLATE_PLACEHOLDER_ITEM_PREFIX)) {
                    const placeholderId = blockName.slice(UIRichTextEditor.TEMPLATE_PLACEHOLDER_ITEM_PREFIX.length);
                    const placeholder = this.templateBlockPlaceholderItems().find((item) => item.id === placeholderId);
                    if (placeholder)
                        this.insertPlaceholder(placeholder);
                    return;
                }
                this.openTemplateBlockDialog(blockName, event.event?.target);
            }
            return;
        }
        if (id === "block" || id === "list" || id === "table") {
            const tool = event.itemRef;
            const actionId = tool.selectedItemId();
            if (actionId) {
                this.execAction(actionId, event.event?.target);
            }
            return;
        }
        this.execAction(id, event.event?.target);
    }
    /** @internal Returns true when the given action is in the toolbar. */
    hasToolbarAction(action) {
        return this.effectiveToolbarActions().includes(action);
    }
    /** @internal Syncs the compact floating toolbar collapsed state. */
    onToolbarCollapsedChange(value) {
        this.isCompactToolbarCollapsed.set(value);
    }
    execAction(action, anchorEl) {
        if (this.disabled() || this.readonly())
            return;
        // In HTML mode, restore focus to the contenteditable element
        // before executing the action.  In Markdown mode the textarea
        // handles its own focus.
        if (!this.isMarkdownMode()) {
            const savedRange = this.lastEditorRange?.cloneRange() ?? null;
            this.restoreFocus();
            this.restoreLastEditorSelection(savedRange);
        }
        const ctx = this.buildContext();
        const strat = this.strategy();
        if (action === "link") {
            this.openLinkDialog(anchorEl ?? null);
            return;
        }
        if (action === "image") {
            this.openImageDialog(anchorEl ?? null);
            return;
        }
        if (action === "insertTable") {
            this.insertTable();
            return;
        }
        if (action === "insertTableRowBefore") {
            this.insertTableRowAtCursor("before");
            return;
        }
        if (action === "insertTableRowAfter") {
            this.insertTableRowAtCursor("after");
            return;
        }
        if (action === "insertTableColumnBefore") {
            this.insertTableColumnAtCursor("before");
            return;
        }
        if (action === "insertTableColumnAfter") {
            this.insertTableColumnAtCursor("after");
            return;
        }
        if (action === "wrapRowsLoop") {
            this.openWrapTableRowsLoopDialog(anchorEl ?? null);
            return;
        }
        const handled = strat.execAction(action, ctx);
        if (handled) {
            this.syncValueFromEditor();
            this.doRefreshActiveFormats();
        }
    }
    // ── Placeholder insertion ──────────────────────────────────
    /**
     * Inserts a placeholder at the current caret position.
     *
     * In HTML mode this inserts a chip DOM element.
     * In Markdown mode this inserts a self-closing XML block string.
     *
     * @internal
     */
    insertPlaceholder(placeholder) {
        if (this.disabled() || this.readonly())
            return;
        const insertedPlaceholder = {
            key: placeholder.key,
            label: placeholder.label,
            ...(placeholder.category ? { category: placeholder.category } : {}),
        };
        if (this.isMarkdownMode()) {
            this.insertPlaceholderMarkdown(insertedPlaceholder);
        }
        else {
            this.insertPlaceholderHtml(insertedPlaceholder);
        }
        this.isPlaceholderPickerOpen.set(false);
        this.blockInserted.emit({
            name: "placeholder",
            attributes: { key: insertedPlaceholder.key },
        });
    }
    /**
     * Inserts a placeholder chip into the contenteditable editor
     * (HTML mode).
     * @internal
     */
    insertPlaceholderHtml(placeholder) {
        this.restoreFocus();
        this.restoreLastEditorSelection();
        const strat = this.strategy();
        const chip = strat.createPlaceholderChip(placeholder);
        const before = this.createTemplateBlockCaretEdge("before", "block");
        const after = this.createTemplateBlockCaretEdge("after");
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
            this.insertNodesAtSelection([before, chip, after]);
        }
        else {
            this.editorRef().nativeElement.append(before, chip, after);
        }
        this.syncValueFromEditor();
    }
    /**
     * Inserts a self-closing placeholder block into the Markdown
     * textarea.
     * @internal
     */
    insertPlaceholderMarkdown(placeholder) {
        const strat = this.strategy();
        if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
            const textarea = strat.textareaEl;
            const token = `<placeholder key="${this.escapeXmlAttribute(placeholder.key)}" />`;
            const { selectionStart, selectionEnd, value } = textarea;
            textarea.value =
                value.substring(0, selectionStart) +
                    token +
                    value.substring(selectionEnd);
            textarea.selectionStart = selectionStart + token.length;
            textarea.selectionEnd = selectionStart + token.length;
            textarea.focus();
            textarea.dispatchEvent(new Event("input", { bubbles: true }));
        }
        this.syncValueFromEditor();
    }
    /** @internal */
    buildPlaceholderGroupsFromContext(context) {
        const items = this.buildScopedPlaceholderItemsFromContext(context);
        const term = this.placeholderSearchTerm().toLowerCase().trim();
        const filtered = term
            ? items.filter((item) => item.searchText.includes(term))
            : items;
        return filtered.length ? [{ category: "Context", items: filtered }] : [];
    }
    /** @internal */
    buildScopedPlaceholderItemsFromContext(context) {
        this.selectionContextRevision();
        const rootItems = this.buildPlaceholderItemsFromContext(context, {
            depth: 0,
            pathPrefix: "",
            keyPrefix: "",
            insideArray: false,
            includeArrayChildren: false,
        });
        const loopItemsKey = this.getActiveLoopItemsKey();
        if (!loopItemsKey || !this.isInspectableObject(context))
            return rootItems;
        const loopItems = context[loopItemsKey];
        if (!Array.isArray(loopItems))
            return rootItems;
        const sample = loopItems.find((item) => item !== null && item !== undefined);
        if (!this.isInspectableObject(sample))
            return rootItems;
        const localItems = this.buildPlaceholderItemsFromContext(sample, {
            depth: 0,
            pathPrefix: `${loopItemsKey}[]`,
            keyPrefix: "",
            insideArray: true,
            includeArrayChildren: false,
        })
            .filter((item) => !item.isGroup)
            .map((item) => ({
            ...item,
            path: item.key,
            showPath: false,
            searchText: `${item.searchText} ${loopItemsKey}[].${item.key}`.toLowerCase(),
        }));
        return [...localItems, ...rootItems];
    }
    /** @internal */
    buildPlaceholderItemsFromPlaceholders(placeholders) {
        return placeholders.map((placeholder) => ({
            ...placeholder,
            id: placeholder.key,
            path: placeholder.key,
            depth: 0,
            isGroup: false,
            showPath: false,
            searchText: `${placeholder.label} ${placeholder.key} ${placeholder.category ?? ""}`.toLowerCase(),
        }));
    }
    /** @internal */
    buildPlaceholderItemsFromContext(value, options) {
        if (!this.isInspectableObject(value))
            return [];
        const items = [];
        for (const [key, child] of Object.entries(value)) {
            const path = options.pathPrefix ? `${options.pathPrefix}.${key}` : key;
            const insertionKey = options.insideArray
                ? key
                : options.keyPrefix
                    ? `${options.keyPrefix}.${key}`
                    : key;
            if (Array.isArray(child)) {
                items.push(...this.buildPlaceholderItemsFromArray(child, {
                    depth: options.depth,
                    key,
                    path,
                    includeChildren: options.includeArrayChildren,
                }));
                continue;
            }
            if (this.isInspectableObject(child)) {
                items.push({
                    key: insertionKey,
                    label: key,
                    id: `group:${path}`,
                    path,
                    depth: options.depth,
                    isGroup: true,
                    showPath: path !== key,
                    searchText: `${key} ${path}`.toLowerCase(),
                });
                items.push(...this.buildPlaceholderItemsFromContext(child, {
                    depth: options.depth + 1,
                    pathPrefix: path,
                    keyPrefix: insertionKey,
                    insideArray: options.insideArray,
                    includeArrayChildren: options.includeArrayChildren,
                }));
                continue;
            }
            items.push({
                key: insertionKey,
                label: key,
                id: `leaf:${path}`,
                path,
                depth: options.depth,
                isGroup: false,
                showPath: path !== key,
                searchText: `${key} ${path} ${insertionKey}`.toLowerCase(),
            });
        }
        return items;
    }
    /** @internal */
    buildPlaceholderItemsFromArray(value, options) {
        const arrayPath = `${options.path}[]`;
        const items = [
            {
                key: options.key,
                label: `${options.key}[]`,
                id: `group:${arrayPath}`,
                path: arrayPath,
                depth: options.depth,
                isGroup: true,
                showPath: false,
                searchText: `${options.key} ${arrayPath}`.toLowerCase(),
            },
        ];
        if (!options.includeChildren)
            return items;
        const sample = value.find((item) => item !== null && item !== undefined);
        if (this.isInspectableObject(sample)) {
            items.push(...this.buildPlaceholderItemsFromContext(sample, {
                depth: options.depth + 1,
                pathPrefix: arrayPath,
                keyPrefix: "",
                insideArray: true,
                includeArrayChildren: options.includeChildren,
            }));
        }
        return items;
    }
    /** @internal */
    isInspectableObject(value) {
        return (typeof value === "object" &&
            value !== null &&
            !Array.isArray(value) &&
            !(value instanceof Date));
    }
    /**
     * Opens the generic template-block editor for inserting a block.
     *
     * @internal
     */
    openTemplateBlockDialog(blockName, anchorEl) {
        if (this.disabled() || this.readonly())
            return;
        const provider = this.getTemplateBlockUiProvider(blockName);
        if (!provider)
            return;
        const ref = this.popoverService.openPopover({
            component: UITemplateBlockDialog,
            anchor: anchorEl ?? this.elRef.nativeElement,
            inputs: {
                blockName,
                blockLabel: provider.label,
                initialAttributes: this.defaultTemplateBlockAttributes(provider),
                attributeDefinitions: this.getTemplateBlockAttributeDefinitions(provider),
                editMode: false,
            },
            ariaLabel: `Insert ${provider.label} block`,
            closeOnOutsideClick: false,
        });
        ref.closed.subscribe((result) => {
            if (!result)
                return;
            this.insertTemplateBlock(result, provider);
        });
    }
    /**
     * Inserts a new template block into the active editor.
     *
     * @internal
     */
    insertTemplateBlock(result, provider) {
        const xml = this.buildTemplateBlockXml(result, provider);
        if (this.isMarkdownMode()) {
            const strat = this.strategy();
            if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
                this.insertTextIntoTextarea(strat.textareaEl, xml);
            }
            this.syncValueFromEditor();
            this.blockInserted.emit(this.createTemplateBlockEvent(result));
            return;
        }
        if (this.isSourceMode()) {
            const host = this.elRef.nativeElement;
            const source = host.querySelector(".source-editor");
            if (source) {
                this.insertTextIntoTextarea(source, xml);
            }
            this.blockInserted.emit(this.createTemplateBlockEvent(result));
            return;
        }
        this.restoreFocus();
        this.restoreLastEditorSelection();
        const nodes = this.renderTemplateBlockNodes(xml);
        this.insertNodesAtSelection(nodes);
        this.syncValueFromEditor();
        this.blockInserted.emit(this.createTemplateBlockEvent(result));
    }
    /**
     * Inserts an XML-compatible HTML table at the current caret.
     *
     * @internal
     */
    insertTable(columns = 3, rows = 2) {
        const colCount = Math.max(1, columns);
        const rowCount = Math.max(1, rows);
        const headerCells = Array.from({ length: colCount }, (_, index) => `<th>Column ${index + 1}</th>`).join("");
        const bodyRows = Array.from({ length: rowCount }, () => `<tr>${Array.from({ length: colCount }, () => "<td>Value</td>").join("")}</tr>`).join("");
        const tableXml = [
            "<table>",
            "<thead>",
            `<tr>${headerCells}</tr>`,
            "</thead>",
            "<tbody>",
            bodyRows,
            "</tbody>",
            "</table>",
        ].join("");
        if (this.isMarkdownMode()) {
            const strat = this.strategy();
            if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
                this.insertTextIntoTextarea(strat.textareaEl, tableXml);
            }
            this.syncValueFromEditor();
            return;
        }
        if (this.isSourceMode()) {
            const host = this.elRef.nativeElement;
            const source = host.querySelector(".source-editor");
            if (source)
                this.insertTextIntoTextarea(source, tableXml);
            return;
        }
        this.restoreFocus();
        this.restoreLastEditorSelection();
        const nodes = this.renderTemplateBlockNodes(tableXml);
        this.insertNodesAtSelection(nodes);
        this.syncValueFromEditor();
    }
    /**
     * Inserts a row before or after the current table row.
     *
     * @internal
     */
    insertTableRowAtCursor(position) {
        if (this.isMarkdownMode() || this.isSourceMode())
            return;
        this.restoreLastEditorSelection();
        const cell = this.getActiveTableCell();
        const row = cell?.closest("tr");
        if (!row?.parentElement)
            return;
        const newRow = this.createTableRowLike(row);
        if (position === "before") {
            row.before(newRow);
        }
        else {
            row.after(newRow);
        }
        this.syncValueFromEditor();
        this.doRefreshActiveFormats();
    }
    /**
     * Inserts a column before or after the current table column.
     *
     * @internal
     */
    insertTableColumnAtCursor(position) {
        if (this.isMarkdownMode() || this.isSourceMode())
            return;
        this.restoreLastEditorSelection();
        const cell = this.getActiveTableCell();
        const row = cell?.closest("tr");
        const table = cell?.closest("table");
        if (!cell || !row || !table)
            return;
        const cellIndex = Array.from(row.cells).indexOf(cell);
        if (cellIndex < 0)
            return;
        for (const tableRow of this.getDirectTableRows(table)) {
            if (tableRow.classList.contains("rte-template-block"))
                continue;
            const cells = Array.from(tableRow.cells);
            const tagName = this.getTableCellTagName(tableRow);
            const newCell = this.createTableCell(tagName);
            const insertionIndex = position === "before" ? cellIndex : cellIndex + 1;
            const referenceCell = cells[insertionIndex] ?? null;
            tableRow.insertBefore(newCell, referenceCell);
        }
        this.syncValueFromEditor();
        this.doRefreshActiveFormats();
    }
    /**
     * Opens the loop property sheet and wraps the selected/current table rows.
     *
     * @internal
     */
    openWrapTableRowsLoopDialog(anchorEl) {
        if (this.isMarkdownMode() || this.isSourceMode())
            return;
        this.restoreLastEditorSelection();
        const rows = this.getSelectedWrappableTableRows(anchorEl);
        if (!rows.length)
            return;
        const provider = this.getTemplateBlockUiProvider("loop");
        if (!provider)
            return;
        const ref = this.popoverService.openPopover({
            component: UITemplateBlockDialog,
            anchor: anchorEl ?? this.elRef.nativeElement,
            inputs: {
                blockName: "loop",
                blockLabel: provider.label,
                initialAttributes: this.defaultTemplateBlockAttributes(provider),
                attributeDefinitions: this.getTemplateBlockAttributeDefinitions(provider),
                editMode: false,
            },
            ariaLabel: "Loop table rows",
            closeOnOutsideClick: false,
        });
        ref.closed.subscribe((result) => {
            if (!result)
                return;
            this.wrapTableRowsInTemplateBlock(rows, result, provider);
        });
    }
    /**
     * Handles browser caret edge cases before the native selection settles.
     *
     * @internal
     */
    onEditorMouseDown(event) {
        if (this.disabled() || this.readonly() || this.isMarkdownMode())
            return;
        const target = event.target;
        const clickedTemplateUi = target.closest("[data-template-block], .header");
        if (clickedTemplateUi)
            return;
        const cell = target.closest("td, th");
        if (!cell || !this.editorRef().nativeElement.contains(cell))
            return;
        if (!cell.querySelector("[data-template-block]"))
            return;
        event.preventDefault();
        this.placeCaretAtEndOfTableCell(cell);
    }
    /**
     * Handles clicks on rendered template block chips and headers.
     *
     * @internal
     */
    onEditorClick(event) {
        if (this.disabled() || this.readonly() || this.isMarkdownMode())
            return;
        const target = event.target;
        const selfClosingBlock = target.closest("[data-template-block][data-template-self-closing='true']");
        const header = target.closest(".rte-template-block .header");
        const block = selfClosingBlock ?? header?.closest("[data-template-block]");
        if (!block)
            return;
        event.preventDefault();
        this.openExistingTemplateBlockDialog(block, target);
    }
    /**
     * Opens the generic template-block editor for an existing rendered block.
     *
     * @internal
     */
    openExistingTemplateBlockDialog(block, anchorEl) {
        const blockName = block.dataset["templateBlock"] ?? "";
        const provider = getRichTextTemplateBlockUiProvider(blockName) ??
            this.createGenericTemplateBlockUiProvider(block);
        const ref = this.popoverService.openPopover({
            component: UITemplateBlockDialog,
            anchor: anchorEl,
            inputs: {
                blockName,
                blockLabel: provider.label,
                initialAttributes: this.readTemplateDatasetAttributes(block),
                attributeDefinitions: this.getTemplateBlockAttributeDefinitions(provider),
                editMode: true,
            },
            ariaLabel: `Edit ${provider.label} block`,
            closeOnOutsideClick: false,
        });
        ref.closed.subscribe((result) => {
            if (!result)
                return;
            this.replaceTemplateBlock(block, result, provider);
        });
    }
    /** @internal */
    togglePlaceholderPicker() {
        if (this.disabled() || this.readonly())
            return;
        this.isEmojiPickerOpen.set(false);
        this.isTablePickerOpen.set(false);
        this.isPlaceholderPickerOpen.update((v) => {
            if (v)
                this.placeholderSearchTerm.set("");
            return !v;
        });
    }
    /** @internal */
    closePlaceholderPicker() {
        this.isPlaceholderPickerOpen.set(false);
        this.placeholderSearchTerm.set("");
    }
    /** @internal */
    toggleTablePicker() {
        if (this.disabled() || this.readonly())
            return;
        this.isPlaceholderPickerOpen.set(false);
        this.isEmojiPickerOpen.set(false);
        this.isTablePickerOpen.update((value) => !value);
    }
    /** @internal */
    setTablePickerSize(row, col) {
        this.tablePickerRows.set(row);
        this.tablePickerCols.set(col);
    }
    /** @internal */
    isTablePickerCellActive(row, col) {
        return row <= this.tablePickerRows() && col <= this.tablePickerCols();
    }
    /** @internal */
    insertSelectedTable() {
        this.insertTable(this.tablePickerCols(), this.tablePickerRows());
        this.isTablePickerOpen.set(false);
    }
    /**
     * Opens the block property sheet from the unified template insert picker.
     *
     * @internal
     */
    insertTemplateBlockFromPicker(blockName, event) {
        const anchor = event.currentTarget;
        this.openTemplateBlockDialog(blockName, anchor ?? undefined);
        this.closePlaceholderPicker();
    }
    // ── Emoji picker ──────────────────────────────────────────
    /**
     * Toggles the emoji picker dropdown.
     * @internal
     */
    toggleEmojiPicker() {
        if (this.disabled() || this.readonly())
            return;
        this.isPlaceholderPickerOpen.set(false);
        this.isTablePickerOpen.set(false);
        this.isEmojiPickerOpen.update((v) => !v);
    }
    /**
     * Inserts the selected emoji at the current caret position.
     * @internal
     */
    insertEmoji(emoji) {
        if (this.disabled() || this.readonly())
            return;
        this.isEmojiPickerOpen.set(false);
        if (this.isMarkdownMode()) {
            this.insertEmojiMarkdown(emoji);
        }
        else {
            this.insertEmojiHtml(emoji);
        }
    }
    /**
     * Inserts an emoji character into the contenteditable editor
     * (HTML mode).
     * @internal
     */
    insertEmojiHtml(emoji) {
        this.restoreFocus();
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
            const range = sel.getRangeAt(0);
            range.deleteContents();
            const textNode = document.createTextNode(emoji);
            range.insertNode(textNode);
            range.setStartAfter(textNode);
            range.collapse(true);
            sel.removeAllRanges();
            sel.addRange(range);
        }
        else {
            this.editorRef().nativeElement.appendChild(document.createTextNode(emoji));
        }
        this.syncValueFromEditor();
    }
    /**
     * Inserts an emoji character into the Markdown textarea.
     * @internal
     */
    insertEmojiMarkdown(emoji) {
        const strat = this.strategy();
        if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
            const textarea = strat.textareaEl;
            const { selectionStart, selectionEnd, value } = textarea;
            textarea.value =
                value.substring(0, selectionStart) +
                    emoji +
                    value.substring(selectionEnd);
            textarea.selectionStart = selectionStart + emoji.length;
            textarea.selectionEnd = selectionStart + emoji.length;
            textarea.focus();
            textarea.dispatchEvent(new Event("input", { bubbles: true }));
        }
        this.syncValueFromEditor();
    }
    /**
     * Updates the placeholder picker search term.
     * @internal
     */
    onPlaceholderSearch(event) {
        const input = event.target;
        this.placeholderSearchTerm.set(input.value);
    }
    // ── Hyperlink dialog ───────────────────────────────────────
    /**
     * Opens the hyperlink popover.
     * @internal
     */
    openLinkDialog(anchorEl) {
        if (this.disabled() || this.readonly())
            return;
        this.isPlaceholderPickerOpen.set(false);
        this.isTablePickerOpen.set(false);
        this.isEmojiPickerOpen.set(false);
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
            this.savedRange = sel.getRangeAt(0).cloneRange();
        }
        const existingAnchor = this.findAncestorAnchor();
        const isEdit = !!existingAnchor;
        const initialUrl = existingAnchor?.getAttribute("href") ?? "";
        const initialText = existingAnchor
            ? (existingAnchor.textContent ?? "")
            : (sel?.toString() ?? "");
        const anchor = anchorEl ?? this.elRef.nativeElement;
        const ref = this.popoverService.openPopover({
            component: UILinkDialog,
            anchor,
            verticalAxisAlignment: "bottom",
            horizontalAxisAlignment: "center",
            verticalOffset: 4,
            closeOnOutsideClick: true,
            inputs: {
                initialUrl,
                initialText,
                editMode: isEdit,
            },
        });
        ref.closed.subscribe((result) => {
            if (result) {
                this.applyLinkResult(result, existingAnchor);
            }
            else {
                this.savedRange = null;
                this.restoreFocus();
            }
        });
    }
    /**
     * Applies the link result returned by the popover.
     * @internal
     */
    applyLinkResult(result, existingAnchor) {
        const ctx = this.buildContext();
        const strat = this.strategy();
        strat.applyLink(result, existingAnchor, this.savedRange, ctx);
        this.savedRange = null;
        this.syncValueFromEditor();
        this.doRefreshActiveFormats();
    }
    /**
     * Finds the closest `<a>` ancestor of the current selection.
     * @internal
     */
    findAncestorAnchor() {
        const sel = window.getSelection();
        if (!sel || sel.rangeCount === 0)
            return null;
        let node = sel.anchorNode;
        while (node && node !== this.editorRef().nativeElement) {
            if (node instanceof HTMLAnchorElement)
                return node;
            node = node.parentNode;
        }
        return null;
    }
    // ── Image dialog ───────────────────────────────────────────
    /**
     * Opens the image insertion popover.
     * @internal
     */
    openImageDialog(anchorEl) {
        if (this.disabled() || this.readonly())
            return;
        this.isPlaceholderPickerOpen.set(false);
        this.isTablePickerOpen.set(false);
        this.isEmojiPickerOpen.set(false);
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
            this.savedRange = sel.getRangeAt(0).cloneRange();
        }
        const anchor = anchorEl ?? this.elRef.nativeElement;
        const ref = this.popoverService.openPopover({
            component: UIImageDialog,
            anchor,
            verticalAxisAlignment: "bottom",
            horizontalAxisAlignment: "center",
            verticalOffset: 4,
            closeOnOutsideClick: true,
            inputs: {
                initialSrc: "",
                initialAlt: "",
            },
        });
        ref.closed.subscribe((result) => {
            if (result) {
                this.applyImageResult(result);
            }
            else {
                this.savedRange = null;
                this.restoreFocus();
            }
        });
    }
    /**
     * Applies the image result returned by the popover.
     * @internal
     */
    applyImageResult(result) {
        const ctx = this.buildContext();
        const strat = this.strategy();
        if (this.isMarkdownMode()) {
            // Insert Markdown image syntax into the textarea
            if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
                const textarea = strat.textareaEl;
                const imgMarkdown = `![${result.alt}](${result.src})`;
                const { selectionStart, selectionEnd, value } = textarea;
                textarea.value =
                    value.substring(0, selectionStart) +
                        imgMarkdown +
                        value.substring(selectionEnd);
                textarea.selectionStart = selectionStart + imgMarkdown.length;
                textarea.selectionEnd = selectionStart + imgMarkdown.length;
                textarea.focus();
                textarea.dispatchEvent(new Event("input", { bubbles: true }));
            }
        }
        else {
            // Restore selection range and insert <img> in HTML mode
            if (this.savedRange) {
                const sel = window.getSelection();
                if (sel) {
                    sel.removeAllRanges();
                    sel.addRange(this.savedRange);
                }
            }
            this.restoreFocus();
            const img = document.createElement("img");
            img.src = result.src;
            img.alt = result.alt;
            img.style.maxWidth = "100%";
            const sel = window.getSelection();
            if (sel && sel.rangeCount > 0) {
                const range = sel.getRangeAt(0);
                range.deleteContents();
                range.insertNode(img);
                range.setStartAfter(img);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
            else {
                ctx.editorEl.appendChild(img);
            }
        }
        this.savedRange = null;
        this.syncValueFromEditor();
        this.doRefreshActiveFormats();
    }
    /**
     * Returns `true` when the given formatting action is currently
     * active at the caret position.
     * @internal
     */
    isActionActive(action) {
        return this.activeFormats().has(action);
    }
    // ── Source mode ────────────────────────────────────────────
    /**
     * Toggles between WYSIWYG-only and split source + preview mode.
     *
     * In Markdown mode this toggles the preview visibility.
     * In HTML mode this shows the raw HTML textarea.
     *
     * @internal
     */
    toggleSourceMode() {
        if (this.disabled() || this.readonly())
            return;
        this.isPlaceholderPickerOpen.set(false);
        this.isTablePickerOpen.set(false);
        this.isEmojiPickerOpen.set(false);
        const next = !this.isSourceMode();
        this.isSourceMode.set(next);
        if (!next) {
            this.renderToEditor(this.value());
            this.doRefreshActiveFormats();
        }
    }
    /**
     * Toggles the editor between full-screen (full-window overlay) and
     * normal inline mode.
     *
     * @internal
     */
    toggleFullscreen() {
        this.isFullscreen.update((v) => !v);
    }
    /**
     * Cycles the markdown split-pane direction between `'vertical'` and
     * `'horizontal'`.  Has no effect unless `mode === 'markdown'`.
     *
     * @internal
     */
    cycleSplitDirection() {
        const next = this.effectiveSplitDirection() === "horizontal"
            ? "vertical"
            : "horizontal";
        this._splitDirectionOverride.set(next);
    }
    /**
     * Begins a drag-resize interaction on the split pane handle.
     * Tracks `pointermove` on `document` until `pointerup`/`pointercancel`,
     * adjusting the flex-basis of the textarea pane.
     *
     * @internal
     */
    onSplitPointerDown(event) {
        const handle = event.target;
        if (!handle.classList.contains("split-handle"))
            return;
        event.preventDefault();
        const host = this.elRef.nativeElement;
        const isHorizontal = this.effectiveSplitDirection() === "horizontal";
        const textarea = host.querySelector(".markdown-editor");
        if (!textarea)
            return;
        const startPos = isHorizontal ? event.clientX : event.clientY;
        const startSize = isHorizontal
            ? textarea.offsetWidth
            : textarea.offsetHeight;
        const onMove = (e) => {
            const delta = (isHorizontal ? e.clientX : e.clientY) - startPos;
            const hostSize = isHorizontal ? host.offsetWidth : host.offsetHeight;
            const newSize = Math.min(Math.max(startSize + delta, 80), hostSize - 80);
            textarea.style.flexBasis = `${newSize}px`;
            textarea.style.flexGrow = "0";
            textarea.style.flexShrink = "0";
        };
        const onUp = () => {
            document.removeEventListener("pointermove", onMove);
            document.removeEventListener("pointerup", onUp);
            document.removeEventListener("pointercancel", onUp);
        };
        document.addEventListener("pointermove", onMove);
        document.addEventListener("pointerup", onUp);
        document.addEventListener("pointercancel", onUp);
    }
    /**
     * Handles input events from the source-mode `<textarea>`.
     *
     * In HTML mode: writes raw HTML to `value` and live-renders
     * the preview.
     *
     * In Markdown mode: writes Markdown to `value` and live-renders
     * the HTML preview.
     *
     * @internal
     */
    onSourceInput(event) {
        const textarea = event.target;
        this.lastSyncedValue = textarea.value;
        this.value.set(textarea.value);
        if (this.isMarkdownMode()) {
            this.renderToEditor(textarea.value);
        }
        this.doRefreshActiveFormats();
    }
    // ── Editor event handlers ──────────────────────────────────
    /** @internal */
    onEditorInput() {
        if (!this.isMarkdownMode()) {
            this.syncValueFromEditor();
        }
    }
    /** @internal */
    onEditorFocus() {
        this.isFocused.set(true);
        this.doRefreshActiveFormats();
    }
    /** @internal */
    onEditorBlur() {
        this.isFocused.set(false);
        this.activeFormats.set(new Set());
    }
    /**
     * Handles paste events.
     *
     * When the clipboard contains an image file, the image is
     * processed first:
     * - If an `imageHandler` is provided, it is called and the
     *   returned URL is inserted.
     * - Otherwise the image is embedded inline as a base64
     *   `data:` URI.
     *
     * For non-image paste data, delegates to the active strategy.
     *
     * @internal
     */
    onEditorPaste(event) {
        const imageFile = this.extractImageFile(event);
        if (imageFile) {
            event.preventDefault();
            this.handleImagePaste(imageFile);
            return;
        }
        const ctx = this.buildContext();
        this.strategy().handlePaste(event, ctx);
        this.syncValueFromEditor();
    }
    /**
     * Extracts the first image `File` from a paste event's
     * clipboard data, or `null` if none is present.
     * @internal
     */
    extractImageFile(event) {
        const items = event.clipboardData?.items;
        if (!items)
            return null;
        for (const item of items) {
            if (item.type.startsWith("image/")) {
                const file = item.getAsFile();
                if (file)
                    return file;
            }
        }
        return null;
    }
    /**
     * Processes a pasted image file.
     *
     * When an `imageHandler` is provided, it is called with the
     * file and the resulting URL is inserted.  Otherwise the image
     * is read as a base64 data URI and embedded inline.
     *
     * @internal
     */
    handleImagePaste(file) {
        const handler = this.imageHandler();
        if (handler) {
            handler(file).then((url) => this.insertPastedImage(url, file.name), (err) => this.log.error("Image upload failed", [err]));
        }
        else {
            const reader = new FileReader();
            reader.onload = () => {
                const dataUrl = reader.result;
                this.insertPastedImage(dataUrl, file.name);
            };
            reader.readAsDataURL(file);
        }
    }
    /**
     * Inserts an image at the current caret position.
     *
     * In HTML mode, inserts an `<img>` element.
     * In Markdown mode, inserts `![alt](url)` syntax.
     *
     * @internal
     */
    insertPastedImage(src, alt) {
        if (this.isMarkdownMode()) {
            const strat = this.strategy();
            if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
                const textarea = strat.textareaEl;
                const imgMarkdown = `![${alt}](${src})`;
                const { selectionStart, selectionEnd, value } = textarea;
                textarea.value =
                    value.substring(0, selectionStart) +
                        imgMarkdown +
                        value.substring(selectionEnd);
                textarea.selectionStart = selectionStart + imgMarkdown.length;
                textarea.selectionEnd = selectionStart + imgMarkdown.length;
                textarea.focus();
                textarea.dispatchEvent(new Event("input", { bubbles: true }));
            }
        }
        else {
            this.restoreFocus();
            const img = document.createElement("img");
            img.src = src;
            img.alt = alt;
            img.style.maxWidth = "100%";
            const sel = window.getSelection();
            if (sel && sel.rangeCount > 0) {
                const range = sel.getRangeAt(0);
                range.deleteContents();
                range.insertNode(img);
                range.setStartAfter(img);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
            else {
                this.editorRef().nativeElement.appendChild(img);
            }
        }
        this.syncValueFromEditor();
    }
    /**
     * Handles keyboard shortcuts and prevents deletion of
     * placeholder chip interiors.  Applies to both HTML and
     * Markdown modes.
     *
     * @internal
     */
    onEditorKeydown(event) {
        if (this.handleKeyboardShortcut(event))
            return;
        // Placeholder chip protection — HTML mode only
        if (this.isMarkdownMode())
            return;
        if (this.handleTableTabNavigation(event))
            return;
        if (this.handleTableVerticalNavigation(event))
            return;
        if (this.handleTemplateBlockCaretNavigation(event))
            return;
        if (this.handleTemplateBlockCaretDeletion(event))
            return;
        if (event.key === "Backspace" || event.key === "Delete") {
            const sel = window.getSelection();
            if (!sel || sel.rangeCount === 0)
                return;
            const range = sel.getRangeAt(0);
            if (!range.collapsed)
                return;
            const node = event.key === "Backspace"
                ? this.previousNode(range.startContainer, range.startOffset)
                : this.nextNode(range.startContainer, range.startOffset);
            if (node instanceof HTMLElement &&
                node.classList.contains(PLACEHOLDER_CLASS)) {
                event.preventDefault();
                node.remove();
                this.syncValueFromEditor();
            }
        }
    }
    /** @internal */
    handleTableTabNavigation(event) {
        if (event.key !== "Tab")
            return false;
        if (event.altKey || event.ctrlKey || event.metaKey)
            return false;
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0)
            return false;
        const range = this.normaliseTemplateBlockCaretEdgeRange(selection.getRangeAt(0));
        if (!this.isRangeInsideEditor(range))
            return false;
        const currentCell = this.getTableCellFromRange(range);
        if (!currentCell)
            return false;
        const currentRow = currentCell.closest("tr");
        const table = currentCell.closest("table");
        if (!currentRow || !table)
            return false;
        const rows = this.getDirectTableRows(table).filter((row) => !row.classList.contains("rte-template-block"));
        const rowIndex = rows.indexOf(currentRow);
        if (rowIndex < 0)
            return false;
        const columnIndex = Array.from(currentRow.cells).indexOf(currentCell);
        if (columnIndex < 0)
            return false;
        const movingBackward = event.shiftKey;
        let targetRow = currentRow;
        let targetColumnIndex = movingBackward ? columnIndex - 1 : columnIndex + 1;
        if (targetColumnIndex < 0) {
            targetRow = rows[rowIndex - 1] ?? null;
            if (!targetRow)
                return false;
            targetColumnIndex = targetRow.cells.length - 1;
        }
        else if (targetColumnIndex >= currentRow.cells.length) {
            targetRow = rows[rowIndex + 1] ?? null;
            if (!targetRow)
                return false;
            targetColumnIndex = 0;
        }
        const targetCell = targetRow.cells[targetColumnIndex] ?? null;
        if (!targetCell)
            return false;
        event.preventDefault();
        this.selectTableCellContents(targetCell);
        return true;
    }
    /** @internal */
    handleTableVerticalNavigation(event) {
        if (event.key !== "ArrowUp" && event.key !== "ArrowDown")
            return false;
        if (event.altKey || event.ctrlKey || event.metaKey)
            return false;
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0)
            return false;
        const range = this.normaliseTemplateBlockCaretEdgeRange(selection.getRangeAt(0));
        if (!this.isRangeInsideEditor(range))
            return false;
        const currentCell = this.getTableCellFromRange(range);
        if (!currentCell)
            return false;
        const currentRow = currentCell.closest("tr");
        const table = currentCell.closest("table");
        if (!currentRow || !table)
            return false;
        const rows = this.getDirectTableRows(table).filter((row) => !row.classList.contains("rte-template-block"));
        const rowIndex = rows.indexOf(currentRow);
        if (rowIndex < 0)
            return false;
        const targetIndex = event.key === "ArrowUp" ? rowIndex - 1 : rowIndex + 1;
        const targetRow = rows[targetIndex] ?? null;
        if (!targetRow)
            return false;
        const columnIndex = Array.from(currentRow.cells).indexOf(currentCell);
        if (columnIndex < 0)
            return false;
        const targetCell = targetRow.cells[Math.min(columnIndex, targetRow.cells.length - 1)] ??
            null;
        if (!targetCell)
            return false;
        event.preventDefault();
        this.selectTableCellContents(targetCell);
        return true;
    }
    /** @internal */
    handleTemplateBlockCaretNavigation(event) {
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight")
            return false;
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0)
            return false;
        const range = this.normaliseTemplateBlockCaretEdgeRange(selection.getRangeAt(0));
        if (!range.collapsed || !this.isRangeInsideEditor(range))
            return false;
        const edgeNode = event.key === "ArrowLeft"
            ? this.previousNode(range.startContainer, range.startOffset)
            : this.nextNode(range.startContainer, range.startOffset);
        const edge = edgeNode instanceof HTMLElement
            ? this.findTemplateBlockCaretEdge(edgeNode)
            : null;
        if (!edge)
            return false;
        const cluster = this.getTemplateBlockCaretCluster(edge);
        if (!cluster)
            return false;
        if (event.key === "ArrowRight" && edge === cluster.leadingEdge) {
            event.preventDefault();
            this.setCollapsedSelectionAfterNode(cluster.trailingEdge);
            return true;
        }
        if (event.key === "ArrowLeft" && edge === cluster.trailingEdge) {
            event.preventDefault();
            this.setCollapsedSelectionBeforeNode(cluster.leadingEdge);
            return true;
        }
        return false;
    }
    /** @internal */
    handleTemplateBlockCaretDeletion(event) {
        if (event.key !== "Backspace" && event.key !== "Delete")
            return false;
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0)
            return false;
        const range = this.normaliseTemplateBlockCaretEdgeRange(selection.getRangeAt(0));
        if (!range.collapsed || !this.isRangeInsideEditor(range))
            return false;
        const edgeNode = event.key === "Backspace"
            ? this.previousNode(range.startContainer, range.startOffset)
            : this.nextNode(range.startContainer, range.startOffset);
        const edge = edgeNode instanceof HTMLElement
            ? this.findTemplateBlockCaretEdge(edgeNode)
            : null;
        if (!edge)
            return false;
        const cluster = this.getTemplateBlockCaretCluster(edge);
        if (!cluster)
            return false;
        event.preventDefault();
        this.removeTemplateBlockCaretCluster(cluster);
        this.syncValueFromEditor();
        this.doRefreshActiveFormats();
        return true;
    }
    /**
     * Maps common keyboard shortcuts to formatting actions.
     * Returns `true` if the event was handled.
     *
     * | Shortcut             | Action        |
     * | -------------------- | ------------- |
     * | Ctrl/⌘+B             | bold          |
     * | Ctrl/⌘+I             | italic        |
     * | Ctrl/⌘+U             | underline     |
     * | Ctrl/⌘+Shift+S       | strikethrough |
     * | Ctrl/⌘+Shift+X       | strikethrough |
     * | Ctrl/⌘+K             | link          |
     * | Ctrl/⌘+Z             | undo          |
     * | Ctrl/⌘+Shift+Z / Y   | redo          |
     *
     * @internal
     */
    handleKeyboardShortcut(event) {
        if (this.disabled() || this.readonly())
            return false;
        const mod = event.metaKey || event.ctrlKey;
        if (!mod)
            return false;
        const key = event.key.toLowerCase();
        let action = null;
        if (!event.shiftKey) {
            switch (key) {
                case "b":
                    action = "bold";
                    break;
                case "i":
                    action = "italic";
                    break;
                case "u":
                    action = "underline";
                    break;
                case "k":
                    action = "link";
                    break;
                case "z":
                    action = "undo";
                    break;
                case "y":
                    action = "redo";
                    break;
            }
        }
        else {
            switch (key) {
                case "s":
                case "x":
                    action = "strikethrough";
                    break;
                case "z":
                    action = "redo";
                    break;
            }
        }
        if (action) {
            event.preventDefault();
            this.execAction(action);
            return true;
        }
        return false;
    }
    // ── Markdown textarea hookup ──────────────────────────────
    /**
     * Called from the template when the Markdown textarea is
     * created, to pass a reference to the strategy.
     * @internal
     */
    onMarkdownTextareaCreated(textarea) {
        const strat = this.strategy();
        if (strat instanceof MarkdownEditingStrategy) {
            strat.textareaEl = textarea;
        }
    }
    // ── Internal helpers ───────────────────────────────────────
    /**
     * Builds default attributes for a newly inserted template block.
     *
     * @internal
     */
    defaultTemplateBlockAttributes(provider) {
        if (provider.attributes?.length) {
            return Object.fromEntries(provider.attributes.map((field) => [
                field.key,
                field.type === "boolean" ? "false" : "",
            ]));
        }
        if (provider.name === "if")
            return { test: "" };
        if (provider.name === "loop")
            return { items: "" };
        if (provider.name === "placeholder")
            return { key: "" };
        return {};
    }
    /**
     * Returns block attribute editor metadata, enriched with contextual choices
     * where the current editor state can provide them.
     *
     * @internal
     */
    getTemplateBlockAttributeDefinitions(provider) {
        const attributes = provider.attributes ?? [];
        if (provider.name === "placeholder") {
            const placeholderOptions = this.getCurrentContextPlaceholderOptions();
            if (!placeholderOptions.length)
                return attributes;
            return attributes.map((field) => field.key === "key"
                ? {
                    ...field,
                    type: "select",
                    options: placeholderOptions,
                }
                : field);
        }
        if (provider.name === "email") {
            const placeholderOptions = this.getCurrentContextPlaceholderOptions();
            if (!placeholderOptions.length)
                return attributes;
            return attributes.map((field) => field.key === "email" || field.key === "text"
                ? {
                    ...field,
                    type: "select",
                    options: placeholderOptions,
                }
                : field);
        }
        if (provider.name !== "loop")
            return attributes;
        const arrayOptions = this.getCurrentContextArrayOptions();
        if (!arrayOptions.length)
            return attributes;
        return attributes.map((field) => field.key === "items"
            ? {
                ...field,
                type: "select",
                options: arrayOptions,
            }
            : field);
    }
    /** @internal */
    getCurrentContextPlaceholderOptions() {
        const context = this.placeholderContext();
        if (context === undefined || context === null) {
            return this.placeholders().map((placeholder) => ({
                value: placeholder.key,
                label: placeholder.label,
            }));
        }
        return this.buildScopedPlaceholderItemsFromContext(context)
            .filter((item) => !item.isGroup)
            .map((item) => ({
            value: item.key,
            label: item.showPath ? item.path : item.label,
        }));
    }
    /** @internal */
    getCurrentContextArrayOptions() {
        const context = this.getCurrentTemplateContextRecord();
        if (!context)
            return [];
        return Object.entries(context)
            .filter(([, value]) => Array.isArray(value))
            .map(([key]) => ({ value: key, label: key }));
    }
    /** @internal */
    getCurrentTemplateContextRecord() {
        const context = this.placeholderContext();
        if (!this.isInspectableObject(context))
            return undefined;
        const loopItemsKey = this.getActiveLoopItemsKey();
        if (!loopItemsKey)
            return context;
        const loopItems = context[loopItemsKey];
        if (!Array.isArray(loopItems))
            return context;
        const sample = loopItems.find((item) => item !== null && item !== undefined);
        if (!this.isInspectableObject(sample))
            return context;
        return { ...context, ...sample };
    }
    /**
     * Builds canonical XML for a template block edit result.
     *
     * @internal
     */
    buildTemplateBlockXml(result, provider) {
        const attrs = Object.entries(result.attributes)
            .map(([key, value]) => ` ${key}="${this.escapeXmlAttribute(value)}"`)
            .join("");
        if (provider.selfClosing)
            return `<${result.name}${attrs} />`;
        return `<${result.name}${attrs}>${this.defaultTemplateBlockBody(result.name)}</${result.name}>`;
    }
    /**
     * Default body inserted for new container blocks.
     *
     * @internal
     */
    defaultTemplateBlockBody(name) {
        if (name === "loop")
            return "<p>Repeated content</p>";
        if (name === "if")
            return "<p>Conditional content</p>";
        return "<p>Block content</p>";
    }
    /**
     * Inserts text into a textarea and dispatches an input event.
     *
     * @internal
     */
    insertTextIntoTextarea(textarea, text) {
        const { selectionStart, selectionEnd, value } = textarea;
        textarea.value =
            value.substring(0, selectionStart) + text + value.substring(selectionEnd);
        textarea.selectionStart = selectionStart + text.length;
        textarea.selectionEnd = selectionStart + text.length;
        textarea.focus();
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
    }
    /**
     * Finds the table cell that contains the saved editor caret.
     *
     * @internal
     */
    getActiveTableCell() {
        const range = this.lastEditorRange;
        const rangeCell = range && this.isRangeInsideEditor(range)
            ? this.getTableCellFromRange(range)
            : null;
        if (rangeCell)
            return rangeCell;
        if (this.lastActiveTableCell &&
            this.editorRef().nativeElement.contains(this.lastActiveTableCell)) {
            return this.lastActiveTableCell;
        }
        return null;
    }
    /** @internal */
    getTableCellFromRange(range) {
        const node = range.commonAncestorContainer;
        const element = node instanceof Element ? node : (node.parentElement ?? null);
        const cell = element?.closest("th, td") ?? null;
        if (!cell || !this.editorRef().nativeElement.contains(cell))
            return null;
        return cell;
    }
    /**
     * Creates a new editable table row matching the current row shape.
     *
     * @internal
     */
    createTableRowLike(row) {
        const newRow = document.createElement("tr");
        const tagName = this.getTableCellTagName(row);
        const cellCount = Math.max(1, row.cells.length);
        for (let index = 0; index < cellCount; index += 1) {
            newRow.append(this.createTableCell(tagName));
        }
        return newRow;
    }
    /**
     * Creates a default table cell for editor-side table commands.
     *
     * @internal
     */
    createTableCell(tagName) {
        const cell = document.createElement(tagName);
        cell.textContent = tagName === "th" ? "Column" : "Value";
        return cell;
    }
    /**
     * Returns only rows that belong directly to a table or its direct sections.
     *
     * @internal
     */
    getDirectTableRows(table) {
        const rows = [];
        for (const child of Array.from(table.children)) {
            const tagName = child.tagName.toLowerCase();
            if (tagName === "tr") {
                rows.push(child);
                continue;
            }
            if (tagName !== "thead" && tagName !== "tbody" && tagName !== "tfoot") {
                continue;
            }
            rows.push(...Array.from(child.children).filter((row) => row.tagName.toLowerCase() === "tr"));
        }
        return rows;
    }
    /**
     * Chooses whether a new cell in the row should be a header or body cell.
     *
     * @internal
     */
    getTableCellTagName(row) {
        const inHeader = row.parentElement?.tagName.toLowerCase() === "thead";
        const hasHeaderCells = Array.from(row.cells).some((cell) => cell.tagName.toLowerCase() === "th");
        return inHeader || hasHeaderCells ? "th" : "td";
    }
    /**
     * Finds selected table body rows that can be wrapped in a container block.
     *
     * @internal
     */
    getSelectedWrappableTableRows(anchorEl) {
        const selection = window.getSelection();
        const range = selection && selection.rangeCount > 0 ? selection.getRangeAt(0) : null;
        const anchorRow = this.findClosestTableBodyRow(anchorEl ?? selection?.anchorNode ?? null);
        const table = anchorRow?.closest("table") ??
            this.findClosestTable(range?.commonAncestorContainer ?? null);
        if (!table)
            return anchorRow ? [anchorRow] : [];
        const rows = Array.from(table.querySelectorAll("tbody > tr")).filter((row) => this.isWrappableTableRow(row));
        if (!range)
            return anchorRow ? [anchorRow] : [];
        const selectedRows = rows.filter((row) => range.intersectsNode(row));
        if (selectedRows.length)
            return selectedRows;
        return anchorRow && rows.includes(anchorRow) ? [anchorRow] : [];
    }
    /**
     * Wraps table rows in the rendered loop block shape used by the editor.
     *
     * @internal
     */
    wrapTableRowsInTemplateBlock(rows, result, provider) {
        const firstRow = rows[0];
        if (!firstRow?.parentElement)
            return;
        const wrapper = document.createElement("tr");
        wrapper.className = "rte-template-block table-row-block";
        wrapper.dataset["templateBlock"] = result.name;
        wrapper.dataset["templateSelfClosing"] = "false";
        for (const [key, value] of Object.entries(result.attributes)) {
            wrapper.setAttribute(`data-template-attr-${key}`, value);
        }
        const cell = document.createElement("td");
        cell.colSpan = 999;
        const before = this.createTemplateBlockCaretEdge("before");
        const shell = document.createElement("div");
        shell.className = "shell";
        const header = document.createElement("span");
        header.className = "header";
        header.contentEditable = "false";
        header.textContent =
            provider.formatLabel?.(result.attributes) ?? provider.label;
        const table = document.createElement("table");
        table.className = "table-content";
        const body = document.createElement("tbody");
        body.className = "content";
        table.append(body);
        shell.append(header, table);
        cell.append(before, shell, this.createTemplateBlockCaretEdge("after", "block"));
        wrapper.append(cell);
        firstRow.before(wrapper);
        for (const row of rows) {
            body.append(row);
        }
        this.syncValueFromEditor();
        this.blockInserted.emit(this.createTemplateBlockEvent(result));
    }
    /** @internal */
    findClosestTableBodyRow(value) {
        const element = value instanceof Element ? value : (value?.parentElement ?? null);
        const row = element?.closest("tbody > tr") ?? null;
        return row && this.isWrappableTableRow(row) ? row : null;
    }
    /** @internal */
    findClosestTable(value) {
        const element = value instanceof Element ? value : (value?.parentElement ?? null);
        return element?.closest("table") ?? null;
    }
    /** @internal */
    isWrappableTableRow(row) {
        return !row.closest("[data-template-block]");
    }
    /**
     * Renders XML into editor DOM nodes using the active strategy.
     *
     * @internal
     */
    renderTemplateBlockNodes(xml) {
        const ctx = this.buildContext();
        const html = this.strategy().deserialiseContent(xml, ctx);
        const container = html.trimStart().startsWith("<tr")
            ? document.createElement("tbody")
            : document.createElement("div");
        container.innerHTML = html;
        return Array.from(container.childNodes);
    }
    /** @internal */
    createTemplateBlockCaretEdge(position, display = "inline") {
        const edge = document.createElement("span");
        edge.className = TEMPLATE_BLOCK_CARET_EDGE_CLASS;
        edge.setAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR, position);
        if (display === "block") {
            edge.setAttribute(TEMPLATE_BLOCK_CARET_EDGE_DISPLAY_ATTR, "block");
        }
        edge.setAttribute("aria-hidden", "true");
        edge.textContent = ZERO_WIDTH_SPACE;
        return edge;
    }
    /** @internal */
    placeCaretAtEndOfTableCell(cell) {
        this.restoreFocus();
        const range = document.createRange();
        range.selectNodeContents(cell);
        range.collapse(false);
        const selection = window.getSelection();
        if (!selection)
            return;
        selection.removeAllRanges();
        selection.addRange(range);
        this.lastEditorRange = range.cloneRange();
        this.lastActiveTableCell = cell;
        this.selectionContextRevision.update((value) => value + 1);
    }
    /** @internal */
    selectTableCellContents(cell) {
        this.restoreFocus();
        const range = document.createRange();
        range.selectNodeContents(cell);
        this.applyEditorSelection(range);
    }
    /**
     * Inserts DOM nodes at the current selection.
     *
     * @internal
     */
    insertNodesAtSelection(nodes) {
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0) {
            const range = sel.getRangeAt(0);
            range.deleteContents();
            let lastNode = null;
            for (const node of nodes) {
                range.insertNode(node);
                range.setStartAfter(node);
                lastNode = node;
            }
            if (lastNode) {
                range.setStartAfter(lastNode);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
            return;
        }
        this.editorRef().nativeElement.append(...nodes);
    }
    /**
     * Replaces an existing rendered template block with updated XML.
     *
     * @internal
     */
    replaceTemplateBlock(block, result, provider) {
        const xml = this.buildTemplateBlockXmlForExisting(block, result, provider);
        const nodes = this.renderTemplateBlockNodes(xml);
        block.replaceWith(...nodes);
        this.syncValueFromEditor();
        this.blockEdited.emit(this.createTemplateBlockEvent(result));
    }
    /**
     * Builds XML for an existing block while preserving container body content.
     *
     * @internal
     */
    buildTemplateBlockXmlForExisting(block, result, provider) {
        const attrs = Object.entries(result.attributes)
            .map(([key, value]) => ` ${key}="${this.escapeXmlAttribute(value)}"`)
            .join("");
        if (provider.selfClosing)
            return `<${result.name}${attrs} />`;
        const content = block.querySelector(".content");
        return `<${result.name}${attrs}>${content?.innerHTML ?? ""}</${result.name}>`;
    }
    /**
     * Reads template attributes stored on rendered block UI.
     *
     * @internal
     */
    readTemplateDatasetAttributes(block) {
        const attrs = {};
        for (const [key, value] of Object.entries(block.dataset)) {
            if (!key.startsWith("templateAttr") || value === undefined)
                continue;
            const attrName = key
                .slice("templateAttr".length)
                .replace(/^[A-Z]/, (first) => first.toLowerCase())
                .replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
            attrs[attrName] = value;
        }
        if (!attrs["key"] && block.dataset["placeholderKey"]) {
            attrs["key"] = block.dataset["placeholderKey"];
        }
        return attrs;
    }
    /** @internal */
    createTemplateBlockEvent(result) {
        return {
            name: result.name,
            attributes: { ...result.attributes },
        };
    }
    /** @internal */
    createTemplateBlockEventFromElement(block) {
        return {
            name: block.dataset["templateBlock"] ?? "block",
            attributes: this.readTemplateDatasetAttributes(block),
        };
    }
    /**
     * Creates fallback UI metadata for registered custom blocks.
     *
     * @internal
     */
    createGenericTemplateBlockUiProvider(block) {
        const name = block.dataset["templateBlock"] ?? "block";
        const selfClosing = block.dataset["templateSelfClosing"] === "true";
        const registeredProvider = getRegisteredTextTemplateBlockProviders().find((provider) => provider.name === name);
        if (registeredProvider) {
            return this.createGenericTemplateBlockUiProviderFromProvider(registeredProvider, selfClosing);
        }
        return {
            name,
            label: this.humanizeTemplateBlockName(name),
            selfClosing,
            display: selfClosing ? "inline" : "block",
        };
    }
    /**
     * Resolves custom block UI metadata from either the RTE UI registry or the
     * foundation runtime provider registry.
     *
     * @internal
     */
    getTemplateBlockUiProvider(blockName) {
        const uiProvider = getRichTextTemplateBlockUiProvider(blockName);
        if (uiProvider)
            return uiProvider;
        const blockProvider = getRegisteredTextTemplateBlockProviders().find((provider) => provider.name === blockName);
        return blockProvider
            ? this.createGenericTemplateBlockUiProviderFromProvider(blockProvider)
            : undefined;
    }
    /**
     * Creates fallback UI metadata from a foundation block provider.
     *
     * @internal
     */
    createGenericTemplateBlockUiProviderFromProvider(provider, selfClosingOverride) {
        const selfClosing = selfClosingOverride ?? provider.contentModel === "self-closing";
        return {
            name: provider.name,
            label: this.humanizeTemplateBlockName(provider.name),
            selfClosing,
            display: selfClosing ? "inline" : "block",
            attributes: [
                ...(provider.requiredAttributes ?? []).map((key) => this.createGenericTemplateBlockAttribute(key, true)),
                ...(provider.optionalAttributes ?? []).map((key) => this.createGenericTemplateBlockAttribute(key, false)),
            ],
        };
    }
    /**
     * Creates generic property-sheet metadata for a block attribute.
     *
     * @internal
     */
    createGenericTemplateBlockAttribute(key, required) {
        return {
            key,
            label: this.humanizeTemplateBlockName(key),
            type: "string",
            required,
            placeholder: key,
        };
    }
    /**
     * Converts XML-ish block and attribute names into a readable label.
     *
     * @internal
     */
    humanizeTemplateBlockName(name) {
        return name
            .replace(/[-_]+/g, " ")
            .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
            .replace(/\b\w/g, (letter) => letter.toUpperCase());
    }
    /**
     * Reads the editor content via the active strategy and pushes
     * the serialised value to `this.value`.
     * @internal
     */
    syncValueFromEditor() {
        const ctx = this.buildContext();
        const strat = this.strategy();
        if (this.isMarkdownMode()) {
            // In Markdown mode the textarea is the source of truth
            if (strat instanceof MarkdownEditingStrategy && strat.textareaEl) {
                const md = strat.textareaEl.value;
                this.lastSyncedValue = md;
                this.value.set(md);
                // Also update the preview
                this.renderToEditor(md);
            }
        }
        else {
            const editor = this.editorRef().nativeElement;
            const serialised = strat.serialiseContent(editor, ctx);
            this.lastSyncedValue = serialised;
            this.value.set(serialised);
        }
    }
    /**
     * Renders the given value into the preview/editor element
     * via the active strategy.
     * @internal
     */
    renderToEditor(val) {
        const ctx = this.buildContext();
        const strat = this.strategy();
        const editor = this.editorRef().nativeElement;
        const expanded = strat.deserialiseContent(val, ctx);
        editor.innerHTML = expanded;
    }
    /**
     * Refreshes the active format set via the strategy.
     * @internal
     */
    doRefreshActiveFormats() {
        const ctx = this.buildContext();
        const formats = this.strategy().refreshActiveFormats(ctx);
        this.activeFormats.set(formats);
    }
    /** Restores focus to the editor element. */
    restoreFocus() {
        const editor = this.editorRef().nativeElement;
        if (document.activeElement !== editor) {
            editor.focus();
        }
    }
    /** @internal */
    captureEditorSelectionFromWindow() {
        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0)
            return;
        const range = this.normaliseTemplateBlockCaretEdgeRange(selection.getRangeAt(0));
        if (!this.isRangeInsideEditor(range))
            return;
        selection.removeAllRanges();
        selection.addRange(range);
        this.lastEditorRange = range.cloneRange();
        this.lastActiveTableCell = this.getTableCellFromRange(range);
        this.selectionContextRevision.update((value) => value + 1);
    }
    /** @internal */
    restoreLastEditorSelection(range = this.lastEditorRange) {
        if (!range)
            return;
        const selection = window.getSelection();
        if (!selection)
            return;
        const restoredRange = this.normaliseTemplateBlockCaretEdgeRange(range);
        selection.removeAllRanges();
        selection.addRange(restoredRange);
        this.lastEditorRange = restoredRange.cloneRange();
        this.lastActiveTableCell = this.getTableCellFromRange(restoredRange);
        this.selectionContextRevision.update((value) => value + 1);
    }
    /** @internal */
    normaliseTemplateBlockCaretEdgeRange(input) {
        const range = input.cloneRange();
        if (!range.collapsed)
            return range;
        const edge = this.findTemplateBlockCaretEdge(range.startContainer);
        if (!edge)
            return range;
        const position = edge.getAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR);
        if (position === "before") {
            range.setStartBefore(edge);
        }
        else {
            range.setStartAfter(edge);
        }
        range.collapse(true);
        const previous = this.previousNode(range.startContainer, range.startOffset);
        const next = this.nextNode(range.startContainer, range.startOffset);
        const previousEdge = previous instanceof HTMLElement
            ? this.findTemplateBlockCaretEdge(previous)
            : null;
        if (previousEdge) {
            const cluster = this.getTemplateBlockCaretCluster(previousEdge);
            if (cluster &&
                previousEdge === cluster.leadingEdge &&
                next === cluster.token) {
                range.setStartBefore(cluster.leadingEdge);
                range.collapse(true);
                return range;
            }
        }
        const nextEdge = next instanceof HTMLElement
            ? this.findTemplateBlockCaretEdge(next)
            : null;
        if (nextEdge) {
            const cluster = this.getTemplateBlockCaretCluster(nextEdge);
            if (cluster &&
                nextEdge === cluster.trailingEdge &&
                previous === cluster.token) {
                range.setStartAfter(cluster.trailingEdge);
                range.collapse(true);
            }
        }
        return range;
    }
    /** @internal */
    findTemplateBlockCaretEdge(node) {
        const element = node instanceof Element ? node : node.parentElement;
        return (element?.closest(`[${TEMPLATE_BLOCK_CARET_EDGE_ATTR}]`) ??
            null);
    }
    /** @internal */
    getTemplateBlockCaretCluster(edge) {
        const position = edge.getAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR);
        const token = position === "before"
            ? edge.nextSibling
            : position === "after"
                ? edge.previousSibling
                : null;
        if (!(token instanceof HTMLElement) ||
            !token.hasAttribute("data-template-block")) {
            return null;
        }
        const leadingEdge = position === "before"
            ? edge
            : token.previousSibling instanceof HTMLElement
                ? token.previousSibling
                : null;
        const trailingEdge = position === "after"
            ? edge
            : token.nextSibling instanceof HTMLElement
                ? token.nextSibling
                : null;
        if (!(leadingEdge instanceof HTMLElement) ||
            !(trailingEdge instanceof HTMLElement) ||
            leadingEdge.getAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR) !== "before" ||
            trailingEdge.getAttribute(TEMPLATE_BLOCK_CARET_EDGE_ATTR) !== "after") {
            return null;
        }
        return { leadingEdge, token, trailingEdge };
    }
    /** @internal */
    setCollapsedSelectionBeforeNode(node) {
        const range = document.createRange();
        range.setStartBefore(node);
        range.collapse(true);
        this.applyEditorSelection(range);
    }
    /** @internal */
    setCollapsedSelectionAfterNode(node) {
        const range = document.createRange();
        range.setStartAfter(node);
        range.collapse(true);
        this.applyEditorSelection(range);
    }
    /** @internal */
    applyEditorSelection(range) {
        const selection = window.getSelection();
        if (!selection)
            return;
        selection.removeAllRanges();
        selection.addRange(range);
        this.lastEditorRange = range.cloneRange();
        this.lastActiveTableCell = this.getTableCellFromRange(range);
        this.selectionContextRevision.update((value) => value + 1);
    }
    /** @internal */
    removeTemplateBlockCaretCluster(cluster) {
        const removedBlock = this.createTemplateBlockEventFromElement(cluster.token);
        const parent = cluster.leadingEdge.parentNode;
        if (!parent)
            return;
        const nextSibling = cluster.trailingEdge.nextSibling;
        cluster.leadingEdge.remove();
        cluster.token.remove();
        cluster.trailingEdge.remove();
        const range = document.createRange();
        if (nextSibling) {
            range.setStartBefore(nextSibling);
        }
        else {
            range.setStart(parent, parent.childNodes.length);
        }
        range.collapse(true);
        this.applyEditorSelection(range);
        this.blockRemoved.emit(removedBlock);
    }
    /** @internal */
    getActiveLoopItemsKey() {
        const range = this.lastEditorRange;
        if (!range)
            return undefined;
        const node = range.commonAncestorContainer;
        const element = node instanceof Element ? node : (node.parentElement ?? null);
        const loopBlock = element?.closest('[data-template-block="loop"]');
        if (!loopBlock || !this.editorRef().nativeElement.contains(loopBlock)) {
            return undefined;
        }
        return loopBlock.dataset["templateAttrItems"];
    }
    /** @internal */
    isRangeInsideEditor(range) {
        const editor = this.editorRef().nativeElement;
        const node = range.commonAncestorContainer;
        return node === editor || editor.contains(node);
    }
    /** Escapes a value for use inside XML attributes. */
    escapeXmlAttribute(value) {
        return value
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/"/g, "&quot;");
    }
    /**
     * Returns the DOM node immediately before the given
     * container/offset position.
     */
    previousNode(container, offset) {
        if (container.nodeType === Node.TEXT_NODE) {
            return offset === 0 ? container.previousSibling : null;
        }
        return offset > 0 ? container.childNodes[offset - 1] : null;
    }
    /**
     * Returns the DOM node immediately after the given
     * container/offset position.
     */
    nextNode(container, offset) {
        if (container.nodeType === Node.TEXT_NODE) {
            return offset === container.length
                ? container.nextSibling
                : null;
        }
        return offset < container.childNodes.length
            ? container.childNodes[offset]
            : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIRichTextEditor, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIRichTextEditor, isStandalone: true, selector: "ui-rich-text-editor", inputs: { mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, presentation: { classPropertyName: "presentation", publicName: "presentation", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, toolbarActions: { classPropertyName: "toolbarActions", publicName: "toolbarActions", isSignal: true, isRequired: false, transformFunction: null }, compactToolbarActions: { classPropertyName: "compactToolbarActions", publicName: "compactToolbarActions", isSignal: true, isRequired: false, transformFunction: null }, placeholders: { classPropertyName: "placeholders", publicName: "placeholders", isSignal: true, isRequired: false, transformFunction: null }, placeholderContext: { classPropertyName: "placeholderContext", publicName: "placeholderContext", isSignal: true, isRequired: false, transformFunction: null }, splitDirection: { classPropertyName: "splitDirection", publicName: "splitDirection", isSignal: true, isRequired: false, transformFunction: null }, sanitise: { classPropertyName: "sanitise", publicName: "sanitise", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, imageHandler: { classPropertyName: "imageHandler", publicName: "imageHandler", isSignal: true, isRequired: false, transformFunction: null }, emojiCategories: { classPropertyName: "emojiCategories", publicName: "emojiCategories", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", blockInserted: "blockInserted", blockEdited: "blockEdited", blockRemoved: "blockRemoved" }, host: { properties: { "class.disabled": "disabled()", "class.readonly": "readonly()", "class.markdown": "mode() === 'markdown'", "class.compact": "presentation() === 'compact'", "class.fullscreen": "isFullscreen()", "class.split-horizontal": "isMarkdownMode() && effectiveSplitDirection() === 'horizontal'", "class.split-vertical": "isMarkdownMode() && effectiveSplitDirection() === 'vertical'" }, classAttribute: "ui-rich-text-editor" }, viewQueries: [{ propertyName: "editorRef", first: true, predicate: ["editorEl"], descendants: true, isSignal: true }, { propertyName: "mdTextareaRef", first: true, predicate: ["mdTextarea"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<!-- \u2500\u2500 Toolbar \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n<ui-toolbar role=\"toolbar\" aria-label=\"Formatting\" [displayMode]=\"toolbarDisplayMode()\"\n  [collapsed]=\"isCompactToolbarCollapsed()\" (collapsedChange)=\"onToolbarCollapsedChange($event)\"\n  (toolAction)=\"onToolAction($event)\">\n\n  <!-- History: Undo / Redo -->\n  @if (showHistoryGroup()) {\n  <ui-button-group-tool id=\"history\">\n    @if (hasToolbarAction('undo')) {\n    <ui-button-tool id=\"undo\" [icon]=\"teIcons.Undo\" ariaLabel=\"Undo\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('redo')) {\n    <ui-button-tool id=\"redo\" [icon]=\"teIcons.Redo\" ariaLabel=\"Redo\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  <ui-separator-tool id=\"sep-history\" />\n  }\n\n  <!-- Inline: Bold / Italic / Underline / Strikethrough -->\n  @if (showInlineGroup()) {\n  <ui-button-group-tool id=\"inline\">\n    @if (hasToolbarAction('bold')) {\n    <ui-toggle-tool id=\"bold\" [icon]=\"teIcons.Bold\" ariaLabel=\"Bold\" [checked]=\"isActionActive('bold')\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('italic')) {\n    <ui-toggle-tool id=\"italic\" [icon]=\"teIcons.Italic\" ariaLabel=\"Italic\" [checked]=\"isActionActive('italic')\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('underline')) {\n    <ui-toggle-tool id=\"underline\" [icon]=\"teIcons.Underline\" ariaLabel=\"Underline\"\n      [checked]=\"isActionActive('underline')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('strikethrough')) {\n    <ui-toggle-tool id=\"strikethrough\" [icon]=\"teIcons.Strikethrough\" ariaLabel=\"Strikethrough\"\n      [checked]=\"isActionActive('strikethrough')\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  <ui-separator-tool id=\"sep-inline\" />\n  }\n\n  <!-- Block styles (dropdown) -->\n  @if (blockDropdownItems().length > 0) {\n  <ui-dropdown-tool id=\"block\" [icon]=\"teIcons.Styles\" ariaLabel=\"Styles\" [items]=\"blockDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Lists (dropdown) -->\n  @if (listDropdownItems().length > 0) {\n  <ui-dropdown-tool id=\"list\" [icon]=\"teIcons.List\" ariaLabel=\"Lists\" [items]=\"listDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Alignment (radio-style, HTML mode only) -->\n  @if (!isMarkdownMode() && showAlignGroup()) {\n  <ui-separator-tool id=\"sep-align-before\" />\n  <ui-toggle-group-tool id=\"align\" aria-label=\"Alignment\">\n    @if (hasToolbarAction('alignLeft')) {\n    <ui-toggle-tool id=\"alignLeft\" [icon]=\"teIcons.AlignLeft\" ariaLabel=\"Align left\"\n      [checked]=\"isActionActive('alignLeft')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignCenter')) {\n    <ui-toggle-tool id=\"alignCenter\" [icon]=\"teIcons.AlignCenter\" ariaLabel=\"Align centre\"\n      [checked]=\"isActionActive('alignCenter')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignRight')) {\n    <ui-toggle-tool id=\"alignRight\" [icon]=\"teIcons.AlignRight\" ariaLabel=\"Align right\"\n      [checked]=\"isActionActive('alignRight')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignJustify')) {\n    <ui-toggle-tool id=\"alignJustify\" [icon]=\"teIcons.AlignJustify\" ariaLabel=\"Justify\"\n      [checked]=\"isActionActive('alignJustify')\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-toggle-group-tool>\n  <ui-separator-tool id=\"sep-align-after\" />\n  }\n\n  <!-- Insert: Horizontal rule / Image -->\n  @if (showInsertGroup()) {\n  @if (hasToolbarAction('horizontalRule') || hasToolbarAction('image')) {\n  <ui-button-group-tool id=\"insert\">\n    @if (hasToolbarAction('horizontalRule')) {\n    <ui-button-tool id=\"horizontalRule\" [icon]=\"teIcons.HorizontalRule\" ariaLabel=\"Horizontal rule\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('image')) {\n    <ui-button-tool id=\"image\" [icon]=\"teIcons.Image\" ariaLabel=\"Insert image\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  }\n  @if (hasToolbarAction('insertTable')) {\n  <div class=\"table-picker-wrapper\">\n    <button type=\"button\" class=\"tool-btn\" aria-label=\"Insert table\" title=\"Insert table\" tabindex=\"-1\"\n      [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isTablePickerOpen()\" (mousedown)=\"$event.preventDefault()\"\n      (click)=\"toggleTablePicker()\">\n      <ui-icon [svg]=\"teIcons.Table\" [size]=\"16\" />\n    </button>\n\n    @if (isTablePickerOpen()) {\n    <div class=\"table-picker-dropdown\" role=\"grid\" aria-label=\"Choose table size\" (mousedown)=\"$event.preventDefault()\">\n      <div class=\"table-size-label\">{{ tablePickerSizeLabel() }}</div>\n      @for (row of tablePickerRowOptions; track row) {\n      <div class=\"table-size-row\" role=\"row\">\n        @for (col of tablePickerColumnOptions; track col) {\n        <button type=\"button\" class=\"table-size-cell\" role=\"gridcell\" tabindex=\"-1\"\n          [class.active]=\"isTablePickerCellActive(row, col)\" [attr.aria-label]=\"col + ' columns, ' + row + ' rows'\"\n          (mouseenter)=\"setTablePickerSize(row, col)\" (focus)=\"setTablePickerSize(row, col)\"\n          (click)=\"insertSelectedTable()\"></button>\n        }\n      </div>\n      }\n    </div>\n    }\n  </div>\n  }\n  @if (!isMarkdownMode() && canEditActiveTable()) {\n  <ui-dropdown-tool id=\"table\" [icon]=\"teIcons.Table\" ariaLabel=\"Table options\" [items]=\"tableDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled() || tableDropdownItems().length === 0\" />\n  }\n  <ui-separator-tool id=\"sep-insert\" />\n  }\n  <!-- Link -->\n  @if (hasToolbarAction('link')) {\n  <ui-button-tool id=\"link\" [icon]=\"teIcons.Link\" ariaLabel=\"Hyperlink\" [disabled]=\"isEditorDisabled()\" />\n  <ui-separator-tool id=\"sep-link\" />\n  }\n\n  <!-- Remove formatting -->\n  @if (hasToolbarAction('removeFormat')) {\n  <ui-button-tool id=\"removeFormat\" [icon]=\"teIcons.RemoveFormat\" ariaLabel=\"Clear formatting\"\n    [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Template insert picker -->\n  @if (!isCompactPresentation() && hasTemplateInsertItems()) {\n  <ui-separator-tool id=\"sep-placeholder\" />\n  <div class=\"placeholder-picker\">\n    <button type=\"button\" class=\"tool-btn placeholder-trigger\" aria-label=\"Insert template block\"\n      title=\"Insert template block\" [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isPlaceholderPickerOpen()\"\n      (mousedown)=\"$event.preventDefault()\" (click)=\"togglePlaceholderPicker()\">\n      <ui-icon [svg]=\"sourceIcon\" [size]=\"16\" />\n    </button>\n\n    @if (isPlaceholderPickerOpen()) {\n    <div class=\"placeholder-dropdown\" role=\"listbox\" aria-label=\"Available template blocks\">\n      @if (hasPlaceholderPickerItems()) {\n      <div class=\"placeholder-search\">\n        <input type=\"text\" class=\"placeholder-search-input\" placeholder=\"Search placeholders\u2026\"\n          aria-label=\"Filter placeholders\" (input)=\"onPlaceholderSearch($event)\"\n          (mousedown)=\"$event.stopPropagation()\" />\n      </div>\n      @for (group of placeholderPickerGroups(); track group.category) {\n      @if (group.category) {\n      <div class=\"placeholder-category\">{{ group.category }}</div>\n      }\n      @for (ph of group.items; track ph.id) {\n      @if (ph.isGroup) {\n      <div class=\"placeholder-group\" role=\"presentation\" [style.padding-left.rem]=\"0.6 + ph.depth * 0.9\">\n        <span class=\"placeholder-label\">{{ ph.label }}</span>\n        @if (ph.showPath) {\n        <span class=\"placeholder-path\">{{ ph.path }}</span>\n        }\n      </div>\n      } @else {\n      <button type=\"button\" class=\"placeholder-option\" role=\"option\" [attr.aria-label]=\"'Insert ' + ph.path\"\n        [attr.aria-selected]=\"false\" [attr.data-placeholder-key]=\"ph.key\"\n        [style.padding-left.rem]=\"0.6 + ph.depth * 0.9\" (mousedown)=\"$event.preventDefault()\"\n        (click)=\"insertPlaceholder(ph)\">\n        <span class=\"placeholder-label\">{{ ph.label }}</span>\n        @if (ph.showPath) {\n        <span class=\"placeholder-path\">{{ ph.path }}</span>\n        }\n      </button>\n      }\n      }\n      }\n      @if (placeholderPickerGroups().length === 0) {\n      <div class=\"placeholder-empty\">No matches</div>\n      }\n      }\n      @if (templateBlockProviderItems().length > 0) {\n      <div class=\"placeholder-category\">Blocks</div>\n      @for (block of templateBlockProviderItems(); track block.id) {\n      <button type=\"button\" class=\"placeholder-option block-option\" role=\"option\"\n        [attr.aria-label]=\"'Insert ' + block.label\" [attr.aria-selected]=\"false\"\n        [attr.data-template-block-name]=\"block.id\" (mousedown)=\"$event.preventDefault()\"\n        (click)=\"insertTemplateBlockFromPicker(block.id, $event)\">\n        @if (block.icon) {\n        <ui-icon [svg]=\"block.icon\" [size]=\"14\" />\n        }\n        <span class=\"placeholder-label\">{{ block.label }}</span>\n      </button>\n      }\n      }\n    </div>\n    }\n  </div>\n  }\n\n  <!-- Emoji picker -->\n  @if (!isCompactPresentation()) {\n  <ui-separator-tool id=\"sep-emoji\" />\n  <div class=\"emoji-picker-wrapper\">\n    <button type=\"button\" class=\"tool-btn\" aria-label=\"Insert emoji\" title=\"Insert emoji\"\n      [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isEmojiPickerOpen()\" (mousedown)=\"$event.preventDefault()\"\n      (click)=\"toggleEmojiPicker()\">\n      <ui-icon [svg]=\"emojiIcon\" [size]=\"16\" />\n    </button>\n\n    @if (isEmojiPickerOpen()) {\n    <div class=\"emoji-picker-dropdown\">\n      <ui-emoji-picker [categories]=\"emojiCategories()\" (emojiSelected)=\"insertEmoji($event)\" />\n    </div>\n    }\n  </div>\n  }\n\n  <!-- Source toggle (HTML mode only) -->\n  @if (!isCompactPresentation() && !isMarkdownMode()) {\n  <ui-separator-tool id=\"sep-source\" />\n  <ui-toggle-tool id=\"source-mode\" [icon]=\"sourceIcon\" [ariaLabel]=\"sourceToggleLabel()\" [checked]=\"isSourceMode()\"\n    [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Split-direction toggle + preview toggle + validity indicator (Markdown mode only) -->\n  @if (isMarkdownMode()) {\n  @if (!isCompactPresentation()) {\n  <ui-spacer-tool id=\"spacer-before-md-tools\" />\n  <ui-button-tool id=\"split-direction\"\n    [icon]=\"effectiveSplitDirection() === 'horizontal' ? teIcons.SplitVertical : teIcons.SplitHorizontal\"\n    [ariaLabel]=\"effectiveSplitDirection() === 'horizontal' ? 'Switch to vertical split' : 'Switch to side-by-side split'\" />\n  <ui-separator-tool id=\"sep-preview\" />\n  }\n  <ui-toggle-tool id=\"toggle-preview\" [icon]=\"showMarkdownPreview() ? teIcons.PreviewShow : teIcons.PreviewHide\"\n    [ariaLabel]=\"showMarkdownPreview() ? 'Hide preview' : 'Show preview'\" [checked]=\"showMarkdownPreview()\" />\n  @if (!isCompactPresentation()) {\n  <ui-separator-tool id=\"sep-validity\" />\n  <ui-icon class=\"markdown-validity-indicator\" [class.valid]=\"isValidMarkdown()\" [class.invalid]=\"!isValidMarkdown()\"\n    [svg]=\"isValidMarkdown() ? teIcons.ValidMarkdown : teIcons.InvalidMarkdown\" [size]=\"16\"\n    [attr.aria-label]=\"isValidMarkdown() ? 'Valid markdown' : 'Empty \u2014 no markdown content'\" role=\"img\" />\n  }\n  }\n\n  <!-- Fullscreen toggle \u2014 pushed to the right by the spacer -->\n  @if (!isCompactPresentation()) {\n  <ui-spacer-tool id=\"spacer-before-fullscreen\" />\n  <ui-button-tool id=\"fullscreen\" [icon]=\"isFullscreen() ? teIcons.ExitFullscreen : teIcons.Fullscreen\"\n    [ariaLabel]=\"isFullscreen() ? 'Exit full screen' : 'Full screen'\" />\n  }\n\n</ui-toolbar>\n\n<!-- \u2500\u2500 HTML source textarea (HTML mode only) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n@if (!isMarkdownMode() && isSourceMode()) {\n<textarea class=\"source-editor\" [attr.aria-label]=\"ariaLabel() + ' (HTML source)'\" [value]=\"value()\"\n  [disabled]=\"disabled()\" [readOnly]=\"readonly()\" (input)=\"onSourceInput($event)\" (focus)=\"onEditorFocus()\"\n  (blur)=\"onEditorBlur()\" spellcheck=\"false\"></textarea>\n<div class=\"preview-label\" aria-hidden=\"true\">Preview</div>\n}\n\n<!-- \u2500\u2500 Markdown textarea + split handle (Markdown mode) \u2500\u2500\u2500\u2500 -->\n@if (isMarkdownMode()) {\n<textarea #mdTextarea class=\"source-editor markdown-editor\" [attr.aria-label]=\"ariaLabel()\" [value]=\"value()\"\n  [disabled]=\"disabled()\" [readOnly]=\"readonly()\" [attr.data-placeholder]=\"placeholder()\"\n  [attr.placeholder]=\"placeholder()\" (input)=\"onSourceInput($event)\" (focus)=\"onEditorFocus()\" (blur)=\"onEditorBlur()\"\n  (paste)=\"onEditorPaste($event)\" (keydown)=\"onEditorKeydown($event)\" spellcheck=\"true\"></textarea>\n<div class=\"split-handle\" role=\"separator\" aria-label=\"Resize panes\" [hidden]=\"!showMarkdownPreview()\"\n  (pointerdown)=\"onSplitPointerDown($event)\"></div>\n}\n\n<!-- \u2500\u2500 WYSIWYG editor / markdown preview \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n<div class=\"editor-wrapper\" [class.editor-wrapper--focused]=\"isFocused() && !isSourceMode() && !isMarkdownMode()\"\n  [class.editor-wrapper--preview]=\"isSourceMode() || isMarkdownMode()\"\n  [hidden]=\"isMarkdownMode() && !showMarkdownPreview()\">\n  @if (isMarkdownMode() && showMarkdownPreview()) {\n  <div class=\"preview-label\" aria-hidden=\"true\">Preview</div>\n  <ui-rich-text-view class=\"markdown-preview\" [content]=\"markdownPreviewHtml()\" strategy=\"html\"\n    [ariaLabel]=\"ariaLabel() + ' (preview)'\" />\n  }\n  <!-- #editorEl must remain in the DOM \u2014 it is required by viewChild.required -->\n  <div #editorEl class=\"editor\" [hidden]=\"isMarkdownMode()\" role=\"textbox\" tabindex=\"0\" aria-multiline=\"true\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.contenteditable]=\"!disabled() && !readonly() && !isSourceMode() && !isMarkdownMode()\"\n    [attr.data-placeholder]=\"placeholder()\" (input)=\"onEditorInput()\" (focus)=\"onEditorFocus()\" (blur)=\"onEditorBlur()\"\n    (mousedown)=\"onEditorMouseDown($event)\" (click)=\"onEditorClick($event)\" (paste)=\"onEditorPaste($event)\"\n    (keydown)=\"onEditorKeydown($event)\"></div>\n</div>\n\n<!-- \u2500\u2500 Character count footer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n@if (maxLength(); as max) {\n<div class=\"footer\" [class.footer--over]=\"isOverMaxLength()\" aria-live=\"polite\">\n  <span class=\"char-count\">{{ charCount() }} / {{ max }}</span>\n</div>\n}", styles: ["@charset \"UTF-8\";:host{--rich-text-text: var(--ui-text);--rich-text-muted: var(--ui-text-muted);--rich-text-surface: var(--ui-surface);--rich-text-surface-2: var(--ui-surface-2);--rich-text-hover: var(--ui-hover-bg);--rich-text-border: var(--ui-border);--rich-text-border-strong: var(--ui-border-strong);--rich-text-accent: var(--ui-accent);--rich-text-primary-container: var(--ui-primary-container);--rich-text-shadow: var(--ui-shadow-dropdown);--rich-text-error: var(--ui-error);--rich-text-success: var(--ui-success);--rich-text-warning: var(--ui-warning);--rich-text-focus: var(--ui-focus-ring, var(--ui-accent));--rich-text-cursor: var(--ui-cursor-click, pointer);display:flex;flex-direction:column;min-height:0;font-family:var(--ui-font, inherit);font-size:var(--ui-font-body, .875rem)}:host.compact{position:relative}ui-toolbar{align-self:stretch;border-radius:var(--ui-radius, .375rem) var(--ui-radius, .375rem) 0 0;border:1px solid var(--rich-text-border);flex-wrap:wrap;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep ui-toolbar .toolbar-shell{overflow:visible}:host.compact ui-toolbar{align-self:auto;border:none;border-radius:0;background:transparent;z-index:20}.tool-btn{appearance:none;cursor:var(--rich-text-cursor);font-family:inherit;font-size:.8125rem;font-weight:600;padding:.25rem;border-radius:.2rem;min-width:1.75rem;min-height:1.75rem;display:inline-flex;align-items:center;justify-content:center;line-height:1;color:var(--rich-text-text);background:transparent;border:1px solid transparent;transition:background-color .1s ease,border-color .1s ease}.tool-btn:hover:not(:disabled){background:var(--rich-text-hover)}.tool-btn:disabled{opacity:.4;cursor:not-allowed}.tool-btn:focus-visible{outline:2px solid var(--rich-text-focus);outline-offset:-1px}.placeholder-trigger{font-weight:400;letter-spacing:0}.placeholder-picker{position:relative;display:inline-flex}.placeholder-dropdown{position:absolute;top:100%;left:0;z-index:110;min-width:12rem;max-height:16rem;overflow-y:auto;margin-top:.25rem;padding:.25rem 0;border-radius:.25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);box-shadow:var(--rich-text-shadow)}.placeholder-category{padding:.35rem .6rem .15rem;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--rich-text-muted);background:transparent}.placeholder-group{display:flex;flex-direction:column;gap:.05rem;padding:.35rem .6rem;font-family:inherit;font-size:.8125rem;color:var(--rich-text-muted);background:transparent}.placeholder-option{appearance:none;border:none;display:flex;flex-direction:column;gap:.05rem;width:100%;text-align:left;padding:.35rem .6rem;font-family:inherit;font-size:.8125rem;cursor:var(--ui-cursor-click, pointer);color:var(--rich-text-text);background:transparent;transition:background-color 80ms ease}.placeholder-option:hover{background:var(--rich-text-hover)}.placeholder-option:focus-visible{outline-offset:-2px}.block-option{align-items:center;flex-direction:row;gap:.45rem}.placeholder-label{font-weight:600}.placeholder-path{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:.6875rem;font-weight:400;color:var(--rich-text-muted);background:transparent}.table-picker-wrapper{position:relative;display:inline-flex}.table-picker-dropdown{position:absolute;top:100%;left:0;z-index:110;margin-top:.25rem;padding:.45rem;border-radius:.25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);box-shadow:var(--rich-text-shadow)}.table-size-label{min-width:8.5rem;margin-bottom:.4rem;font-size:.75rem;font-weight:600;color:var(--rich-text-muted);background:transparent}.table-size-row{display:flex;gap:.2rem}.table-size-row+.table-size-row{margin-top:.2rem}.table-size-cell{appearance:none;width:1.15rem;height:1.15rem;padding:0;cursor:var(--ui-cursor-click, pointer);border-radius:.15rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}.table-size-cell.active{color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-color:var(--rich-text-accent)}.table-size-cell:focus-visible{outline-offset:1px}.emoji-picker-wrapper{position:relative;display:inline-flex}.emoji-picker-dropdown{position:absolute;top:100%;right:0;z-index:110;margin-top:.25rem}.editor-wrapper{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column;border-radius:0 0 .25rem .25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);border-top:none;transition:border-color .12s ease,box-shadow .12s ease,background-color .12s ease}.editor-wrapper:focus-within{border-color:var(--rich-text-accent);background:color-mix(in srgb,var(--rich-text-accent) 3%,var(--rich-text-surface));box-shadow:0 0 0 3px color-mix(in srgb,var(--rich-text-accent) 18%,transparent)}.editor-wrapper[hidden],.split-handle[hidden],.editor[hidden]{display:none!important}:host.compact .editor-wrapper{border-top:1px solid var(--rich-text-border);border-radius:calc(var(--ui-radius, .375rem) * 1.6)}.editor{flex:1;min-height:8rem;padding:.5rem .6rem;line-height:1.5;outline:none;overflow-y:auto}.editor::selection{color:var(--rich-text-text);background:color-mix(in srgb,var(--rich-text-accent) 28%,transparent)}.editor:empty:before{content:attr(data-placeholder);color:var(--rich-text-muted);pointer-events:none}.editor h1{font-size:1.5em;font-weight:700;margin:.4em 0 .2em}.editor h2{font-size:1.25em;font-weight:600;margin:.35em 0 .2em}.editor h3{font-size:1.1em;font-weight:600;margin:.3em 0 .15em}.editor ul,.editor ol{margin:.25em 0;padding-left:1.5em}.editor p{margin:.2em 0}.editor blockquote{margin:.4em 0;padding:.3em .8em;font-style:italic;border-left:3px solid var(--rich-text-accent);background:var(--rich-text-hover);border-radius:0 .2rem .2rem 0}.editor pre{margin:.4em 0;padding:.5em .6em;border-radius:.25rem;font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.85em;line-height:1.45;white-space:pre-wrap;word-break:break-all;overflow-x:auto;color:var(--rich-text-text);background:var(--rich-text-surface-2)}.editor a{color:var(--rich-text-accent);text-decoration:underline;text-underline-offset:.15em;cursor:var(--ui-cursor-click, pointer);word-break:break-all}.editor a:hover{text-decoration-thickness:2px}:host ::ng-deep .editor table{width:100%;margin:.45em 0;border-collapse:collapse;table-layout:auto;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border-strong)}:host ::ng-deep .editor th,:host ::ng-deep .editor td{min-width:4rem;padding:.35rem .45rem;vertical-align:top;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border-strong)}:host ::ng-deep .editor th{font-weight:700;color:var(--rich-text-text);background:var(--rich-text-surface-2)}:host.compact .editor{min-height:5.5rem;padding:.7rem .85rem}:host ::ng-deep .rte-placeholder{display:inline-block;padding:.05rem .4rem;margin:0 .1rem;border-radius:.75rem;font-size:.8125em;font-weight:500;white-space:nowrap;-webkit-user-select:all;user-select:all;vertical-align:baseline;line-height:1.4;cursor:default;color:var(--rich-text-accent);background:var(--rich-text-primary-container)}:host ::ng-deep .rte-placeholder:before{content:\"<\";opacity:.5}:host ::ng-deep .rte-placeholder:after{content:\" />\";opacity:.5}:host ::ng-deep .rte-caret-edge{display:inline;inline-size:0;min-height:0;overflow:visible;white-space:pre;-webkit-user-select:text;user-select:text;color:transparent;caret-color:var(--rich-text-text);background:transparent;line-height:inherit;vertical-align:baseline}:host ::ng-deep .rte-caret-edge[data-rte-caret-edge-display=block]{display:block;block-size:0;min-height:0;line-height:inherit}:host ::ng-deep .rte-template-block.block{display:block;margin:.5rem 0;border:1px solid var(--rich-text-border);border-radius:.35rem;overflow:hidden;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep .rte-template-block.block>.header{display:block;padding:.25rem .5rem;font-size:.75rem;font-weight:600;color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-bottom:1px solid var(--rich-text-border)}:host ::ng-deep .rte-template-block.block>.content{min-height:1.5rem;padding:.45rem .55rem;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block{color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block>td{padding:.35rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}:host ::ng-deep tr.rte-template-block.table-row-block .shell{overflow:hidden;border:1px solid var(--rich-text-border);border-radius:.35rem;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block .header{display:block;padding:.25rem .5rem;font-size:.75rem;font-weight:600;cursor:var(--ui-cursor-click, pointer);color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-bottom:1px solid var(--rich-text-border)}:host ::ng-deep tr.rte-template-block.table-row-block .table-content{width:100%;border-collapse:collapse;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block .content{min-height:1.5rem;color:var(--rich-text-text);background:var(--rich-text-surface)}.toolbar-btn--active{color:var(--rich-text-accent);background:var(--rich-text-primary-container)}.toolbar-btn--active:hover:not(:disabled){opacity:.9}.source-editor{display:block;width:100%;min-height:8rem;padding:.5rem .6rem;border:none;border-bottom:1px solid var(--rich-text-border);border-radius:0;font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.8125rem;line-height:1.5;resize:vertical;outline:none;box-sizing:border-box;color:var(--rich-text-text);background:var(--rich-text-surface);transition:border-color .12s ease;tab-size:2;white-space:pre;overflow-x:auto}.source-editor::selection{color:var(--rich-text-text);background:color-mix(in srgb,var(--rich-text-accent) 28%,transparent)}.source-editor:disabled{opacity:.5;cursor:not-allowed}:host.compact .source-editor{min-height:5.5rem;border:1px solid var(--rich-text-border);border-radius:calc(var(--ui-radius, .375rem) * 1.6)}:host.compact.markdown .source-editor{border-bottom:1px solid var(--rich-text-border)}.preview-label{padding:.15rem .5rem;font-size:.625rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--rich-text-muted);background:var(--rich-text-surface-2)}.editor-wrapper--preview{opacity:.75;pointer-events:none}.editor-wrapper--preview .editor{min-height:4rem;cursor:default}.editor-wrapper--preview .markdown-preview{flex:1;overflow:auto;padding:.5rem;min-height:4rem}:host.disabled .toolbar{opacity:.5;pointer-events:none}:host.disabled .editor-wrapper{opacity:.5;pointer-events:none}:host.readonly .toolbar{opacity:.6}:host.readonly .editor{cursor:default}:host.markdown .markdown-editor{min-height:12rem;border:none;border-bottom:1px solid var(--rich-text-border);font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.8125rem;line-height:1.6;tab-size:4;white-space:pre-wrap;word-wrap:break-word;color:var(--rich-text-text);background:var(--rich-text-surface)}:host.markdown .editor-wrapper--preview{opacity:1;pointer-events:none}:host.markdown .editor-wrapper--preview .editor{min-height:4rem;cursor:default}:host.markdown .editor-wrapper--preview .markdown-preview{flex:1;min-height:0;overflow-y:auto;padding:.5rem;pointer-events:auto}:host.compact.markdown .markdown-editor{min-height:5.5rem}:host.compact.markdown .editor-wrapper{margin-top:.5rem}.placeholder-search{padding:.25rem}.placeholder-search-input{width:100%;box-sizing:border-box;padding:.25rem .5rem;font-size:.75rem;font-family:inherit;border-radius:.2rem;outline:none;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}.placeholder-search-input:focus{border-color:var(--rich-text-accent)}.placeholder-empty{padding:.5rem .75rem;font-size:.75rem;font-style:italic;color:var(--rich-text-muted);background:transparent}.footer{display:flex;justify-content:flex-end;padding:.125rem .5rem;border-top:1px solid var(--rich-text-border);border-radius:0 0 .25rem .25rem;font-size:.6875rem;color:var(--rich-text-muted);background:var(--rich-text-surface)}.footer--over .char-count{font-weight:600;color:var(--rich-text-error)}.char-count{font-variant-numeric:tabular-nums}.markdown-validity-indicator{display:inline-flex;align-items:center;align-self:center;padding:0 .25rem;flex-shrink:0}.markdown-validity-indicator.valid{color:var(--rich-text-success)}.markdown-validity-indicator.invalid{color:var(--rich-text-warning)}.split-handle{flex:0 0 5px;background:var(--rich-text-border);touch-action:none;transition:background .12s ease}.split-handle:hover,.split-handle:active{background:var(--rich-text-accent)}:host.markdown.split-vertical{display:flex;flex-direction:column}:host.markdown.split-vertical .markdown-editor{flex:1 1 50%;min-height:6rem;resize:none;border-bottom:none}:host.markdown.split-vertical .split-handle{cursor:row-resize;width:100%;height:5px}:host.markdown.split-vertical .editor-wrapper{flex:1 1 50%;min-height:4rem;overflow-y:auto;border-top:1px solid var(--rich-text-border)}:host.markdown.split-horizontal{display:grid;grid-template-columns:1fr 5px 1fr;grid-template-rows:auto 1fr auto}:host.markdown.split-horizontal>ui-toolbar,:host.markdown.split-horizontal>.footer{grid-column:1/-1}:host.markdown.split-horizontal>.markdown-editor{grid-column:1;grid-row:2;min-height:0;resize:none;border-bottom:none;border-right:1px solid var(--rich-text-border)}:host.markdown.split-horizontal>.split-handle{grid-column:2;grid-row:2;cursor:col-resize;width:5px;height:auto;align-self:stretch}:host.markdown.split-horizontal>.editor-wrapper{grid-column:3;grid-row:2;min-height:0;overflow-y:auto;border-top:1px solid var(--rich-text-border)}:host.markdown.split-horizontal>.footer{grid-row:3}:host.fullscreen{position:fixed;inset:0;z-index:1000;border-radius:0;overflow:hidden;color:var(--rich-text-text);background:var(--rich-text-surface)}:host.fullscreen .editor-wrapper{overflow-y:auto;border-radius:0}:host.fullscreen .editor-wrapper .editor{min-height:100%}:host.fullscreen .source-editor{resize:none}:host.fullscreen.split-vertical{display:flex;flex-direction:column}:host.fullscreen.split-vertical .markdown-editor{flex:1 1 50%}:host.fullscreen.split-vertical .editor-wrapper{flex:1 1 50%}:host.fullscreen.split-horizontal{height:100%;grid-template-rows:auto 1fr auto}\n"], dependencies: [{ kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }, { kind: "component", type: UIEmojiPicker, selector: "ui-emoji-picker", inputs: ["categories", "emojiSearchTerms", "searchPlaceholder", "ariaLabel", "previewSize"], outputs: ["emojiSelected"] }, { kind: "component", type: UIToolbar, selector: "ui-toolbar", inputs: ["orientation", "displayMode", "ariaLabel", "collapsed"], outputs: ["collapsedChange", "toolAction"] }, { kind: "component", type: UIButtonTool, selector: "ui-button-tool" }, { kind: "component", type: UIToggleTool, selector: "ui-toggle-tool", inputs: ["checked"], outputs: ["checkedChange"] }, { kind: "component", type: UISeparatorTool, selector: "ui-separator-tool" }, { kind: "component", type: UISpacerTool, selector: "ui-spacer-tool" }, { kind: "component", type: UIDropdownTool, selector: "ui-dropdown-tool", inputs: ["items", "displayMode"] }, { kind: "component", type: UIButtonGroupTool, selector: "ui-button-group-tool" }, { kind: "component", type: UIToggleGroupTool, selector: "ui-toggle-group-tool" }, { kind: "component", type: UIRichTextView, selector: "ui-rich-text-view", inputs: ["content", "strategy", "ariaLabel", "dataDetectors"], outputs: ["contentChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIRichTextEditor, decorators: [{
            type: Component,
            args: [{ selector: "ui-rich-text-editor", standalone: true, imports: [
                        UIIcon,
                        UIEmojiPicker,
                        UIToolbar,
                        UIButtonTool,
                        UIToggleTool,
                        UISeparatorTool,
                        UISpacerTool,
                        UIDropdownTool,
                        UIButtonGroupTool,
                        UIToggleGroupTool,
                        UIRichTextView,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-rich-text-editor",
                        "[class.disabled]": "disabled()",
                        "[class.readonly]": "readonly()",
                        "[class.markdown]": "mode() === 'markdown'",
                        "[class.compact]": "presentation() === 'compact'",
                        "[class.fullscreen]": "isFullscreen()",
                        "[class.split-horizontal]": "isMarkdownMode() && effectiveSplitDirection() === 'horizontal'",
                        "[class.split-vertical]": "isMarkdownMode() && effectiveSplitDirection() === 'vertical'",
                    }, template: "<!-- \u2500\u2500 Toolbar \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n<ui-toolbar role=\"toolbar\" aria-label=\"Formatting\" [displayMode]=\"toolbarDisplayMode()\"\n  [collapsed]=\"isCompactToolbarCollapsed()\" (collapsedChange)=\"onToolbarCollapsedChange($event)\"\n  (toolAction)=\"onToolAction($event)\">\n\n  <!-- History: Undo / Redo -->\n  @if (showHistoryGroup()) {\n  <ui-button-group-tool id=\"history\">\n    @if (hasToolbarAction('undo')) {\n    <ui-button-tool id=\"undo\" [icon]=\"teIcons.Undo\" ariaLabel=\"Undo\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('redo')) {\n    <ui-button-tool id=\"redo\" [icon]=\"teIcons.Redo\" ariaLabel=\"Redo\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  <ui-separator-tool id=\"sep-history\" />\n  }\n\n  <!-- Inline: Bold / Italic / Underline / Strikethrough -->\n  @if (showInlineGroup()) {\n  <ui-button-group-tool id=\"inline\">\n    @if (hasToolbarAction('bold')) {\n    <ui-toggle-tool id=\"bold\" [icon]=\"teIcons.Bold\" ariaLabel=\"Bold\" [checked]=\"isActionActive('bold')\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('italic')) {\n    <ui-toggle-tool id=\"italic\" [icon]=\"teIcons.Italic\" ariaLabel=\"Italic\" [checked]=\"isActionActive('italic')\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('underline')) {\n    <ui-toggle-tool id=\"underline\" [icon]=\"teIcons.Underline\" ariaLabel=\"Underline\"\n      [checked]=\"isActionActive('underline')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('strikethrough')) {\n    <ui-toggle-tool id=\"strikethrough\" [icon]=\"teIcons.Strikethrough\" ariaLabel=\"Strikethrough\"\n      [checked]=\"isActionActive('strikethrough')\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  <ui-separator-tool id=\"sep-inline\" />\n  }\n\n  <!-- Block styles (dropdown) -->\n  @if (blockDropdownItems().length > 0) {\n  <ui-dropdown-tool id=\"block\" [icon]=\"teIcons.Styles\" ariaLabel=\"Styles\" [items]=\"blockDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Lists (dropdown) -->\n  @if (listDropdownItems().length > 0) {\n  <ui-dropdown-tool id=\"list\" [icon]=\"teIcons.List\" ariaLabel=\"Lists\" [items]=\"listDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Alignment (radio-style, HTML mode only) -->\n  @if (!isMarkdownMode() && showAlignGroup()) {\n  <ui-separator-tool id=\"sep-align-before\" />\n  <ui-toggle-group-tool id=\"align\" aria-label=\"Alignment\">\n    @if (hasToolbarAction('alignLeft')) {\n    <ui-toggle-tool id=\"alignLeft\" [icon]=\"teIcons.AlignLeft\" ariaLabel=\"Align left\"\n      [checked]=\"isActionActive('alignLeft')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignCenter')) {\n    <ui-toggle-tool id=\"alignCenter\" [icon]=\"teIcons.AlignCenter\" ariaLabel=\"Align centre\"\n      [checked]=\"isActionActive('alignCenter')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignRight')) {\n    <ui-toggle-tool id=\"alignRight\" [icon]=\"teIcons.AlignRight\" ariaLabel=\"Align right\"\n      [checked]=\"isActionActive('alignRight')\" [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('alignJustify')) {\n    <ui-toggle-tool id=\"alignJustify\" [icon]=\"teIcons.AlignJustify\" ariaLabel=\"Justify\"\n      [checked]=\"isActionActive('alignJustify')\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-toggle-group-tool>\n  <ui-separator-tool id=\"sep-align-after\" />\n  }\n\n  <!-- Insert: Horizontal rule / Image -->\n  @if (showInsertGroup()) {\n  @if (hasToolbarAction('horizontalRule') || hasToolbarAction('image')) {\n  <ui-button-group-tool id=\"insert\">\n    @if (hasToolbarAction('horizontalRule')) {\n    <ui-button-tool id=\"horizontalRule\" [icon]=\"teIcons.HorizontalRule\" ariaLabel=\"Horizontal rule\"\n      [disabled]=\"isEditorDisabled()\" />\n    }\n    @if (hasToolbarAction('image')) {\n    <ui-button-tool id=\"image\" [icon]=\"teIcons.Image\" ariaLabel=\"Insert image\" [disabled]=\"isEditorDisabled()\" />\n    }\n  </ui-button-group-tool>\n  }\n  @if (hasToolbarAction('insertTable')) {\n  <div class=\"table-picker-wrapper\">\n    <button type=\"button\" class=\"tool-btn\" aria-label=\"Insert table\" title=\"Insert table\" tabindex=\"-1\"\n      [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isTablePickerOpen()\" (mousedown)=\"$event.preventDefault()\"\n      (click)=\"toggleTablePicker()\">\n      <ui-icon [svg]=\"teIcons.Table\" [size]=\"16\" />\n    </button>\n\n    @if (isTablePickerOpen()) {\n    <div class=\"table-picker-dropdown\" role=\"grid\" aria-label=\"Choose table size\" (mousedown)=\"$event.preventDefault()\">\n      <div class=\"table-size-label\">{{ tablePickerSizeLabel() }}</div>\n      @for (row of tablePickerRowOptions; track row) {\n      <div class=\"table-size-row\" role=\"row\">\n        @for (col of tablePickerColumnOptions; track col) {\n        <button type=\"button\" class=\"table-size-cell\" role=\"gridcell\" tabindex=\"-1\"\n          [class.active]=\"isTablePickerCellActive(row, col)\" [attr.aria-label]=\"col + ' columns, ' + row + ' rows'\"\n          (mouseenter)=\"setTablePickerSize(row, col)\" (focus)=\"setTablePickerSize(row, col)\"\n          (click)=\"insertSelectedTable()\"></button>\n        }\n      </div>\n      }\n    </div>\n    }\n  </div>\n  }\n  @if (!isMarkdownMode() && canEditActiveTable()) {\n  <ui-dropdown-tool id=\"table\" [icon]=\"teIcons.Table\" ariaLabel=\"Table options\" [items]=\"tableDropdownItems()\"\n    displayMode=\"list\" [disabled]=\"isEditorDisabled() || tableDropdownItems().length === 0\" />\n  }\n  <ui-separator-tool id=\"sep-insert\" />\n  }\n  <!-- Link -->\n  @if (hasToolbarAction('link')) {\n  <ui-button-tool id=\"link\" [icon]=\"teIcons.Link\" ariaLabel=\"Hyperlink\" [disabled]=\"isEditorDisabled()\" />\n  <ui-separator-tool id=\"sep-link\" />\n  }\n\n  <!-- Remove formatting -->\n  @if (hasToolbarAction('removeFormat')) {\n  <ui-button-tool id=\"removeFormat\" [icon]=\"teIcons.RemoveFormat\" ariaLabel=\"Clear formatting\"\n    [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Template insert picker -->\n  @if (!isCompactPresentation() && hasTemplateInsertItems()) {\n  <ui-separator-tool id=\"sep-placeholder\" />\n  <div class=\"placeholder-picker\">\n    <button type=\"button\" class=\"tool-btn placeholder-trigger\" aria-label=\"Insert template block\"\n      title=\"Insert template block\" [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isPlaceholderPickerOpen()\"\n      (mousedown)=\"$event.preventDefault()\" (click)=\"togglePlaceholderPicker()\">\n      <ui-icon [svg]=\"sourceIcon\" [size]=\"16\" />\n    </button>\n\n    @if (isPlaceholderPickerOpen()) {\n    <div class=\"placeholder-dropdown\" role=\"listbox\" aria-label=\"Available template blocks\">\n      @if (hasPlaceholderPickerItems()) {\n      <div class=\"placeholder-search\">\n        <input type=\"text\" class=\"placeholder-search-input\" placeholder=\"Search placeholders\u2026\"\n          aria-label=\"Filter placeholders\" (input)=\"onPlaceholderSearch($event)\"\n          (mousedown)=\"$event.stopPropagation()\" />\n      </div>\n      @for (group of placeholderPickerGroups(); track group.category) {\n      @if (group.category) {\n      <div class=\"placeholder-category\">{{ group.category }}</div>\n      }\n      @for (ph of group.items; track ph.id) {\n      @if (ph.isGroup) {\n      <div class=\"placeholder-group\" role=\"presentation\" [style.padding-left.rem]=\"0.6 + ph.depth * 0.9\">\n        <span class=\"placeholder-label\">{{ ph.label }}</span>\n        @if (ph.showPath) {\n        <span class=\"placeholder-path\">{{ ph.path }}</span>\n        }\n      </div>\n      } @else {\n      <button type=\"button\" class=\"placeholder-option\" role=\"option\" [attr.aria-label]=\"'Insert ' + ph.path\"\n        [attr.aria-selected]=\"false\" [attr.data-placeholder-key]=\"ph.key\"\n        [style.padding-left.rem]=\"0.6 + ph.depth * 0.9\" (mousedown)=\"$event.preventDefault()\"\n        (click)=\"insertPlaceholder(ph)\">\n        <span class=\"placeholder-label\">{{ ph.label }}</span>\n        @if (ph.showPath) {\n        <span class=\"placeholder-path\">{{ ph.path }}</span>\n        }\n      </button>\n      }\n      }\n      }\n      @if (placeholderPickerGroups().length === 0) {\n      <div class=\"placeholder-empty\">No matches</div>\n      }\n      }\n      @if (templateBlockProviderItems().length > 0) {\n      <div class=\"placeholder-category\">Blocks</div>\n      @for (block of templateBlockProviderItems(); track block.id) {\n      <button type=\"button\" class=\"placeholder-option block-option\" role=\"option\"\n        [attr.aria-label]=\"'Insert ' + block.label\" [attr.aria-selected]=\"false\"\n        [attr.data-template-block-name]=\"block.id\" (mousedown)=\"$event.preventDefault()\"\n        (click)=\"insertTemplateBlockFromPicker(block.id, $event)\">\n        @if (block.icon) {\n        <ui-icon [svg]=\"block.icon\" [size]=\"14\" />\n        }\n        <span class=\"placeholder-label\">{{ block.label }}</span>\n      </button>\n      }\n      }\n    </div>\n    }\n  </div>\n  }\n\n  <!-- Emoji picker -->\n  @if (!isCompactPresentation()) {\n  <ui-separator-tool id=\"sep-emoji\" />\n  <div class=\"emoji-picker-wrapper\">\n    <button type=\"button\" class=\"tool-btn\" aria-label=\"Insert emoji\" title=\"Insert emoji\"\n      [disabled]=\"isEditorDisabled()\" [attr.aria-expanded]=\"isEmojiPickerOpen()\" (mousedown)=\"$event.preventDefault()\"\n      (click)=\"toggleEmojiPicker()\">\n      <ui-icon [svg]=\"emojiIcon\" [size]=\"16\" />\n    </button>\n\n    @if (isEmojiPickerOpen()) {\n    <div class=\"emoji-picker-dropdown\">\n      <ui-emoji-picker [categories]=\"emojiCategories()\" (emojiSelected)=\"insertEmoji($event)\" />\n    </div>\n    }\n  </div>\n  }\n\n  <!-- Source toggle (HTML mode only) -->\n  @if (!isCompactPresentation() && !isMarkdownMode()) {\n  <ui-separator-tool id=\"sep-source\" />\n  <ui-toggle-tool id=\"source-mode\" [icon]=\"sourceIcon\" [ariaLabel]=\"sourceToggleLabel()\" [checked]=\"isSourceMode()\"\n    [disabled]=\"isEditorDisabled()\" />\n  }\n\n  <!-- Split-direction toggle + preview toggle + validity indicator (Markdown mode only) -->\n  @if (isMarkdownMode()) {\n  @if (!isCompactPresentation()) {\n  <ui-spacer-tool id=\"spacer-before-md-tools\" />\n  <ui-button-tool id=\"split-direction\"\n    [icon]=\"effectiveSplitDirection() === 'horizontal' ? teIcons.SplitVertical : teIcons.SplitHorizontal\"\n    [ariaLabel]=\"effectiveSplitDirection() === 'horizontal' ? 'Switch to vertical split' : 'Switch to side-by-side split'\" />\n  <ui-separator-tool id=\"sep-preview\" />\n  }\n  <ui-toggle-tool id=\"toggle-preview\" [icon]=\"showMarkdownPreview() ? teIcons.PreviewShow : teIcons.PreviewHide\"\n    [ariaLabel]=\"showMarkdownPreview() ? 'Hide preview' : 'Show preview'\" [checked]=\"showMarkdownPreview()\" />\n  @if (!isCompactPresentation()) {\n  <ui-separator-tool id=\"sep-validity\" />\n  <ui-icon class=\"markdown-validity-indicator\" [class.valid]=\"isValidMarkdown()\" [class.invalid]=\"!isValidMarkdown()\"\n    [svg]=\"isValidMarkdown() ? teIcons.ValidMarkdown : teIcons.InvalidMarkdown\" [size]=\"16\"\n    [attr.aria-label]=\"isValidMarkdown() ? 'Valid markdown' : 'Empty \u2014 no markdown content'\" role=\"img\" />\n  }\n  }\n\n  <!-- Fullscreen toggle \u2014 pushed to the right by the spacer -->\n  @if (!isCompactPresentation()) {\n  <ui-spacer-tool id=\"spacer-before-fullscreen\" />\n  <ui-button-tool id=\"fullscreen\" [icon]=\"isFullscreen() ? teIcons.ExitFullscreen : teIcons.Fullscreen\"\n    [ariaLabel]=\"isFullscreen() ? 'Exit full screen' : 'Full screen'\" />\n  }\n\n</ui-toolbar>\n\n<!-- \u2500\u2500 HTML source textarea (HTML mode only) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n@if (!isMarkdownMode() && isSourceMode()) {\n<textarea class=\"source-editor\" [attr.aria-label]=\"ariaLabel() + ' (HTML source)'\" [value]=\"value()\"\n  [disabled]=\"disabled()\" [readOnly]=\"readonly()\" (input)=\"onSourceInput($event)\" (focus)=\"onEditorFocus()\"\n  (blur)=\"onEditorBlur()\" spellcheck=\"false\"></textarea>\n<div class=\"preview-label\" aria-hidden=\"true\">Preview</div>\n}\n\n<!-- \u2500\u2500 Markdown textarea + split handle (Markdown mode) \u2500\u2500\u2500\u2500 -->\n@if (isMarkdownMode()) {\n<textarea #mdTextarea class=\"source-editor markdown-editor\" [attr.aria-label]=\"ariaLabel()\" [value]=\"value()\"\n  [disabled]=\"disabled()\" [readOnly]=\"readonly()\" [attr.data-placeholder]=\"placeholder()\"\n  [attr.placeholder]=\"placeholder()\" (input)=\"onSourceInput($event)\" (focus)=\"onEditorFocus()\" (blur)=\"onEditorBlur()\"\n  (paste)=\"onEditorPaste($event)\" (keydown)=\"onEditorKeydown($event)\" spellcheck=\"true\"></textarea>\n<div class=\"split-handle\" role=\"separator\" aria-label=\"Resize panes\" [hidden]=\"!showMarkdownPreview()\"\n  (pointerdown)=\"onSplitPointerDown($event)\"></div>\n}\n\n<!-- \u2500\u2500 WYSIWYG editor / markdown preview \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n<div class=\"editor-wrapper\" [class.editor-wrapper--focused]=\"isFocused() && !isSourceMode() && !isMarkdownMode()\"\n  [class.editor-wrapper--preview]=\"isSourceMode() || isMarkdownMode()\"\n  [hidden]=\"isMarkdownMode() && !showMarkdownPreview()\">\n  @if (isMarkdownMode() && showMarkdownPreview()) {\n  <div class=\"preview-label\" aria-hidden=\"true\">Preview</div>\n  <ui-rich-text-view class=\"markdown-preview\" [content]=\"markdownPreviewHtml()\" strategy=\"html\"\n    [ariaLabel]=\"ariaLabel() + ' (preview)'\" />\n  }\n  <!-- #editorEl must remain in the DOM \u2014 it is required by viewChild.required -->\n  <div #editorEl class=\"editor\" [hidden]=\"isMarkdownMode()\" role=\"textbox\" tabindex=\"0\" aria-multiline=\"true\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.contenteditable]=\"!disabled() && !readonly() && !isSourceMode() && !isMarkdownMode()\"\n    [attr.data-placeholder]=\"placeholder()\" (input)=\"onEditorInput()\" (focus)=\"onEditorFocus()\" (blur)=\"onEditorBlur()\"\n    (mousedown)=\"onEditorMouseDown($event)\" (click)=\"onEditorClick($event)\" (paste)=\"onEditorPaste($event)\"\n    (keydown)=\"onEditorKeydown($event)\"></div>\n</div>\n\n<!-- \u2500\u2500 Character count footer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n@if (maxLength(); as max) {\n<div class=\"footer\" [class.footer--over]=\"isOverMaxLength()\" aria-live=\"polite\">\n  <span class=\"char-count\">{{ charCount() }} / {{ max }}</span>\n</div>\n}", styles: ["@charset \"UTF-8\";:host{--rich-text-text: var(--ui-text);--rich-text-muted: var(--ui-text-muted);--rich-text-surface: var(--ui-surface);--rich-text-surface-2: var(--ui-surface-2);--rich-text-hover: var(--ui-hover-bg);--rich-text-border: var(--ui-border);--rich-text-border-strong: var(--ui-border-strong);--rich-text-accent: var(--ui-accent);--rich-text-primary-container: var(--ui-primary-container);--rich-text-shadow: var(--ui-shadow-dropdown);--rich-text-error: var(--ui-error);--rich-text-success: var(--ui-success);--rich-text-warning: var(--ui-warning);--rich-text-focus: var(--ui-focus-ring, var(--ui-accent));--rich-text-cursor: var(--ui-cursor-click, pointer);display:flex;flex-direction:column;min-height:0;font-family:var(--ui-font, inherit);font-size:var(--ui-font-body, .875rem)}:host.compact{position:relative}ui-toolbar{align-self:stretch;border-radius:var(--ui-radius, .375rem) var(--ui-radius, .375rem) 0 0;border:1px solid var(--rich-text-border);flex-wrap:wrap;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep ui-toolbar .toolbar-shell{overflow:visible}:host.compact ui-toolbar{align-self:auto;border:none;border-radius:0;background:transparent;z-index:20}.tool-btn{appearance:none;cursor:var(--rich-text-cursor);font-family:inherit;font-size:.8125rem;font-weight:600;padding:.25rem;border-radius:.2rem;min-width:1.75rem;min-height:1.75rem;display:inline-flex;align-items:center;justify-content:center;line-height:1;color:var(--rich-text-text);background:transparent;border:1px solid transparent;transition:background-color .1s ease,border-color .1s ease}.tool-btn:hover:not(:disabled){background:var(--rich-text-hover)}.tool-btn:disabled{opacity:.4;cursor:not-allowed}.tool-btn:focus-visible{outline:2px solid var(--rich-text-focus);outline-offset:-1px}.placeholder-trigger{font-weight:400;letter-spacing:0}.placeholder-picker{position:relative;display:inline-flex}.placeholder-dropdown{position:absolute;top:100%;left:0;z-index:110;min-width:12rem;max-height:16rem;overflow-y:auto;margin-top:.25rem;padding:.25rem 0;border-radius:.25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);box-shadow:var(--rich-text-shadow)}.placeholder-category{padding:.35rem .6rem .15rem;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--rich-text-muted);background:transparent}.placeholder-group{display:flex;flex-direction:column;gap:.05rem;padding:.35rem .6rem;font-family:inherit;font-size:.8125rem;color:var(--rich-text-muted);background:transparent}.placeholder-option{appearance:none;border:none;display:flex;flex-direction:column;gap:.05rem;width:100%;text-align:left;padding:.35rem .6rem;font-family:inherit;font-size:.8125rem;cursor:var(--ui-cursor-click, pointer);color:var(--rich-text-text);background:transparent;transition:background-color 80ms ease}.placeholder-option:hover{background:var(--rich-text-hover)}.placeholder-option:focus-visible{outline-offset:-2px}.block-option{align-items:center;flex-direction:row;gap:.45rem}.placeholder-label{font-weight:600}.placeholder-path{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:.6875rem;font-weight:400;color:var(--rich-text-muted);background:transparent}.table-picker-wrapper{position:relative;display:inline-flex}.table-picker-dropdown{position:absolute;top:100%;left:0;z-index:110;margin-top:.25rem;padding:.45rem;border-radius:.25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);box-shadow:var(--rich-text-shadow)}.table-size-label{min-width:8.5rem;margin-bottom:.4rem;font-size:.75rem;font-weight:600;color:var(--rich-text-muted);background:transparent}.table-size-row{display:flex;gap:.2rem}.table-size-row+.table-size-row{margin-top:.2rem}.table-size-cell{appearance:none;width:1.15rem;height:1.15rem;padding:0;cursor:var(--ui-cursor-click, pointer);border-radius:.15rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}.table-size-cell.active{color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-color:var(--rich-text-accent)}.table-size-cell:focus-visible{outline-offset:1px}.emoji-picker-wrapper{position:relative;display:inline-flex}.emoji-picker-dropdown{position:absolute;top:100%;right:0;z-index:110;margin-top:.25rem}.editor-wrapper{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column;border-radius:0 0 .25rem .25rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border);border-top:none;transition:border-color .12s ease,box-shadow .12s ease,background-color .12s ease}.editor-wrapper:focus-within{border-color:var(--rich-text-accent);background:color-mix(in srgb,var(--rich-text-accent) 3%,var(--rich-text-surface));box-shadow:0 0 0 3px color-mix(in srgb,var(--rich-text-accent) 18%,transparent)}.editor-wrapper[hidden],.split-handle[hidden],.editor[hidden]{display:none!important}:host.compact .editor-wrapper{border-top:1px solid var(--rich-text-border);border-radius:calc(var(--ui-radius, .375rem) * 1.6)}.editor{flex:1;min-height:8rem;padding:.5rem .6rem;line-height:1.5;outline:none;overflow-y:auto}.editor::selection{color:var(--rich-text-text);background:color-mix(in srgb,var(--rich-text-accent) 28%,transparent)}.editor:empty:before{content:attr(data-placeholder);color:var(--rich-text-muted);pointer-events:none}.editor h1{font-size:1.5em;font-weight:700;margin:.4em 0 .2em}.editor h2{font-size:1.25em;font-weight:600;margin:.35em 0 .2em}.editor h3{font-size:1.1em;font-weight:600;margin:.3em 0 .15em}.editor ul,.editor ol{margin:.25em 0;padding-left:1.5em}.editor p{margin:.2em 0}.editor blockquote{margin:.4em 0;padding:.3em .8em;font-style:italic;border-left:3px solid var(--rich-text-accent);background:var(--rich-text-hover);border-radius:0 .2rem .2rem 0}.editor pre{margin:.4em 0;padding:.5em .6em;border-radius:.25rem;font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.85em;line-height:1.45;white-space:pre-wrap;word-break:break-all;overflow-x:auto;color:var(--rich-text-text);background:var(--rich-text-surface-2)}.editor a{color:var(--rich-text-accent);text-decoration:underline;text-underline-offset:.15em;cursor:var(--ui-cursor-click, pointer);word-break:break-all}.editor a:hover{text-decoration-thickness:2px}:host ::ng-deep .editor table{width:100%;margin:.45em 0;border-collapse:collapse;table-layout:auto;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border-strong)}:host ::ng-deep .editor th,:host ::ng-deep .editor td{min-width:4rem;padding:.35rem .45rem;vertical-align:top;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border-strong)}:host ::ng-deep .editor th{font-weight:700;color:var(--rich-text-text);background:var(--rich-text-surface-2)}:host.compact .editor{min-height:5.5rem;padding:.7rem .85rem}:host ::ng-deep .rte-placeholder{display:inline-block;padding:.05rem .4rem;margin:0 .1rem;border-radius:.75rem;font-size:.8125em;font-weight:500;white-space:nowrap;-webkit-user-select:all;user-select:all;vertical-align:baseline;line-height:1.4;cursor:default;color:var(--rich-text-accent);background:var(--rich-text-primary-container)}:host ::ng-deep .rte-placeholder:before{content:\"<\";opacity:.5}:host ::ng-deep .rte-placeholder:after{content:\" />\";opacity:.5}:host ::ng-deep .rte-caret-edge{display:inline;inline-size:0;min-height:0;overflow:visible;white-space:pre;-webkit-user-select:text;user-select:text;color:transparent;caret-color:var(--rich-text-text);background:transparent;line-height:inherit;vertical-align:baseline}:host ::ng-deep .rte-caret-edge[data-rte-caret-edge-display=block]{display:block;block-size:0;min-height:0;line-height:inherit}:host ::ng-deep .rte-template-block.block{display:block;margin:.5rem 0;border:1px solid var(--rich-text-border);border-radius:.35rem;overflow:hidden;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep .rte-template-block.block>.header{display:block;padding:.25rem .5rem;font-size:.75rem;font-weight:600;color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-bottom:1px solid var(--rich-text-border)}:host ::ng-deep .rte-template-block.block>.content{min-height:1.5rem;padding:.45rem .55rem;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block{color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block>td{padding:.35rem;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}:host ::ng-deep tr.rte-template-block.table-row-block .shell{overflow:hidden;border:1px solid var(--rich-text-border);border-radius:.35rem;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block .header{display:block;padding:.25rem .5rem;font-size:.75rem;font-weight:600;cursor:var(--ui-cursor-click, pointer);color:var(--rich-text-accent);background:var(--rich-text-primary-container);border-bottom:1px solid var(--rich-text-border)}:host ::ng-deep tr.rte-template-block.table-row-block .table-content{width:100%;border-collapse:collapse;color:var(--rich-text-text);background:var(--rich-text-surface)}:host ::ng-deep tr.rte-template-block.table-row-block .content{min-height:1.5rem;color:var(--rich-text-text);background:var(--rich-text-surface)}.toolbar-btn--active{color:var(--rich-text-accent);background:var(--rich-text-primary-container)}.toolbar-btn--active:hover:not(:disabled){opacity:.9}.source-editor{display:block;width:100%;min-height:8rem;padding:.5rem .6rem;border:none;border-bottom:1px solid var(--rich-text-border);border-radius:0;font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.8125rem;line-height:1.5;resize:vertical;outline:none;box-sizing:border-box;color:var(--rich-text-text);background:var(--rich-text-surface);transition:border-color .12s ease;tab-size:2;white-space:pre;overflow-x:auto}.source-editor::selection{color:var(--rich-text-text);background:color-mix(in srgb,var(--rich-text-accent) 28%,transparent)}.source-editor:disabled{opacity:.5;cursor:not-allowed}:host.compact .source-editor{min-height:5.5rem;border:1px solid var(--rich-text-border);border-radius:calc(var(--ui-radius, .375rem) * 1.6)}:host.compact.markdown .source-editor{border-bottom:1px solid var(--rich-text-border)}.preview-label{padding:.15rem .5rem;font-size:.625rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--rich-text-muted);background:var(--rich-text-surface-2)}.editor-wrapper--preview{opacity:.75;pointer-events:none}.editor-wrapper--preview .editor{min-height:4rem;cursor:default}.editor-wrapper--preview .markdown-preview{flex:1;overflow:auto;padding:.5rem;min-height:4rem}:host.disabled .toolbar{opacity:.5;pointer-events:none}:host.disabled .editor-wrapper{opacity:.5;pointer-events:none}:host.readonly .toolbar{opacity:.6}:host.readonly .editor{cursor:default}:host.markdown .markdown-editor{min-height:12rem;border:none;border-bottom:1px solid var(--rich-text-border);font-family:ui-monospace,SF Mono,Menlo,Consolas,monospace;font-size:.8125rem;line-height:1.6;tab-size:4;white-space:pre-wrap;word-wrap:break-word;color:var(--rich-text-text);background:var(--rich-text-surface)}:host.markdown .editor-wrapper--preview{opacity:1;pointer-events:none}:host.markdown .editor-wrapper--preview .editor{min-height:4rem;cursor:default}:host.markdown .editor-wrapper--preview .markdown-preview{flex:1;min-height:0;overflow-y:auto;padding:.5rem;pointer-events:auto}:host.compact.markdown .markdown-editor{min-height:5.5rem}:host.compact.markdown .editor-wrapper{margin-top:.5rem}.placeholder-search{padding:.25rem}.placeholder-search-input{width:100%;box-sizing:border-box;padding:.25rem .5rem;font-size:.75rem;font-family:inherit;border-radius:.2rem;outline:none;color:var(--rich-text-text);background:var(--rich-text-surface);border:1px solid var(--rich-text-border)}.placeholder-search-input:focus{border-color:var(--rich-text-accent)}.placeholder-empty{padding:.5rem .75rem;font-size:.75rem;font-style:italic;color:var(--rich-text-muted);background:transparent}.footer{display:flex;justify-content:flex-end;padding:.125rem .5rem;border-top:1px solid var(--rich-text-border);border-radius:0 0 .25rem .25rem;font-size:.6875rem;color:var(--rich-text-muted);background:var(--rich-text-surface)}.footer--over .char-count{font-weight:600;color:var(--rich-text-error)}.char-count{font-variant-numeric:tabular-nums}.markdown-validity-indicator{display:inline-flex;align-items:center;align-self:center;padding:0 .25rem;flex-shrink:0}.markdown-validity-indicator.valid{color:var(--rich-text-success)}.markdown-validity-indicator.invalid{color:var(--rich-text-warning)}.split-handle{flex:0 0 5px;background:var(--rich-text-border);touch-action:none;transition:background .12s ease}.split-handle:hover,.split-handle:active{background:var(--rich-text-accent)}:host.markdown.split-vertical{display:flex;flex-direction:column}:host.markdown.split-vertical .markdown-editor{flex:1 1 50%;min-height:6rem;resize:none;border-bottom:none}:host.markdown.split-vertical .split-handle{cursor:row-resize;width:100%;height:5px}:host.markdown.split-vertical .editor-wrapper{flex:1 1 50%;min-height:4rem;overflow-y:auto;border-top:1px solid var(--rich-text-border)}:host.markdown.split-horizontal{display:grid;grid-template-columns:1fr 5px 1fr;grid-template-rows:auto 1fr auto}:host.markdown.split-horizontal>ui-toolbar,:host.markdown.split-horizontal>.footer{grid-column:1/-1}:host.markdown.split-horizontal>.markdown-editor{grid-column:1;grid-row:2;min-height:0;resize:none;border-bottom:none;border-right:1px solid var(--rich-text-border)}:host.markdown.split-horizontal>.split-handle{grid-column:2;grid-row:2;cursor:col-resize;width:5px;height:auto;align-self:stretch}:host.markdown.split-horizontal>.editor-wrapper{grid-column:3;grid-row:2;min-height:0;overflow-y:auto;border-top:1px solid var(--rich-text-border)}:host.markdown.split-horizontal>.footer{grid-row:3}:host.fullscreen{position:fixed;inset:0;z-index:1000;border-radius:0;overflow:hidden;color:var(--rich-text-text);background:var(--rich-text-surface)}:host.fullscreen .editor-wrapper{overflow-y:auto;border-radius:0}:host.fullscreen .editor-wrapper .editor{min-height:100%}:host.fullscreen .source-editor{resize:none}:host.fullscreen.split-vertical{display:flex;flex-direction:column}:host.fullscreen.split-vertical .markdown-editor{flex:1 1 50%}:host.fullscreen.split-vertical .editor-wrapper{flex:1 1 50%}:host.fullscreen.split-horizontal{height:100%;grid-template-rows:auto 1fr auto}\n"] }]
        }], propDecorators: { editorRef: [{ type: i0.ViewChild, args: ["editorEl", { isSignal: true }] }], mdTextareaRef: [{ type: i0.ViewChild, args: ["mdTextarea", { isSignal: true }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], presentation: [{ type: i0.Input, args: [{ isSignal: true, alias: "presentation", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], toolbarActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarActions", required: false }] }], compactToolbarActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "compactToolbarActions", required: false }] }], placeholders: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholders", required: false }] }], placeholderContext: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderContext", required: false }] }], splitDirection: [{ type: i0.Input, args: [{ isSignal: true, alias: "splitDirection", required: false }] }], sanitise: [{ type: i0.Input, args: [{ isSignal: true, alias: "sanitise", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], imageHandler: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageHandler", required: false }] }], emojiCategories: [{ type: i0.Input, args: [{ isSignal: true, alias: "emojiCategories", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], blockInserted: [{ type: i0.Output, args: ["blockInserted"] }], blockEdited: [{ type: i0.Output, args: ["blockEdited"] }], blockRemoved: [{ type: i0.Output, args: ["blockRemoved"] }] } });

/**
 * A keyboard-triggered command palette that provides quick access
 * to application actions through a searchable, grouped list.
 *
 * Open with `Cmd+K` / `Ctrl+K` (when {@link globalShortcut} is
 * enabled) or by setting the `open` model to `true`.
 *
 * ### Basic usage
 * ```html
 * <ui-command-palette
 *   [commands]="commands"
 *   [(open)]="paletteOpen"
 *   (execute)="onExecute($event)"
 * />
 * ```
 *
 * ### With recent items
 * ```html
 * <ui-command-palette
 *   [commands]="commands"
 *   [maxRecent]="5"
 *   [(open)]="paletteOpen"
 *   (execute)="onExecute($event)"
 * />
 * ```
 */
class UICommandPalette {
    // ── Inputs ────────────────────────────────────────────────────────
    /** The full list of available commands. */
    commands = input.required(...(ngDevMode ? [{ debugName: "commands" }] : []));
    /** Placeholder text for the search input. */
    placeholder = input("Type a command…", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /** Accessible label for the palette. */
    ariaLabel = input("Command palette", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Whether the global `Cmd+K` / `Ctrl+K` keyboard shortcut is
     * active. Defaults to `true`.
     */
    globalShortcut = input(true, ...(ngDevMode ? [{ debugName: "globalShortcut" }] : []));
    /**
     * Maximum number of recent commands to track. Set to `0` to
     * disable the recent-items section. Defaults to `5`.
     */
    maxRecent = input(5, ...(ngDevMode ? [{ debugName: "maxRecent" }] : []));
    // ── Models ────────────────────────────────────────────────────────
    /** Whether the palette is open (two-way bindable). */
    open = model(false, ...(ngDevMode ? [{ debugName: "open" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emitted when a command is executed. */
    execute = output();
    // ── View queries ──────────────────────────────────────────────────
    /** @internal */
    searchInputRef = viewChild("searchInput", ...(ngDevMode ? [{ debugName: "searchInputRef" }] : []));
    // ── Internal state ────────────────────────────────────────────────
    /** @internal — current search query. */
    query = signal("", ...(ngDevMode ? [{ debugName: "query" }] : []));
    /** @internal — index of the active (highlighted) item. */
    activeIndex = signal(0, ...(ngDevMode ? [{ debugName: "activeIndex" }] : []));
    /** @internal — IDs of recently executed commands (most recent first). */
    recentIds = signal([], ...(ngDevMode ? [{ debugName: "recentIds" }] : []));
    // ── Icons ─────────────────────────────────────────────────────────
    /** @internal */
    searchIcon = UIIcons.Lucide.Social.Search;
    /** @internal */
    returnIcon = UIIcons.Lucide.Arrows.CornerDownLeft;
    /** @internal */
    arrowUpIcon = UIIcons.Lucide.Arrows.ArrowUp;
    /** @internal */
    arrowDownIcon = UIIcons.Lucide.Arrows.ArrowDown;
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — filtered and grouped commands based on the query. */
    filteredGroups = computed(() => {
        const q = this.query().toLowerCase().trim();
        const all = this.commands();
        const matching = q
            ? all.filter((cmd) => cmd.label.toLowerCase().includes(q) ||
                (cmd.keywords ?? []).some((k) => k.toLowerCase().includes(q)) ||
                (cmd.group ?? "").toLowerCase().includes(q))
            : all;
        return this.groupCommands(matching);
    }, ...(ngDevMode ? [{ debugName: "filteredGroups" }] : []));
    /** @internal — recent commands that are still in the full commands list. */
    recentCommands = computed(() => {
        const ids = this.recentIds();
        const max = this.maxRecent();
        if (max === 0 || ids.length === 0)
            return [];
        const all = this.commands();
        const lookup = new Map(all.map((c) => [c.id, c]));
        return ids
            .map((id) => lookup.get(id))
            .filter((c) => c !== undefined)
            .slice(0, max);
    }, ...(ngDevMode ? [{ debugName: "recentCommands" }] : []));
    /** @internal — whether to show the recent section. */
    showRecent = computed(() => this.maxRecent() > 0 &&
        this.recentCommands().length > 0 &&
        !this.query().trim(), ...(ngDevMode ? [{ debugName: "showRecent" }] : []));
    /** @internal — flat list of all currently visible items for keyboard nav. */
    flatItems = computed(() => {
        const items = [];
        if (this.showRecent()) {
            items.push(...this.recentCommands());
        }
        for (const group of this.filteredGroups()) {
            items.push(...group.items);
        }
        return items;
    }, ...(ngDevMode ? [{ debugName: "flatItems" }] : []));
    // ── Constructor ───────────────────────────────────────────────────
    constructor() {
        // Register global keyboard shortcut
        const onKeydown = (e) => {
            if (!this.globalShortcut())
                return;
            if ((e.metaKey || e.ctrlKey) && e.key === "k") {
                e.preventDefault();
                this.open.update((v) => !v);
            }
        };
        if (typeof document !== "undefined") {
            document.addEventListener("keydown", onKeydown);
        }
        // Focus the search input when the palette opens
        effect(() => {
            if (this.open()) {
                this.query.set("");
                this.activeIndex.set(0);
                // Allow DOM to render before focusing
                queueMicrotask(() => {
                    this.searchInputRef()?.nativeElement.focus();
                });
            }
        });
        // Reset active index when query changes
        effect(() => {
            this.query();
            this.activeIndex.set(0);
        });
    }
    // ── Public methods ────────────────────────────────────────────────
    /** Programmatically open the palette. */
    show() {
        this.open.set(true);
    }
    /** Programmatically close the palette. */
    close() {
        this.open.set(false);
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal */
    onSearchInput(event) {
        const input = event.target;
        this.query.set(input.value);
    }
    /** @internal */
    onKeydown(event) {
        const items = this.flatItems();
        const len = items.length;
        if (len === 0)
            return;
        switch (event.key) {
            case "ArrowDown":
                event.preventDefault();
                this.activeIndex.update((i) => (i + 1) % len);
                this.scrollActiveIntoView();
                break;
            case "ArrowUp":
                event.preventDefault();
                this.activeIndex.update((i) => (i - 1 + len) % len);
                this.scrollActiveIntoView();
                break;
            case "Enter": {
                event.preventDefault();
                const item = items[this.activeIndex()];
                if (item && !item.disabled) {
                    this.executeCommand(item);
                }
                break;
            }
            case "Escape":
                event.preventDefault();
                this.close();
                break;
        }
    }
    /** @internal */
    onItemClick(item) {
        if (item.disabled)
            return;
        this.executeCommand(item);
    }
    /** @internal */
    onBackdropClick() {
        this.close();
    }
    /** @internal — compute the flat index for a group item. */
    getFlatIndex(groupIndex, itemIndex) {
        const groups = this.filteredGroups();
        let offset = this.showRecent() ? this.recentCommands().length : 0;
        for (let g = 0; g < groupIndex; g++) {
            offset += groups[g].items.length;
        }
        return offset + itemIndex;
    }
    /** @internal — compute the flat index for a recent item. */
    getRecentFlatIndex(index) {
        return index;
    }
    // ── Private methods ───────────────────────────────────────────────
    executeCommand(item) {
        this.execute.emit({
            command: item,
            executedAt: new Date().toISOString(),
        });
        this.addToRecent(item.id);
        this.close();
    }
    addToRecent(id) {
        const max = this.maxRecent();
        if (max === 0)
            return;
        this.recentIds.update((ids) => {
            const filtered = ids.filter((i) => i !== id);
            return [id, ...filtered].slice(0, max);
        });
    }
    groupCommands(items) {
        const map = new Map();
        for (const item of items) {
            const group = item.group ?? "";
            let list = map.get(group);
            if (!list) {
                list = [];
                map.set(group, list);
            }
            list.push(item);
        }
        const result = [];
        for (const [name, groupItems] of map) {
            result.push({ name, items: groupItems });
        }
        return result;
    }
    scrollActiveIntoView() {
        queueMicrotask(() => {
            const active = this.searchInputRef()
                ?.nativeElement.closest(".cp-dialog")
                ?.querySelector(".cp-item--active");
            active?.scrollIntoView?.({ block: "nearest" });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UICommandPalette, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UICommandPalette, isStandalone: true, selector: "ui-command-palette", inputs: { commands: { classPropertyName: "commands", publicName: "commands", isSignal: true, isRequired: true, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, globalShortcut: { classPropertyName: "globalShortcut", publicName: "globalShortcut", isSignal: true, isRequired: false, transformFunction: null }, maxRecent: { classPropertyName: "maxRecent", publicName: "maxRecent", isSignal: true, isRequired: false, transformFunction: null }, open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", execute: "execute" }, host: { classAttribute: "ui-command-palette" }, viewQueries: [{ propertyName: "searchInputRef", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "@if (open()) {\n  <div class=\"cp-backdrop\" (click)=\"onBackdropClick()\" (keydown)=\"onKeydown($event)\" tabindex=\"-1\"></div>\n  <div\n    class=\"cp-dialog\"\n    role=\"dialog\"\n    [attr.aria-label]=\"ariaLabel()\"\n    (keydown)=\"onKeydown($event)\"\n  >\n    <!-- Search bar -->\n    <div class=\"cp-search\">\n      <ui-icon class=\"cp-search-icon\" [svg]=\"searchIcon\" [size]=\"18\" />\n      <input\n        #searchInput\n        class=\"cp-search-input\"\n        type=\"text\"\n        [placeholder]=\"placeholder()\"\n        [value]=\"query()\"\n        (input)=\"onSearchInput($event)\"\n        role=\"combobox\"\n        aria-autocomplete=\"list\"\n        aria-expanded=\"true\"\n        aria-controls=\"cp-results\"\n        [attr.aria-activedescendant]=\"\n          flatItems().length\n            ? 'cp-item-' + activeIndex()\n            : null\n        \"\n      />\n      <kbd class=\"cp-kbd\">esc</kbd>\n    </div>\n\n    <!-- Results List -->\n    <div\n      id=\"cp-results\"\n      class=\"cp-results\"\n      role=\"listbox\"\n      [attr.aria-label]=\"'Search results'\"\n    >\n      @if (flatItems().length === 0) {\n        <div class=\"cp-empty\">No matching commands</div>\n      } @else {\n        <!-- Recent Commands -->\n        @if (showRecent()) {\n          <div class=\"cp-group\">\n            <div class=\"cp-group-heading\">Recent</div>\n            @for (item of recentCommands(); track item.id; let i = $index) {\n              <div\n                class=\"cp-item\"\n                role=\"option\"\n                tabindex=\"-1\"\n                [id]=\"'cp-item-' + getRecentFlatIndex(i)\"\n                [class.cp-item--active]=\"activeIndex() === getRecentFlatIndex(i)\"\n                [class.cp-item--disabled]=\"item.disabled\"\n                [attr.aria-selected]=\"activeIndex() === getRecentFlatIndex(i)\"\n                [attr.aria-disabled]=\"item.disabled ?? false\"\n                (click)=\"onItemClick(item)\"\n                (keydown)=\"onKeydown($event)\"\n                (pointerenter)=\"activeIndex.set(getRecentFlatIndex(i))\"\n              >\n                @if (item.icon) {\n                  <ui-icon class=\"cp-item-icon\" [svg]=\"item.icon\" [size]=\"16\" />\n                }\n                <span class=\"cp-item-label\">{{ item.label }}</span>\n                @if (item.shortcut) {\n                  <kbd class=\"cp-item-shortcut\">{{ item.shortcut }}</kbd>\n                }\n              </div>\n            }\n          </div>\n        }\n\n        <!-- Grouped commands -->\n        @for (group of filteredGroups(); track group.name; let gi = $index) {\n          <div class=\"cp-group\">\n            @if (group.name) {\n              <div class=\"cp-group-heading\">{{ group.name }}</div>\n            }\n            @for (item of group.items; track item.id; let ii = $index) {\n              <div\n                class=\"cp-item\"\n                role=\"option\"\n                tabindex=\"-1\"\n                [id]=\"'cp-item-' + getFlatIndex(gi, ii)\"\n                [class.cp-item--active]=\"activeIndex() === getFlatIndex(gi, ii)\"\n                [class.cp-item--disabled]=\"item.disabled\"\n                [attr.aria-selected]=\"activeIndex() === getFlatIndex(gi, ii)\"\n                [attr.aria-disabled]=\"item.disabled ?? false\"\n                (click)=\"onItemClick(item)\"\n                (keydown)=\"onKeydown($event)\"\n                (pointerenter)=\"activeIndex.set(getFlatIndex(gi, ii))\"\n              >\n                @if (item.icon) {\n                  <ui-icon class=\"cp-item-icon\" [svg]=\"item.icon\" [size]=\"16\" />\n                }\n                <span class=\"cp-item-label\">{{ item.label }}</span>\n                @if (item.shortcut) {\n                  <kbd class=\"cp-item-shortcut\">{{ item.shortcut }}</kbd>\n                }\n              </div>\n            }\n          </div>\n        }\n      }\n    </div>\n\n    <!-- Footer hints -->\n    <div class=\"cp-footer\">\n      <span class=\"cp-hint\">\n        <ui-icon [svg]=\"returnIcon\" [size]=\"12\" />\n        <span>to select</span>\n      </span>\n      <span class=\"cp-hint\">\n        <ui-icon [svg]=\"arrowUpIcon\" [size]=\"12\" />\n        <ui-icon [svg]=\"arrowDownIcon\" [size]=\"12\" />\n        <span>to navigate</span>\n      </span>\n      <span class=\"cp-hint\">\n        <kbd>esc</kbd>\n        <span>to close</span>\n      </span>\n    </div>\n  </div>\n}\n", styles: [":host{--cp-bg: var(--ui-surface, #ffffff);--cp-text: var(--ui-text, #1d232b);--cp-border: var(--ui-border, #d7dce2);--cp-muted: var(--ui-text-muted, #6b7280);--cp-item-active-bg: var(--ui-accent, #3584e4);--cp-item-active-text: var(--ui-accent-contrast, #ffffff);--cp-kbd-bg: var(--ui-border, #d7dce2);--cp-kbd-text: var(--ui-text, #1d232b);--cp-shadow: var(--ui-shadow-lg);--cp-radius: var(--ui-radius, .75rem);--cp-disabled-opacity: .4;display:contents}.cp-backdrop{position:fixed;inset:0;z-index:999;animation:cp-fade-in .12s ease-out}.cp-dialog{position:fixed;top:20%;left:50%;transform:translate(-50%);z-index:1000;width:min(560px,100vw - 32px);max-height:420px;border-radius:var(--cp-radius);display:flex;flex-direction:column;overflow:hidden;animation:cp-slide-in .14s ease-out;color:var(--cp-text);background:var(--cp-bg);border:1px solid var(--cp-border);box-shadow:var(--cp-shadow)}.cp-search{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--cp-border)}.cp-search-icon{flex-shrink:0;color:var(--cp-muted)}.cp-kbd{flex-shrink:0;font-size:11px;font-family:inherit;padding:2px 7px;border-radius:4px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}.cp-search-input{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);flex:1;font:inherit;font-size:15px;color:var(--cp-text);background:transparent}.cp-results{flex:1;overflow-y:auto;padding:6px 0}.cp-empty{padding:24px 16px;text-align:center;font-size:14px;color:var(--cp-muted)}.cp-group+.cp-group{margin-top:4px}.cp-group-heading{padding:6px 16px 4px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--cp-muted)}.cp-item{display:flex;align-items:center;gap:10px;padding:8px 16px;cursor:pointer;font-size:14px;border-radius:6px;margin:0 6px;transition:background 60ms ease;color:var(--cp-text)}.cp-item.cp-item--active{background:var(--cp-item-active-bg);color:var(--cp-item-active-text)}.cp-item.cp-item--disabled{opacity:var(--cp-disabled-opacity);cursor:not-allowed}.cp-item-icon{flex-shrink:0}.cp-item-label{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cp-item-shortcut{flex-shrink:0;font-size:11px;font-family:inherit;padding:2px 6px;border-radius:4px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}.cp-item--active .cp-item-shortcut{color:var(--cp-item-active-text);background:color-mix(in srgb,var(--cp-item-active-bg) 70%,transparent)}.cp-footer{display:flex;align-items:center;gap:16px;padding:8px 16px;font-size:12px;border-top:1px solid var(--cp-border);color:var(--cp-muted)}.cp-hint{display:inline-flex;align-items:center;gap:4px}.cp-hint kbd{font-size:10px;font-family:inherit;padding:1px 5px;border-radius:3px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}@keyframes cp-fade-in{0%{opacity:0}to{opacity:1}}@keyframes cp-slide-in{0%{opacity:0;transform:translate(-50%) translateY(-8px)}to{opacity:1;transform:translate(-50%) translateY(0)}}\n"], dependencies: [{ kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UICommandPalette, decorators: [{
            type: Component,
            args: [{ selector: "ui-command-palette", standalone: true, imports: [UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-command-palette",
                    }, template: "@if (open()) {\n  <div class=\"cp-backdrop\" (click)=\"onBackdropClick()\" (keydown)=\"onKeydown($event)\" tabindex=\"-1\"></div>\n  <div\n    class=\"cp-dialog\"\n    role=\"dialog\"\n    [attr.aria-label]=\"ariaLabel()\"\n    (keydown)=\"onKeydown($event)\"\n  >\n    <!-- Search bar -->\n    <div class=\"cp-search\">\n      <ui-icon class=\"cp-search-icon\" [svg]=\"searchIcon\" [size]=\"18\" />\n      <input\n        #searchInput\n        class=\"cp-search-input\"\n        type=\"text\"\n        [placeholder]=\"placeholder()\"\n        [value]=\"query()\"\n        (input)=\"onSearchInput($event)\"\n        role=\"combobox\"\n        aria-autocomplete=\"list\"\n        aria-expanded=\"true\"\n        aria-controls=\"cp-results\"\n        [attr.aria-activedescendant]=\"\n          flatItems().length\n            ? 'cp-item-' + activeIndex()\n            : null\n        \"\n      />\n      <kbd class=\"cp-kbd\">esc</kbd>\n    </div>\n\n    <!-- Results List -->\n    <div\n      id=\"cp-results\"\n      class=\"cp-results\"\n      role=\"listbox\"\n      [attr.aria-label]=\"'Search results'\"\n    >\n      @if (flatItems().length === 0) {\n        <div class=\"cp-empty\">No matching commands</div>\n      } @else {\n        <!-- Recent Commands -->\n        @if (showRecent()) {\n          <div class=\"cp-group\">\n            <div class=\"cp-group-heading\">Recent</div>\n            @for (item of recentCommands(); track item.id; let i = $index) {\n              <div\n                class=\"cp-item\"\n                role=\"option\"\n                tabindex=\"-1\"\n                [id]=\"'cp-item-' + getRecentFlatIndex(i)\"\n                [class.cp-item--active]=\"activeIndex() === getRecentFlatIndex(i)\"\n                [class.cp-item--disabled]=\"item.disabled\"\n                [attr.aria-selected]=\"activeIndex() === getRecentFlatIndex(i)\"\n                [attr.aria-disabled]=\"item.disabled ?? false\"\n                (click)=\"onItemClick(item)\"\n                (keydown)=\"onKeydown($event)\"\n                (pointerenter)=\"activeIndex.set(getRecentFlatIndex(i))\"\n              >\n                @if (item.icon) {\n                  <ui-icon class=\"cp-item-icon\" [svg]=\"item.icon\" [size]=\"16\" />\n                }\n                <span class=\"cp-item-label\">{{ item.label }}</span>\n                @if (item.shortcut) {\n                  <kbd class=\"cp-item-shortcut\">{{ item.shortcut }}</kbd>\n                }\n              </div>\n            }\n          </div>\n        }\n\n        <!-- Grouped commands -->\n        @for (group of filteredGroups(); track group.name; let gi = $index) {\n          <div class=\"cp-group\">\n            @if (group.name) {\n              <div class=\"cp-group-heading\">{{ group.name }}</div>\n            }\n            @for (item of group.items; track item.id; let ii = $index) {\n              <div\n                class=\"cp-item\"\n                role=\"option\"\n                tabindex=\"-1\"\n                [id]=\"'cp-item-' + getFlatIndex(gi, ii)\"\n                [class.cp-item--active]=\"activeIndex() === getFlatIndex(gi, ii)\"\n                [class.cp-item--disabled]=\"item.disabled\"\n                [attr.aria-selected]=\"activeIndex() === getFlatIndex(gi, ii)\"\n                [attr.aria-disabled]=\"item.disabled ?? false\"\n                (click)=\"onItemClick(item)\"\n                (keydown)=\"onKeydown($event)\"\n                (pointerenter)=\"activeIndex.set(getFlatIndex(gi, ii))\"\n              >\n                @if (item.icon) {\n                  <ui-icon class=\"cp-item-icon\" [svg]=\"item.icon\" [size]=\"16\" />\n                }\n                <span class=\"cp-item-label\">{{ item.label }}</span>\n                @if (item.shortcut) {\n                  <kbd class=\"cp-item-shortcut\">{{ item.shortcut }}</kbd>\n                }\n              </div>\n            }\n          </div>\n        }\n      }\n    </div>\n\n    <!-- Footer hints -->\n    <div class=\"cp-footer\">\n      <span class=\"cp-hint\">\n        <ui-icon [svg]=\"returnIcon\" [size]=\"12\" />\n        <span>to select</span>\n      </span>\n      <span class=\"cp-hint\">\n        <ui-icon [svg]=\"arrowUpIcon\" [size]=\"12\" />\n        <ui-icon [svg]=\"arrowDownIcon\" [size]=\"12\" />\n        <span>to navigate</span>\n      </span>\n      <span class=\"cp-hint\">\n        <kbd>esc</kbd>\n        <span>to close</span>\n      </span>\n    </div>\n  </div>\n}\n", styles: [":host{--cp-bg: var(--ui-surface, #ffffff);--cp-text: var(--ui-text, #1d232b);--cp-border: var(--ui-border, #d7dce2);--cp-muted: var(--ui-text-muted, #6b7280);--cp-item-active-bg: var(--ui-accent, #3584e4);--cp-item-active-text: var(--ui-accent-contrast, #ffffff);--cp-kbd-bg: var(--ui-border, #d7dce2);--cp-kbd-text: var(--ui-text, #1d232b);--cp-shadow: var(--ui-shadow-lg);--cp-radius: var(--ui-radius, .75rem);--cp-disabled-opacity: .4;display:contents}.cp-backdrop{position:fixed;inset:0;z-index:999;animation:cp-fade-in .12s ease-out}.cp-dialog{position:fixed;top:20%;left:50%;transform:translate(-50%);z-index:1000;width:min(560px,100vw - 32px);max-height:420px;border-radius:var(--cp-radius);display:flex;flex-direction:column;overflow:hidden;animation:cp-slide-in .14s ease-out;color:var(--cp-text);background:var(--cp-bg);border:1px solid var(--cp-border);box-shadow:var(--cp-shadow)}.cp-search{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid var(--cp-border)}.cp-search-icon{flex-shrink:0;color:var(--cp-muted)}.cp-kbd{flex-shrink:0;font-size:11px;font-family:inherit;padding:2px 7px;border-radius:4px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}.cp-search-input{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);flex:1;font:inherit;font-size:15px;color:var(--cp-text);background:transparent}.cp-results{flex:1;overflow-y:auto;padding:6px 0}.cp-empty{padding:24px 16px;text-align:center;font-size:14px;color:var(--cp-muted)}.cp-group+.cp-group{margin-top:4px}.cp-group-heading{padding:6px 16px 4px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--cp-muted)}.cp-item{display:flex;align-items:center;gap:10px;padding:8px 16px;cursor:pointer;font-size:14px;border-radius:6px;margin:0 6px;transition:background 60ms ease;color:var(--cp-text)}.cp-item.cp-item--active{background:var(--cp-item-active-bg);color:var(--cp-item-active-text)}.cp-item.cp-item--disabled{opacity:var(--cp-disabled-opacity);cursor:not-allowed}.cp-item-icon{flex-shrink:0}.cp-item-label{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cp-item-shortcut{flex-shrink:0;font-size:11px;font-family:inherit;padding:2px 6px;border-radius:4px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}.cp-item--active .cp-item-shortcut{color:var(--cp-item-active-text);background:color-mix(in srgb,var(--cp-item-active-bg) 70%,transparent)}.cp-footer{display:flex;align-items:center;gap:16px;padding:8px 16px;font-size:12px;border-top:1px solid var(--cp-border);color:var(--cp-muted)}.cp-hint{display:inline-flex;align-items:center;gap:4px}.cp-hint kbd{font-size:10px;font-family:inherit;padding:1px 5px;border-radius:3px;color:var(--cp-kbd-text);background:var(--cp-kbd-bg)}@keyframes cp-fade-in{0%{opacity:0}to{opacity:1}}@keyframes cp-slide-in{0%{opacity:0;transform:translate(-50%) translateY(-8px)}to{opacity:1;transform:translate(-50%) translateY(0)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { commands: [{ type: i0.Input, args: [{ isSignal: true, alias: "commands", required: true }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], globalShortcut: [{ type: i0.Input, args: [{ isSignal: true, alias: "globalShortcut", required: false }] }], maxRecent: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxRecent", required: false }] }], open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], execute: [{ type: i0.Output, args: ["execute"] }], searchInputRef: [{ type: i0.ViewChild, args: ["searchInput", { isSignal: true }] }] } });

/**
 * DI token for the customisable file-icon registry.
 *
 * When provided, the icon view resolves icons by looking up the
 * file's extension (lower-case, without the leading dot) in the
 * registry. Falls back to the default file/folder icon.
 */
const FILE_ICON_REGISTRY = new InjectionToken("FILE_ICON_REGISTRY");
/**
 * Parses a comma-separated allowed-types mask into an {@link AllowedFileTypes}
 * object.
 *
 * The format mirrors the HTML `<input accept>` attribute:
 * - `.ext`        — file extension (case-insensitive, leading dot optional)
 * - `type/subtype`— exact MIME type, e.g. `application/json`
 * - `type/*`      — MIME wildcard, e.g. `image/*`
 *
 * @example
 * ```ts
 * const types = parseAllowedTypes(".ts, .tsx, image/*");
 * ```
 */
function parseAllowedTypes(mask) {
    const entries = mask
        .split(",")
        .map((t) => t.trim().toLowerCase())
        .filter((t) => t.length > 0)
        .map((t) => {
        if (t.includes("/")) {
            return { kind: "mime", value: t };
        }
        // Strip leading dot — store extension without it
        return { kind: "extension", value: t.startsWith(".") ? t.slice(1) : t };
    });
    return {
        entries,
        matches(name, mimeType) {
            if (entries.length === 0)
                return true;
            return entries.some((e) => {
                if (e.kind === "extension") {
                    const dot = name.lastIndexOf(".");
                    const ext = dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";
                    return ext === e.value;
                }
                // MIME matching
                if (!mimeType)
                    return false;
                const [eType, eSubtype] = e.value.split("/");
                const [mType, mSubtype] = mimeType.toLowerCase().split("/");
                if (eType !== mType)
                    return false;
                return eSubtype === "*" || eSubtype === mSubtype;
            });
        },
    };
}
/**
 * Well-known storage keys for common file-browser use cases.
 *
 * Pass one of these as `[name]` to share preferences across all instances
 * that serve the same purpose:
 *
 * ```html
 * <ui-file-browser [datasource]="ds" [name]="UIFileBrowserKeys.OpenFile" />
 * ```
 *
 * `Global` is used automatically when no `[name]` is supplied; you do not
 * normally need to reference it directly.
 *
 * Library users may pass any plain string as `[name]` to create their own
 * isolated preference scope.
 */
const UIFileBrowserKeys = {
    /** Shared key used when no explicit `[name]` is provided. */
    Global: "__global__",
    /**
     * Conventional key for open-file dialogs. Use
     * `[name]="UIFileBrowserKeys.OpenFile"` to opt in.
     */
    OpenFile: "open-file",
    /**
     * Conventional key for save-file dialogs. Use
     * `[name]="UIFileBrowserKeys.SaveFile"` to opt in.
     */
    SaveFile: "save-file",
};
/**
 * Adapter that converts {@link FileBrowserEntry} items to
 * {@link TreeNode} items for the tree-view sidebar.
 *
 * @internal
 */
function entryToTreeNode(entry, children) {
    return {
        id: entry.id,
        data: entry,
        children,
        icon: entry.icon,
    };
}

/**
 * A two-panel file browser block composing {@link UITreeView},
 * {@link UIBreadcrumb}, and a contents list.
 *
 * The tree sidebar shows the folder hierarchy. Selecting a folder
 * displays its contents (files and sub-folders) in the main panel.
 * A breadcrumb bar shows the current path and allows quick
 * navigation to ancestor folders.
 *
 * ### Basic usage
 * ```html
 * <ui-file-browser [datasource]="ds" (fileActivated)="open($event)" />
 * ```
 *
 * ### With custom entry template
 * ```html
 * <ui-file-browser [datasource]="ds">
 *   <ng-template #entryTemplate let-entry>
 *     <span>{{ entry.name }} — {{ entry.meta?.size }}</span>
 *   </ng-template>
 * </ui-file-browser>
 * ```
 */
class UIFileBrowser {
    // ── Inputs ────────────────────────────────────────────────────────
    /** The datasource providing the file/directory structure. */
    datasource = input.required(...(ngDevMode ? [{ debugName: "datasource" }] : []));
    /** Accessible label for the file browser. */
    ariaLabel = input("File browser", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /** Whether to show the sidebar tree panel. */
    showSidebar = input(true, ...(ngDevMode ? [{ debugName: "showSidebar" }] : []));
    /** Label for the root breadcrumb item. */
    rootLabel = input("Root", ...(ngDevMode ? [{ debugName: "rootLabel" }] : []));
    /** Active view mode for the contents panel (two-way bindable). */
    viewMode = model("list", ...(ngDevMode ? [{ debugName: "viewMode" }] : []));
    /** Whether to show the details pane for the selected entry (two-way bindable). */
    showDetails = model(false, ...(ngDevMode ? [{ debugName: "showDetails" }] : []));
    /**
     * When `true`, a toolbar is rendered in the header that lets the user
     * switch between view modes and toggle the details panel.
     */
    showToolbar = input(false, ...(ngDevMode ? [{ debugName: "showToolbar" }] : []));
    /**
     * Optional persistence key. When set, sidebar and details panel widths
     * are saved to and restored from storage.
     */
    name = input(undefined, ...(ngDevMode ? [{ debugName: "name" }] : []));
    /**
     * Callback that extracts metadata fields from a selected entry.
     * Required for the details pane to display meaningful data.
     */
    metadataProvider = input(null, ...(ngDevMode ? [{ debugName: "metadataProvider" }] : []));
    /**
     * Optional allowed-types mask. Accepts either a comma-separated string in
     * the `<input accept>` format (`.ext`, `type/subtype`, `type/*`) or a
     * pre-parsed {@link AllowedFileTypes} object.
     *
     * When set, files that do not match are either grayed-out and non-interactive
     * (default) or hidden entirely if {@link hideFiltered} is `true`.
     * Directories are never filtered.
     *
     * @example
     * ```html
     * <!-- string attribute -->
     * <ui-file-browser allowedTypes=".ts,.tsx,image/*" />
     *
     * <!-- bound object -->
     * <ui-file-browser [allowedTypes]="myAllowedTypes" />
     * ```
     */
    allowedTypes = input(null, ...(ngDevMode ? [{ debugName: "allowedTypes" }] : []));
    /**
     * When `true`, entries that do not pass the {@link allowedTypes} filter are
     * removed from the contents list entirely. When `false` (default) they are
     * still rendered but dimmed and non-interactive.
     */
    hideFiltered = input(false, ...(ngDevMode ? [{ debugName: "hideFiltered" }] : []));
    // ── Models ────────────────────────────────────────────────────────
    /** The currently selected entry (two-way bindable). */
    selectedEntry = model(null, ...(ngDevMode ? [{ debugName: "selectedEntry" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emitted when a file (non-directory) is activated (double-click / Enter). */
    fileActivated = output();
    /** Emitted when the current directory changes. */
    directoryChange = output();
    // ── Content projection ────────────────────────────────────────────
    /** Optional custom template for rendering each entry in the contents panel. */
    entryTemplate = contentChild("entryTemplate", ...(ngDevMode ? [{ debugName: "entryTemplate" }] : []));
    // ── View queries ──────────────────────────────────────────────────
    /** @internal */
    treeViewRef = viewChild("treeView", ...(ngDevMode ? [{ debugName: "treeViewRef" }] : []));
    // ── Internal state ────────────────────────────────────────────────
    /** @internal — the breadcrumb path from root to the current directory. */
    path = signal([], ...(ngDevMode ? [{ debugName: "path" }] : []));
    /** @internal — the current directory (`null` = root). */
    currentDirectory = signal(null, ...(ngDevMode ? [{ debugName: "currentDirectory" }] : []));
    /** @internal — contents of the current directory. */
    contents = signal([], ...(ngDevMode ? [{ debugName: "contents" }] : []));
    /** @internal — tree selection for one-way binding. */
    treeSelected = signal([], ...(ngDevMode ? [{ debugName: "treeSelected" }] : []));
    /** @internal — tree datasource adapter. */
    treeDatasource = computed(() => {
        const ds = this.datasource();
        return this.createTreeDatasource(ds);
    }, ...(ngDevMode ? [{ debugName: "treeDatasource" }] : []));
    /** @internal — display function for tree nodes. */
    displayNodeLabel = (entry) => entry.name;
    // ── Icons ─────────────────────────────────────────────────────────
    /** @internal */
    icons = {
        folder: UIIcons.Lucide.Files.Folder,
        folderOpen: UIIcons.Lucide.Files.FolderOpen,
        file: UIIcons.Lucide.Files.File,
        fileText: UIIcons.Lucide.Files.FileText,
        chevronRight: UIIcons.Lucide.Arrows.ChevronRight,
        viewList: UIIcons.Lucide.Layout.LayoutList,
        viewIcons: UIIcons.Lucide.Layout.LayoutGrid,
        viewDetail: UIIcons.Lucide.Files.Table2,
        viewTree: UIIcons.Lucide.Files.ListTree,
        viewColumn: UIIcons.Lucide.Layout.Columns2,
        panelRight: UIIcons.Lucide.Layout.PanelRight,
        panelRightOpen: UIIcons.Lucide.Layout.PanelRightOpen,
    };
    // ── DI ────────────────────────────────────────────────────────────
    /** @internal — optional icon registry supplied via DI. */
    iconRegistry = inject(FILE_ICON_REGISTRY, {
        optional: true,
    });
    /** @internal */
    elRef = inject(ElementRef);
    /** @internal */
    injector = inject(Injector);
    /** @internal */
    storage = inject(StorageService);
    // ── Resize state ──────────────────────────────────────────────────
    /** @internal — current sidebar width in pixels. */
    sidebarWidthPx = signal(240, ...(ngDevMode ? [{ debugName: "sidebarWidthPx" }] : []));
    /** @internal — current details panel width in pixels. */
    detailsWidthPx = signal(220, ...(ngDevMode ? [{ debugName: "detailsWidthPx" }] : []));
    /** @internal — which panel divider is actively being dragged. */
    draggingPanel = signal(null, ...(ngDevMode ? [{ debugName: "draggingPanel" }] : []));
    /** @internal — collapsed state for sidebar. */
    sidebarCollapsed = signal(false, ...(ngDevMode ? [{ debugName: "sidebarCollapsed" }] : []));
    /** @internal — collapsed state for details panel. */
    detailsCollapsed = signal(false, ...(ngDevMode ? [{ debugName: "detailsCollapsed" }] : []));
    /** @internal — width before sidebar collapse for restore. */
    preSidebarCollapseWidth = null;
    /** @internal — width before details collapse for restore. */
    preDetailsCollapseWidth = null;
    /** @internal — true once settings have been applied from storage. */
    settingsReady = signal(false, ...(ngDevMode ? [{ debugName: "settingsReady" }] : []));
    // ── Column-view state ─────────────────────────────────────────────
    /**
     * @internal — each element represents one column in the column view.
     * Index 0 = root, subsequent = each directory navigated into.
     */
    columnPanes = signal([], ...(ngDevMode ? [{ debugName: "columnPanes" }] : []));
    /**
     * @internal — the entry selected in each column pane (by pane index).
     */
    columnSelections = signal([], ...(ngDevMode ? [{ debugName: "columnSelections" }] : []));
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — breadcrumb items built from the current path. */
    breadcrumbItems = computed(() => {
        const items = [{ label: this.rootLabel() }];
        for (const entry of this.path()) {
            items.push({ label: entry.name });
        }
        return items;
    }, ...(ngDevMode ? [{ debugName: "breadcrumbItems" }] : []));
    /** @internal — whether an entry is selected in the contents panel. */
    hasSelection = computed(() => this.selectedEntry() !== null, ...(ngDevMode ? [{ debugName: "hasSelection" }] : []));
    /** @internal — metadata fields for the selected entry (details pane). */
    detailFields = computed(() => {
        const entry = this.selectedEntry();
        const provider = this.metadataProvider();
        if (!entry || !provider)
            return [];
        return provider(entry);
    }, ...(ngDevMode ? [{ debugName: "detailFields" }] : []));
    /**
     * @internal — normalised allowed-types filter.
     * Converts a string mask to {@link AllowedFileTypes} on first access.
     */
    resolvedAllowedTypes = computed(() => {
        const v = this.allowedTypes();
        if (!v)
            return null;
        return typeof v === "string" ? parseAllowedTypes(v) : v;
    }, ...(ngDevMode ? [{ debugName: "resolvedAllowedTypes" }] : []));
    /**
     * @internal — contents of the current directory after applying the
     * allowed-types filter (hide mode only; in dim mode all entries are kept).
     */
    filteredContents = computed(() => {
        const filter = this.resolvedAllowedTypes();
        if (!filter || !this.hideFiltered())
            return this.contents();
        return this.contents().filter((e) => e.isDirectory || filter.matches(e.name, e.mimeType));
    }, ...(ngDevMode ? [{ debugName: "filteredContents" }] : []));
    // ── Constructor ───────────────────────────────────────────────────
    constructor() {
        // Load root contents on init
        effect(() => {
            const ds = this.datasource();
            this.loadContents(ds, null);
        });
        // Initialise column-view root pane when datasource is ready
        effect(() => {
            const ds = this.datasource();
            const mode = this.viewMode();
            if (mode === "column") {
                this.initColumnView(ds);
            }
        });
        // Persist toolbar state whenever viewMode or showDetails change
        effect(() => {
            const _mode = this.viewMode();
            const _details = this.showDetails();
            if (!this.settingsReady())
                return;
            this.saveSettings();
        });
    }
    // ── Lifecycle ─────────────────────────────────────────────────────
    ngAfterViewInit() {
        const s = this.loadSettings();
        if (s.viewMode)
            this.viewMode.set(s.viewMode);
        if (s.showDetails !== undefined)
            this.showDetails.set(s.showDetails);
        if (s.sidebarWidth !== undefined)
            this.sidebarWidthPx.set(s.sidebarWidth);
        if (s.detailsWidth !== undefined)
            this.detailsWidthPx.set(s.detailsWidth);
        if (s.sidebarCollapsed !== undefined)
            this.sidebarCollapsed.set(s.sidebarCollapsed);
        if (s.detailsCollapsed !== undefined)
            this.detailsCollapsed.set(s.detailsCollapsed);
        this.settingsReady.set(true);
    }
    // ── Public methods ────────────────────────────────────────────────
    /** Navigate to the root directory. */
    navigateToRoot() {
        this.navigateTo(null, []);
    }
    /** Navigate to a specific directory entry. */
    navigateToDirectory(entry) {
        if (!entry.isDirectory)
            return;
        const newPath = [...this.path(), entry];
        this.navigateTo(entry, newPath);
    }
    /** Set the active view mode (used by the toolbar). */
    setViewMode(mode) {
        this.viewMode.set(mode);
    }
    /** Toggle the details panel (used by the toolbar). */
    toggleDetails() {
        this.showDetails.update((v) => !v);
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — starts pointer-based divider dragging for a panel. */
    onDividerPointerDown(event, panel) {
        event.preventDefault();
        const divider = event.currentTarget;
        divider.setPointerCapture(event.pointerId);
        this.draggingPanel.set(panel);
        const body = this.elRef.nativeElement.querySelector(".fb-body");
        if (!body)
            return;
        const bodyRect = body.getBoundingClientRect();
        const onMove = (e) => {
            const cursor = e.clientX - bodyRect.left;
            const bodyWidth = bodyRect.width;
            if (panel === "sidebar") {
                const clampedPx = Math.max(80, Math.min(cursor, bodyWidth * 0.5));
                this.sidebarWidthPx.set(Math.round(clampedPx));
                this.sidebarCollapsed.set(false);
            }
            else {
                // Details panel: measure from the right edge
                const fromRight = bodyRect.right - e.clientX;
                const clampedPx = Math.max(120, Math.min(fromRight, bodyWidth * 0.5));
                this.detailsWidthPx.set(Math.round(clampedPx));
                this.detailsCollapsed.set(false);
            }
        };
        const onUp = () => {
            this.draggingPanel.set(null);
            divider.removeEventListener("pointermove", onMove);
            divider.removeEventListener("pointerup", onUp);
            divider.removeEventListener("pointercancel", onUp);
            this.saveSettings();
        };
        divider.addEventListener("pointermove", onMove);
        divider.addEventListener("pointerup", onUp);
        divider.addEventListener("pointercancel", onUp);
    }
    /** @internal — double-click on a divider toggles panel collapse. */
    onDividerDblClick(panel) {
        if (panel === "sidebar") {
            if (this.sidebarCollapsed()) {
                this.sidebarCollapsed.set(false);
                if (this.preSidebarCollapseWidth) {
                    this.sidebarWidthPx.set(this.preSidebarCollapseWidth);
                    this.preSidebarCollapseWidth = null;
                }
            }
            else {
                this.preSidebarCollapseWidth = this.sidebarWidthPx();
                this.sidebarCollapsed.set(true);
            }
        }
        else {
            if (this.detailsCollapsed()) {
                this.detailsCollapsed.set(false);
                if (this.preDetailsCollapseWidth) {
                    this.detailsWidthPx.set(this.preDetailsCollapseWidth);
                    this.preDetailsCollapseWidth = null;
                }
            }
            else {
                this.preDetailsCollapseWidth = this.detailsWidthPx();
                this.detailsCollapsed.set(true);
            }
        }
        this.saveSettings();
    }
    /** @internal */
    onBreadcrumbClick(item) {
        const items = this.breadcrumbItems();
        const idx = items.indexOf(item);
        if (idx === 0) {
            // Root
            this.navigateTo(null, []);
        }
        else {
            // Navigate to that ancestor
            const newPath = this.path().slice(0, idx);
            const target = newPath[newPath.length - 1] ?? null;
            this.navigateTo(target, [...newPath]);
        }
    }
    /** @internal */
    onTreeNodeSelected(selected) {
        if (selected.length === 0)
            return;
        const node = selected[0];
        const entry = node.data;
        if (entry.isDirectory) {
            const newPath = this.buildPathToNode(node);
            this.navigateTo(entry, newPath);
        }
    }
    /** @internal */
    onTreeNodeActivated(node) {
        const entry = node.data;
        if (entry.isDirectory) {
            const newPath = this.buildPathToNode(node);
            this.navigateTo(entry, newPath);
        }
    }
    /**
     * @internal — returns `true` if the entry is allowed by the current filter.
     * Directories are always allowed.
     */
    isEntryAllowed(entry) {
        if (entry.isDirectory)
            return true;
        const filter = this.resolvedAllowedTypes();
        if (!filter)
            return true;
        return filter.matches(entry.name, entry.mimeType);
    }
    /**
     * @internal — returns the entries for a column pane after applying the
     * hide-filtered logic (dim mode returns all entries; hide mode filters).
     */
    columnPaneVisibleEntries(entries) {
        const filter = this.resolvedAllowedTypes();
        if (!filter || !this.hideFiltered())
            return entries;
        return entries.filter((e) => e.isDirectory || filter.matches(e.name, e.mimeType));
    }
    /** @internal */
    onEntryClick(entry) {
        if (!this.isEntryAllowed(entry))
            return;
        this.selectedEntry.set(entry);
    }
    /** @internal */
    onEntryDblClick(entry) {
        if (!this.isEntryAllowed(entry))
            return;
        if (entry.isDirectory) {
            this.navigateToDirectory(entry);
        }
        else {
            this.fileActivated.emit({
                entry,
                activatedAt: new Date().toISOString(),
            });
        }
    }
    /** @internal */
    onEntryKeydown(event, entry) {
        if (event.key === "Enter") {
            event.preventDefault();
            this.onEntryDblClick(entry);
        }
    }
    /** @internal */
    getEntryIcon(entry) {
        if (entry.icon)
            return entry.icon;
        if (entry.isDirectory)
            return this.icons.folder;
        // Check DI icon registry by file extension
        if (this.iconRegistry) {
            const ext = this.extractExtension(entry.name);
            if (ext && ext in this.iconRegistry) {
                return this.iconRegistry[ext];
            }
        }
        return this.icons.file;
    }
    /** @internal */
    isEntrySelected(entry) {
        return this.selectedEntry()?.id === entry.id;
    }
    // ── Private methods ───────────────────────────────────────────────
    navigateTo(directory, path) {
        this.currentDirectory.set(directory);
        this.path.set(path);
        this.selectedEntry.set(null);
        this.loadContents(this.datasource(), directory);
        this.directoryChange.emit({ directory, path });
        // Keep the tree selection in sync with the active directory
        this.treeSelected.set(directory ? [entryToTreeNode(directory)] : []);
        // Expand the tree to the selected folder
        this.expandTreeToPath(path);
    }
    async loadContents(ds, parent) {
        const result = await Promise.resolve(ds.getChildren(parent));
        this.contents.set(result);
    }
    createTreeDatasource(ds) {
        return {
            getRootNodes: () => {
                const children = ds.getChildren(null);
                if (children instanceof Promise) {
                    return children.then((items) => items.filter((e) => e.isDirectory).map((e) => entryToTreeNode(e)));
                }
                return children
                    .filter((e) => e.isDirectory)
                    .map((e) => entryToTreeNode(e));
            },
            getChildren: (node) => {
                const children = ds.getChildren(node.data);
                if (children instanceof Promise) {
                    return children.then((items) => items.filter((e) => e.isDirectory).map((e) => entryToTreeNode(e)));
                }
                return children
                    .filter((e) => e.isDirectory)
                    .map((e) => entryToTreeNode(e));
            },
            hasChildren: (node) => ds.isDirectory(node.data),
        };
    }
    buildPathToNode(node) {
        // Walk the tree from roots to find the path to this node
        const ds = this.treeDatasource();
        const roots = ds.getRootNodes();
        if (!Array.isArray(roots))
            return [node.data];
        const path = [];
        const found = this.findNodePath(roots, node.id, path, ds);
        return found ? path : [node.data];
    }
    findNodePath(nodes, targetId, path, ds) {
        for (const n of nodes) {
            path.push(n.data);
            if (n.id === targetId)
                return true;
            if (ds.hasChildren(n)) {
                const children = ds.getChildren(n);
                if (Array.isArray(children) &&
                    this.findNodePath(children, targetId, path, ds)) {
                    return true;
                }
            }
            path.pop();
        }
        return false;
    }
    expandTreeToPath(path) {
        const tree = this.treeViewRef();
        if (!tree)
            return;
        for (const entry of path) {
            const node = entryToTreeNode(entry);
            tree.expand(node);
        }
    }
    // ── Column-view helpers ───────────────────────────────────────────
    /** @internal — handle click on an entry inside a column pane. */
    async onColumnEntryClick(paneIndex, entry) {
        if (!this.isEntryAllowed(entry))
            return;
        // Update selection in this pane
        const sels = [...this.columnSelections()];
        sels[paneIndex] = entry;
        // Clear selections in deeper panes
        this.columnSelections.set(sels.slice(0, paneIndex + 1));
        this.selectedEntry.set(entry);
        // If directory, open a new pane to the right (truncate deeper panes first)
        if (entry.isDirectory) {
            const ds = this.datasource();
            const children = await Promise.resolve(ds.getChildren(entry));
            const panes = this.columnPanes().slice(0, paneIndex + 1);
            this.columnPanes.set([...panes, { directory: entry, entries: children }]);
            this.scrollLastColumnPaneIntoView();
        }
        else {
            // Truncate deeper panes for file selection
            this.columnPanes.set(this.columnPanes().slice(0, paneIndex + 1));
        }
    }
    /** @internal — double-click in column view activates a file. */
    onColumnEntryDblClick(entry) {
        if (!this.isEntryAllowed(entry))
            return;
        if (!entry.isDirectory) {
            this.fileActivated.emit({
                entry,
                activatedAt: new Date().toISOString(),
            });
        }
    }
    /** @internal — check if entry is selected in a column pane. */
    isColumnEntrySelected(paneIndex, entry) {
        return this.columnSelections()[paneIndex]?.id === entry.id;
    }
    async initColumnView(ds) {
        const rootEntries = await Promise.resolve(ds.getChildren(null));
        this.columnPanes.set([{ directory: null, entries: rootEntries }]);
        this.columnSelections.set([]);
    }
    extractExtension(filename) {
        const dot = filename.lastIndexOf(".");
        if (dot < 1)
            return null;
        return filename.slice(dot + 1).toLowerCase();
    }
    /** @internal — scroll the rightmost column pane into view after DOM update. */
    scrollLastColumnPaneIntoView() {
        afterNextRender(() => {
            const container = this.elRef.nativeElement.querySelector(".fb-contents--column");
            if (container) {
                const lastPane = container.querySelector(".fb-column-pane:last-child");
                lastPane?.scrollIntoView?.({
                    behavior: "smooth",
                    block: "nearest",
                    inline: "end",
                });
            }
        }, { injector: this.injector });
    }
    // ── Settings persistence ──────────────────────────────────────────
    static STORAGE_PREFIX = "ui-file-browser:";
    /**
     * Save current settings to storage.
     *
     * - **Named key** (`name` input set): saves all settings including panel widths.
     * - **Global key** (`name` not set): saves only viewMode and showDetails — panel
     *   widths are layout-specific and not shared across instances.
     */
    saveSettings() {
        const name = this.name();
        const key = name ?? UIFileBrowserKeys.Global;
        const settings = {
            viewMode: this.viewMode(),
            showDetails: this.showDetails(),
            ...(name
                ? {
                    sidebarWidth: this.sidebarWidthPx(),
                    detailsWidth: this.detailsWidthPx(),
                    sidebarCollapsed: this.sidebarCollapsed(),
                    detailsCollapsed: this.detailsCollapsed(),
                }
                : {}),
        };
        this.storage.setItem(UIFileBrowser.STORAGE_PREFIX + key, JSON.stringify(settings));
    }
    /**
     * Load persisted settings for this instance.
     *
     * Always reads the global key first, then merges with the named key
     * (when `name` is set). Named values override global values where
     * both are present.
     */
    loadSettings() {
        const global = this.parseSettings(this.storage.getItem(UIFileBrowser.STORAGE_PREFIX + UIFileBrowserKeys.Global));
        const name = this.name();
        if (!name)
            return global;
        const named = this.parseSettings(this.storage.getItem(UIFileBrowser.STORAGE_PREFIX + name));
        return { ...global, ...named };
    }
    /** @internal — safely deserialise a raw JSON string into settings. */
    parseSettings(raw) {
        if (!raw)
            return {};
        try {
            const p = JSON.parse(raw);
            if (typeof p !== "object" || p === null)
                return {};
            const out = {};
            if (typeof p["viewMode"] === "string") {
                out.viewMode = p["viewMode"];
            }
            if (typeof p["showDetails"] === "boolean") {
                out.showDetails = p["showDetails"];
            }
            if (typeof p["sidebarWidth"] === "number") {
                out.sidebarWidth = p["sidebarWidth"];
            }
            if (typeof p["detailsWidth"] === "number") {
                out.detailsWidth = p["detailsWidth"];
            }
            if (typeof p["sidebarCollapsed"] === "boolean") {
                out.sidebarCollapsed =
                    p["sidebarCollapsed"];
            }
            if (typeof p["detailsCollapsed"] === "boolean") {
                out.detailsCollapsed =
                    p["detailsCollapsed"];
            }
            return out;
        }
        catch {
            return {};
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIFileBrowser, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIFileBrowser, isStandalone: true, selector: "ui-file-browser", inputs: { datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, showSidebar: { classPropertyName: "showSidebar", publicName: "showSidebar", isSignal: true, isRequired: false, transformFunction: null }, rootLabel: { classPropertyName: "rootLabel", publicName: "rootLabel", isSignal: true, isRequired: false, transformFunction: null }, viewMode: { classPropertyName: "viewMode", publicName: "viewMode", isSignal: true, isRequired: false, transformFunction: null }, showDetails: { classPropertyName: "showDetails", publicName: "showDetails", isSignal: true, isRequired: false, transformFunction: null }, showToolbar: { classPropertyName: "showToolbar", publicName: "showToolbar", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, metadataProvider: { classPropertyName: "metadataProvider", publicName: "metadataProvider", isSignal: true, isRequired: false, transformFunction: null }, allowedTypes: { classPropertyName: "allowedTypes", publicName: "allowedTypes", isSignal: true, isRequired: false, transformFunction: null }, hideFiltered: { classPropertyName: "hideFiltered", publicName: "hideFiltered", isSignal: true, isRequired: false, transformFunction: null }, selectedEntry: { classPropertyName: "selectedEntry", publicName: "selectedEntry", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { viewMode: "viewModeChange", showDetails: "showDetailsChange", selectedEntry: "selectedEntryChange", fileActivated: "fileActivated", directoryChange: "directoryChange" }, host: { properties: { "class.dragging": "draggingPanel()", "style.--fb-sidebar-width": "sidebarWidthPx() + 'px'", "style.--fb-details-width": "detailsWidthPx() + 'px'" }, classAttribute: "ui-file-browser" }, queries: [{ propertyName: "entryTemplate", first: true, predicate: ["entryTemplate"], descendants: true, isSignal: true }], viewQueries: [{ propertyName: "treeViewRef", first: true, predicate: ["treeView"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"fb-header\">\n  <ui-breadcrumb [items]=\"breadcrumbItems()\" variant=\"button\" ariaLabel=\"File path\"\n    (itemClicked)=\"onBreadcrumbClick($event)\" />\n  @if (showToolbar()) {\n  <div class=\"fb-toolbar\" role=\"toolbar\" aria-label=\"File browser toolbar\">\n    <div class=\"fb-toolbar-group\" role=\"group\" aria-label=\"View mode\">\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'list'\"\n        [attr.aria-pressed]=\"viewMode() === 'list'\" aria-label=\"List view\"\n        (click)=\"setViewMode('list')\">\n        <ui-icon [svg]=\"icons.viewList\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'icons'\"\n        [attr.aria-pressed]=\"viewMode() === 'icons'\" aria-label=\"Icon view\"\n        (click)=\"setViewMode('icons')\">\n        <ui-icon [svg]=\"icons.viewIcons\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'detail'\"\n        [attr.aria-pressed]=\"viewMode() === 'detail'\" aria-label=\"Detail view\"\n        (click)=\"setViewMode('detail')\">\n        <ui-icon [svg]=\"icons.viewDetail\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'tree'\"\n        [attr.aria-pressed]=\"viewMode() === 'tree'\" aria-label=\"Tree view\"\n        (click)=\"setViewMode('tree')\">\n        <ui-icon [svg]=\"icons.viewTree\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'column'\"\n        [attr.aria-pressed]=\"viewMode() === 'column'\" aria-label=\"Column view\"\n        (click)=\"setViewMode('column')\">\n        <ui-icon [svg]=\"icons.viewColumn\" [size]=\"16\" />\n      </button>\n    </div>\n    <div class=\"fb-toolbar-divider\" aria-hidden=\"true\"></div>\n    <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"showDetails()\"\n      [attr.aria-pressed]=\"showDetails()\" aria-label=\"Toggle details panel\"\n      (click)=\"toggleDetails()\">\n      <ui-icon [svg]=\"showDetails() ? icons.panelRightOpen : icons.panelRight\" [size]=\"16\" />\n    </button>\n  </div>\n  }\n</div>\n\n<div class=\"fb-body\">\n  <!-- Sidebar: Folder tree \u2014 hidden in column view (root is the first column) -->\n  @if (showSidebar() && viewMode() !== 'column') {\n  <div class=\"fb-sidebar\" [class.fb-sidebar--collapsed]=\"sidebarCollapsed()\">\n    @if (!sidebarCollapsed()) {\n    <ui-tree-view #treeView [datasource]=\"treeDatasource()\" [displayWith]=\"displayNodeLabel\" ariaLabel=\"Folder tree\"\n      [selected]=\"treeSelected()\" (selectedChange)=\"onTreeNodeSelected($event)\"\n      (nodeActivated)=\"onTreeNodeActivated($event)\">\n      <ng-template #nodeTemplate let-node>\n        <ui-icon [svg]=\"node.data.icon ?? icons.folder\" [size]=\"16\" />\n        <span class=\"fb-node-label\">{{ node.data.name }}</span>\n      </ng-template>\n    </ui-tree-view>\n    }\n  </div>\n\n  <!-- Sidebar resize divider -->\n  <div class=\"fb-divider fb-divider--sidebar ui-surface-type-raised\" role=\"separator\" tabindex=\"0\"\n    aria-label=\"Resize sidebar\" aria-orientation=\"horizontal\" (pointerdown)=\"onDividerPointerDown($event, 'sidebar')\"\n    (dblclick)=\"onDividerDblClick('sidebar')\">\n    <div class=\"fb-divider-handle\"></div>\n  </div>\n  }\n\n  <!-- \u2550\u2550\u2550 Contents panel \u2014 switches on viewMode \u2550\u2550\u2550 -->\n\n  @switch (viewMode()) {\n\n  <!-- \u2500\u2500 List view (default) \u2500\u2500 -->\n  @case ('list') {\n  <div class=\"fb-contents fb-contents--list\" role=\"list\" [attr.aria-label]=\"ariaLabel()\">\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-entry\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-entry--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      [class.fb-entry--directory]=\"entry.isDirectory\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\" (keydown)=\"onEntryKeydown($event, entry)\">\n      @if (entryTemplate(); as tpl) {\n      <ng-container [ngTemplateOutlet]=\"tpl\" [ngTemplateOutletContext]=\"{ $implicit: entry }\" />\n      } @else {\n      <ui-icon class=\"fb-entry-icon\" [svg]=\"getEntryIcon(entry)\" [size]=\"18\" />\n      <span class=\"fb-entry-name\">{{ entry.name }}</span>\n      @if (entry.isDirectory) {\n      <ui-icon class=\"fb-entry-chevron\" [svg]=\"icons.chevronRight\" [size]=\"14\" />\n      }\n      }\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Icon view \u2500\u2500 -->\n  @case ('icons') {\n  <div class=\"fb-contents fb-contents--icons\" role=\"list\" [attr.aria-label]=\"ariaLabel()\">\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-icon-tile\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-icon-tile--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\"\n      (keydown)=\"onEntryKeydown($event, entry)\">\n      <ui-icon class=\"fb-icon-tile-icon\" [svg]=\"getEntryIcon(entry)\" [size]=\"40\" />\n      <span class=\"fb-icon-tile-name\">{{ entry.name }}</span>\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Detail view (table-like) \u2500\u2500 -->\n  @case ('detail') {\n  <div class=\"fb-contents fb-contents--detail\" role=\"table\" [attr.aria-label]=\"ariaLabel()\">\n    <div class=\"fb-detail-header\" role=\"row\">\n      <span class=\"fb-detail-cell fb-detail-cell--icon\" role=\"columnheader\"></span>\n      <span class=\"fb-detail-cell fb-detail-cell--name\" role=\"columnheader\">Name</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Size</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Type</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Modified</span>\n    </div>\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-detail-row\" role=\"row\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-detail-row--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      [class.fb-detail-row--directory]=\"entry.isDirectory\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\" (keydown)=\"onEntryKeydown($event, entry)\">\n      <span class=\"fb-detail-cell fb-detail-cell--icon\" role=\"cell\">\n        <ui-icon [svg]=\"getEntryIcon(entry)\" [size]=\"16\" />\n      </span>\n      <span class=\"fb-detail-cell fb-detail-cell--name\" role=\"cell\">{{ entry.name }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.size ?? '\u2014' }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.type ?? '\u2014' }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.modified ?? '\u2014' }}</span>\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Tree view \u2500\u2500 -->\n  @case ('tree') {\n  <div class=\"fb-contents fb-contents--tree\" [attr.aria-label]=\"ariaLabel()\">\n    <ui-tree-view [datasource]=\"treeDatasource()\" [displayWith]=\"displayNodeLabel\" ariaLabel=\"File tree\"\n      (nodeActivated)=\"onTreeNodeActivated($event)\">\n      <ng-template #nodeTemplate let-node>\n        <ui-icon [svg]=\"getEntryIcon(node.data)\" [size]=\"16\" />\n        <span class=\"fb-node-label\">{{ node.data.name }}</span>\n      </ng-template>\n    </ui-tree-view>\n  </div>\n  }\n\n  <!-- \u2500\u2500 Column view (NeXTSTEP / macOS Finder) \u2500\u2500 -->\n  @case ('column') {\n  <div class=\"fb-contents fb-contents--column\" [attr.aria-label]=\"ariaLabel()\">\n    @for (pane of columnPanes(); track $index; let i = $index) {\n    <div class=\"fb-column-pane\" role=\"list\">\n      @for (entry of columnPaneVisibleEntries(pane.entries); track entry.id) {\n      <div class=\"fb-column-entry\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n        [class.fb-column-entry--selected]=\"isColumnEntrySelected(i, entry)\"\n        [class.filtered]=\"!isEntryAllowed(entry)\"\n        [attr.aria-selected]=\"isColumnEntrySelected(i, entry)\"\n        [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n        [class.fb-column-entry--directory]=\"entry.isDirectory\"\n        (click)=\"onColumnEntryClick(i, entry)\" (dblclick)=\"onColumnEntryDblClick(entry)\"\n        (keydown)=\"onEntryKeydown($event, entry)\">\n        <ui-icon [svg]=\"getEntryIcon(entry)\" [size]=\"16\" />\n        <span class=\"fb-column-entry-name\">{{ entry.name }}</span>\n        @if (entry.isDirectory) {\n        <ui-icon class=\"fb-entry-chevron\" [svg]=\"icons.chevronRight\" [size]=\"12\" />\n        }\n      </div>\n      } @empty {\n      <div class=\"fb-empty\">Empty</div>\n      }\n    </div>\n    }\n  </div>\n  }\n  }\n\n  <!-- \u2550\u2550\u2550 Details pane \u2550\u2550\u2550 -->\n  @if (showDetails()) {\n  <!-- Details resize divider -->\n  <div class=\"fb-divider fb-divider--details ui-surface-type-raised\" role=\"separator\" tabindex=\"0\"\n    aria-label=\"Resize details\" aria-orientation=\"horizontal\" (pointerdown)=\"onDividerPointerDown($event, 'details')\"\n    (dblclick)=\"onDividerDblClick('details')\">\n    <div class=\"fb-divider-handle\"></div>\n  </div>\n\n  <aside class=\"fb-details\" [class.fb-details--collapsed]=\"detailsCollapsed()\" aria-label=\"File details\">\n    @if (!detailsCollapsed()) {\n      @if (hasSelection()) {\n      <div class=\"fb-details-header\">\n        <ui-icon [svg]=\"getEntryIcon(selectedEntry()!)\" [size]=\"32\" />\n        <span class=\"fb-details-name\">{{ selectedEntry()!.name }}</span>\n        <span class=\"fb-details-kind\">\n          {{ selectedEntry()!.isDirectory ? 'Folder' : 'File' }}\n        </span>\n      </div>\n\n      @if (detailFields().length > 0) {\n      <dl class=\"fb-details-meta\">\n        @for (field of detailFields(); track field.label) {\n        <dt class=\"fb-details-label\">{{ field.label }}</dt>\n        <dd class=\"fb-details-value\">{{ field.value }}</dd>\n        }\n      </dl>\n      }\n      } @else {\n      <div class=\"fb-details-empty\">No selection</div>\n      }\n    }\n  </aside>\n  }\n</div>", styles: [":host{--fb-sidebar-width: 240px;--fb-details-width: 220px;--fb-column-width: 220px;display:flex;flex-direction:column;height:100%;border-radius:8px;overflow:hidden}.fb-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;min-height:40px}.fb-header ui-breadcrumb{flex:1;min-width:0}.fb-toolbar{display:flex;align-items:center;gap:2px;flex-shrink:0;margin-left:8px}.fb-toolbar-group{display:flex;align-items:center;gap:1px}.fb-toolbar-divider{width:1px;height:20px;background:var(--ui-border, rgba(0, 0, 0, .12));margin:0 4px;flex-shrink:0}.fb-toolbar-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:4px;background:transparent;color:var(--ui-text-muted, #6b7280);cursor:pointer;outline:none;transition:background 60ms ease,color 60ms ease}.fb-toolbar-btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06));color:var(--ui-text, #1d232b)}.fb-toolbar-btn:focus-visible{background:var(--ui-hover-bg, rgba(0, 0, 0, .06));color:var(--ui-text, #1d232b);outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-toolbar-btn.active{background:var(--ui-selected-bg, rgba(53, 132, 228, .18));color:var(--ui-accent, #3584e4)}.fb-body{display:flex;flex:1;min-height:0}.fb-sidebar{width:var(--fb-sidebar-width);min-width:var(--fb-sidebar-width);border-right:none;overflow-y:auto;padding:4px 0;transition:width .15s ease,min-width .15s ease}.fb-sidebar ui-tree-view{font-size:13px}.fb-sidebar--collapsed{width:0;min-width:0;overflow:hidden;padding:0}.fb-node-label{margin-left:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fb-divider{flex:0 0 5px;display:flex;align-items:center;justify-content:center;border:none;outline:none;-webkit-user-select:none;user-select:none;touch-action:none;cursor:col-resize;background:transparent;transition:background-color .15s ease;position:relative;z-index:2}.fb-divider:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-divider:hover .fb-divider-handle{background:var(--ui-accent, #3584e4)}.fb-divider:focus-visible{outline-offset:-2px}.fb-divider-handle{width:2px;height:24px;border-radius:2px;background:var(--ui-border-strong, #505d6d);transition:background-color .15s ease}:host(.dragging){cursor:col-resize}:host(.dragging) .fb-contents,:host(.dragging) .fb-sidebar,:host(.dragging) .fb-details{pointer-events:none;-webkit-user-select:none;user-select:none}.fb-contents{flex:1;overflow-y:auto;padding:4px 0;min-width:0}.fb-empty{padding:32px 16px;text-align:center;font-size:14px}.fb-entry{display:flex;align-items:center;gap:8px;padding:6px 12px;cursor:pointer;font-size:14px;border-radius:4px;margin:1px 6px;transition:background 60ms ease;outline:none}.fb-entry:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-entry:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-entry--selected{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-entry--selected:hover,.fb-entry--selected:focus-visible{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent-hover, color-mix(in srgb, var(--ui-accent, #3584e4) 85%, black))}.fb-entry-icon{flex-shrink:0}.fb-entry-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-entry-chevron{flex-shrink:0;opacity:.5}.fb-entry--directory{font-weight:500}.fb-contents--icons{display:flex;flex-wrap:wrap;align-content:flex-start;gap:4px;padding:12px}.fb-icon-tile{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:6px;width:88px;padding:10px 4px;border-radius:6px;cursor:pointer;text-align:center;outline:none;transition:background 60ms ease}.fb-icon-tile:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-icon-tile:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-icon-tile--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-icon-tile--selected:hover,.fb-icon-tile--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-icon-tile-icon{flex-shrink:0}.fb-icon-tile-name{font-size:11px;line-height:1.3;max-width:80px;word-break:break-word;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.fb-contents--detail{padding:0}.fb-detail-header{display:flex;align-items:center;padding:6px 12px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;position:sticky;top:0;z-index:1}.fb-detail-row{display:flex;align-items:center;padding:5px 12px;font-size:13px;cursor:pointer;outline:none;transition:background 60ms ease}.fb-detail-row:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-detail-row:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-detail-row.fb-detail-row--directory{font-weight:500}.fb-detail-row--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-detail-row--selected:hover,.fb-detail-row--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-detail-cell{padding:0 6px}.fb-detail-cell--icon{flex:0 0 28px;display:flex;align-items:center;justify-content:center}.fb-detail-cell--name{flex:2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-detail-cell--meta{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;font-size:12px}.fb-detail-row--selected .fb-detail-cell--meta{opacity:.8}.fb-contents--tree ui-tree-view{font-size:13px}.fb-contents--column{display:flex;overflow-x:auto;overflow-y:hidden;padding:0}.fb-column-pane{flex:0 0 var(--fb-column-width);min-width:var(--fb-column-width);overflow-y:auto;padding:2px 0}.fb-column-pane:last-child{border-right:none}.fb-column-entry{display:flex;align-items:center;gap:6px;padding:5px 10px;font-size:13px;cursor:pointer;outline:none;transition:background 60ms ease}.fb-column-entry:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-column-entry:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-column-entry.fb-column-entry--directory{font-weight:500}.fb-column-entry--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-column-entry--selected:hover,.fb-column-entry--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-column-entry-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-details{width:var(--fb-details-width);min-width:var(--fb-details-width);border-left:none;overflow-y:auto;padding:16px 12px;display:flex;flex-direction:column;gap:16px;transition:width .15s ease,min-width .15s ease}.fb-details--collapsed{width:0;min-width:0;overflow:hidden;padding:0}.fb-details-header{display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center}.fb-details-empty{display:flex;align-items:center;justify-content:center;flex:1;padding:24px 12px;font-size:13px;color:var(--ui-text-muted, #6b7280);text-align:center}.fb-details-name{font-weight:600;font-size:14px;word-break:break-word}.fb-details-kind{font-size:12px}.fb-details-meta{display:grid;grid-template-columns:auto 1fr;gap:6px 10px;font-size:12px;margin:0}.fb-details-label{font-weight:600}.fb-details-value{margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.filtered{opacity:.35;pointer-events:none;-webkit-user-select:none;user-select:none;cursor:default}\n"], dependencies: [{ kind: "component", type: UITreeView, selector: "ui-tree-view", inputs: ["disabled", "datasource", "ariaLabel", "displayWith", "filterPredicate", "sortComparator", "selected"], outputs: ["selectedChange", "nodeExpanded", "nodeCollapsed", "nodeActivated"] }, { kind: "component", type: UIBreadcrumb, selector: "ui-breadcrumb", inputs: ["disabled", "items", "variant", "separator", "ariaLabel"], outputs: ["itemClicked"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIFileBrowser, decorators: [{
            type: Component,
            args: [{ selector: "ui-file-browser", standalone: true, imports: [UITreeView, UIBreadcrumb, UIIcon, NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-file-browser",
                        "[class.dragging]": "draggingPanel()",
                        "[style.--fb-sidebar-width]": "sidebarWidthPx() + 'px'",
                        "[style.--fb-details-width]": "detailsWidthPx() + 'px'",
                    }, template: "<div class=\"fb-header\">\n  <ui-breadcrumb [items]=\"breadcrumbItems()\" variant=\"button\" ariaLabel=\"File path\"\n    (itemClicked)=\"onBreadcrumbClick($event)\" />\n  @if (showToolbar()) {\n  <div class=\"fb-toolbar\" role=\"toolbar\" aria-label=\"File browser toolbar\">\n    <div class=\"fb-toolbar-group\" role=\"group\" aria-label=\"View mode\">\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'list'\"\n        [attr.aria-pressed]=\"viewMode() === 'list'\" aria-label=\"List view\"\n        (click)=\"setViewMode('list')\">\n        <ui-icon [svg]=\"icons.viewList\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'icons'\"\n        [attr.aria-pressed]=\"viewMode() === 'icons'\" aria-label=\"Icon view\"\n        (click)=\"setViewMode('icons')\">\n        <ui-icon [svg]=\"icons.viewIcons\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'detail'\"\n        [attr.aria-pressed]=\"viewMode() === 'detail'\" aria-label=\"Detail view\"\n        (click)=\"setViewMode('detail')\">\n        <ui-icon [svg]=\"icons.viewDetail\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'tree'\"\n        [attr.aria-pressed]=\"viewMode() === 'tree'\" aria-label=\"Tree view\"\n        (click)=\"setViewMode('tree')\">\n        <ui-icon [svg]=\"icons.viewTree\" [size]=\"16\" />\n      </button>\n      <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"viewMode() === 'column'\"\n        [attr.aria-pressed]=\"viewMode() === 'column'\" aria-label=\"Column view\"\n        (click)=\"setViewMode('column')\">\n        <ui-icon [svg]=\"icons.viewColumn\" [size]=\"16\" />\n      </button>\n    </div>\n    <div class=\"fb-toolbar-divider\" aria-hidden=\"true\"></div>\n    <button type=\"button\" class=\"fb-toolbar-btn\" [class.active]=\"showDetails()\"\n      [attr.aria-pressed]=\"showDetails()\" aria-label=\"Toggle details panel\"\n      (click)=\"toggleDetails()\">\n      <ui-icon [svg]=\"showDetails() ? icons.panelRightOpen : icons.panelRight\" [size]=\"16\" />\n    </button>\n  </div>\n  }\n</div>\n\n<div class=\"fb-body\">\n  <!-- Sidebar: Folder tree \u2014 hidden in column view (root is the first column) -->\n  @if (showSidebar() && viewMode() !== 'column') {\n  <div class=\"fb-sidebar\" [class.fb-sidebar--collapsed]=\"sidebarCollapsed()\">\n    @if (!sidebarCollapsed()) {\n    <ui-tree-view #treeView [datasource]=\"treeDatasource()\" [displayWith]=\"displayNodeLabel\" ariaLabel=\"Folder tree\"\n      [selected]=\"treeSelected()\" (selectedChange)=\"onTreeNodeSelected($event)\"\n      (nodeActivated)=\"onTreeNodeActivated($event)\">\n      <ng-template #nodeTemplate let-node>\n        <ui-icon [svg]=\"node.data.icon ?? icons.folder\" [size]=\"16\" />\n        <span class=\"fb-node-label\">{{ node.data.name }}</span>\n      </ng-template>\n    </ui-tree-view>\n    }\n  </div>\n\n  <!-- Sidebar resize divider -->\n  <div class=\"fb-divider fb-divider--sidebar ui-surface-type-raised\" role=\"separator\" tabindex=\"0\"\n    aria-label=\"Resize sidebar\" aria-orientation=\"horizontal\" (pointerdown)=\"onDividerPointerDown($event, 'sidebar')\"\n    (dblclick)=\"onDividerDblClick('sidebar')\">\n    <div class=\"fb-divider-handle\"></div>\n  </div>\n  }\n\n  <!-- \u2550\u2550\u2550 Contents panel \u2014 switches on viewMode \u2550\u2550\u2550 -->\n\n  @switch (viewMode()) {\n\n  <!-- \u2500\u2500 List view (default) \u2500\u2500 -->\n  @case ('list') {\n  <div class=\"fb-contents fb-contents--list\" role=\"list\" [attr.aria-label]=\"ariaLabel()\">\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-entry\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-entry--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      [class.fb-entry--directory]=\"entry.isDirectory\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\" (keydown)=\"onEntryKeydown($event, entry)\">\n      @if (entryTemplate(); as tpl) {\n      <ng-container [ngTemplateOutlet]=\"tpl\" [ngTemplateOutletContext]=\"{ $implicit: entry }\" />\n      } @else {\n      <ui-icon class=\"fb-entry-icon\" [svg]=\"getEntryIcon(entry)\" [size]=\"18\" />\n      <span class=\"fb-entry-name\">{{ entry.name }}</span>\n      @if (entry.isDirectory) {\n      <ui-icon class=\"fb-entry-chevron\" [svg]=\"icons.chevronRight\" [size]=\"14\" />\n      }\n      }\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Icon view \u2500\u2500 -->\n  @case ('icons') {\n  <div class=\"fb-contents fb-contents--icons\" role=\"list\" [attr.aria-label]=\"ariaLabel()\">\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-icon-tile\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-icon-tile--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\"\n      (keydown)=\"onEntryKeydown($event, entry)\">\n      <ui-icon class=\"fb-icon-tile-icon\" [svg]=\"getEntryIcon(entry)\" [size]=\"40\" />\n      <span class=\"fb-icon-tile-name\">{{ entry.name }}</span>\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Detail view (table-like) \u2500\u2500 -->\n  @case ('detail') {\n  <div class=\"fb-contents fb-contents--detail\" role=\"table\" [attr.aria-label]=\"ariaLabel()\">\n    <div class=\"fb-detail-header\" role=\"row\">\n      <span class=\"fb-detail-cell fb-detail-cell--icon\" role=\"columnheader\"></span>\n      <span class=\"fb-detail-cell fb-detail-cell--name\" role=\"columnheader\">Name</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Size</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Type</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"columnheader\">Modified</span>\n    </div>\n    @if (filteredContents().length === 0) {\n    <div class=\"fb-empty\">Empty folder</div>\n    } @else {\n    @for (entry of filteredContents(); track entry.id) {\n    <div class=\"fb-detail-row\" role=\"row\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n      [class.fb-detail-row--selected]=\"isEntrySelected(entry)\"\n      [class.filtered]=\"!isEntryAllowed(entry)\"\n      [attr.aria-selected]=\"isEntrySelected(entry)\"\n      [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n      [class.fb-detail-row--directory]=\"entry.isDirectory\"\n      (click)=\"onEntryClick(entry)\" (dblclick)=\"onEntryDblClick(entry)\" (keydown)=\"onEntryKeydown($event, entry)\">\n      <span class=\"fb-detail-cell fb-detail-cell--icon\" role=\"cell\">\n        <ui-icon [svg]=\"getEntryIcon(entry)\" [size]=\"16\" />\n      </span>\n      <span class=\"fb-detail-cell fb-detail-cell--name\" role=\"cell\">{{ entry.name }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.size ?? '\u2014' }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.type ?? '\u2014' }}</span>\n      <span class=\"fb-detail-cell fb-detail-cell--meta\" role=\"cell\">{{ $any(entry.meta)?.modified ?? '\u2014' }}</span>\n    </div>\n    }\n    }\n  </div>\n  }\n\n  <!-- \u2500\u2500 Tree view \u2500\u2500 -->\n  @case ('tree') {\n  <div class=\"fb-contents fb-contents--tree\" [attr.aria-label]=\"ariaLabel()\">\n    <ui-tree-view [datasource]=\"treeDatasource()\" [displayWith]=\"displayNodeLabel\" ariaLabel=\"File tree\"\n      (nodeActivated)=\"onTreeNodeActivated($event)\">\n      <ng-template #nodeTemplate let-node>\n        <ui-icon [svg]=\"getEntryIcon(node.data)\" [size]=\"16\" />\n        <span class=\"fb-node-label\">{{ node.data.name }}</span>\n      </ng-template>\n    </ui-tree-view>\n  </div>\n  }\n\n  <!-- \u2500\u2500 Column view (NeXTSTEP / macOS Finder) \u2500\u2500 -->\n  @case ('column') {\n  <div class=\"fb-contents fb-contents--column\" [attr.aria-label]=\"ariaLabel()\">\n    @for (pane of columnPanes(); track $index; let i = $index) {\n    <div class=\"fb-column-pane\" role=\"list\">\n      @for (entry of columnPaneVisibleEntries(pane.entries); track entry.id) {\n      <div class=\"fb-column-entry\" role=\"listitem\" [attr.tabindex]=\"isEntryAllowed(entry) ? 0 : -1\"\n        [class.fb-column-entry--selected]=\"isColumnEntrySelected(i, entry)\"\n        [class.filtered]=\"!isEntryAllowed(entry)\"\n        [attr.aria-selected]=\"isColumnEntrySelected(i, entry)\"\n        [attr.aria-disabled]=\"!isEntryAllowed(entry) || null\"\n        [class.fb-column-entry--directory]=\"entry.isDirectory\"\n        (click)=\"onColumnEntryClick(i, entry)\" (dblclick)=\"onColumnEntryDblClick(entry)\"\n        (keydown)=\"onEntryKeydown($event, entry)\">\n        <ui-icon [svg]=\"getEntryIcon(entry)\" [size]=\"16\" />\n        <span class=\"fb-column-entry-name\">{{ entry.name }}</span>\n        @if (entry.isDirectory) {\n        <ui-icon class=\"fb-entry-chevron\" [svg]=\"icons.chevronRight\" [size]=\"12\" />\n        }\n      </div>\n      } @empty {\n      <div class=\"fb-empty\">Empty</div>\n      }\n    </div>\n    }\n  </div>\n  }\n  }\n\n  <!-- \u2550\u2550\u2550 Details pane \u2550\u2550\u2550 -->\n  @if (showDetails()) {\n  <!-- Details resize divider -->\n  <div class=\"fb-divider fb-divider--details ui-surface-type-raised\" role=\"separator\" tabindex=\"0\"\n    aria-label=\"Resize details\" aria-orientation=\"horizontal\" (pointerdown)=\"onDividerPointerDown($event, 'details')\"\n    (dblclick)=\"onDividerDblClick('details')\">\n    <div class=\"fb-divider-handle\"></div>\n  </div>\n\n  <aside class=\"fb-details\" [class.fb-details--collapsed]=\"detailsCollapsed()\" aria-label=\"File details\">\n    @if (!detailsCollapsed()) {\n      @if (hasSelection()) {\n      <div class=\"fb-details-header\">\n        <ui-icon [svg]=\"getEntryIcon(selectedEntry()!)\" [size]=\"32\" />\n        <span class=\"fb-details-name\">{{ selectedEntry()!.name }}</span>\n        <span class=\"fb-details-kind\">\n          {{ selectedEntry()!.isDirectory ? 'Folder' : 'File' }}\n        </span>\n      </div>\n\n      @if (detailFields().length > 0) {\n      <dl class=\"fb-details-meta\">\n        @for (field of detailFields(); track field.label) {\n        <dt class=\"fb-details-label\">{{ field.label }}</dt>\n        <dd class=\"fb-details-value\">{{ field.value }}</dd>\n        }\n      </dl>\n      }\n      } @else {\n      <div class=\"fb-details-empty\">No selection</div>\n      }\n    }\n  </aside>\n  }\n</div>", styles: [":host{--fb-sidebar-width: 240px;--fb-details-width: 220px;--fb-column-width: 220px;display:flex;flex-direction:column;height:100%;border-radius:8px;overflow:hidden}.fb-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;min-height:40px}.fb-header ui-breadcrumb{flex:1;min-width:0}.fb-toolbar{display:flex;align-items:center;gap:2px;flex-shrink:0;margin-left:8px}.fb-toolbar-group{display:flex;align-items:center;gap:1px}.fb-toolbar-divider{width:1px;height:20px;background:var(--ui-border, rgba(0, 0, 0, .12));margin:0 4px;flex-shrink:0}.fb-toolbar-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;padding:0;border:none;border-radius:4px;background:transparent;color:var(--ui-text-muted, #6b7280);cursor:pointer;outline:none;transition:background 60ms ease,color 60ms ease}.fb-toolbar-btn:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06));color:var(--ui-text, #1d232b)}.fb-toolbar-btn:focus-visible{background:var(--ui-hover-bg, rgba(0, 0, 0, .06));color:var(--ui-text, #1d232b);outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-toolbar-btn.active{background:var(--ui-selected-bg, rgba(53, 132, 228, .18));color:var(--ui-accent, #3584e4)}.fb-body{display:flex;flex:1;min-height:0}.fb-sidebar{width:var(--fb-sidebar-width);min-width:var(--fb-sidebar-width);border-right:none;overflow-y:auto;padding:4px 0;transition:width .15s ease,min-width .15s ease}.fb-sidebar ui-tree-view{font-size:13px}.fb-sidebar--collapsed{width:0;min-width:0;overflow:hidden;padding:0}.fb-node-label{margin-left:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fb-divider{flex:0 0 5px;display:flex;align-items:center;justify-content:center;border:none;outline:none;-webkit-user-select:none;user-select:none;touch-action:none;cursor:col-resize;background:transparent;transition:background-color .15s ease;position:relative;z-index:2}.fb-divider:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-divider:hover .fb-divider-handle{background:var(--ui-accent, #3584e4)}.fb-divider:focus-visible{outline-offset:-2px}.fb-divider-handle{width:2px;height:24px;border-radius:2px;background:var(--ui-border-strong, #505d6d);transition:background-color .15s ease}:host(.dragging){cursor:col-resize}:host(.dragging) .fb-contents,:host(.dragging) .fb-sidebar,:host(.dragging) .fb-details{pointer-events:none;-webkit-user-select:none;user-select:none}.fb-contents{flex:1;overflow-y:auto;padding:4px 0;min-width:0}.fb-empty{padding:32px 16px;text-align:center;font-size:14px}.fb-entry{display:flex;align-items:center;gap:8px;padding:6px 12px;cursor:pointer;font-size:14px;border-radius:4px;margin:1px 6px;transition:background 60ms ease;outline:none}.fb-entry:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-entry:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-entry--selected{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-entry--selected:hover,.fb-entry--selected:focus-visible{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent-hover, color-mix(in srgb, var(--ui-accent, #3584e4) 85%, black))}.fb-entry-icon{flex-shrink:0}.fb-entry-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-entry-chevron{flex-shrink:0;opacity:.5}.fb-entry--directory{font-weight:500}.fb-contents--icons{display:flex;flex-wrap:wrap;align-content:flex-start;gap:4px;padding:12px}.fb-icon-tile{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:6px;width:88px;padding:10px 4px;border-radius:6px;cursor:pointer;text-align:center;outline:none;transition:background 60ms ease}.fb-icon-tile:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-icon-tile:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-icon-tile--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-icon-tile--selected:hover,.fb-icon-tile--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-icon-tile-icon{flex-shrink:0}.fb-icon-tile-name{font-size:11px;line-height:1.3;max-width:80px;word-break:break-word;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.fb-contents--detail{padding:0}.fb-detail-header{display:flex;align-items:center;padding:6px 12px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;position:sticky;top:0;z-index:1}.fb-detail-row{display:flex;align-items:center;padding:5px 12px;font-size:13px;cursor:pointer;outline:none;transition:background 60ms ease}.fb-detail-row:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-detail-row:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-detail-row.fb-detail-row--directory{font-weight:500}.fb-detail-row--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-detail-row--selected:hover,.fb-detail-row--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-detail-cell{padding:0 6px}.fb-detail-cell--icon{flex:0 0 28px;display:flex;align-items:center;justify-content:center}.fb-detail-cell--name{flex:2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-detail-cell--meta{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;font-size:12px}.fb-detail-row--selected .fb-detail-cell--meta{opacity:.8}.fb-contents--tree ui-tree-view{font-size:13px}.fb-contents--column{display:flex;overflow-x:auto;overflow-y:hidden;padding:0}.fb-column-pane{flex:0 0 var(--fb-column-width);min-width:var(--fb-column-width);overflow-y:auto;padding:2px 0}.fb-column-pane:last-child{border-right:none}.fb-column-entry{display:flex;align-items:center;gap:6px;padding:5px 10px;font-size:13px;cursor:pointer;outline:none;transition:background 60ms ease}.fb-column-entry:hover{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06))}.fb-column-entry:focus-visible{color:inherit;background:var(--ui-hover-bg, rgba(0, 0, 0, .06));outline:2px solid var(--ui-accent, #3584e4);outline-offset:-2px}.fb-column-entry.fb-column-entry--directory{font-weight:500}.fb-column-entry--selected{color:var(--ui-accent, #3584e4);background:var(--ui-selected-bg, rgba(53, 132, 228, .18));box-shadow:inset 0 0 0 1px var(--ui-accent, #3584e4)}.fb-column-entry--selected:hover,.fb-column-entry--selected:focus-visible{color:var(--ui-accent, #3584e4);background:var(--ui-selected-hover-bg, rgba(53, 132, 228, .24))}.fb-column-entry-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.fb-details{width:var(--fb-details-width);min-width:var(--fb-details-width);border-left:none;overflow-y:auto;padding:16px 12px;display:flex;flex-direction:column;gap:16px;transition:width .15s ease,min-width .15s ease}.fb-details--collapsed{width:0;min-width:0;overflow:hidden;padding:0}.fb-details-header{display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center}.fb-details-empty{display:flex;align-items:center;justify-content:center;flex:1;padding:24px 12px;font-size:13px;color:var(--ui-text-muted, #6b7280);text-align:center}.fb-details-name{font-weight:600;font-size:14px;word-break:break-word}.fb-details-kind{font-size:12px}.fb-details-meta{display:grid;grid-template-columns:auto 1fr;gap:6px 10px;font-size:12px;margin:0}.fb-details-label{font-weight:600}.fb-details-value{margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.filtered{opacity:.35;pointer-events:none;-webkit-user-select:none;user-select:none;cursor:default}\n"] }]
        }], ctorParameters: () => [], propDecorators: { datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], showSidebar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSidebar", required: false }] }], rootLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rootLabel", required: false }] }], viewMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewMode", required: false }] }, { type: i0.Output, args: ["viewModeChange"] }], showDetails: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDetails", required: false }] }, { type: i0.Output, args: ["showDetailsChange"] }], showToolbar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showToolbar", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], metadataProvider: [{ type: i0.Input, args: [{ isSignal: true, alias: "metadataProvider", required: false }] }], allowedTypes: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowedTypes", required: false }] }], hideFiltered: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideFiltered", required: false }] }], selectedEntry: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedEntry", required: false }] }, { type: i0.Output, args: ["selectedEntryChange"] }], fileActivated: [{ type: i0.Output, args: ["fileActivated"] }], directoryChange: [{ type: i0.Output, args: ["directoryChange"] }], entryTemplate: [{ type: i0.ContentChild, args: ["entryTemplate", { isSignal: true }] }], treeViewRef: [{ type: i0.ViewChild, args: ["treeView", { isSignal: true }] }] } });

/**
 * A single chat message bubble with optional avatar, sender name,
 * content, and timestamp.
 *
 * The bubble adjusts its visual alignment and styling based on the
 * `isMine` input — right-aligned with accent colour for the
 * current user, left-aligned with a neutral surface for others.
 *
 * ### Usage
 * ```html
 * <ui-message-bubble [message]="msg" [isMine]="false" />
 * ```
 */
class UIMessageBubble {
    // ── Inputs ────────────────────────────────────────────────────────
    /** The message to render. */
    message = input.required(...(ngDevMode ? [{ debugName: "message" }] : []));
    /** Whether this message belongs to the current user. */
    isMine = input(false, ...(ngDevMode ? [{ debugName: "isMine" }] : []));
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — whether content should be rendered as HTML. */
    isRichText = computed(() => (this.message().type ?? "text") === "rich-text", ...(ngDevMode ? [{ debugName: "isRichText" }] : []));
    /** @internal — formatted short time string. */
    timeString = computed(() => {
        const ts = this.message().timestamp;
        return ts.toLocaleTimeString(undefined, {
            hour: "numeric",
            minute: "2-digit",
        });
    }, ...(ngDevMode ? [{ debugName: "timeString" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIMessageBubble, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIMessageBubble, isStandalone: true, selector: "ui-message-bubble", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: true, transformFunction: null }, isMine: { classPropertyName: "isMine", publicName: "isMine", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.mine": "isMine()" }, classAttribute: "ui-message-bubble" }, ngImport: i0, template: "@if (!isMine()) {\n  <ui-avatar\n    [name]=\"message().sender.name\"\n    [src]=\"message().sender.avatarSrc\"\n    [email]=\"message().sender.avatarEmail\"\n    size=\"small\"\n  />\n}\n\n<div class=\"bubble-body\">\n  @if (!isMine()) {\n    <span class=\"bubble-sender\">{{ message().sender.name }}</span>\n  }\n\n  @if (isRichText()) {\n    <div class=\"bubble-content\" [innerHTML]=\"message().content\"></div>\n  } @else {\n    <div class=\"bubble-content\">{{ message().content }}</div>\n  }\n\n  <time class=\"bubble-timestamp\">{{ timeString() }}</time>\n</div>\n", styles: [":host{display:flex;align-items:flex-end;gap:8px;max-width:80%;margin-bottom:2px}:host(.mine){align-self:flex-end;flex-direction:row-reverse}:host(.mine) .bubble-body{align-items:flex-end}:host(.mine) .bubble-content{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-radius:16px 16px 4px}:host(.mine) .bubble-timestamp{text-align:right}.bubble-body{display:flex;flex-direction:column;gap:2px;min-width:0}.bubble-sender{font-size:.75rem;font-weight:600;padding-left:4px;color:var(--ui-text-muted, #5a6470)}.bubble-content{padding:8px 14px;border-radius:16px 16px 16px 4px;font-size:.875rem;line-height:1.45;word-wrap:break-word;overflow-wrap:break-word;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5)}.bubble-timestamp{font-size:.6875rem;padding:0 4px;color:var(--ui-text-muted, #5a6470)}\n"], dependencies: [{ kind: "component", type: UIAvatar, selector: "ui-avatar", inputs: ["src", "email", "name", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIMessageBubble, decorators: [{
            type: Component,
            args: [{ selector: "ui-message-bubble", standalone: true, imports: [UIAvatar], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: "ui-message-bubble",
                        "[class.mine]": "isMine()",
                    }, template: "@if (!isMine()) {\n  <ui-avatar\n    [name]=\"message().sender.name\"\n    [src]=\"message().sender.avatarSrc\"\n    [email]=\"message().sender.avatarEmail\"\n    size=\"small\"\n  />\n}\n\n<div class=\"bubble-body\">\n  @if (!isMine()) {\n    <span class=\"bubble-sender\">{{ message().sender.name }}</span>\n  }\n\n  @if (isRichText()) {\n    <div class=\"bubble-content\" [innerHTML]=\"message().content\"></div>\n  } @else {\n    <div class=\"bubble-content\">{{ message().content }}</div>\n  }\n\n  <time class=\"bubble-timestamp\">{{ timeString() }}</time>\n</div>\n", styles: [":host{display:flex;align-items:flex-end;gap:8px;max-width:80%;margin-bottom:2px}:host(.mine){align-self:flex-end;flex-direction:row-reverse}:host(.mine) .bubble-body{align-items:flex-end}:host(.mine) .bubble-content{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4);border-radius:16px 16px 4px}:host(.mine) .bubble-timestamp{text-align:right}.bubble-body{display:flex;flex-direction:column;gap:2px;min-width:0}.bubble-sender{font-size:.75rem;font-weight:600;padding-left:4px;color:var(--ui-text-muted, #5a6470)}.bubble-content{padding:8px 14px;border-radius:16px 16px 16px 4px;font-size:.875rem;line-height:1.45;word-wrap:break-word;overflow-wrap:break-word;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5)}.bubble-timestamp{font-size:.6875rem;padding:0 4px;color:var(--ui-text-muted, #5a6470)}\n"] }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: true }] }], isMine: [{ type: i0.Input, args: [{ isSignal: true, alias: "isMine", required: false }] }] } });

/**
 * A chat / messaging view composing UIAvatar, UIRichTextEditor,
 * and a scrollable message list with a composer bar.
 *
 * Messages are supplied via the `messages` input. The component
 * groups them by date and renders each with sender avatar, bubble,
 * and timestamp. The current user's messages are right-aligned.
 *
 * The composer bar supports both plain-text (`textarea`) and
 * rich-text (`UIRichTextEditor`) modes via the `composerMode`
 * input.
 *
 * Custom message templates can be projected using a
 * `#messageTemplate` content child.
 *
 * ### Basic usage
 * ```html
 * <ui-chat-view
 *   [messages]="messages"
 *   [currentUser]="me"
 *   (messageSend)="onSend($event)"
 * />
 * ```
 *
 * ### Rich-text composer
 * ```html
 * <ui-chat-view
 *   [messages]="messages"
 *   [currentUser]="me"
 *   composerMode="rich-text"
 *   (messageSend)="onSend($event)"
 * />
 * ```
 */
class UIChatView {
    /** @internal Compact chat composer toolbar actions. */
    static DEFAULT_COMPACT_COMPOSER_ACTIONS = ["bold", "italic", "strikethrough", "link"];
    // ── Inputs ────────────────────────────────────────────────────────
    /** The list of messages to display. */
    messages = input([], ...(ngDevMode ? [{ debugName: "messages" }] : []));
    /** The current user (their messages are right-aligned). */
    currentUser = input.required(...(ngDevMode ? [{ debugName: "currentUser" }] : []));
    /** Composer input mode. */
    composerMode = input("text", ...(ngDevMode ? [{ debugName: "composerMode" }] : []));
    /**
     * Rich-text composer presentation.
     *
     * - `'compact'` — small floating-toolbar composer (default)
     * - `'default'` — full rich-text editor chrome
     */
    composerPresentation = input("compact", ...(ngDevMode ? [{ debugName: "composerPresentation" }] : []));
    /**
     * Toolbar actions for the compact rich-text composer.
     *
     * Defaults to a small chat-oriented set.
     */
    composerToolbarActions = input(UIChatView.DEFAULT_COMPACT_COMPOSER_ACTIONS, ...(ngDevMode ? [{ debugName: "composerToolbarActions" }] : []));
    /** Placeholder text for the composer. */
    placeholder = input("Type a message…", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /** Accessible label for the chat view. */
    ariaLabel = input("Chat", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    // ── Content children ──────────────────────────────────────────────
    /**
     * Optional custom template for rendering individual messages.
     * Receives a {@link MessageTemplateContext}.
     */
    messageTemplate = contentChild(TemplateRef, ...(ngDevMode ? [{ debugName: "messageTemplate" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emitted when the user sends a message. */
    messageSend = output();
    // ── View queries ──────────────────────────────────────────────────
    /** @internal */
    messageListRef = viewChild("messageList", ...(ngDevMode ? [{ debugName: "messageListRef" }] : []));
    /** @internal */
    composerInputRef = viewChild("composerInput", ...(ngDevMode ? [{ debugName: "composerInputRef" }] : []));
    // ── Internal state ────────────────────────────────────────────────
    /** @internal — current text in the composer. */
    composerValue = signal("", ...(ngDevMode ? [{ debugName: "composerValue" }] : []));
    // ── Icons ─────────────────────────────────────────────────────────
    /** @internal */
    sendIcon = UIIcons.Lucide.Communication.SendHorizontal;
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — messages grouped by date. */
    groupedMessages = computed(() => this.groupByDate(this.messages()), ...(ngDevMode ? [{ debugName: "groupedMessages" }] : []));
    /** @internal — whether the send button should be enabled. */
    canSend = computed(() => this.composerValue().trim().length > 0, ...(ngDevMode ? [{ debugName: "canSend" }] : []));
    // ── Constructor ───────────────────────────────────────────────────
    constructor() {
        // Auto-scroll to bottom when messages change
        effect(() => {
            this.messages(); // track
            this.scrollToBottom();
        });
    }
    // ── Lifecycle ─────────────────────────────────────────────────────
    ngAfterViewInit() {
        this.scrollToBottom();
    }
    // ── Public methods ────────────────────────────────────────────────
    /** Scroll the message list to the bottom. */
    scrollToBottom() {
        requestAnimationFrame(() => {
            const el = this.messageListRef()?.nativeElement;
            if (el) {
                el.scrollTop = el.scrollHeight;
            }
        });
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — determine if a message was sent by the current user. */
    isMine(message) {
        return message.sender.id === this.currentUser().id;
    }
    /** @internal — send the composed message. */
    send() {
        const content = this.composerValue().trim();
        if (!content)
            return;
        this.messageSend.emit({ content });
        this.composerValue.set("");
        // Re-focus the plain-text composer
        const textarea = this.composerInputRef()?.nativeElement;
        if (textarea) {
            textarea.focus();
        }
    }
    /** @internal — handle Enter key in the text composer. */
    onComposerKeydown(event) {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            this.send();
        }
    }
    /** @internal — handle input events on the textarea. */
    onComposerInput(event) {
        const target = event.target;
        this.composerValue.set(target.value);
    }
    // ── Private methods ───────────────────────────────────────────────
    /** Group messages by date, producing human-readable labels. */
    groupByDate(messages) {
        const groups = new Map();
        for (const msg of messages) {
            const key = this.toDateKey(msg.timestamp);
            const list = groups.get(key);
            if (list) {
                list.push(msg);
            }
            else {
                groups.set(key, [msg]);
            }
        }
        const today = this.toDateKey(new Date());
        const yesterday = this.toDateKey(new Date(Date.now() - 86_400_000));
        const result = [];
        for (const [date, msgs] of groups) {
            let label;
            if (date === today) {
                label = "Today";
            }
            else if (date === yesterday) {
                label = "Yesterday";
            }
            else {
                label = new Date(date).toLocaleDateString(undefined, {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                });
            }
            result.push({ date, label, messages: msgs });
        }
        return result;
    }
    /** Convert a Date to a YYYY-MM-DD key. */
    toDateKey(d) {
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIChatView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIChatView, isStandalone: true, selector: "ui-chat-view", inputs: { messages: { classPropertyName: "messages", publicName: "messages", isSignal: true, isRequired: false, transformFunction: null }, currentUser: { classPropertyName: "currentUser", publicName: "currentUser", isSignal: true, isRequired: true, transformFunction: null }, composerMode: { classPropertyName: "composerMode", publicName: "composerMode", isSignal: true, isRequired: false, transformFunction: null }, composerPresentation: { classPropertyName: "composerPresentation", publicName: "composerPresentation", isSignal: true, isRequired: false, transformFunction: null }, composerToolbarActions: { classPropertyName: "composerToolbarActions", publicName: "composerToolbarActions", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { messageSend: "messageSend" }, host: { classAttribute: "ui-chat-view" }, queries: [{ propertyName: "messageTemplate", first: true, predicate: TemplateRef, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "messageListRef", first: true, predicate: ["messageList"], descendants: true, isSignal: true }, { propertyName: "composerInputRef", first: true, predicate: ["composerInput"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"chat-messages\" #messageList role=\"log\" [attr.aria-label]=\"ariaLabel()\">\n  @for (group of groupedMessages(); track group.date) {\n    <div class=\"chat-date-divider\" role=\"separator\">\n      <span class=\"chat-date-label\">{{ group.label }}</span>\n    </div>\n\n    @for (message of group.messages; track message.id) {\n      @if (messageTemplate(); as tpl) {\n        <ng-container\n          *ngTemplateOutlet=\"tpl; context: { $implicit: message, message: message, isMine: isMine(message) }\"\n        />\n      } @else {\n        @if ((message.type ?? 'text') === 'system') {\n          <div class=\"chat-system-message\">\n            {{ message.content }}\n          </div>\n        } @else {\n          <ui-message-bubble\n            [message]=\"message\"\n            [isMine]=\"isMine(message)\"\n          />\n        }\n      }\n    }\n  }\n\n  @if (groupedMessages().length === 0) {\n    <div class=\"chat-empty\">No messages yet</div>\n  }\n</div>\n\n<div class=\"chat-composer\">\n  @if (composerMode() === 'rich-text') {\n    <ui-rich-text-editor\n      [(value)]=\"composerValue\"\n      [presentation]=\"composerPresentation()\"\n      [compactToolbarActions]=\"composerToolbarActions()\"\n      [placeholder]=\"placeholder()\"\n      ariaLabel=\"Message composer\"\n    />\n  } @else {\n    <textarea\n      #composerInput\n      class=\"chat-composer-input\"\n      [placeholder]=\"placeholder()\"\n      [value]=\"composerValue()\"\n      (input)=\"onComposerInput($event)\"\n      (keydown)=\"onComposerKeydown($event)\"\n      rows=\"1\"\n      aria-label=\"Message composer\"\n    ></textarea>\n  }\n\n  <button\n    type=\"button\"\n    class=\"chat-send-button\"\n    [disabled]=\"!canSend()\"\n    [attr.aria-label]=\"'Send message'\"\n    (click)=\"send()\"\n  >\n    <ui-icon [svg]=\"sendIcon\" [size]=\"18\" />\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%;border-radius:8px;overflow:hidden}.chat-messages{flex:1;padding:16px;display:flex;flex-direction:column;gap:4px;overflow-y:auto;overscroll-behavior:contain;min-height:0}.chat-date-divider{display:flex;align-items:center;gap:12px;margin:16px 0 8px}.chat-date-divider:before,.chat-date-divider:after{content:\"\";flex:1;height:1px;background:var(--ui-border, #d4d8dd)}.chat-date-label{font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em;white-space:nowrap;color:var(--ui-text-muted, #5a6470)}.chat-system-message{text-align:center;font-size:.8125rem;font-style:italic;padding:4px 0;color:var(--ui-text-muted, #5a6470)}.chat-empty{flex:1;display:flex;align-items:center;justify-content:center;font-size:.875rem;color:var(--ui-text-muted, #5a6470)}.chat-composer{display:flex;align-items:flex-end;gap:8px;padding:12px 16px;border-top:1px solid var(--ui-border, #d4d8dd)}.chat-composer ui-rich-text-editor{flex:1;min-width:0}.chat-composer-input{flex:1;min-width:0;resize:none;border-radius:20px;padding:8px 16px;font-size:.875rem;line-height:1.4;font-family:inherit;outline:none;max-height:120px;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5);border:1px solid var(--ui-border, #d4d8dd)}.chat-composer-input:focus{border-color:var(--ui-accent, #3584e4)}.chat-send-button{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;flex-shrink:0;cursor:pointer;transition:opacity .15s;color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4)}.chat-send-button:disabled{cursor:default;opacity:.4}.chat-send-button:not(:disabled):hover{opacity:.85}.chat-send-button:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }, { kind: "component", type: UIMessageBubble, selector: "ui-message-bubble", inputs: ["message", "isMine"] }, { kind: "component", type: UIRichTextEditor, selector: "ui-rich-text-editor", inputs: ["mode", "disabled", "presentation", "readonly", "ariaLabel", "placeholder", "toolbarActions", "compactToolbarActions", "placeholders", "placeholderContext", "splitDirection", "sanitise", "maxLength", "imageHandler", "emojiCategories", "value"], outputs: ["valueChange", "blockInserted", "blockEdited", "blockRemoved"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIChatView, decorators: [{
            type: Component,
            args: [{ selector: "ui-chat-view", standalone: true, imports: [NgTemplateOutlet, UIIcon, UIMessageBubble, UIRichTextEditor], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-chat-view",
                    }, template: "<div class=\"chat-messages\" #messageList role=\"log\" [attr.aria-label]=\"ariaLabel()\">\n  @for (group of groupedMessages(); track group.date) {\n    <div class=\"chat-date-divider\" role=\"separator\">\n      <span class=\"chat-date-label\">{{ group.label }}</span>\n    </div>\n\n    @for (message of group.messages; track message.id) {\n      @if (messageTemplate(); as tpl) {\n        <ng-container\n          *ngTemplateOutlet=\"tpl; context: { $implicit: message, message: message, isMine: isMine(message) }\"\n        />\n      } @else {\n        @if ((message.type ?? 'text') === 'system') {\n          <div class=\"chat-system-message\">\n            {{ message.content }}\n          </div>\n        } @else {\n          <ui-message-bubble\n            [message]=\"message\"\n            [isMine]=\"isMine(message)\"\n          />\n        }\n      }\n    }\n  }\n\n  @if (groupedMessages().length === 0) {\n    <div class=\"chat-empty\">No messages yet</div>\n  }\n</div>\n\n<div class=\"chat-composer\">\n  @if (composerMode() === 'rich-text') {\n    <ui-rich-text-editor\n      [(value)]=\"composerValue\"\n      [presentation]=\"composerPresentation()\"\n      [compactToolbarActions]=\"composerToolbarActions()\"\n      [placeholder]=\"placeholder()\"\n      ariaLabel=\"Message composer\"\n    />\n  } @else {\n    <textarea\n      #composerInput\n      class=\"chat-composer-input\"\n      [placeholder]=\"placeholder()\"\n      [value]=\"composerValue()\"\n      (input)=\"onComposerInput($event)\"\n      (keydown)=\"onComposerKeydown($event)\"\n      rows=\"1\"\n      aria-label=\"Message composer\"\n    ></textarea>\n  }\n\n  <button\n    type=\"button\"\n    class=\"chat-send-button\"\n    [disabled]=\"!canSend()\"\n    [attr.aria-label]=\"'Send message'\"\n    (click)=\"send()\"\n  >\n    <ui-icon [svg]=\"sendIcon\" [size]=\"18\" />\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%;border-radius:8px;overflow:hidden}.chat-messages{flex:1;padding:16px;display:flex;flex-direction:column;gap:4px;overflow-y:auto;overscroll-behavior:contain;min-height:0}.chat-date-divider{display:flex;align-items:center;gap:12px;margin:16px 0 8px}.chat-date-divider:before,.chat-date-divider:after{content:\"\";flex:1;height:1px;background:var(--ui-border, #d4d8dd)}.chat-date-label{font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em;white-space:nowrap;color:var(--ui-text-muted, #5a6470)}.chat-system-message{text-align:center;font-size:.8125rem;font-style:italic;padding:4px 0;color:var(--ui-text-muted, #5a6470)}.chat-empty{flex:1;display:flex;align-items:center;justify-content:center;font-size:.875rem;color:var(--ui-text-muted, #5a6470)}.chat-composer{display:flex;align-items:flex-end;gap:8px;padding:12px 16px;border-top:1px solid var(--ui-border, #d4d8dd)}.chat-composer ui-rich-text-editor{flex:1;min-width:0}.chat-composer-input{flex:1;min-width:0;resize:none;border-radius:20px;padding:8px 16px;font-size:.875rem;line-height:1.4;font-family:inherit;outline:none;max-height:120px;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5);border:1px solid var(--ui-border, #d4d8dd)}.chat-composer-input:focus{border-color:var(--ui-accent, #3584e4)}.chat-send-button{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;flex-shrink:0;cursor:pointer;transition:opacity .15s;color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3584e4)}.chat-send-button:disabled{cursor:default;opacity:.4}.chat-send-button:not(:disabled):hover{opacity:.85}.chat-send-button:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { messages: [{ type: i0.Input, args: [{ isSignal: true, alias: "messages", required: false }] }], currentUser: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentUser", required: true }] }], composerMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "composerMode", required: false }] }], composerPresentation: [{ type: i0.Input, args: [{ isSignal: true, alias: "composerPresentation", required: false }] }], composerToolbarActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "composerToolbarActions", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], messageTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => TemplateRef), { isSignal: true }] }], messageSend: [{ type: i0.Output, args: ["messageSend"] }], messageListRef: [{ type: i0.ViewChild, args: ["messageList", { isSignal: true }] }], composerInputRef: [{ type: i0.ViewChild, args: ["composerInput", { isSignal: true }] }] } });

/**
 * A single step inside a {@link UIWizard}.
 *
 * Wrap each piece of wizard content in this component and project
 * it into `<ui-wizard>`.
 *
 * ### Usage
 * ```html
 * <ui-wizard>
 *   <ui-wizard-step label="Account">…</ui-wizard-step>
 *   <ui-wizard-step label="Profile">…</ui-wizard-step>
 *   <ui-wizard-step label="Confirm">…</ui-wizard-step>
 * </ui-wizard>
 * ```
 */
class UIWizardStep {
    // ── Inputs ────────────────────────────────────────────────────────
    /** Label shown in the step indicator. */
    label = input.required(...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Whether this step is optional (shown as hint text). */
    optional = input(false, ...(ngDevMode ? [{ debugName: "optional" }] : []));
    /**
     * Whether the user can advance past this step. Bind a
     * signal expression to create a validation gate.
     *
     * @default true
     */
    canAdvance = input(true, ...(ngDevMode ? [{ debugName: "canAdvance" }] : []));
    // ── View queries ──────────────────────────────────────────────────
    /** @internal — template holding the step's projected content. */
    contentTemplate = viewChild.required("stepContent");
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIWizardStep, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.1.0", type: UIWizardStep, isStandalone: true, selector: "ui-wizard-step", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, optional: { classPropertyName: "optional", publicName: "optional", isSignal: true, isRequired: false, transformFunction: null }, canAdvance: { classPropertyName: "canAdvance", publicName: "canAdvance", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style.display": "\"none\"" }, classAttribute: "ui-wizard-step" }, providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: ["stepContent"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<ng-template #stepContent><ng-content /></ng-template>", isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIWizardStep, decorators: [{
            type: Component,
            args: [{
                    selector: "ui-wizard-step",
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }],
                    providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }],
                    template: "<ng-template #stepContent><ng-content /></ng-template>",
                    host: {
                        class: "ui-wizard-step",
                        "[style.display]": '"none"',
                    },
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], optional: [{ type: i0.Input, args: [{ isSignal: true, alias: "optional", required: false }] }], canAdvance: [{ type: i0.Input, args: [{ isSignal: true, alias: "canAdvance", required: false }] }], contentTemplate: [{ type: i0.ViewChild, args: ["stepContent", { isSignal: true }] }] } });

/**
 * A multi-step workflow shell with a step indicator, navigation
 * buttons, and optional validation gates.
 *
 * Steps are defined by projecting `<ui-wizard-step>` children.
 * The wizard discovers them via content queries and renders only
 * the active step.
 *
 * ### Basic usage
 * ```html
 * <ui-wizard (complete)="onFinish()">
 *   <ui-wizard-step label="Account">…</ui-wizard-step>
 *   <ui-wizard-step label="Profile">…</ui-wizard-step>
 *   <ui-wizard-step label="Confirm">…</ui-wizard-step>
 * </ui-wizard>
 * ```
 *
 * ### With validation gates
 * ```html
 * <ui-wizard linear>
 *   <ui-wizard-step label="Details" [canAdvance]="formValid()">
 *     …
 *   </ui-wizard-step>
 *   <ui-wizard-step label="Review">…</ui-wizard-step>
 * </ui-wizard>
 * ```
 */
class UIWizard {
    // ── Inputs ────────────────────────────────────────────────────────
    /**
     * When `true`, the user must complete steps in order and
     * cannot click ahead on the step indicator.
     */
    linear = input(false, ...(ngDevMode ? [{ debugName: "linear" }] : []));
    /** Whether to show the step indicator bar. */
    showStepIndicator = input(true, ...(ngDevMode ? [{ debugName: "showStepIndicator" }] : []));
    /** Label for the Back button. */
    backLabel = input("Back", ...(ngDevMode ? [{ debugName: "backLabel" }] : []));
    /** Label for the Next button. */
    nextLabel = input("Next", ...(ngDevMode ? [{ debugName: "nextLabel" }] : []));
    /** Label for the Finish button (shown on the last step). */
    finishLabel = input("Finish", ...(ngDevMode ? [{ debugName: "finishLabel" }] : []));
    /** Accessible label for the wizard. */
    ariaLabel = input("Wizard", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    // ── Models ────────────────────────────────────────────────────────
    /** Zero-based index of the active step (two-way bindable). */
    activeIndex = model(0, ...(ngDevMode ? [{ debugName: "activeIndex" }] : []));
    // ── Content children ──────────────────────────────────────────────
    /** @internal — discovered wizard steps. */
    steps = contentChildren(UIWizardStep, ...(ngDevMode ? [{ debugName: "steps" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emitted when the active step changes. */
    stepChange = output();
    /** Emitted when the user clicks Finish on the last step. */
    complete = output();
    // ── Icons ─────────────────────────────────────────────────────────
    /** @internal */
    checkIcon = UIIcons.Lucide.Notifications.Check;
    // ── Computed ──────────────────────────────────────────────────────
    /** @internal — the currently active step. */
    activeStep = computed(() => {
        const all = this.steps();
        const idx = this.activeIndex();
        return idx >= 0 && idx < all.length ? all[idx] : undefined;
    }, ...(ngDevMode ? [{ debugName: "activeStep" }] : []));
    /** @internal */
    isFirstStep = computed(() => this.activeIndex() === 0, ...(ngDevMode ? [{ debugName: "isFirstStep" }] : []));
    /** @internal */
    isLastStep = computed(() => this.activeIndex() === this.steps().length - 1, ...(ngDevMode ? [{ debugName: "isLastStep" }] : []));
    /** @internal — whether the current step allows advancing. */
    canGoNext = computed(() => {
        const step = this.activeStep();
        return step ? step.canAdvance() : false;
    }, ...(ngDevMode ? [{ debugName: "canGoNext" }] : []));
    /**
     * @internal — whether all non-optional steps are valid.
     * Used to gate the Finish button; prevents completing a wizard
     * that was navigated out-of-order while earlier steps are invalid.
     */
    canFinish = computed(() => this.steps()
        .filter((s) => !s.optional())
        .every((s) => s.canAdvance()), ...(ngDevMode ? [{ debugName: "canFinish" }] : []));
    // ── Public methods ────────────────────────────────────────────────
    /** Advance to the next step (respects validation). */
    next() {
        if (this.isLastStep() || !this.canGoNext())
            return;
        this.goToStep(this.activeIndex() + 1);
    }
    /** Go back to the previous step. */
    previous() {
        if (this.isFirstStep())
            return;
        this.goToStep(this.activeIndex() - 1);
    }
    /** Navigate to a specific step by index. */
    goToStep(index) {
        const all = this.steps();
        if (index < 0 || index >= all.length)
            return;
        // In linear mode, prevent skipping ahead beyond validated steps
        if (this.linear() && index > this.activeIndex()) {
            // Check all steps between current and target are valid
            for (let i = this.activeIndex(); i < index; i++) {
                if (!all[i].canAdvance())
                    return;
            }
        }
        const previous = this.activeIndex();
        if (previous === index)
            return;
        this.activeIndex.set(index);
        this.stepChange.emit({ previousIndex: previous, currentIndex: index });
    }
    /** Complete the wizard (only works on the last step with all steps valid). */
    finish() {
        if (!this.isLastStep() || !this.canFinish())
            return;
        this.complete.emit();
    }
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — handle step indicator click. */
    onStepClick(index) {
        if (this.linear() && index > this.activeIndex()) {
            // In linear mode, only allow clicking completed steps or current
            return;
        }
        this.goToStep(index);
    }
    /** @internal — whether a step indicator is clickable. */
    isStepClickable(index) {
        if (!this.linear())
            return true;
        return index <= this.activeIndex();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIWizard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIWizard, isStandalone: true, selector: "ui-wizard", inputs: { linear: { classPropertyName: "linear", publicName: "linear", isSignal: true, isRequired: false, transformFunction: null }, showStepIndicator: { classPropertyName: "showStepIndicator", publicName: "showStepIndicator", isSignal: true, isRequired: false, transformFunction: null }, backLabel: { classPropertyName: "backLabel", publicName: "backLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, finishLabel: { classPropertyName: "finishLabel", publicName: "finishLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeIndex: "activeIndexChange", stepChange: "stepChange", complete: "complete" }, host: { classAttribute: "ui-wizard" }, providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], queries: [{ propertyName: "steps", predicate: UIWizardStep, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "@if (showStepIndicator()) {\n  <nav class=\"wizard-indicator\" [attr.aria-label]=\"ariaLabel() + ' steps'\" role=\"tablist\">\n    @for (step of steps(); track $index; let i = $index) {\n      @if (i > 0) {\n        <div\n          class=\"wizard-connector\"\n          [class.wizard-connector--completed]=\"i <= activeIndex()\"\n        ></div>\n      }\n\n      <button\n        type=\"button\"\n        class=\"wizard-step-indicator\"\n        [class.wizard-step-indicator--active]=\"i === activeIndex()\"\n        [class.wizard-step-indicator--completed]=\"i < activeIndex()\"\n        [class.wizard-step-indicator--clickable]=\"isStepClickable(i)\"\n        [disabled]=\"!isStepClickable(i)\"\n        role=\"tab\"\n        [attr.aria-selected]=\"i === activeIndex()\"\n        [attr.aria-label]=\"step.label()\"\n        (click)=\"onStepClick(i)\"\n      >\n        <span class=\"wizard-step-number\">\n          @if (i < activeIndex()) {\n            <ui-icon [svg]=\"checkIcon\" [size]=\"14\" />\n          } @else {\n            {{ i + 1 }}\n          }\n        </span>\n        <span class=\"wizard-step-label\">\n          {{ step.label() }}\n          @if (step.optional()) {\n            <span class=\"wizard-step-optional\">Optional</span>\n          }\n        </span>\n      </button>\n    }\n  </nav>\n}\n\n<div class=\"wizard-content\" role=\"tabpanel\">\n  @if (activeStep(); as step) {\n    <ng-container *ngTemplateOutlet=\"step.contentTemplate()\" />\n  }\n</div>\n\n<div class=\"wizard-navigation\">\n  @if (!isFirstStep()) {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--back\"\n      (click)=\"previous()\"\n    >\n      {{ backLabel() }}\n    </button>\n  }\n\n  <div class=\"wizard-nav-spacer\"></div>\n\n  @if (isLastStep()) {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--finish\"\n      [disabled]=\"!canFinish()\"\n      (click)=\"finish()\"\n    >\n      {{ finishLabel() }}\n    </button>\n  } @else {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--next\"\n      [disabled]=\"!canGoNext()\"\n      (click)=\"next()\"\n    >\n      {{ nextLabel() }}\n    </button>\n  }\n</div>\n", styles: [":host{color:var(--ui-text, #1d232b);display:flex;flex-direction:column;border-radius:8px;overflow:hidden}.wizard-indicator{display:flex;align-items:center;padding:20px 24px;gap:0;border-bottom:1px solid var(--ui-border, #dde1e6)}.wizard-connector{flex:1;height:2px;margin:0 4px;background:var(--ui-border, #dde1e6);transition:background .2s}.wizard-connector--completed{background:var(--ui-accent, #3b82f6)}.wizard-step-indicator{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:6px;cursor:default;flex-shrink:0;color:var(--ui-text-muted, #697077)}.wizard-step-indicator--active,.wizard-step-indicator--completed{color:var(--ui-accent, #3b82f6)}.wizard-step-indicator--clickable{cursor:pointer}.wizard-step-indicator--clickable:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .04))}.wizard-step-indicator:disabled{opacity:.5;cursor:default}.wizard-step-indicator:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}.wizard-step-number{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;font-size:.8125rem;font-weight:600;transition:background .2s,color .2s;flex-shrink:0;color:var(--ui-text-muted, #697077);background:var(--ui-surface-2, #f2f4f8);border:2px solid var(--ui-border, #dde1e6)}.wizard-step-indicator--active .wizard-step-number,.wizard-step-indicator--completed .wizard-step-number{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3b82f6);border-color:var(--ui-accent, #3b82f6)}.wizard-step-label{display:flex;flex-direction:column;font-size:.8125rem;font-weight:500;line-height:1.3}.wizard-step-indicator--active .wizard-step-label{font-weight:600}.wizard-step-optional{font-size:.6875rem;font-weight:400;color:var(--ui-text-muted, #697077)}.wizard-content{flex:1;padding:24px;overflow-y:auto;overscroll-behavior:contain;min-height:0}.wizard-navigation{display:flex;align-items:center;gap:12px;padding:16px 24px;border-top:1px solid var(--ui-border, #dde1e6)}.wizard-nav-spacer{flex:1}.wizard-nav-button{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;padding:8px 20px;border-radius:6px;font-size:.875rem;font-weight:500;cursor:pointer;transition:background .15s,opacity .15s}.wizard-nav-button--back{color:var(--ui-text, #1d232b);background:transparent;border:1px solid var(--ui-border, #dde1e6)}.wizard-nav-button--back:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .04))}.wizard-nav-button--next,.wizard-nav-button--finish{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3b82f6)}.wizard-nav-button--next:not(:disabled):hover,.wizard-nav-button--finish:not(:disabled):hover{opacity:.85}.wizard-nav-button--next:disabled,.wizard-nav-button--finish:disabled{cursor:default;opacity:.6}.wizard-nav-button:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: UIIcon, selector: "ui-icon", inputs: ["svg", "size", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIWizard, decorators: [{
            type: Component,
            args: [{ selector: "ui-wizard", standalone: true, imports: [NgTemplateOutlet, UIIcon], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], providers: [{ provide: UI_DEFAULT_SURFACE_TYPE, useValue: "panel" }], host: {
                        class: "ui-wizard",
                    }, template: "@if (showStepIndicator()) {\n  <nav class=\"wizard-indicator\" [attr.aria-label]=\"ariaLabel() + ' steps'\" role=\"tablist\">\n    @for (step of steps(); track $index; let i = $index) {\n      @if (i > 0) {\n        <div\n          class=\"wizard-connector\"\n          [class.wizard-connector--completed]=\"i <= activeIndex()\"\n        ></div>\n      }\n\n      <button\n        type=\"button\"\n        class=\"wizard-step-indicator\"\n        [class.wizard-step-indicator--active]=\"i === activeIndex()\"\n        [class.wizard-step-indicator--completed]=\"i < activeIndex()\"\n        [class.wizard-step-indicator--clickable]=\"isStepClickable(i)\"\n        [disabled]=\"!isStepClickable(i)\"\n        role=\"tab\"\n        [attr.aria-selected]=\"i === activeIndex()\"\n        [attr.aria-label]=\"step.label()\"\n        (click)=\"onStepClick(i)\"\n      >\n        <span class=\"wizard-step-number\">\n          @if (i < activeIndex()) {\n            <ui-icon [svg]=\"checkIcon\" [size]=\"14\" />\n          } @else {\n            {{ i + 1 }}\n          }\n        </span>\n        <span class=\"wizard-step-label\">\n          {{ step.label() }}\n          @if (step.optional()) {\n            <span class=\"wizard-step-optional\">Optional</span>\n          }\n        </span>\n      </button>\n    }\n  </nav>\n}\n\n<div class=\"wizard-content\" role=\"tabpanel\">\n  @if (activeStep(); as step) {\n    <ng-container *ngTemplateOutlet=\"step.contentTemplate()\" />\n  }\n</div>\n\n<div class=\"wizard-navigation\">\n  @if (!isFirstStep()) {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--back\"\n      (click)=\"previous()\"\n    >\n      {{ backLabel() }}\n    </button>\n  }\n\n  <div class=\"wizard-nav-spacer\"></div>\n\n  @if (isLastStep()) {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--finish\"\n      [disabled]=\"!canFinish()\"\n      (click)=\"finish()\"\n    >\n      {{ finishLabel() }}\n    </button>\n  } @else {\n    <button\n      type=\"button\"\n      class=\"wizard-nav-button wizard-nav-button--next\"\n      [disabled]=\"!canGoNext()\"\n      (click)=\"next()\"\n    >\n      {{ nextLabel() }}\n    </button>\n  }\n</div>\n", styles: [":host{color:var(--ui-text, #1d232b);display:flex;flex-direction:column;border-radius:8px;overflow:hidden}.wizard-indicator{display:flex;align-items:center;padding:20px 24px;gap:0;border-bottom:1px solid var(--ui-border, #dde1e6)}.wizard-connector{flex:1;height:2px;margin:0 4px;background:var(--ui-border, #dde1e6);transition:background .2s}.wizard-connector--completed{background:var(--ui-accent, #3b82f6)}.wizard-step-indicator{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:6px;cursor:default;flex-shrink:0;color:var(--ui-text-muted, #697077)}.wizard-step-indicator--active,.wizard-step-indicator--completed{color:var(--ui-accent, #3b82f6)}.wizard-step-indicator--clickable{cursor:pointer}.wizard-step-indicator--clickable:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .04))}.wizard-step-indicator:disabled{opacity:.5;cursor:default}.wizard-step-indicator:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}.wizard-step-number{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;font-size:.8125rem;font-weight:600;transition:background .2s,color .2s;flex-shrink:0;color:var(--ui-text-muted, #697077);background:var(--ui-surface-2, #f2f4f8);border:2px solid var(--ui-border, #dde1e6)}.wizard-step-indicator--active .wizard-step-number,.wizard-step-indicator--completed .wizard-step-number{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3b82f6);border-color:var(--ui-accent, #3b82f6)}.wizard-step-label{display:flex;flex-direction:column;font-size:.8125rem;font-weight:500;line-height:1.3}.wizard-step-indicator--active .wizard-step-label{font-weight:600}.wizard-step-optional{font-size:.6875rem;font-weight:400;color:var(--ui-text-muted, #697077)}.wizard-content{flex:1;padding:24px;overflow-y:auto;overscroll-behavior:contain;min-height:0}.wizard-navigation{display:flex;align-items:center;gap:12px;padding:16px 24px;border-top:1px solid var(--ui-border, #dde1e6)}.wizard-nav-spacer{flex:1}.wizard-nav-button{appearance:none;border:none;background:none;cursor:var(--ui-cursor-click, pointer);font-family:var(--ui-font, inherit);display:inline-flex;align-items:center;justify-content:center;padding:8px 20px;border-radius:6px;font-size:.875rem;font-weight:500;cursor:pointer;transition:background .15s,opacity .15s}.wizard-nav-button--back{color:var(--ui-text, #1d232b);background:transparent;border:1px solid var(--ui-border, #dde1e6)}.wizard-nav-button--back:hover{background:var(--ui-hover-bg, rgba(0, 0, 0, .04))}.wizard-nav-button--next,.wizard-nav-button--finish{color:var(--ui-accent-contrast, #ffffff);background:var(--ui-accent, #3b82f6)}.wizard-nav-button--next:not(:disabled):hover,.wizard-nav-button--finish:not(:disabled):hover{opacity:.85}.wizard-nav-button--next:disabled,.wizard-nav-button--finish:disabled{cursor:default;opacity:.6}.wizard-nav-button:focus-visible{outline:2px solid var(--ui-focus-ring, var(--ui-brand, var(--ui-accent, #3584e4)));outline-offset:2px}\n"] }]
        }], propDecorators: { linear: [{ type: i0.Input, args: [{ isSignal: true, alias: "linear", required: false }] }], showStepIndicator: [{ type: i0.Input, args: [{ isSignal: true, alias: "showStepIndicator", required: false }] }], backLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "backLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], finishLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "finishLabel", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }, { type: i0.Output, args: ["activeIndexChange"] }], steps: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => UIWizardStep), { isSignal: true }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }], complete: [{ type: i0.Output, args: ["complete"] }] } });

/**
 * Column-based kanban board with drag-and-drop card reordering.
 *
 * Cards can be moved within a column (reorder) or across columns
 * (transfer). Columns and cards are provided via a two-way `columns`
 * model. Project an `<ng-template>` to customise card rendering.
 *
 * ### Basic usage
 * ```html
 * <ui-kanban-board [(columns)]="columns">
 *   <ng-template let-card let-column="column">
 *     <h4>{{ card.data.title }}</h4>
 *     <p>{{ card.data.description }}</p>
 *   </ng-template>
 * </ui-kanban-board>
 * ```
 */
class UIKanbanBoard {
    // ── Models ────────────────────────────────────────────────────────
    /** Column data (two-way bindable). Mutated in-place during drag operations. */
    columns = model.required(...(ngDevMode ? [{ debugName: "columns" }] : []));
    // ── Inputs ────────────────────────────────────────────────────────
    /** Accessible label for the board region. */
    ariaLabel = input("Kanban board", ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    // ── Content children ──────────────────────────────────────────────
    /** Optional projected template for card rendering. */
    cardTemplate = contentChild(TemplateRef, ...(ngDevMode ? [{ debugName: "cardTemplate" }] : []));
    // ── Outputs ───────────────────────────────────────────────────────
    /** Emitted after a card is moved (reorder or transfer). */
    cardMoved = output();
    /** Emitted when a card is clicked. */
    cardClicked = output();
    // ── Protected methods ─────────────────────────────────────────────
    /** @internal — handle CDK drop event. */
    onDrop(event) {
        const card = event.item.data;
        const previousColumnId = event.previousContainer.id;
        const currentColumnId = event.container.id;
        const previousIndex = event.previousIndex;
        const currentIndex = event.currentIndex;
        if (event.previousContainer === event.container) {
            moveItemInArray(event.container.data, previousIndex, currentIndex);
        }
        else {
            transferArrayItem(event.previousContainer.data, event.container.data, previousIndex, currentIndex);
        }
        // Trigger signal update with new array reference
        this.columns.set([...this.columns()]);
        this.cardMoved.emit({
            card,
            previousColumnId,
            currentColumnId,
            previousIndex,
            currentIndex,
        });
    }
    /** @internal — handle card click. */
    onCardClick(card) {
        this.cardClicked.emit(card);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIKanbanBoard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIKanbanBoard, isStandalone: true, selector: "ui-kanban-board", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { columns: "columnsChange", cardMoved: "cardMoved", cardClicked: "cardClicked" }, host: { classAttribute: "ui-kanban-board" }, queries: [{ propertyName: "cardTemplate", first: true, predicate: TemplateRef, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: "<div class=\"kanban-columns\" cdkDropListGroup role=\"region\" [attr.aria-label]=\"ariaLabel()\">\n  @for (column of columns(); track column.id) {\n    <div class=\"kanban-column\" [style.border-top-color]=\"column.color ?? null\">\n      <div class=\"kanban-column-header\">\n        <span class=\"kanban-column-title\">{{ column.title }}</span>\n        <span class=\"kanban-column-count\" [attr.aria-label]=\"column.cards.length + ' cards'\">\n          {{ column.cards.length }}\n        </span>\n      </div>\n\n      <div\n        class=\"kanban-column-body\"\n        cdkDropList\n        [cdkDropListData]=\"column.cards\"\n        [id]=\"column.id\"\n        (cdkDropListDropped)=\"onDrop($event)\"\n      >\n        @for (card of column.cards; track card.id) {\n          <div\n            class=\"kanban-card-wrapper\"\n            cdkDrag\n            [cdkDragData]=\"card\"\n            tabindex=\"0\"\n            role=\"listitem\"\n            (click)=\"onCardClick(card)\"\n            (keydown.enter)=\"onCardClick(card)\"\n          >\n            <div cdkDragPlaceholder class=\"kanban-card-placeholder\"></div>\n\n            @if (cardTemplate(); as tpl) {\n              <ng-container\n                *ngTemplateOutlet=\"tpl; context: { $implicit: card, column: column }\"\n              />\n            } @else {\n              <div class=\"kanban-card-fallback\">{{ card.id }}</div>\n            }\n          </div>\n        } @empty {\n          <div class=\"kanban-column-empty\">No cards</div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{--kb-column-width: 280px;--kb-column-gap: 16px;--kb-card-gap: 8px;--kb-column-radius: 8px;--kb-card-radius: 6px;display:flex;flex-direction:column;width:100%;height:100%;min-height:0}.kanban-columns{display:flex;flex:1;gap:var(--kb-column-gap);overflow-x:auto;overscroll-behavior:contain;padding:4px;min-height:0}.kanban-column{flex:1 0 var(--kb-column-width);display:flex;flex-direction:column;border-radius:var(--kb-column-radius);min-height:0;max-height:100%;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5);border:1px solid var(--ui-border, #d4d8dd);border-top:3px solid var(--ui-border, #d4d8dd)}.kanban-column-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px}.kanban-column-title{font-weight:600;font-size:.875rem}.kanban-column-count{font-size:.75rem;border-radius:10px;padding:2px 8px;min-width:1.5em;text-align:center;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.kanban-column-body{flex:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;padding:8px;display:flex;flex-direction:column;gap:var(--kb-card-gap);min-height:60px}.kanban-card-wrapper{border-radius:var(--kb-card-radius);cursor:grab;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);box-shadow:0 1px 3px #0000000f;transition:box-shadow .15s ease,border-color .15s ease}.kanban-card-wrapper:hover{border-color:var(--ui-border-strong, #505d6d);box-shadow:0 2px 6px #0000001a}.kanban-card-wrapper:active{cursor:grabbing}.kanban-card-fallback{padding:8px 12px;font-size:.875rem}.kanban-column-empty{padding:16px;text-align:center;font-size:.813rem;font-style:italic;color:var(--ui-text-muted, #5a6470)}.cdk-drag-preview{border-radius:var(--kb-card-radius);box-shadow:0 4px 16px #00000029}.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.kanban-card-placeholder{display:none;opacity:.12;border-radius:var(--kb-card-radius);min-height:48px;background:var(--ui-accent, #3584e4)}.cdk-drag-placeholder .kanban-card-placeholder{display:block}.kanban-column-body.cdk-drop-list-dragging .kanban-card-wrapper:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: CdkDropListGroup, selector: "[cdkDropListGroup]", inputs: ["cdkDropListGroupDisabled"], exportAs: ["cdkDropListGroup"] }, { kind: "directive", type: CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIKanbanBoard, decorators: [{
            type: Component,
            args: [{ selector: "ui-kanban-board", standalone: true, imports: [
                        NgTemplateOutlet,
                        CdkDropListGroup,
                        CdkDropList,
                        CdkDrag,
                        CdkDragPlaceholder,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: {
                        class: "ui-kanban-board",
                    }, template: "<div class=\"kanban-columns\" cdkDropListGroup role=\"region\" [attr.aria-label]=\"ariaLabel()\">\n  @for (column of columns(); track column.id) {\n    <div class=\"kanban-column\" [style.border-top-color]=\"column.color ?? null\">\n      <div class=\"kanban-column-header\">\n        <span class=\"kanban-column-title\">{{ column.title }}</span>\n        <span class=\"kanban-column-count\" [attr.aria-label]=\"column.cards.length + ' cards'\">\n          {{ column.cards.length }}\n        </span>\n      </div>\n\n      <div\n        class=\"kanban-column-body\"\n        cdkDropList\n        [cdkDropListData]=\"column.cards\"\n        [id]=\"column.id\"\n        (cdkDropListDropped)=\"onDrop($event)\"\n      >\n        @for (card of column.cards; track card.id) {\n          <div\n            class=\"kanban-card-wrapper\"\n            cdkDrag\n            [cdkDragData]=\"card\"\n            tabindex=\"0\"\n            role=\"listitem\"\n            (click)=\"onCardClick(card)\"\n            (keydown.enter)=\"onCardClick(card)\"\n          >\n            <div cdkDragPlaceholder class=\"kanban-card-placeholder\"></div>\n\n            @if (cardTemplate(); as tpl) {\n              <ng-container\n                *ngTemplateOutlet=\"tpl; context: { $implicit: card, column: column }\"\n              />\n            } @else {\n              <div class=\"kanban-card-fallback\">{{ card.id }}</div>\n            }\n          </div>\n        } @empty {\n          <div class=\"kanban-column-empty\">No cards</div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{--kb-column-width: 280px;--kb-column-gap: 16px;--kb-card-gap: 8px;--kb-column-radius: 8px;--kb-card-radius: 6px;display:flex;flex-direction:column;width:100%;height:100%;min-height:0}.kanban-columns{display:flex;flex:1;gap:var(--kb-column-gap);overflow-x:auto;overscroll-behavior:contain;padding:4px;min-height:0}.kanban-column{flex:1 0 var(--kb-column-width);display:flex;flex-direction:column;border-radius:var(--kb-column-radius);min-height:0;max-height:100%;color:var(--ui-text, #1d232b);background:var(--ui-surface-2, #f0f2f5);border:1px solid var(--ui-border, #d4d8dd);border-top:3px solid var(--ui-border, #d4d8dd)}.kanban-column-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px}.kanban-column-title{font-weight:600;font-size:.875rem}.kanban-column-count{font-size:.75rem;border-radius:10px;padding:2px 8px;min-width:1.5em;text-align:center;color:var(--ui-text-muted, #5a6470);background:var(--ui-surface, #ffffff)}.kanban-column-body{flex:1;overflow-y:auto;overscroll-behavior:contain;min-height:0;padding:8px;display:flex;flex-direction:column;gap:var(--kb-card-gap);min-height:60px}.kanban-card-wrapper{border-radius:var(--kb-card-radius);cursor:grab;color:var(--ui-text, #1d232b);background:var(--ui-surface, #ffffff);border:1px solid var(--ui-border, #d4d8dd);box-shadow:0 1px 3px #0000000f;transition:box-shadow .15s ease,border-color .15s ease}.kanban-card-wrapper:hover{border-color:var(--ui-border-strong, #505d6d);box-shadow:0 2px 6px #0000001a}.kanban-card-wrapper:active{cursor:grabbing}.kanban-card-fallback{padding:8px 12px;font-size:.875rem}.kanban-column-empty{padding:16px;text-align:center;font-size:.813rem;font-style:italic;color:var(--ui-text-muted, #5a6470)}.cdk-drag-preview{border-radius:var(--kb-card-radius);box-shadow:0 4px 16px #00000029}.cdk-drag-animating{transition:transform .2s cubic-bezier(0,0,.2,1)}.kanban-card-placeholder{display:none;opacity:.12;border-radius:var(--kb-card-radius);min-height:48px;background:var(--ui-accent, #3584e4)}.cdk-drag-placeholder .kanban-card-placeholder{display:block}.kanban-column-body.cdk-drop-list-dragging .kanban-card-wrapper:not(.cdk-drag-placeholder){transition:transform .2s cubic-bezier(0,0,.2,1)}\n"] }]
        }], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }, { type: i0.Output, args: ["columnsChange"] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], cardTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => TemplateRef), { isSignal: true }] }], cardMoved: [{ type: i0.Output, args: ["cardMoved"] }], cardClicked: [{ type: i0.Output, args: ["cardClicked"] }] } });

/**
 * Content component for a simple alert dialog.
 *
 * Displayed by {@link CommonDialogService.alert}. Shows a title,
 * message, and a single dismiss button.
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UIAlertDialog {
    title = input("Alert", ...(ngDevMode ? [{ debugName: "title" }] : []));
    message = input("", ...(ngDevMode ? [{ debugName: "message" }] : []));
    buttonLabel = input("Acknowledge message", ...(ngDevMode ? [{ debugName: "buttonLabel" }] : []));
    modalRef = inject((ModalRef));
    dismiss() {
        this.modalRef.close(undefined);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIAlertDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UIAlertDialog, isStandalone: true, selector: "ui-alert-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, buttonLabel: { classPropertyName: "buttonLabel", publicName: "buttonLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-alert-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="filled"
        [ariaLabel]="buttonLabel()"
        (click)="dismiss()"
      >
        {{ buttonLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;min-width:20rem}.cd-message{margin:0;line-height:1.55;white-space:pre-wrap}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIAlertDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-alert-dialog", standalone: true, imports: [UIButton, UIDialogHeader, UIDialogBody, UIDialogFooter], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-alert-dialog" }, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="filled"
        [ariaLabel]="buttonLabel()"
        (click)="dismiss()"
      >
        {{ buttonLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{display:flex;flex-direction:column;min-width:20rem}.cd-message{margin:0;line-height:1.55;white-space:pre-wrap}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], buttonLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonLabel", required: false }] }] } });

/**
 * Content component for a confirm dialog.
 *
 * Displayed by {@link CommonDialogService.confirm}. Shows a title,
 * message, and confirm / cancel buttons. Resolves to `true` (confirm)
 * or `false` (cancel / dismiss).
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UIConfirmDialog {
    title = input("Confirm", ...(ngDevMode ? [{ debugName: "title" }] : []));
    message = input("", ...(ngDevMode ? [{ debugName: "message" }] : []));
    confirmLabel = input("Confirm action", ...(ngDevMode ? [{ debugName: "confirmLabel" }] : []));
    cancelLabel = input("Keep current state", ...(ngDevMode ? [{ debugName: "cancelLabel" }] : []));
    variant = input("primary", ...(ngDevMode ? [{ debugName: "variant" }] : []));
    modalRef = inject((ModalRef));
    confirm() {
        this.modalRef.close(true);
    }
    cancel() {
        this.modalRef.close(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIConfirmDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UIConfirmDialog, isStandalone: true, selector: "ui-confirm-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, confirmLabel: { classPropertyName: "confirmLabel", publicName: "confirmLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.danger": "variant() === 'danger'", "class.warning": "variant() === 'warning'" }, classAttribute: "ui-confirm-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="outlined"
        [ariaLabel]="cancelLabel()"
        (click)="cancel()"
      >
        {{ cancelLabel() }}
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="confirmLabel()"
        (click)="confirm()"
      >
        {{ confirmLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;min-width:20rem}.cd-message{margin:0;line-height:1.55;white-space:pre-wrap}:host(.danger){--ui-accent: #d93025}:host(.warning){--ui-accent: #e5a50a}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIConfirmDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-confirm-dialog", standalone: true, imports: [UIButton, UIDialogHeader, UIDialogBody, UIDialogFooter], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ["surfaceType"] }], host: {
                        class: "ui-confirm-dialog",
                        "[class.danger]": "variant() === 'danger'",
                        "[class.warning]": "variant() === 'warning'",
                    }, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="outlined"
        [ariaLabel]="cancelLabel()"
        (click)="cancel()"
      >
        {{ cancelLabel() }}
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="confirmLabel()"
        (click)="confirm()"
      >
        {{ confirmLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{display:flex;flex-direction:column;min-width:20rem}.cd-message{margin:0;line-height:1.55;white-space:pre-wrap}:host(.danger){--ui-accent: #d93025}:host(.warning){--ui-accent: #e5a50a}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], confirmLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "confirmLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });

/**
 * Content component for a prompt dialog.
 *
 * Displayed by {@link CommonDialogService.prompt}. Shows a title,
 * message, a text input, and explicit submit / alternative buttons. Resolves to the
 * entered string or `null` if cancelled.
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UIPromptDialog {
    title = input("Prompt", ...(ngDevMode ? [{ debugName: "title" }] : []));
    message = input("", ...(ngDevMode ? [{ debugName: "message" }] : []));
    defaultValue = input("", ...(ngDevMode ? [{ debugName: "defaultValue" }] : []));
    placeholder = input("", ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    okLabel = input("Apply value", ...(ngDevMode ? [{ debugName: "okLabel" }] : []));
    cancelLabel = input("Keep current value", ...(ngDevMode ? [{ debugName: "cancelLabel" }] : []));
    inputValue = signal("", ...(ngDevMode ? [{ debugName: "inputValue" }] : []));
    modalRef = inject((ModalRef));
    ngOnInit() {
        this.inputValue.set(this.defaultValue());
    }
    ok() {
        this.modalRef.close(this.inputValue());
    }
    cancel() {
        this.modalRef.close(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIPromptDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UIPromptDialog, isStandalone: true, selector: "ui-prompt-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, defaultValue: { classPropertyName: "defaultValue", publicName: "defaultValue", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, okLabel: { classPropertyName: "okLabel", publicName: "okLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-prompt-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
      <ui-input
        [(value)]="inputValue"
        [placeholder]="placeholder()"
        ariaLabel="Prompt input"
      />
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="outlined"
        [ariaLabel]="cancelLabel()"
        (click)="cancel()"
      >
        {{ cancelLabel() }}
      </ui-button>
      <ui-button variant="filled" [ariaLabel]="okLabel()" (click)="ok()">
        {{ okLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;min-width:24rem}.cd-message{margin:0 0 .75rem;line-height:1.55;white-space:pre-wrap}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIInput, selector: "ui-input", inputs: ["type", "text", "value", "adapter", "placeholder", "disabled", "multiline", "rows", "heightAdjustable", "ariaLabel"], outputs: ["textChange", "valueChange"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIPromptDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-prompt-dialog", standalone: true, imports: [UIButton, UIInput, UIDialogHeader, UIDialogBody, UIDialogFooter], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-prompt-dialog" }, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-message">{{ message() }}</p>
      <ui-input
        [(value)]="inputValue"
        [placeholder]="placeholder()"
        ariaLabel="Prompt input"
      />
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button
        variant="outlined"
        [ariaLabel]="cancelLabel()"
        (click)="cancel()"
      >
        {{ cancelLabel() }}
      </ui-button>
      <ui-button variant="filled" [ariaLabel]="okLabel()" (click)="ok()">
        {{ okLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{display:flex;flex-direction:column;min-width:24rem}.cd-message{margin:0 0 .75rem;line-height:1.55;white-space:pre-wrap}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], defaultValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultValue", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], okLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "okLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }] } });

/**
 * Content component for an open-file dialog.
 *
 * Displayed by {@link CommonDialogService.openFile}. Embeds a
 * {@link UIFileBrowser} and resolves to the selected file(s) or
 * `null` if cancelled.
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UIOpenFileDialog {
    title = input("Open File", ...(ngDevMode ? [{ debugName: "title" }] : []));
    openLabel = input("Open selected file", ...(ngDevMode ? [{ debugName: "openLabel" }] : []));
    datasource = input.required(...(ngDevMode ? [{ debugName: "datasource" }] : []));
    selectedFile = signal(null, ...(ngDevMode ? [{ debugName: "selectedFile" }] : []));
    modalRef = inject((ModalRef));
    onFileActivated(_event) {
        const entry = this.selectedFile();
        if (entry && !entry.isDirectory) {
            this.modalRef.close({ files: [entry] });
        }
    }
    open() {
        const entry = this.selectedFile();
        if (entry && !entry.isDirectory) {
            this.modalRef.close({ files: [entry] });
        }
    }
    cancel() {
        this.modalRef.close(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIOpenFileDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UIOpenFileDialog, isStandalone: true, selector: "ui-open-file-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, openLabel: { classPropertyName: "openLabel", publicName: "openLabel", isSignal: true, isRequired: false, transformFunction: null }, datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "ui-open-file-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-instruction">Select a file to open.</p>
      <div class="cd-browser-frame">
        <ui-file-browser
          [datasource]="datasource()"
          [(selectedEntry)]="selectedFile"
          (fileActivated)="onFileActivated($event)"
          ariaLabel="Browse files"
        />
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="outlined" ariaLabel="Cancel file selection" (click)="cancel()">
        Cancel file selection
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="openLabel()"
        [disabled]="!selectedFile() || selectedFile()!.isDirectory"
        (click)="open()"
      >
        {{ openLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{--cd-surface: var(--ui-surface, #f7f8fa);--cd-surface-raised: var(--ui-surface-2, #eef2f6);--cd-border: var(--ui-border, #d7dce2);--cd-text: var(--ui-text, #1d232b);--cd-muted: var(--ui-text-muted, #5c6875);display:flex;flex-direction:column;min-width:36rem;color:var(--cd-text);background:var(--cd-surface)}:host ::ng-deep ui-dialog-body{display:flex;flex-direction:column;gap:.625rem;height:24rem;overflow:hidden}.cd-instruction{margin:0;color:var(--cd-muted);background:var(--cd-surface);font-size:.8125rem}.cd-browser-frame{flex:1;min-height:0;overflow:hidden;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}:host ::ng-deep ui-dialog-body ui-file-browser{height:100%}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }, { kind: "component", type: UIFileBrowser, selector: "ui-file-browser", inputs: ["datasource", "ariaLabel", "showSidebar", "rootLabel", "viewMode", "showDetails", "showToolbar", "name", "metadataProvider", "allowedTypes", "hideFiltered", "selectedEntry"], outputs: ["viewModeChange", "showDetailsChange", "selectedEntryChange", "fileActivated", "directoryChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIOpenFileDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-open-file-dialog", standalone: true, imports: [
                        UIButton,
                        UIDialogHeader,
                        UIDialogBody,
                        UIDialogFooter,
                        UIFileBrowser,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-open-file-dialog" }, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-instruction">Select a file to open.</p>
      <div class="cd-browser-frame">
        <ui-file-browser
          [datasource]="datasource()"
          [(selectedEntry)]="selectedFile"
          (fileActivated)="onFileActivated($event)"
          ariaLabel="Browse files"
        />
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="outlined" ariaLabel="Cancel file selection" (click)="cancel()">
        Cancel file selection
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="openLabel()"
        [disabled]="!selectedFile() || selectedFile()!.isDirectory"
        (click)="open()"
      >
        {{ openLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{--cd-surface: var(--ui-surface, #f7f8fa);--cd-surface-raised: var(--ui-surface-2, #eef2f6);--cd-border: var(--ui-border, #d7dce2);--cd-text: var(--ui-text, #1d232b);--cd-muted: var(--ui-text-muted, #5c6875);display:flex;flex-direction:column;min-width:36rem;color:var(--cd-text);background:var(--cd-surface)}:host ::ng-deep ui-dialog-body{display:flex;flex-direction:column;gap:.625rem;height:24rem;overflow:hidden}.cd-instruction{margin:0;color:var(--cd-muted);background:var(--cd-surface);font-size:.8125rem}.cd-browser-frame{flex:1;min-height:0;overflow:hidden;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}:host ::ng-deep ui-dialog-body ui-file-browser{height:100%}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], openLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "openLabel", required: false }] }], datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: true }] }] } });

/**
 * Content component for a save-file dialog.
 *
 * Displayed by {@link CommonDialogService.saveFile}. Embeds a
 * {@link UIFileBrowser} for directory navigation plus a file-name
 * input. Resolves to a directory + file name, or `null` if cancelled.
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UISaveFileDialog {
    title = input("Save File", ...(ngDevMode ? [{ debugName: "title" }] : []));
    saveLabel = input("Save file", ...(ngDevMode ? [{ debugName: "saveLabel" }] : []));
    defaultName = input("", ...(ngDevMode ? [{ debugName: "defaultName" }] : []));
    datasource = input.required(...(ngDevMode ? [{ debugName: "datasource" }] : []));
    fileName = signal("", ...(ngDevMode ? [{ debugName: "fileName" }] : []));
    currentDir = signal(null, ...(ngDevMode ? [{ debugName: "currentDir" }] : []));
    modalRef = inject((ModalRef));
    ngOnInit() {
        this.fileName.set(this.defaultName());
    }
    onDirectoryChange(event) {
        this.currentDir.set(event.directory);
    }
    save() {
        const name = this.fileName().trim();
        if (name) {
            this.modalRef.close({ directory: this.currentDir(), name });
        }
    }
    cancel() {
        this.modalRef.close(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISaveFileDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.1.0", type: UISaveFileDialog, isStandalone: true, selector: "ui-save-file-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, saveLabel: { classPropertyName: "saveLabel", publicName: "saveLabel", isSignal: true, isRequired: false, transformFunction: null }, defaultName: { classPropertyName: "defaultName", publicName: "defaultName", isSignal: true, isRequired: false, transformFunction: null }, datasource: { classPropertyName: "datasource", publicName: "datasource", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "ui-save-file-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-instruction">Choose a folder, then enter a name for the file.</p>
      <div class="cd-browser-frame">
        <ui-file-browser
          [datasource]="datasource()"
          (directoryChange)="onDirectoryChange($event)"
          ariaLabel="Browse directories"
        />
      </div>
      <div class="cd-filename-panel">
        <div class="cd-filename-row">
          <span class="cd-filename-label">File name</span>
          <ui-input
            [(value)]="fileName"
            placeholder="Enter file name"
            ariaLabel="File name"
          />
        </div>
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="outlined" ariaLabel="Cancel file save" (click)="cancel()">
        Cancel file save
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="saveLabel()"
        [disabled]="!fileName().trim()"
        (click)="save()"
      >
        {{ saveLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{--cd-surface: var(--ui-surface, #f7f8fa);--cd-surface-raised: var(--ui-surface-2, #eef2f6);--cd-border: var(--ui-border, #d7dce2);--cd-text: var(--ui-text, #1d232b);--cd-muted: var(--ui-text-muted, #5c6875);display:flex;flex-direction:column;min-width:36rem;color:var(--cd-text);background:var(--cd-surface)}:host ::ng-deep ui-dialog-body{display:flex;flex-direction:column;gap:.625rem;height:26rem;overflow:hidden}.cd-instruction{margin:0;color:var(--cd-muted);background:var(--cd-surface);font-size:.8125rem}.cd-browser-frame{flex:1;min-height:0;overflow:hidden;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}:host ::ng-deep ui-dialog-body ui-file-browser{height:100%}.cd-filename-panel{padding:.625rem .75rem;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}.cd-filename-row{display:flex;align-items:center;gap:.75rem}.cd-filename-label{font-weight:600;font-size:.88rem;white-space:nowrap;color:var(--cd-text);background:var(--cd-surface-raised)}.cd-filename-row ui-input{flex:1}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIInput, selector: "ui-input", inputs: ["type", "text", "value", "adapter", "placeholder", "disabled", "multiline", "rows", "heightAdjustable", "ariaLabel"], outputs: ["textChange", "valueChange"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }, { kind: "component", type: UIFileBrowser, selector: "ui-file-browser", inputs: ["datasource", "ariaLabel", "showSidebar", "rootLabel", "viewMode", "showDetails", "showToolbar", "name", "metadataProvider", "allowedTypes", "hideFiltered", "selectedEntry"], outputs: ["viewModeChange", "showDetailsChange", "selectedEntryChange", "fileActivated", "directoryChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UISaveFileDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-save-file-dialog", standalone: true, imports: [
                        UIButton,
                        UIInput,
                        UIDialogHeader,
                        UIDialogBody,
                        UIDialogFooter,
                        UIFileBrowser,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-save-file-dialog" }, template: `
    <ui-dialog-header>{{ title() }}</ui-dialog-header>
    <ui-dialog-body>
      <p class="cd-instruction">Choose a folder, then enter a name for the file.</p>
      <div class="cd-browser-frame">
        <ui-file-browser
          [datasource]="datasource()"
          (directoryChange)="onDirectoryChange($event)"
          ariaLabel="Browse directories"
        />
      </div>
      <div class="cd-filename-panel">
        <div class="cd-filename-row">
          <span class="cd-filename-label">File name</span>
          <ui-input
            [(value)]="fileName"
            placeholder="Enter file name"
            ariaLabel="File name"
          />
        </div>
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="outlined" ariaLabel="Cancel file save" (click)="cancel()">
        Cancel file save
      </ui-button>
      <ui-button
        variant="filled"
        [ariaLabel]="saveLabel()"
        [disabled]="!fileName().trim()"
        (click)="save()"
      >
        {{ saveLabel() }}
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{--cd-surface: var(--ui-surface, #f7f8fa);--cd-surface-raised: var(--ui-surface-2, #eef2f6);--cd-border: var(--ui-border, #d7dce2);--cd-text: var(--ui-text, #1d232b);--cd-muted: var(--ui-text-muted, #5c6875);display:flex;flex-direction:column;min-width:36rem;color:var(--cd-text);background:var(--cd-surface)}:host ::ng-deep ui-dialog-body{display:flex;flex-direction:column;gap:.625rem;height:26rem;overflow:hidden}.cd-instruction{margin:0;color:var(--cd-muted);background:var(--cd-surface);font-size:.8125rem}.cd-browser-frame{flex:1;min-height:0;overflow:hidden;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}:host ::ng-deep ui-dialog-body ui-file-browser{height:100%}.cd-filename-panel{padding:.625rem .75rem;border:1px solid var(--cd-border);border-radius:var(--ui-radius, .375rem);color:var(--cd-text);background:var(--cd-surface-raised)}.cd-filename-row{display:flex;align-items:center;gap:.75rem}.cd-filename-label{font-weight:600;font-size:.88rem;white-space:nowrap;color:var(--cd-text);background:var(--cd-surface-raised)}.cd-filename-row ui-input{flex:1}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], saveLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "saveLabel", required: false }] }], defaultName: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultName", required: false }] }], datasource: [{ type: i0.Input, args: [{ isSignal: true, alias: "datasource", required: true }] }] } });

/**
 * Content component for an "About" dialog.
 *
 * Displayed by {@link CommonDialogService.about}. Shows the
 * application name, version, description, optional logo, copyright
 * notice, and credits.
 *
 * @internal — not intended for direct use; use the service instead.
 */
class UIAboutDialog {
    appName = input("Application", ...(ngDevMode ? [{ debugName: "appName" }] : []));
    version = input("", ...(ngDevMode ? [{ debugName: "version" }] : []));
    description = input("", ...(ngDevMode ? [{ debugName: "description" }] : []));
    logoUrl = input("", ...(ngDevMode ? [{ debugName: "logoUrl" }] : []));
    copyright = input("", ...(ngDevMode ? [{ debugName: "copyright" }] : []));
    credits = input([], ...(ngDevMode ? [{ debugName: "credits" }] : []));
    modalRef = inject((ModalRef));
    dismiss() {
        this.modalRef.close(undefined);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIAboutDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: UIAboutDialog, isStandalone: true, selector: "ui-about-dialog", inputs: { appName: { classPropertyName: "appName", publicName: "appName", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, logoUrl: { classPropertyName: "logoUrl", publicName: "logoUrl", isSignal: true, isRequired: false, transformFunction: null }, copyright: { classPropertyName: "copyright", publicName: "copyright", isSignal: true, isRequired: false, transformFunction: null }, credits: { classPropertyName: "credits", publicName: "credits", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ui-about-dialog" }, hostDirectives: [{ directive: i1.UISurface, inputs: ["surfaceType", "surfaceType"] }], ngImport: i0, template: `
    <ui-dialog-header>About {{ appName() }}</ui-dialog-header>
    <ui-dialog-body>
      <div class="cd-about-content">
        @if (logoUrl()) {
          <img
            class="cd-about-logo"
            [src]="logoUrl()"
            [alt]="appName() + ' logo'"
          />
        }
        <h2 class="cd-about-name">{{ appName() }}</h2>
        @if (version()) {
          <span class="cd-about-version">Version {{ version() }}</span>
        }
        @if (description()) {
          <p class="cd-about-desc">{{ description() }}</p>
        }
        @if (credits().length > 0) {
          <div class="cd-about-credits">
            <h4 class="cd-about-credits-title">Credits</h4>
            <ul class="cd-about-credits-list">
              @for (credit of credits(); track credit) {
                <li>{{ credit }}</li>
              }
            </ul>
          </div>
        }
        @if (copyright()) {
          <p class="cd-about-copyright">{{ copyright() }}</p>
        }
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="filled" ariaLabel="Close" (click)="dismiss()">
        Close
      </ui-button>
    </ui-dialog-footer>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;min-width:22rem;max-width:28rem}.cd-about-content{display:flex;flex-direction:column;align-items:center;text-align:center;gap:.25rem}.cd-about-logo{width:64px;height:64px;object-fit:contain;margin-bottom:.5rem}.cd-about-name{margin:0;font-size:1.25rem;font-weight:700}.cd-about-version{font-size:.82rem;color:var(--ui-text-muted, #5a6470)}.cd-about-desc{margin:.5rem 0 0;line-height:1.55;font-size:.92rem}.cd-about-credits{margin-top:.75rem;width:100%;text-align:left}.cd-about-credits-title{margin:0 0 .35rem;font-size:.85rem;font-weight:600}.cd-about-credits-list{margin:0;padding-left:1.25rem;font-size:.85rem;line-height:1.6;color:var(--ui-text-muted, #5a6470)}.cd-about-copyright{margin:.75rem 0 0;font-size:.78rem;color:var(--ui-text-muted, #5a6470)}\n"], dependencies: [{ kind: "component", type: UIButton, selector: "ui-button", inputs: ["type", "variant", "color", "muted", "size", "pill", "disabled", "ariaLabel"] }, { kind: "component", type: UIDialogHeader, selector: "ui-dialog-header" }, { kind: "component", type: UIDialogBody, selector: "ui-dialog-body" }, { kind: "component", type: UIDialogFooter, selector: "ui-dialog-footer" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: UIAboutDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-about-dialog", standalone: true, imports: [UIButton, UIDialogHeader, UIDialogBody, UIDialogFooter], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [{ directive: UISurface, inputs: ['surfaceType'] }], host: { class: "ui-about-dialog" }, template: `
    <ui-dialog-header>About {{ appName() }}</ui-dialog-header>
    <ui-dialog-body>
      <div class="cd-about-content">
        @if (logoUrl()) {
          <img
            class="cd-about-logo"
            [src]="logoUrl()"
            [alt]="appName() + ' logo'"
          />
        }
        <h2 class="cd-about-name">{{ appName() }}</h2>
        @if (version()) {
          <span class="cd-about-version">Version {{ version() }}</span>
        }
        @if (description()) {
          <p class="cd-about-desc">{{ description() }}</p>
        }
        @if (credits().length > 0) {
          <div class="cd-about-credits">
            <h4 class="cd-about-credits-title">Credits</h4>
            <ul class="cd-about-credits-list">
              @for (credit of credits(); track credit) {
                <li>{{ credit }}</li>
              }
            </ul>
          </div>
        }
        @if (copyright()) {
          <p class="cd-about-copyright">{{ copyright() }}</p>
        }
      </div>
    </ui-dialog-body>
    <ui-dialog-footer>
      <ui-button variant="filled" ariaLabel="Close" (click)="dismiss()">
        Close
      </ui-button>
    </ui-dialog-footer>
  `, styles: [":host{display:flex;flex-direction:column;min-width:22rem;max-width:28rem}.cd-about-content{display:flex;flex-direction:column;align-items:center;text-align:center;gap:.25rem}.cd-about-logo{width:64px;height:64px;object-fit:contain;margin-bottom:.5rem}.cd-about-name{margin:0;font-size:1.25rem;font-weight:700}.cd-about-version{font-size:.82rem;color:var(--ui-text-muted, #5a6470)}.cd-about-desc{margin:.5rem 0 0;line-height:1.55;font-size:.92rem}.cd-about-credits{margin-top:.75rem;width:100%;text-align:left}.cd-about-credits-title{margin:0 0 .35rem;font-size:.85rem;font-weight:600}.cd-about-credits-list{margin:0;padding-left:1.25rem;font-size:.85rem;line-height:1.6;color:var(--ui-text-muted, #5a6470)}.cd-about-copyright{margin:.75rem 0 0;font-size:.78rem;color:var(--ui-text-muted, #5a6470)}\n"] }]
        }], propDecorators: { appName: [{ type: i0.Input, args: [{ isSignal: true, alias: "appName", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], logoUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "logoUrl", required: false }] }], copyright: [{ type: i0.Input, args: [{ isSignal: true, alias: "copyright", required: false }] }], credits: [{ type: i0.Input, args: [{ isSignal: true, alias: "credits", required: false }] }] } });

/**
 * Service for showing common application dialogs — alert, confirm,
 * prompt, open-file, save-file, and about.
 *
 * Each method opens a modal dialog and returns a `Promise` that
 * resolves when the user closes it. The service delegates to
 * {@link ModalService} for the underlying dialog lifecycle.
 *
 * @example
 * ```ts
 * const confirmed = await this.dialogs.confirm({
 *   title: 'Delete item?',
 *   message: 'This action cannot be undone.',
 *   variant: 'danger',
 * });
 *
 * if (confirmed) { ... }
 * ```
 */
class CommonDialogService {
    modal = inject(ModalService);
    /**
     * Show a simple informational alert with a dismiss button.
     *
     * @returns Resolves when the user dismisses the dialog.
     */
    async alert(options) {
        const ref = this.modal.openModal({
            component: UIAlertDialog,
            inputs: {
                title: options.title,
                message: options.message,
                buttonLabel: options.buttonLabel ?? "Acknowledge message",
            },
            ariaLabel: options.ariaLabel ?? options.title,
        });
        await firstValueFrom(ref.closed);
    }
    /**
     * Show a confirmation dialog with confirm and cancel buttons.
     *
     * @returns `true` if the user confirmed, `false` otherwise.
     */
    async confirm(options) {
        const ref = this.modal.openModal({
            component: UIConfirmDialog,
            inputs: {
                title: options.title,
                message: options.message,
                confirmLabel: options.confirmLabel ?? "Confirm action",
                cancelLabel: options.cancelLabel ?? "Keep current state",
                variant: options.variant ?? "primary",
            },
            ariaLabel: options.ariaLabel ?? options.title,
        });
        const result = await firstValueFrom(ref.closed);
        return result ?? false;
    }
    /**
     * Show a prompt dialog with a text input.
     *
     * @returns The entered string, or `null` if cancelled.
     */
    async prompt(options) {
        const ref = this.modal.openModal({
            component: UIPromptDialog,
            inputs: {
                title: options.title,
                message: options.message,
                defaultValue: options.defaultValue ?? "",
                placeholder: options.placeholder ?? "",
                okLabel: options.okLabel ?? "Apply value",
                cancelLabel: options.cancelLabel ?? "Keep current value",
            },
            ariaLabel: options.ariaLabel ?? options.title,
        });
        const result = await firstValueFrom(ref.closed);
        return result ?? null;
    }
    /**
     * Show an open-file dialog powered by {@link UIFileBrowser}.
     *
     * @returns The selected file(s), or `null` if cancelled.
     */
    async openFile(options) {
        const ref = this.modal.openModal({
            component: UIOpenFileDialog,
            inputs: {
                title: options.title ?? "Open File",
                openLabel: options.openLabel ?? "Open selected file",
                datasource: options.datasource,
            },
            ariaLabel: options.ariaLabel ?? options.title ?? "Open File",
        });
        const result = await firstValueFrom(ref.closed);
        return result ?? null;
    }
    /**
     * Show a save-file dialog powered by {@link UIFileBrowser} with a
     * file-name input.
     *
     * @returns The directory and file name, or `null` if cancelled.
     */
    async saveFile(options) {
        const ref = this.modal.openModal({
            component: UISaveFileDialog,
            inputs: {
                title: options.title ?? "Save File",
                saveLabel: options.saveLabel ?? "Save file",
                defaultName: options.defaultName ?? "",
                datasource: options.datasource,
            },
            ariaLabel: options.ariaLabel ?? options.title ?? "Save File",
        });
        const result = await firstValueFrom(ref.closed);
        return result ?? null;
    }
    /**
     * Show an "About" dialog with application information.
     *
     * @returns Resolves when the user closes the dialog.
     */
    async about(options) {
        const ref = this.modal.openModal({
            component: UIAboutDialog,
            inputs: {
                appName: options.appName,
                version: options.version ?? "",
                description: options.description ?? "",
                logoUrl: options.logoUrl ?? "",
                copyright: options.copyright ?? "",
                credits: options.credits ?? [],
            },
            ariaLabel: options.ariaLabel ?? `About ${options.appName}`,
        });
        await firstValueFrom(ref.closed);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CommonDialogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CommonDialogService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CommonDialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/*
 * Public API Surface of @theredhead/lucid-blocks
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CommonDialogService, DEFAULT_TOOLBAR_ACTIONS, FILE_ICON_REGISTRY, HtmlEditingStrategy, MARKDOWN_PARSER, MarkdownEditingStrategy, SavedSearchService, UIAboutDialog, UIAlertDialog, UIChatView, UICommandPalette, UIConfirmDialog, UIDashboard, UIDashboardPanel, UIFileBrowser, UIFileBrowserKeys, UIKanbanBoard, UIMasterDetailView, UIMessageBubble, UINavigationPage, UIOpenFileDialog, UIPromptDialog, UIPropertySheet, UIRichTextEditor, UISaveFileDialog, UISearchView, UISourceTabs, UIWizard, UIWizardStep, createMarkdownItParser, createMarkedParser, getRichTextTemplateBlockUiProvider, getRichTextTemplateBlockUiProviders, navGroup, navItem, parseAllowedTypes, registerRichTextTemplateBlockUiProvider, routesToNavigation, unregisterRichTextTemplateBlockUiProvider };
//# sourceMappingURL=theredhead-lucid-blocks.mjs.map
